// ============================================================
//  Atlas sync API — serverless function for Vercel
//  Stores the whole workspace as one JSON blob in Upstash Redis
//  (works with Vercel KV / Upstash / any Upstash-compatible REST API).
//
//  GET  /api/workspace            → returns the saved workspace JSON ({} if none)
//  PUT  /api/workspace  (body)    → saves the workspace JSON
//  Optional: ?room=NAME to keep separate workspaces on one deployment.
//
//  Env vars required (set in Vercel → Settings → Environment Variables):
//    KV_REST_API_URL    → e.g. https://your-db.upstash.io
//    KV_REST_API_TOKEN  → the REST token for that database
//  (Vercel KV / Upstash integration sets these for you automatically.)
// ============================================================

const KEY_PREFIX = "atlas:workspace:";

function cors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, PUT, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}

async function redis(path, opts) {
  const base = process.env.KV_REST_API_URL;
  const token = process.env.KV_REST_API_TOKEN;
  if (!base || !token) throw new Error("Storage not configured (missing KV_REST_API_URL / KV_REST_API_TOKEN).");
  const r = await fetch(base + path, {
    ...opts,
    headers: { Authorization: "Bearer " + token, ...(opts && opts.headers) },
  });
  if (!r.ok) throw new Error("Storage error " + r.status);
  return r.json();
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") { res.status(200).end(); return; }

  const room = (req.query && req.query.room ? String(req.query.room) : "default").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64) || "default";
  const key = KEY_PREFIX + room;

  try {
    if (req.method === "GET") {
      // Upstash REST: GET /get/<key> → { result: "<stringified value or null>" }
      const data = await redis("/get/" + encodeURIComponent(key));
      const val = data && data.result ? JSON.parse(data.result) : {};
      res.status(200).json(val);
      return;
    }

    if (req.method === "PUT") {
      let body = req.body;
      if (typeof body === "string") { try { body = JSON.parse(body); } catch (e) { body = {}; } }
      if (!body || typeof body !== "object") body = {};
      const payload = JSON.stringify(body);
      // Upstash REST: POST /set/<key>  with the value as the raw request body
      await redis("/set/" + encodeURIComponent(key), {
        method: "POST",
        body: payload,
      });
      res.status(200).json({ ok: true, savedAt: Date.now() });
      return;
    }

    res.status(405).json({ error: "Method not allowed" });
  } catch (e) {
    res.status(500).json({ error: String(e.message || e) });
  }
}
