/* ============================================================
   SYNC — npoint.io live sync + backup/transfer
   Data-only sync (no files); catalogue uses shared-drive links.
   Exposes window.SyncPanel, window.SyncBadge, window.SyncToast, window.initSync
   ============================================================ */
const { useState: useSy, useEffect: useSyE, useRef: useSyR } = React;

const SYNC_KEY = "atlas.sync.config";
const blob2dataURL = (blob) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob); });
async function dataURL2blob(u) { const r = await fetch(u); return await r.blob(); }

function loadSyncCfg() { try { return JSON.parse(localStorage.getItem(SYNC_KEY)) || {}; } catch (e) { return {}; } }
function saveSyncCfg(c) { localStorage.setItem(SYNC_KEY, JSON.stringify(c)); }

/* ---------- workspace build / restore ---------- */
async function buildWorkspace(includeFiles) {
  const root = Store.getRoot();
  const pkg = { atlas: true, version: 2, exportedAt: new Date().toISOString(), root: { version: 2, projects: root.projects, rev: root.rev || 0, savedAt: root.savedAt || Date.now() }, files: {} };
  if (includeFiles) {
    const all = await Store.files.all();
    for (const [id, blob] of Object.entries(all)) {
      try { pkg.files[id] = await blob2dataURL(blob); } catch (e) {}
    }
  }
  return pkg;
}

// Single-project export. Only files referenced by this project's products are included.
async function buildProjectExport(projectId, includeFiles) {
  const root = Store.getRoot();
  const proj = root.projects.find((p) => p.id === projectId);
  if (!proj) throw new Error("Project not found");
  const pkg = { atlas: true, version: 2, singleProject: true, exportedAt: new Date().toISOString(), root: { version: 2, projects: [proj], rev: 0, savedAt: Date.now() }, files: {} };
  if (includeFiles) {
    const all = await Store.files.all();
    const referenced = new Set();
    (proj.products || []).forEach((p) => { if (p.fileId) referenced.add(p.fileId); });
    referenced.add("atlas.hero." + projectId); // cover image
    for (const id of referenced) {
      const blob = all[id];
      if (blob) { try { pkg.files[id] = await blob2dataURL(blob); } catch (e) {} }
    }
  }
  return pkg;
}

async function restoreWorkspace(pkg, opts) {
  const rootData = pkg.root || pkg;
  if (pkg.singleProject && rootData.projects && rootData.projects.length === 1) {
    // merge single project: add or replace by id, keep other projects intact
    const incoming = rootData.projects[0];
    const root = Store.getRoot();
    const existing = root.projects.findIndex((p) => p.id === incoming.id);
    const newProjects = [...root.projects];
    if (existing >= 0) newProjects[existing] = incoming;
    else newProjects.push(incoming);
    Store.importRoot({ version: 2, projects: newProjects, rev: (root.rev || 0) + 1, savedAt: Date.now() }, opts);
  } else {
    Store.importRoot(rootData, opts);
  }
  if (pkg.files) {
    for (const [id, durl] of Object.entries(pkg.files)) {
      try { Store.files.put(id, await dataURL2blob(durl)); } catch (e) {}
    }
  }
}

/* ---------- remote helpers ---------- */
async function remotePull(cfg) {
  const res = await fetch(cfg.url, { headers: { "Accept": "application/json" } });
  if (!res.ok) throw new Error("GET " + res.status);
  const txt = await res.text();
  if (!txt || !txt.trim()) return null;
  const data = JSON.parse(txt);
  return data.root ? data : { root: data };
}
async function remotePush(cfg, pkg) {
  const res = await fetch(cfg.url, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(pkg) });
  if (!res.ok) throw new Error("PUT " + res.status);
}

/* ---------- npoint.io one-click create ---------- */
async function createNpointBin() {
  const res = await fetch("https://api.npoint.io/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: {} }),
  });
  if (!res.ok) throw new Error("Could not create bin (HTTP " + res.status + ")");
  const json = await res.json();
  // npoint returns something like https://api.npoint.io/abc123
  return "https://api.npoint.io/" + (json.id || json);
}

/* ---------- live sync engine ---------- */
let syncTimer = null, pushDebounce = null, lastPushedRev = -1, lastRemoteSavedAt = 0, unsub = null;
const syncState = { status: "off", msg: "", at: 0, conflict: false, listeners: new Set() };
const toastState = { visible: false, msg: "", listeners: new Set() };

function setSync(status, msg) { syncState.status = status; syncState.msg = msg || ""; syncState.at = Date.now(); syncState.listeners.forEach((l) => l()); }
function showToast(msg) { toastState.visible = true; toastState.msg = msg; toastState.listeners.forEach((l) => l()); setTimeout(() => { toastState.visible = false; toastState.listeners.forEach((l) => l()); }, 4000); }

async function doPull(cfg, { apply } = { apply: true }) {
  const remote = await remotePull(cfg);
  if (!remote || !remote.root) return { changed: false };
  const localAt = Store.getRoot().savedAt || 0;
  const rAt = remote.root.savedAt || 0;
  const rRev = remote.root.rev || 0;
  const localRev = Store.getRoot().rev || 0;

  if (rAt > localAt && rRev !== localRev) {
    // Do we have local edits that haven't been pushed yet?
    const hasLocalPending = localAt > lastRemoteSavedAt && lastPushedRev !== -1 && localRev !== lastPushedRev;
    if (hasLocalPending) {
      // Don't overwrite unsaved local work (which could eject us from a just-created
      // project). Flag the conflict and let our pending push reconcile instead.
      syncState.conflict = true;
      setSync("ok", "Local changes pending — will push");
      lastRemoteSavedAt = rAt;
      return { changed: false };
    }
    if (apply) {
      await restoreWorkspace(remote, { keepActive: true });
      lastPushedRev = Store.getRoot().rev || 0;
      lastRemoteSavedAt = rAt;
      showToast("Workspace updated from the shared endpoint.");
      return { changed: true };
    }
  }
  lastRemoteSavedAt = rAt;
  return { changed: false };
}
async function doPush(cfg) {
  const pkg = await buildWorkspace(false); // never include files in live sync
  await remotePush(cfg, pkg);
  lastPushedRev = Store.getRoot().rev || 0;
  lastRemoteSavedAt = pkg.root.savedAt;
  syncState.conflict = false;
}

function startSync(cfg) {
  stopSync();
  if (!cfg || !cfg.url || !cfg.auto) return;
  setSync("syncing", "Connecting…");
  doPull(cfg).then((r) => { setSync("ok", r.changed ? "Pulled latest" : "Up to date"); })
    .catch((e) => setSync("error", String(e.message || e)));
  syncTimer = setInterval(() => {
    doPull(cfg).then((r) => { if (r.changed) setSync("ok", "Pulled update"); else if (syncState.status !== "error") setSync("ok", "Up to date"); })
      .catch((e) => setSync("error", String(e.message || e)));
  }, Math.max(5, cfg.interval || 10) * 1000);
  unsub = subscribeStore(() => {
    const rev = Store.getRoot().rev || 0;
    if (rev === lastPushedRev) return;
    clearTimeout(pushDebounce);
    pushDebounce = setTimeout(() => {
      setSync("syncing", "Saving…");
      doPush(cfg).then(() => { setSync("ok", "Saved"); showToast("Changes pushed to team."); }).catch((e) => setSync("error", String(e.message || e)));
    }, 1200);
  });
}
function stopSync() {
  clearInterval(syncTimer); syncTimer = null;
  clearTimeout(pushDebounce);
  if (unsub) { unsub(); unsub = null; }
  if (syncState.status !== "off") setSync("off", "");
}

function subscribeStore(fn) {
  let lastRev = Store.getRoot().rev || 0;
  const id = setInterval(() => { const r = Store.getRoot().rev || 0; if (r !== lastRev) { lastRev = r; fn(); } }, 800);
  return () => clearInterval(id);
}

function initSync() {
  const cfg = loadSyncCfg();
  if (cfg.url && cfg.auto) startSync(cfg);
}

/* ---------- Toast ---------- */
function SyncToast() {
  const [, force] = useSy(0);
  useSyE(() => { const l = () => force((x) => x + 1); toastState.listeners.add(l); return () => toastState.listeners.delete(l); }, []);
  if (!toastState.visible) return null;
  return (
    <div className="sync-toast">
      <Icon name="reset" size={14} />
      <span>{toastState.msg}</span>
    </div>
  );
}

/* ---------- Badge ---------- */
function SyncBadge({ onClick }) {
  const [, force] = useSy(0);
  useSyE(() => { const l = () => force((x) => x + 1); syncState.listeners.add(l); return () => syncState.listeners.delete(l); }, []);
  const cfg = loadSyncCfg();
  const live = cfg.url && cfg.auto;
  const map = { off: ["var(--ink-ghost)", "Local only"], ok: ["var(--hue-done)", "Synced"], syncing: ["var(--t-amber)", "Syncing…"], error: ["var(--t-red)", "Sync error"] };
  const [c, label] = live ? map[syncState.status] || map.ok : map.off;
  return (
    <button className="sync-badge" onClick={onClick} title={syncState.msg || label}>
      <span className="sync-dot" style={{ background: c }} />
      <span className="grow" style={{ textAlign: "left" }}>{live ? label : "Backup & sync"}</span>
      <Icon name="reset" size={13} />
    </button>
  );
}

/* ---------- Panel ---------- */
function SyncPanel({ onClose }) {
  const [tab, setTab] = useSy("live");
  const [cfg, setCfg] = useSy(loadSyncCfg());
  const [busy, setBusy] = useSy("");
  const [note, setNote] = useSy(null);
  const [, force] = useSy(0);
  const fileRef = useSyR(null);
  useSyE(() => { const l = () => force((x) => x + 1); syncState.listeners.add(l); return () => syncState.listeners.delete(l); }, []);
  const upd = (c) => { const n = { ...cfg, ...c }; setCfg(n); saveSyncCfg(n); };

  const doExport = async (withFiles) => {
    setBusy("export");
    try {
      const active = Store.getState();
      const pkg = active ? await buildProjectExport(Store.getRoot().activeId, withFiles) : await buildWorkspace(withFiles);
      const filename = active
        ? "atlas-" + (active.meta?.project || "project").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + new Date().toISOString().slice(0, 10) + ".json"
        : "atlas-workspace-" + new Date().toISOString().slice(0, 10) + ".json";
      const blob = new Blob([JSON.stringify(pkg)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNote({ ok: true, msg: active ? `Exported “${active.meta?.project}”.` : "Workspace downloaded." });
    } catch (e) { setNote({ ok: false, msg: "Export failed: " + e.message }); }
    setBusy("");
  };
  const doExportWorkspace = async (withFiles) => {
    setBusy("export-all");
    try {
      const pkg = await buildWorkspace(withFiles);
      const blob = new Blob([JSON.stringify(pkg)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = "atlas-workspace-" + new Date().toISOString().slice(0, 10) + ".json";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNote({ ok: true, msg: "Whole workspace downloaded." });
    } catch (e) { setNote({ ok: false, msg: "Export failed: " + e.message }); }
    setBusy("");
  };
  const doImport = async (file) => {
    setBusy("import");
    try {
      const txt = await file.text(); const pkg = JSON.parse(txt);
      await restoreWorkspace(pkg);
      setNote({ ok: true, msg: "Workspace imported. Everything replaced." });
    } catch (e) { setNote({ ok: false, msg: "Import failed: " + (e.message || "unreadable file") }); }
    setBusy("");
  };

  const doCreateBin = async () => {
    setBusy("create");
    try {
      const url = await createNpointBin();
      upd({ url });
      // immediately push current state so bin isn't empty
      Store.touch();
      await doPush({ ...cfg, url });
      setNote({ ok: true, msg: "Workspace created at npoint.io. Share this URL with your team — anyone with it can sync." });
    } catch (e) { setNote({ ok: false, msg: "Could not create bin: " + e.message }); }
    setBusy("");
  };

  const testConn = async () => {
    setBusy("test");
    try { await remotePull(cfg); setNote({ ok: true, msg: "Connected — endpoint is reachable." }); }
    catch (e) { setNote({ ok: false, msg: "Could not reach endpoint: " + e.message }); }
    setBusy("");
  };
  const toggleLive = (on) => { upd({ auto: on }); if (on) { Store.touch(); startSync({ ...cfg, auto: true }); } else stopSync(); };
  const pushNow = async () => { setBusy("push"); try { Store.touch(); await doPush(cfg); setNote({ ok: true, msg: "Pushed." }); } catch (e) { setNote({ ok: false, msg: "Push failed: " + e.message }); } setBusy(""); };
  const pullNow = async () => { setBusy("pull"); try { const r = await doPull(cfg); setNote({ ok: true, msg: r.changed ? "Pulled latest." : "Already up to date." }); } catch (e) { setNote({ ok: false, msg: "Pull failed: " + e.message }); } setBusy(""); };

  const copyUrl = () => { navigator.clipboard.writeText(cfg.url || ""); setNote({ ok: true, msg: "URL copied to clipboard. Share it with your team." }); };

  // one-click: use the Vercel KV backend served from this same deployment
  const useThisServer = async () => {
    setBusy("server");
    try {
      const url = new URL("/api/workspace", location.origin).href;
      // verify the endpoint is reachable before committing
      const r = await fetch(url, { headers: { Accept: "application/json" } });
      if (!r.ok) throw new Error("Server responded " + r.status + " — is the API deployed and the database connected?");
      upd({ url });
      Store.touch();
      await doPush({ ...cfg, url });
      setNote({ ok: true, msg: "Connected to this site's built-in server. Share this site's URL with your team — they click the same button." });
    } catch (e) {
      setNote({ ok: false, msg: "Couldn't reach the built-in server: " + e.message });
    }
    setBusy("");
  };

  // auto-fix common npoint URL mistakes
  const fixUrl = (raw) => {
    let u = (raw || "").trim();
    u = u.replace(/^https?:\/\/(?:www\.)?npoint\.io\/docs\//, "https://api.npoint.io/");
    u = u.replace(/^https?:\/\/npoint\.io\/(?!api)/, "https://api.npoint.io/");
    return u;
  };
  const onUrlChange = (raw) => { const fixed = fixUrl(raw); if (fixed !== raw) setNote({ ok: true, msg: "Auto-corrected to the API URL." }); return fixed; };

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="reset" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Backup & sync</div>
          <div className="muted" style={{ fontSize: 13 }}>Keep your team in sync via npoint.io, or export/import workspace files.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="sync-tabs">
        <button className={tab === "live" ? "on" : ""} onClick={() => { setTab("live"); setNote(null); }}><Icon name="link" size={15} /> Team sync</button>
        <button className={tab === "backup" ? "on" : ""} onClick={() => { setTab("backup"); setNote(null); }}><Icon name="box" size={15} /> Backup & transfer</button>
      </div>
      <div className="modal-bd">
        {tab === "live" && (
          <div className="col" style={{ gap: 16 }}>
            {!cfg.url && (
              <div className="sync-block" style={{ borderColor: "var(--accent-line)", background: "var(--accent-soft)" }}>
                <div className="sync-block-hd"><Icon name="link" size={16} /><b>Use this site's built-in server</b></div>
                <p className="sync-p">If this Atlas is hosted on Vercel with the sync database connected, one click sets up real two-way sync for your whole team — no third-party service.</p>
                <button className="btn btn-primary" disabled={busy === "server"} onClick={useThisServer}>
                  {busy === "server" ? <Icon name="reset" size={15} className="spin" /> : <Icon name="link" size={15} />} Use this site's server
                </button>
                <p className="sync-p" style={{ fontSize: 12, color: "var(--ink-faint)", margin: "12px 0 0" }}>Teammates open the same site URL and click this same button. Project data syncs live; files go on a shared drive, linked in the Product catalogue.</p>
                <div className="sync-or" style={{ margin: "14px 0 4px" }}>or use a manual JSON endpoint</div>
                <ol className="sync-steps-list">
                  <li><b>Open <a href="https://www.npoint.io" target="_blank" rel="noopener noreferrer">npoint.io</a></b> in a new tab</li>
                  <li>Paste <code>{"{}"}</code> into the editor and click <b>Save</b> — you'll get a URL like <code>api.npoint.io/abc123…</code></li>
                  <li>Copy that URL and paste it below</li>
                </ol>
                <p className="sync-p" style={{ fontSize: 12, color: "var(--ink-faint)", margin: "10px 0 0" }}>Project data syncs live. Files (PDFs, images) should be stored on a <b>shared drive</b> (SharePoint, OneDrive, Google Drive) and linked in the Product catalogue.</p>
              </div>
            )}
            {!cfg.url && (
              <div>
                <div className="field-label">Paste your npoint.io URL here</div>
                <input className="input mono" style={{ fontSize: 13 }} value={cfg.url || ""} placeholder="https://api.npoint.io/abc123…" onChange={(e) => upd({ url: onUrlChange(e.target.value) })} />
              </div>
            )}
            {cfg.url && (
              <>
                <div className="sync-block">
                  <div className="between" style={{ marginBottom: 6 }}>
                    <div className="sync-block-hd" style={{ margin: 0 }}><Icon name="link" size={16} /><b>Shared workspace URL</b></div>
                    <button className="btn btn-sm btn-ghost btn-danger" onClick={() => { stopSync(); upd({ url: "", auto: false }); setNote({ ok: true, msg: "Disconnected. You can paste a new URL." }); }}><Icon name="x" size={13} /> Disconnect</button>
                  </div>
                  <div className="sync-url-row">
                    <input className="input mono" style={{ fontSize: 12, flex: 1 }} value={cfg.url} placeholder="https://api.npoint.io/abc123…" onChange={(e) => { stopSync(); upd({ url: onUrlChange(e.target.value), auto: false }); }} />
                    <button className="btn btn-sm" onClick={copyUrl}><Icon name="link" size={13} /> Copy</button>
                  </div>
                  <p className="sync-p" style={{ margin: "8px 0 0" }}>Share this URL with your team. Edit it to switch endpoints, or Disconnect to start fresh.</p>
                </div>
                <div className="row" style={{ gap: 14, flexWrap: "wrap" }}>
                  <div className="row" style={{ gap: 6 }}>
                    <span className="muted" style={{ fontSize: 12.5 }}>Poll every</span>
                    <input className="datemini" style={{ width: 56 }} type="number" min="3" max="120" value={cfg.interval || 10} onChange={(e) => upd({ interval: Number(e.target.value) })} /><span className="muted" style={{ fontSize: 12.5 }}>s</span>
                  </div>
                </div>
                <div className="row" style={{ gap: 9, flexWrap: "wrap" }}>
                  <button className="btn btn-sm" disabled={!cfg.url || busy} onClick={testConn}>{busy === "test" ? <Icon name="reset" size={14} className="spin" /> : <Icon name="check" size={14} />} Test</button>
                  <button className="btn btn-sm" disabled={!cfg.url || busy} onClick={pushNow}>Push now</button>
                  <button className="btn btn-sm" disabled={!cfg.url || busy} onClick={pullNow}>Pull now</button>
                </div>
                <label className={"sync-live-toggle" + (cfg.auto ? " on" : "")}>
                  <input type="checkbox" checked={!!cfg.auto} disabled={!cfg.url} onChange={(e) => toggleLive(e.target.checked)} />
                  <span className="sync-live-text">
                    <b>Keep this computer in sync</b>
                    <span className="muted">{cfg.auto ? (syncState.msg || "Live") : "Off — changes stay local"}</span>
                  </span>
                  <span className="sync-dot" style={{ background: cfg.auto ? (syncState.status === "error" ? "var(--t-red)" : "var(--hue-done)") : "var(--ink-ghost)" }} />
                </label>
              </>
            )}
          </div>
        )}
        {tab === "backup" && (
          <div className="col" style={{ gap: 18 }}>
            <div className="sync-block">
              <div className="sync-block-hd"><Icon name="upload" size={16} style={{ transform: "rotate(180deg)" }} /><b>{Store.getState() ? `Export “${Store.getState().meta?.project}”` : "Export this workspace"}</b></div>
              <p className="sync-p">{Store.getState() ? "Download this project as a single file. Re-import it anywhere to restore it as it is now." : "Download every project as a single file. Carry it to another computer and import it there."}</p>
              <div className="row" style={{ gap: 9, flexWrap: "wrap" }}>
                <button className="btn btn-primary" disabled={busy === "export"} onClick={() => doExport(true)}>
                  {busy === "export" ? <Icon name="reset" size={15} className="spin" /> : <Icon name="upload" size={15} style={{ transform: "rotate(180deg)" }} />} Export with local files
                </button>
                <button className="btn" disabled={busy === "export"} onClick={() => doExport(false)}>Export data only</button>
              </div>
              {Store.getState() && (
                <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
                  <p className="sync-p" style={{ marginBottom: 8, fontSize: 12 }}>Need everything?</p>
                  <button className="btn btn-sm" disabled={busy === "export-all"} onClick={() => doExportWorkspace(true)}>
                    {busy === "export-all" ? <Icon name="reset" size={14} className="spin" /> : <Icon name="layers" size={14} />} Export whole workspace
                  </button>
                </div>
              )}
            </div>
            <div className="sync-block">
              <div className="sync-block-hd"><Icon name="upload" size={16} /><b>Import a workspace</b></div>
              <p className="sync-p">Load a workspace file. <b>This replaces everything</b> on this computer.</p>
              <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => { if (e.target.files[0]) doImport(e.target.files[0]); e.target.value = ""; }} />
              <button className="btn" disabled={busy === "import"} onClick={() => fileRef.current.click()}>
                {busy === "import" ? <Icon name="reset" size={15} className="spin" /> : <Icon name="upload" size={15} />} Choose file…
              </button>
            </div>
          </div>
        )}
        {note && <div className={"sync-note " + (note.ok ? "ok" : "bad")}><Icon name={note.ok ? "check" : "warn"} size={14} /> {note.msg}</div>}
      </div>
      <div className="modal-ft">
        <span className="muted" style={{ fontSize: 12 }}>Data syncs live. Files should live on your shared drive.</span>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { SyncPanel, SyncBadge, SyncToast, initSync, restoreWorkspace, buildWorkspace, buildProjectExport });
