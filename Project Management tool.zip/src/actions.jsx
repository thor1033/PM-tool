/* ============================================================
   ACTION LIST + DRAG/DROP TIMELINE
   Grouped by CATEGORY · milestones & gates
   Exposes window.Actions
   ============================================================ */
const { useState: useA, useRef: useAR, useMemo: useAM } = React;

const DAY = 86400000;
const fmtD = (s) => { if (!s) return "—"; const d = new Date(s); return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" }); };
const toISO = (d) => d.toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / DAY);

function Actions() {
  const { categories, members } = Store.useStore();
  const [mode, setMode] = useA(localStorage.getItem("atlas.actions.mode") || "list");
  const [sort, setSort] = useA(localStorage.getItem("atlas.actions.sort") || "category");
  const [showTax, setShowTax] = useA(false);
  const [fCat, setFCat] = useA([]);
  const [fWho, setFWho] = useA([]);
  const setM = (m) => { setMode(m); localStorage.setItem("atlas.actions.mode", m); };
  const setS = (s) => { setSort(s); localStorage.setItem("atlas.actions.sort", s); };
  return (
    <>
      <div className="filterbar no-print" style={{ justifyContent: "space-between" }}>
        <div className="row" style={{ gap: 10 }}>
          <div className="seg-toggle">
            <button className={mode === "list" ? "on" : ""} onClick={() => setM("list")}><Icon name="list" size={15} /> Action list</button>
            <button className={mode === "timeline" ? "on" : ""} onClick={() => setM("timeline")}><Icon name="timeline" size={15} /> Timeline</button>
          </div>
        </div>
        <div className="row" style={{ gap: 8 }}>
          <ActionsFilter categories={categories} members={members} fCat={fCat} setFCat={setFCat} fWho={fWho} setFWho={setFWho} />
          <button className="btn btn-sm" onClick={() => setShowTax(true)} title="Edit categories, tags & phases"><Icon name="tag" size={14} /> Edit categories</button>
          <label className="sortby" title="Choose how actions are organised">
            <Icon name="sort" size={14} />
            <span className="sortby-label">Sort by</span>
            <select value={sort} onChange={(e) => setS(e.target.value)}>
              <option value="category">Category</option>
              <option value="sequence">Sequence (date &amp; dependencies)</option>
            </select>
            <Icon name="chevD" size={13} />
          </label>
        </div>
      </div>
      <div className="view-scroll">
        {mode === "list" ? <ActionList sort={sort} fCat={fCat} fWho={fWho} /> : <Timeline sort={sort} fCat={fCat} fWho={fWho} />}
      </div>
      {showTax && <TaxonomyEditor onClose={() => setShowTax(false)} />}
    </>
  );
}

/* Filter by assigned-to + category (shared by the list & timeline views) */
function ActionsFilter({ categories, members, fCat, setFCat, fWho, setFWho }) {
  const [open, setOpen] = useA(false);
  const ref = useAR(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const n = fCat.length + fWho.length;
  const toggle = (arr, set, id) => set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  return (
    <div className="tagpicker" ref={ref}>
      <button className={"btn btn-sm" + (n ? " btn-primary" : "")} onClick={() => setOpen((o) => !o)}>
        <Icon name="filter" size={14} /> Filter{n ? ` · ${n}` : ""}
      </button>
      {open && (
        <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 210, padding: 12 }}>
          <div className="between" style={{ marginBottom: 8 }}>
            <div className="field-label" style={{ margin: 0 }}>Assigned to</div>
            {n > 0 && <button className="btn btn-sm btn-ghost" style={{ padding: "1px 6px" }} onClick={() => { setFCat([]); setFWho([]); }}>Clear</button>}
          </div>
          <div className="wrap" style={{ marginBottom: 14 }}>
            {(members || []).map((m) => (
              <button key={m.id} className={"fpill" + (fWho.includes(m.name) ? " on" : "")} style={{ "--t-var": "var(--t-" + (m.color || "indigo") + ")" }} onClick={() => toggle(fWho, setFWho, m.name)}>
                <span className="chip-dot" style={{ background: "var(--t-" + (m.color || "indigo") + ")" }} />{m.name}
              </button>
            ))}
            <button className={"fpill" + (fWho.includes("__unassigned") ? " on" : "")} onClick={() => toggle(fWho, setFWho, "__unassigned")}>
              <span className="chip-dot" style={{ background: "var(--ink-ghost)" }} />Unassigned
            </button>
            {(members || []).length === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No members yet</span>}
          </div>
          <div className="field-label">Category</div>
          <div className="wrap">
            {categories.map((c) => (
              <button key={c.id} className={"fpill" + (fCat.includes(c.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + c.color + ")" }} onClick={() => toggle(fCat, setFCat, c.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}
              </button>
            ))}
            {categories.length === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No categories yet</span>}
          </div>
        </div>
      )}
    </div>
  );
}

/* order tasks by start date, then by dependency (predecessors first), undated last */
function sequenceTasks(tasks) {
  const byId = Object.fromEntries(tasks.map((t) => [t.id, t]));
  const keyOf = (t) => {
    if (t.start) return new Date(t.start).getTime();
    // inherit from latest predecessor end if undated
    let best = Infinity;
    (t.deps || []).forEach((d) => { if (d.type === "task" && byId[d.refId] && byId[d.refId].end) best = Math.min(best, new Date(byId[d.refId].end).getTime() + 1); });
    return best;
  };
  return [...tasks].sort((a, b) => {
    const ka = keyOf(a), kb = keyOf(b);
    if (ka !== kb) return ka - kb;
    return (a.title || "").localeCompare(b.title || "");
  });
}

/* ============================================================
   ACTION LIST — grouped by category
   ============================================================ */
function ActionList({ sort, fCat = [], fWho = [] }) {
  const { tasks, phases, categories, tags, milestones } = Store.useStore();
  const [open, setOpen] = useA(null);
  const [msEdit, setMsEdit] = useA(null);
  const [dragId, setDragId] = useA(null);
  const [overKey, setOverKey] = useA(null);
  // tasks that pass the assigned-to / category filter (dependency lookups still use the full list)
  const visible = useAM(() => tasks.filter((t) => taskMatchesFilter(t, fCat, fWho)), [tasks, fCat, fWho]);
  const filterActive = fCat.length > 0 || fWho.length > 0;

  const addCategory = () => {
    const colors = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
    const id = Store.uid("ct");
    Store.update("categories", (arr) => [...arr, { id, label: "New category", color: colors[arr.length % colors.length] }]);
  };
  // move a task into a bucket; beforeId = drop before that task, else append to bucket end
  const moveTask = (id, group, beforeId) => {
    Store.setState((st) => {
      const arr = [...st.tasks];
      const di = arr.findIndex((x) => x.id === id);
      if (di < 0) return st;
      const [dragged] = arr.splice(di, 1);
      const updated = { ...dragged, category: group.catId, origin: group.origin || null };
      if (beforeId && beforeId !== id) {
        const bi = arr.findIndex((x) => x.id === beforeId);
        arr.splice(bi < 0 ? arr.length : bi, 0, updated);
      } else {
        // append after the last task already in this bucket
        const inBucket = (x) => group.catId ? x.category === group.catId : group.origin ? x.origin === group.origin : (!x.category || !categories.find((c) => c.id === x.category)) && x.origin !== "comms" && x.origin !== "change";
        let lastIdx = -1;
        arr.forEach((x, i) => { if (inBucket(x)) lastIdx = i; });
        arr.splice(lastIdx + 1, 0, updated);
      }
      return { ...st, tasks: arr };
    });
  };

  const groups = useAM(() => {
    const inCat = (t) => t.category && categories.find((c) => c.id === t.category);
    const g = categories.map((c) => ({
      key: c.id, label: c.label, color: c.color, catId: c.id, origin: null,
      items: visible.filter((t) => t.category === c.id),
      ms: milestones.filter((m) => m.category === c.id),
    }));
    const un = visible.filter((t) => !inCat(t));
    const comms = un.filter((t) => t.origin === "comms");
    const change = un.filter((t) => t.origin === "change");
    const other = un.filter((t) => t.origin !== "comms" && t.origin !== "change");
    const unMs = milestones.filter((m) => !m.category || !categories.find((c) => c.id === m.category));
    if (other.length || unMs.length) g.push({ key: "_un", label: "Uncategorised", color: null, catId: null, origin: null, items: other, ms: unMs });
    // communications + change management sit together at the very bottom
    if (comms.length) g.push({ key: "_comms", label: "Communications", color: "teal", catId: null, origin: "comms", items: comms, ms: [] });
    if (change.length) g.push({ key: "_change", label: "Change management", color: "purple", catId: null, origin: "change", items: change, ms: [] });
    // when a filter is active, hide buckets that have nothing matching
    return filterActive ? g.filter((x) => x.items.length || x.ms.length) : g;
  }, [visible, categories, milestones, filterActive]);

  const addTo = (catId, origin) => {
    const id = Store.uid("t");
    Store.add("tasks", { id, title: "New action", status: "backlog", tags: [], priority: "med", assignees: [], desc: "", phase: null, category: catId, origin: origin || null, start: "", end: "", deps: [] });
    setOpen({ id });
  };
  const addMs = (catId) => {
    const id = Store.uid("ms");
    const cat = catId || (categories[0] && categories[0].id) || null;
    Store.add("milestones", { id, title: "New milestone", type: "milestone", date: toISO(new Date()), category: cat, note: "" });
    setMsEdit(id);
  };

  const ownerText = (t) => assigneesOf(t).length ? (assigneesOf(t).length === 1 ? assigneesOf(t)[0] : assigneesOf(t).length + " people") : "—";

  /* ---- SEQUENCE VIEW: flat, ordered by date & dependencies ---- */
  if (sort === "sequence") {
    const ordered = sequenceTasks(visible);
    const blocked = (t) => (t.deps || []).some((d) => { if (d.type !== "task") return false; const p = tasks.find((x) => x.id === d.refId); return p && p.status !== "done" && t.start && p.end && new Date(t.start) < new Date(p.end); });
    return (
      <div className="view-pad view-wide">
        <div className="act-group">
          <div className="act-group-hd">
            <span className="kcol-dot" style={{ background: "var(--accent)" }} />
            <span className="act-group-title">In sequence</span>
            <span className="kcol-count">{ordered.length} actions · earliest first</span>
            <div className="grow" />
            <button className="btn btn-sm btn-ghost" onClick={() => addTo(null, null)}><Icon name="plus" size={13} /> Add</button>
          </div>
          <div className="act-table">
            <div className="act-head act-head-seq">
              <div>#</div><div>Action</div><div>Category</div><div>Depends on</div><div>Owner</div><div>Dates</div><div>Status</div>
            </div>
            {ordered.length === 0 && <div className="act-empty">No actions yet.</div>}
            {ordered.map((t, i) => {
              const cat = categories.find((c) => c.id === t.category);
              const deps = (t.deps || []).filter((d) => d.type === "task").map((d) => tasks.find((x) => x.id === d.refId)).filter(Boolean);
              const isBlocked = blocked(t);
              return (
                <div key={t.id} className={"act-row act-row-seq" + (isBlocked ? " act-row-blocked" : "")} title={isBlocked ? "Dependency block" : undefined} onClick={() => setOpen(t)}>
                  <div className="seq-num mono">{i + 1}</div>
                  <div className="act-cell-title">
                    <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                    {t.title}
                  </div>
                  <div>{cat ? <UI.Chip label={cat.label} color={cat.color} dot /> : t.origin === "comms" ? <UI.Chip label="Communications" color="teal" dot /> : t.origin === "change" ? <UI.Chip label="Change mgmt" color="purple" dot /> : <span className="muted">—</span>}</div>
                  <div className="seq-deps">
                    {deps.length === 0 ? <span className="muted" style={{ fontSize: 12.5 }}>—</span>
                      : deps.map((p) => <span key={p.id} className={"seq-dep" + (p.status !== "done" ? " open" : "")} title={p.title}>{p.status !== "done" ? "⛔ " : "✓ "}{p.title}</span>)}
                  </div>
                  <div className="muted" style={{ fontSize: 13 }}>{ownerText(t)}</div>
                  <div className="muted mono" style={{ fontSize: 12 }}>{fmtD(t.start)} → {fmtD(t.end)}</div>
                  <div><span className={"status-dot s-" + t.status} />{COLUMNS.find((c) => c.id === t.status)?.title}</div>
                </div>
              );
            })}
          </div>
        </div>
        {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      </div>
    );
  }

  /* ---- CATEGORY VIEW ---- */
  return (
    <div className="view-pad view-wide">
      <div className="act-cat-toolbar no-print">
        <button className="btn btn-sm btn-primary" onClick={addCategory}><Icon name="plus" size={14} /> Add category</button>
        <span className="muted" style={{ fontSize: 12.5 }}>Drag actions between categories to re-bucket them · order top-to-bottom = sequence</span>
      </div>
      {/* tasks grouped by category, milestones pinned at top */}
      {groups.map((g) => (
        <div key={g.key} className="act-group">
          <div className="act-group-hd">
            <span className="kcol-dot" style={{ background: g.color ? "var(--t-" + g.color + ")" : "var(--ink-ghost)" }} />
            {g.catId
              ? <UI.Editable className="act-group-title act-cat-edit" value={g.label} onChange={(v) => Store.update("categories", (arr) => arr.map((c) => c.id === g.catId ? { ...c, label: v || "Untitled" } : c))} placeholder="Category" />
              : <span className="act-group-title">{g.label}</span>}
            <span className="kcol-count">{g.items.length} {g.items.length === 1 ? "action" : "actions"}{g.ms.length ? " · " + g.ms.length + " marker" + (g.ms.length === 1 ? "" : "s") : ""}</span>
            <div className="grow" />
            {g.catId && <button className="btn btn-sm btn-ghost" onClick={() => addMs(g.catId)}><Icon name="flag" size={13} /> Gate / milestone</button>}
            <button className="btn btn-sm btn-ghost" onClick={() => addTo(g.catId, g.origin)}><Icon name="plus" size={13} /> Add</button>
          </div>
          {/* milestones/gates pinned at top */}
          {g.ms.length > 0 && (
            <div className="ms-pinned">
              {g.ms.map((ms) => (
                <div key={ms.id} className={"ms-pin " + ms.type} onClick={() => setMsEdit(ms.id)}>
                  <span className={ms.type === "gate" ? "ms-gate-icon" : "ms-mile-icon"}>{ms.type === "gate" ? "┃" : "◆"}</span>
                  <span className="ms-pin-title">{ms.title}</span>
                  <span className={"ms-type-chip " + ms.type}>{ms.type === "gate" ? "Gate" : "Milestone"}</span>
                  <span className="muted mono" style={{ fontSize: 11 }}>{fmtD(ms.date)}</span>
                </div>
              ))}
            </div>
          )}
          <div className={"act-table" + (overKey === g.key ? " act-table-over" : "")}
            onDragOver={(e) => { if (dragId) { e.preventDefault(); setOverKey(g.key); } }}
            onDragLeave={(e) => { if (e.currentTarget === e.target) setOverKey(null); }}
            onDrop={(e) => { if (dragId) { e.preventDefault(); moveTask(dragId, g, null); } setDragId(null); setOverKey(null); }}>
            <div className="act-head act-head-drag">
              <div></div><div>Action</div><div>Phase</div><div>Tags</div><div>Owner</div><div>Dates</div><div>Status</div>
            </div>
            {g.items.length === 0 && <div className="act-empty">{dragId ? "Drop here to add to this category" : "No actions in this category yet."}</div>}
            {g.items.map((t, i) => {
              const ph = phases.find((p) => p.id === t.phase);
              return (
                <div key={t.id} className={"act-row act-row-drag" + (dragId === t.id ? " act-row-dragging" : "")}
                  draggable
                  onDragStart={(e) => { setDragId(t.id); e.dataTransfer.effectAllowed = "move"; }}
                  onDragEnd={() => { setDragId(null); setOverKey(null); }}
                  onDragOver={(e) => { if (dragId && dragId !== t.id) e.preventDefault(); }}
                  onDrop={(e) => { if (dragId) { e.preventDefault(); e.stopPropagation(); moveTask(dragId, g, t.id); } setDragId(null); setOverKey(null); }}
                  onClick={() => setOpen(t)}>
                  <div className="act-drag-cell"><span className="act-seq-n">{i + 1}</span><span className="act-grip"><Icon name="drag" size={14} /></span></div>
                  <div className="act-cell-title">
                    <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                    {t.title}
                  </div>
                  <div>{ph ? <UI.Chip label={ph.label} color={ph.color} dot /> : <span className="muted">—</span>}</div>
                  <div className="wrap">
                    {(t.tags || []).slice(0, 3).map((id) => { const tg = tags.find((x) => x.id === id); return tg ? <UI.Chip key={id} label={tg.label} color={tg.color} /> : null; })}
                  </div>
                  <div className="muted" style={{ fontSize: 13 }}>{ownerText(t)}</div>
                  <div className="muted mono" style={{ fontSize: 12 }}>{fmtD(t.start)} → {fmtD(t.end)}</div>
                  <div><span className={"status-dot s-" + t.status} />{COLUMNS.find((c) => c.id === t.status)?.title}</div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      {msEdit && <MilestoneModal id={msEdit} onClose={() => setMsEdit(null)} />}
    </div>
  );
}

/* ============================================================
   MILESTONE/GATE MODAL
   ============================================================ */
function MilestoneModal({ id, onClose }) {
  const { categories } = Store.useStore();
  const ms = Store.getState().milestones.find((x) => x.id === id);
  if (!ms) return null;
  const set = (c) => Store.patch("milestones", id, c);
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <span className={ms.type === "gate" ? "ms-gate-icon big" : "ms-mile-icon big"}>{ms.type === "gate" ? "┃" : "◆"}</span>
        <div className="grow">
          <UI.Editable className="cm-title" style={{ fontSize: 20 }} multiline value={ms.title} onChange={(v) => set({ title: v || "Untitled" })} placeholder="Name" />
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="row" style={{ gap: 16, marginBottom: 18 }}>
          <div className="grow">
            <div className="field-label">Type</div>
            <div className="statusseg" style={{ maxWidth: 220 }}>
              <button className={ms.type === "milestone" ? "on" : ""} onClick={() => set({ type: "milestone" })}>◆ Milestone</button>
              <button className={ms.type === "gate" ? "on" : ""} onClick={() => set({ type: "gate", category: ms.category || (categories[0] && categories[0].id) || null })}>┃ Gate</button>
            </div>
          </div>
          <div>
            <div className="field-label">Date</div>
            <input className="datemini" type="date" value={ms.date || ""} onChange={(e) => set({ date: e.target.value })} />
          </div>
        </div>
        <div className="field-label">Category {ms.type === "gate" && <span style={{ color: "var(--t-red)" }}>· required for gates</span>}</div>
        <PickInline options={categories} value={ms.category} onChange={(v) => set({ category: v })} />
        {ms.type === "gate" && !ms.category && <div className="ms-warn">A gate validates a category's work — pick the category it gates.</div>}
        <div style={{ marginTop: 16 }}>
          <div className="field-label">Note</div>
          <UI.Editable className="input" tag="div" multiline value={ms.note} style={{ minHeight: 60, lineHeight: 1.5 }} onChange={(v) => set({ note: v })} placeholder="What does this mark?" />
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost btn-danger" onClick={() => { Store.remove("milestones", id); onClose(); }}><Icon name="trash" size={15} /> Delete</button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

/* ============================================================
   TIMELINE (Gantt) — grouped by category + milestones & gates
   ============================================================ */
function Timeline({ sort, fCat = [], fWho = [] }) {
  const { tasks, categories, milestones, commPlan } = Store.useStore();
  const [open, setOpen] = useA(null);
  const [msEdit, setMsEdit] = useA(null);
  const scrollRef = useAR(null);
  const DAYW = 13;

  const dated = tasks.filter((t) => t.start && t.end && taskMatchesFilter(t, fCat, fWho));
  const datedMs = milestones.filter((m) => m.date);
  const datedComms = (commPlan || []).filter((c) => c.date);
  const allDates = [...dated.map((t) => [t.start, t.end]).flat(), ...datedMs.map((m) => m.date), ...datedComms.map((c) => c.date)];

  const range = useAM(() => {
    if (!allDates.length) { const now = new Date(); return { min: now, max: new Date(+now + 60 * DAY) }; }
    let min = Infinity, max = -Infinity;
    allDates.forEach((d) => { const v = +new Date(d); if (v < min) min = v; if (v > max) max = v; });
    const now = Date.now();
    min = Math.min(min, now); max = Math.max(max, now);
    min -= 4 * DAY; max += 8 * DAY;
    return { min: new Date(min), max: new Date(max) };
  }, [tasks, milestones]);

  const totalDays = Math.max(1, daysBetween(range.min, range.max));
  const totalW = totalDays * DAYW;

  const months = useAM(() => {
    const out = []; const d = new Date(range.min); d.setDate(1);
    while (d < range.max) {
      const start = new Date(Math.max(+d, +range.min));
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
      const end = new Date(Math.min(+next, +range.max));
      out.push({ label: d.toLocaleDateString("en-GB", { month: "short", year: "2-digit" }), left: daysBetween(range.min, start) * DAYW, width: daysBetween(start, end) * DAYW });
      d.setMonth(d.getMonth() + 1);
    }
    return out;
  }, [range]);

  const todayLeft = (() => { const now = new Date(); if (now < range.min || now > range.max) return null; return daysBetween(range.min, now) * DAYW; })();
  const nowTs = Date.now();

  // default the scroll to the "today" line so current work is in view
  React.useEffect(() => {
    if (scrollRef.current && todayLeft != null) {
      scrollRef.current.scrollLeft = Math.max(0, todayLeft - 160);
    }
  }, [todayLeft]);

  const groups = (() => {
    const inCat = (t) => t.category && categories.find((c) => c.id === t.category);
    if (sort === "sequence") {
      return [{ key: "_seq", label: "All actions · in sequence", color: null, items: sequenceTasks(dated) }];
    }
    const arr = categories.map((c) => ({ key: c.id, label: c.label, color: c.color, items: dated.filter((t) => t.category === c.id) }));
    const un = dated.filter((t) => !inCat(t));
    arr.push({ key: "_un", label: "Uncategorised", color: null, items: un.filter((t) => t.origin !== "comms" && t.origin !== "change") });
    arr.push({ key: "_comms", label: "Communications", color: "teal", items: un.filter((t) => t.origin === "comms") });
    arr.push({ key: "_change", label: "Change management", color: "purple", items: un.filter((t) => t.origin === "change") });
    return arr.filter((g) => g.items.length);
  })();

  /* drag */
  const dragRef = useAR(null);
  const onBarDown = (e, task, kind) => {
    e.preventDefault(); e.stopPropagation();
    dragRef.current = { task, kind, startX: e.clientX, start0: new Date(task.start), end0: new Date(task.end), moved: false };
    document.body.style.cursor = kind === "move" ? "grabbing" : "ew-resize";
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };
  const onMove = (e) => {
    const d = dragRef.current; if (!d) return;
    const deltaDays = Math.round((e.clientX - d.startX) / DAYW);
    if (deltaDays !== 0) d.moved = true;
    let s = new Date(d.start0), en = new Date(d.end0);
    if (d.kind === "move") { s = new Date(+d.start0 + deltaDays * DAY); en = new Date(+d.end0 + deltaDays * DAY); }
    else if (d.kind === "l") { s = new Date(Math.min(+d.start0 + deltaDays * DAY, +d.end0 - DAY)); }
    else if (d.kind === "r") { en = new Date(Math.max(+d.end0 + deltaDays * DAY, +d.start0 + DAY)); }
    const el = document.getElementById("bar-" + d.task.id);
    if (el) { el.style.left = daysBetween(range.min, s) * DAYW + "px"; el.style.width = Math.max(DAYW, daysBetween(s, en) * DAYW) + "px"; }
    d.preview = { start: toISO(s), end: toISO(en) };
  };
  const onUp = () => {
    const d = dragRef.current;
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    document.body.style.cursor = "";
    if (d && d.moved && d.preview) Store.patch("tasks", d.task.id, d.preview);
    dragRef.current = null;
  };

  if (!dated.length && !datedMs.length && !datedComms.length) {
    return <div className="view-pad view-wide"><div className="empty"><div className="serif">No dated actions yet</div>Add start and end dates to actions to see them on the timeline.</div></div>;
  }

  // compute layout for every rendered task so we can draw dependency arrows on top
  const taskLayout = new Map();
  let yCursor = 38; // header row height
  groups.forEach((g) => {
    yCursor += 34; // phase row
    g.items.forEach((t) => {
      const barLeft = daysBetween(range.min, t.start) * DAYW;
      const barWidth = Math.max(DAYW, daysBetween(t.start, t.end) * DAYW);
      taskLayout.set(t.id, { rowY: yCursor + 21, barLeft, barWidth });
      yCursor += 42;
    });
  });
  const depLines = [];
  tasks.forEach((t) => {
    if (!t.start || !t.end || !taskLayout.has(t.id)) return;
    (t.deps || []).forEach((d) => {
      if (d.type !== "task") return;
      const pred = tasks.find((x) => x.id === d.refId);
      if (!pred || !pred.start || !pred.end || !taskLayout.has(pred.id)) return;
      const pL = taskLayout.get(pred.id);
      const dL = taskLayout.get(t.id);
      const violated = pred.status !== "done" && new Date(t.start) < new Date(pred.end);
      depLines.push({
        key: d.id || (pred.id + "-" + t.id),
        from: { x: pL.barLeft + pL.barWidth, y: pL.rowY },
        to:   { x: dL.barLeft, y: dL.rowY },
        violated,
        title: violated ? "Dependency block — " + t.title + " needs output from " + pred.title : pred.title + " → " + t.title,
      });
    });
  });

  return (
    <div className="view-pad">
      <div className="gantt panel" ref={scrollRef}>
        <div className="gantt-inner" style={{ width: totalW + 260 }}>
          {/* dependency arrows overlay — positioned over the track area */}
          {depLines.length > 0 && (
            <svg className="gantt-deps" style={{ left: 260, width: totalW, height: yCursor + 20 }}>
              <defs>
                <marker id="gd-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M0,0 L10,5 L0,10 z" fill="currentColor" />
                </marker>
                <marker id="gd-arrow-bad" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M0,0 L10,5 L0,10 z" fill="var(--t-red)" />
                </marker>
              </defs>
              {depLines.map((line) => {
                const stub = 12;
                const arrowEndX = line.to.x - 4;
                const path = line.to.x >= line.from.x + stub * 2
                  ? `M${line.from.x},${line.from.y} h${stub} V${line.to.y} H${arrowEndX}`
                  : `M${line.from.x},${line.from.y} h${stub} V${line.to.y - 14} H${line.to.x - 8} V${line.to.y}`;
                return (
                  <path key={line.key} d={path}
                    className={"gantt-dep" + (line.violated ? " violated" : "")}
                    markerEnd={line.violated ? "url(#gd-arrow-bad)" : "url(#gd-arrow)"}>
                    <title>{line.title}</title>
                  </path>
                );
              })}
            </svg>
          )}
          {/* header */}
          <div className="gantt-row gantt-header">
            <div className="gantt-label gantt-corner">Category / Action</div>
            <div className="gantt-track" style={{ width: totalW }}>
              {months.map((m, i) => <div key={i} className="gantt-month" style={{ left: m.left, width: m.width }}>{m.label}</div>)}
              {todayLeft != null && <div className="gantt-today" style={{ left: todayLeft }}><span>Today</span></div>}
              {/* milestones & gates in header track */}
              {datedMs.map((ms) => {
                const left = daysBetween(range.min, ms.date) * DAYW;
                const cat = categories.find((c) => c.id === ms.category);
                if (ms.type === "gate") {
                  return <div key={ms.id} className="gantt-gate" style={{ left }} title={ms.title + " (gate) — " + fmtD(ms.date)} onClick={() => setMsEdit(ms.id)} />;
                }
                return <div key={ms.id} className="gantt-milestone" style={{ left, "--ms-c": cat ? "var(--t-" + cat.color + ")" : "var(--accent)" }} title={ms.title + " — " + fmtD(ms.date)} onClick={() => setMsEdit(ms.id)}>◆</div>;
              })}
              {/* communications in header track */}
              {datedComms.map((c) => {
                const left = daysBetween(range.min, c.date) * DAYW;
                return <div key={c.id} className="gantt-comm" style={{ left }} title={"Comms: " + (c.audience || "audience") + " — " + fmtD(c.date)}><Icon name="send" size={11} /></div>;
              })}
            </div>
          </div>
          {/* rows by category */}
          {groups.map((g) => (
            <React.Fragment key={g.key}>
              <div className="gantt-row gantt-phaserow">
                <div className="gantt-label">
                  <span className="kcol-dot" style={{ background: g.color ? "var(--t-" + g.color + ")" : "var(--ink-ghost)" }} />
                  <strong>{g.label}</strong>
                </div>
                <div className="gantt-track" style={{ width: totalW }}>
                  {todayLeft != null && <div className="gantt-todayline" style={{ left: todayLeft }} />}
                  {/* gate lines extend through all rows */}
                  {datedMs.filter((ms) => ms.type === "gate").map((ms) => {
                    const left = daysBetween(range.min, ms.date) * DAYW;
                    return <div key={ms.id} className="gantt-gateline" style={{ left }} />;
                  })}
                  {/* milestone markers */}
                  {datedMs.filter((ms) => ms.type === "milestone").map((ms) => {
                    const left = daysBetween(range.min, ms.date) * DAYW;
                    return <div key={ms.id} className="gantt-msline" style={{ left }} />;
                  })}
                  {/* communication lines */}
                  {datedComms.map((c) => {
                    const left = daysBetween(range.min, c.date) * DAYW;
                    return <div key={c.id} className="gantt-commline" style={{ left }} />;
                  })}
                </div>
              </div>
              {g.items.map((t) => {
                const left = daysBetween(range.min, t.start) * DAYW;
                const width = Math.max(DAYW, daysBetween(t.start, t.end) * DAYW);
                const cat = categories.find((c) => c.id === t.category);
                const color = cat ? "var(--t-" + cat.color + ")" : "var(--accent)";
                return (
                  <div className="gantt-row" key={t.id}>
                    <div className="gantt-label gantt-tasklabel" onClick={() => setOpen(t)} title={t.title}>{t.title}</div>
                    <div className="gantt-track" style={{ width: totalW }}>
                      {todayLeft != null && <div className="gantt-todayline" style={{ left: todayLeft }} />}
                      {datedMs.filter((ms) => ms.type === "gate").map((ms) => <div key={ms.id} className="gantt-gateline" style={{ left: daysBetween(range.min, ms.date) * DAYW }} />)}
                      {datedMs.filter((ms) => ms.type === "milestone").map((ms) => <div key={ms.id} className="gantt-msline" style={{ left: daysBetween(range.min, ms.date) * DAYW }} />)}
                      {datedComms.map((c) => <div key={c.id} className="gantt-commline" style={{ left: daysBetween(range.min, c.date) * DAYW }} />)}
                      <div id={"bar-" + t.id} className={"gantt-bar" + (t.status === "done" ? " done" : "") + (+new Date(t.end) < nowTs ? " past" : "")}
                        style={{ left, width, "--bar-c": color }}
                        onPointerDown={(e) => onBarDown(e, t, "move")}
                        onDoubleClick={() => setOpen(t)} title={t.title + " · " + fmtD(t.start) + " → " + fmtD(t.end)}>
                        <span className="gantt-handle l" onPointerDown={(e) => onBarDown(e, t, "l")} />
                        <span className="gantt-bar-label">{t.title}</span>
                        <span className="gantt-handle r" onPointerDown={(e) => onBarDown(e, t, "r")} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      {msEdit && <MilestoneModal id={msEdit} onClose={() => setMsEdit(null)} />}
    </div>
  );
}

Object.assign(window, { Actions });
