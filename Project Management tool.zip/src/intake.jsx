/* ============================================================
   INTAKE WIZARD — guided setup for a NEW project.
   Sizes the project, then asks scope + business-case questions
   (many yes/no) and auto-populates the relevant sections.
   Exposes window.IntakeWizard
   ============================================================ */
const { useState: useIn } = React;

const SIZES = [
  { id: "small", label: "Small", blurb: "A few weeks · one team · low risk & budget.", detail: "Light-touch: a clear purpose, a scope and a handful of actions. Most heavy sections stay optional." },
  { id: "medium", label: "Medium", blurb: "1–3 months · a couple of teams · several stakeholders.", detail: "A full business case, scope and as-is/to-be, plus communication and a light change plan." },
  { id: "large", label: "Large", blurb: "3+ months · multiple departments · high risk & budget.", detail: "Formal governance: business case, financials, risks, stakeholder map, change management and steering." },
];

const SIZE_DEFAULTS = {
  small:  { hasProblem: true, fromUsers: false, fromStakeholders: false, hasOpportunities: false, needProcess: false, needSystem: true, needBehaviour: false, needLeadership: false, hasFinancials: false, hasRisks: false },
  medium: { hasProblem: true, fromUsers: true, fromStakeholders: true, hasOpportunities: true, needProcess: true, needSystem: true, needBehaviour: true, needLeadership: false, hasFinancials: true, hasRisks: true },
  large:  { hasProblem: true, fromUsers: true, fromStakeholders: true, hasOpportunities: true, needProcess: true, needSystem: true, needBehaviour: true, needLeadership: true, hasFinancials: true, hasRisks: true },
};

function YN({ value, onChange, label, hint }) {
  return (
    <div className={"yn" + (value ? " on" : "")}>
      <div className="yn-main">
        <div className="yn-label">{label}</div>
        {hint && <div className="yn-hint">{hint}</div>}
      </div>
      <div className="yn-seg">
        <button className={value ? "on" : ""} onClick={() => onChange(true)}>Yes</button>
        <button className={!value ? "on" : ""} onClick={() => onChange(false)}>No</button>
      </div>
    </div>
  );
}

function Reveal({ show, children }) {
  if (!show) return null;
  return <div className="intake-reveal">{children}</div>;
}

function IntakeWizard({ onClose, onDone }) {
  const s = Store.getState();
  const [step, setStep] = useIn(0);
  const [a, setA] = useIn({
    size: "", purpose: "", problem: "",
    usersText: "", stakeText: "", oppText: "",
    outcomes: "", processText: "", systemText: "", behaviourText: "", leadershipText: "",
    costOneOff: "", costRun: "", saving: "", payback: "",
    inScope: "", outScope: "", risksText: "",
    ...SIZE_DEFAULTS.medium,
  });
  const set = (c) => setA((p) => ({ ...p, ...c }));
  const pickSize = (id) => set({ size: id, ...SIZE_DEFAULTS[id] });

  const STEPS = ["Size", "Situation", "Outcome & effects", "Financials", "Scope & risks"];
  const lines = (t) => (t || "").split("\n").map((x) => x.trim()).filter(Boolean);

  const finish = () => {
    Store.setState((st) => ({
      ...st,
      meta: { ...st.meta, size: a.size || "medium" },
      businessCase: {
        ...st.businessCase,
        purpose: a.purpose || st.businessCase.purpose,
        problem: a.hasProblem ? a.problem : "",
        perspUsers: a.fromUsers ? a.usersText : "",
        perspStakeholders: a.fromStakeholders ? a.stakeText : "",
        opportunities: a.hasOpportunities ? a.oppText : "",
        outcomes: lines(a.outcomes).length ? lines(a.outcomes) : st.businessCase.outcomes,
        effProcess: a.needProcess ? a.processText : "",
        effSystem: a.needSystem ? a.systemText : "",
        effBehaviour: a.needBehaviour ? a.behaviourText : "",
        effLeadership: a.needLeadership ? a.leadershipText : "",
        financial: a.hasFinancials
          ? [
              { label: "Programme cost (one-off)", value: a.costOneOff, note: "" },
              { label: "Annual run cost", value: a.costRun, note: "" },
              { label: "Annual saving", value: a.saving, note: "" },
              { label: "Payback period", value: a.payback, note: "" },
            ]
          : st.businessCase.financial,
      },
      scope: { inScope: lines(a.inScope), outScope: lines(a.outScope) },
      risks: a.hasRisks
        ? lines(a.risksText).map((t) => ({ id: Store.uid("r"), title: t, likelihood: "med", impact: "med", mitigation: "", owner: "", status: "open", taskIds: [] }))
        : st.risks,
    }));
    onDone && onDone();
  };

  const canNext = step !== 0 || !!a.size;

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--accent)" }}><Icon name="scope" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Set up “{s?.meta?.project || "project"}”</div>
          <div className="muted" style={{ fontSize: 13 }}>Answer what's relevant — skip the rest. We'll fill the sections for you.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>

      <div className="intake-steps">
        {STEPS.map((st, i) => (
          <button key={i} className={"intake-step" + (i === step ? " on" : "") + (i < step ? " done" : "")} onClick={() => (i === 0 || a.size) && setStep(i)}>
            <span className="intake-step-n">{i < step ? <Icon name="check" size={12} /> : i + 1}</span>
            <span className="intake-step-l">{st}</span>
          </button>
        ))}
      </div>

      <div className="modal-bd intake-bd">
        {step === 0 && (
          <div>
            <div className="intake-q">How big is this project?</div>
            <p className="muted" style={{ fontSize: 13, lineHeight: 1.5, margin: "0 0 16px" }}>This tailors which sections we ask about — you can change everything later.</p>
            <div className="size-grid">
              {SIZES.map((sz) => (
                <button key={sz.id} className={"size-card" + (a.size === sz.id ? " on" : "")} onClick={() => pickSize(sz.id)}>
                  <div className="size-card-hd"><span className="size-name serif">{sz.label}</span>{a.size === sz.id && <span className="size-check"><Icon name="check" size={13} /></span>}</div>
                  <div className="size-blurb">{sz.blurb}</div>
                  <div className="size-detail">{sz.detail}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="intake-form">
            <div>
              <div className="field-label">Why are we doing this? Why does it matter?</div>
              <textarea className="textarea" rows={2} value={a.purpose} onChange={(e) => set({ purpose: e.target.value })} placeholder="The core reason this project exists." />
            </div>
            <YN value={a.hasProblem} onChange={(v) => set({ hasProblem: v })} label="Is there a clear problem or pain today?" hint="A situation that creates or worsens the challenge." />
            <Reveal show={a.hasProblem}><textarea className="textarea" rows={2} value={a.problem} onChange={(e) => set({ problem: e.target.value })} placeholder="What is wrong today, and what makes it worse?" /></Reveal>
            <YN value={a.fromUsers} onChange={(v) => set({ fromUsers: v })} label="Does this matter from the users' perspective?" />
            <Reveal show={a.fromUsers}><textarea className="textarea" rows={2} value={a.usersText} onChange={(e) => set({ usersText: e.target.value })} placeholder="How do users experience the challenge?" /></Reveal>
            <YN value={a.fromStakeholders} onChange={(v) => set({ fromStakeholders: v })} label="Are other stakeholders affected?" />
            <Reveal show={a.fromStakeholders}><textarea className="textarea" rows={2} value={a.stakeText} onChange={(e) => set({ stakeText: e.target.value })} placeholder="Compliance, leadership, partners…" /></Reveal>
            <YN value={a.hasOpportunities} onChange={(v) => set({ hasOpportunities: v })} label="Are there opportunities we can leverage?" />
            <Reveal show={a.hasOpportunities}><textarea className="textarea" rows={2} value={a.oppText} onChange={(e) => set({ oppText: e.target.value })} placeholder="What can we take advantage of?" /></Reveal>
          </div>
        )}

        {step === 2 && (
          <div className="intake-form">
            <div>
              <div className="field-label">What does good look like? Outcomes / KPIs <span className="ai-opt">one per line</span></div>
              <textarea className="textarea" rows={3} value={a.outcomes} onChange={(e) => set({ outcomes: e.target.value })} placeholder={"Reduce support tickets by 50%\nSingle sign-on across all tools"} />
            </div>
            <div className="intake-sub">Which kinds of change are needed?</div>
            <YN value={a.needProcess} onChange={(v) => set({ needProcess: v })} label="Process change" hint="New or changed process, QMS / Cortex document." />
            <Reveal show={a.needProcess}><textarea className="textarea" rows={2} value={a.processText} onChange={(e) => set({ processText: e.target.value })} placeholder="What process needs to change?" /></Reveal>
            <YN value={a.needSystem} onChange={(v) => set({ needSystem: v })} label="System change" hint="New tools, functionality or templates." />
            <Reveal show={a.needSystem}><textarea className="textarea" rows={2} value={a.systemText} onChange={(e) => set({ systemText: e.target.value })} placeholder="What system changes are needed?" /></Reveal>
            <YN value={a.needBehaviour} onChange={(v) => set({ needBehaviour: v })} label="Behaviour change" hint="What target users & key roles should do." />
            <Reveal show={a.needBehaviour}><textarea className="textarea" rows={2} value={a.behaviourText} onChange={(e) => set({ behaviourText: e.target.value })} placeholder="What should people do differently?" /></Reveal>
            <YN value={a.needLeadership} onChange={(v) => set({ needLeadership: v })} label="Leadership / organisation change" hint="Structure, roles, responsibilities, training." />
            <Reveal show={a.needLeadership}><textarea className="textarea" rows={2} value={a.leadershipText} onChange={(e) => set({ leadershipText: e.target.value })} placeholder="What needs to change in leadership or org?" /></Reveal>
          </div>
        )}

        {step === 3 && (
          <div className="intake-form">
            <YN value={a.hasFinancials} onChange={(v) => set({ hasFinancials: v })} label="Is there a financial case?" hint="Costs, savings and payback. Not every project needs one." />
            <Reveal show={a.hasFinancials}>
              <div className="intake-fin">
                <div><div className="field-label">Programme cost (one-off)</div><input className="input" value={a.costOneOff} onChange={(e) => set({ costOneOff: e.target.value })} placeholder="€480,000" /></div>
                <div><div className="field-label">Annual run cost</div><input className="input" value={a.costRun} onChange={(e) => set({ costRun: e.target.value })} placeholder="€120,000" /></div>
                <div><div className="field-label">Annual saving</div><input className="input" value={a.saving} onChange={(e) => set({ saving: e.target.value })} placeholder="€210,000" /></div>
                <div><div className="field-label">Payback period</div><input className="input" value={a.payback} onChange={(e) => set({ payback: e.target.value })} placeholder="~2.4 years" /></div>
              </div>
            </Reveal>
            {!a.hasFinancials && <p className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>No problem — we'll leave the financial section empty. You can add figures any time on the Business case page.</p>}
          </div>
        )}

        {step === 4 && (
          <div className="intake-form">
            <div className="intake-cols">
              <div>
                <div className="field-label">In scope <span className="ai-opt">one per line</span></div>
                <textarea className="textarea" rows={4} value={a.inScope} onChange={(e) => set({ inScope: e.target.value })} placeholder={"Customer records migration\nSingle sign-on\nNew portal core flows"} />
              </div>
              <div>
                <div className="field-label">Out of scope <span className="ai-opt">one per line</span></div>
                <textarea className="textarea" rows={4} value={a.outScope} onChange={(e) => set({ outScope: e.target.value })} placeholder={"Finance / ERP integration\nNative mobile apps\nPartner portals"} />
              </div>
            </div>
            <YN value={a.hasRisks} onChange={(v) => set({ hasRisks: v })} label="Do you already know of any risks?" hint="We'll add them to the risk register to score later." />
            <Reveal show={a.hasRisks}><textarea className="textarea" rows={3} value={a.risksText} onChange={(e) => set({ risksText: e.target.value })} placeholder={"One risk per line, e.g.\nLegacy data quality worse than expected\nKey user availability during UAT"} /></Reveal>
          </div>
        )}
      </div>

      <div className="modal-ft">
        {step > 0 ? <button className="btn btn-ghost" onClick={() => setStep(step - 1)}><Icon name="chevR" size={14} style={{ transform: "rotate(180deg)" }} /> Back</button>
                  : <button className="btn btn-ghost" onClick={onClose}>Cancel</button>}
        <div className="grow" />
        {step < STEPS.length - 1
          ? <button className="btn btn-primary" disabled={!canNext} onClick={() => setStep(step + 1)}>Continue <Icon name="chevR" size={14} /></button>
          : <button className="btn btn-primary" onClick={finish}><Icon name="check" size={15} /> Create project</button>}
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { IntakeWizard });
