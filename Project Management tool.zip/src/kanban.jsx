/* ============================================================
   KANBAN BOARD + CARD DETAIL MODAL + FILTER BAR
   Exposes window.Kanban, window.CardModal
   ============================================================ */
const { useState: useK, useMemo: useKM } = React;

const COLUMNS = [
  { id: "backlog", title: "Backlog", color: "var(--hue-backlog)" },
  { id: "inprogress", title: "In Progress", color: "var(--hue-progress)" },
  { id: "done", title: "Done", color: "var(--hue-done)" },
];
const PRIO = { high: { c: "var(--t-red)", label: "High" }, med: { c: "var(--t-amber)", label: "Med" }, low: { c: "var(--t-green)", label: "Low" } };

function initials(name) {
  if (!name) return "?";
  return name.split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
}
function tagById(tags, id) { return tags.find((t) => t.id === id); }
function assigneesOf(t) { return Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []); }
// shared task filter: category + assignee ("__unassigned" token matches tasks with no one assigned)
function taskMatchesFilter(t, fCat, fWho) {
  if (fCat && fCat.length && !fCat.includes(t.category)) return false;
  if (fWho && fWho.length) {
    const who = assigneesOf(t);
    const ok = fWho.some((w) => (w === "__unassigned" ? who.length === 0 : who.includes(w)));
    if (!ok) return false;
  }
  return true;
}

/* resolve a dependency to a display descriptor */
function resolveDep(dep, tasks, products, self) {
  if (dep.type === "task") {
    const t = tasks.find((x) => x.id === dep.refId);
    const blocked = t && t.status !== "done";
    // "Dependency block": this task starts before the task it needs output from finishes
    const violated = !!(blocked && self && self.start && t && t.end && new Date(self.start) < new Date(t.end));
    return { icon: "board", name: t ? t.title : "(removed task)", status: t?.status, blocked, violated, scope: "Task", external: false };
  }
  if (dep.type === "deliverable") {
    const p = products.find((x) => x.id === dep.refId);
    return { icon: "box", name: p ? p.name : "(removed deliverable)", scope: "Deliverable", external: false };
  }
  return { icon: "link", name: dep.label || "External dependency", scope: dep.scope || "External", external: true };
}

/* Dependency editor inside the card modal */
function DepEditor({ task, tasks, products, set }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const deps = task.deps || [];
  const addDep = (d) => { set({ deps: [...deps, { id: Store.uid("d"), ...d }] }); setOpen(false); };
  const rmDep = (id) => set({ deps: deps.filter((x) => x.id !== id) });
  const patchDep = (id, c) => set({ deps: deps.map((x) => (x.id === id ? { ...x, ...c } : x)) });
  const otherTasks = tasks.filter((x) => x.id !== task.id && !deps.some((d) => d.type === "task" && d.refId === x.id));
  // detect if adding a task as a dep would create a conflict (this task starts before that task ends)
  const wouldConflict = (otherId) => {
    const other = tasks.find((x) => x.id === otherId);
    if (!other || other.status === "done") return false;
    return task.start && other.end && new Date(task.start) < new Date(other.end);
  };
  const freeProducts = products.filter((p) => !deps.some((d) => d.type === "deliverable" && d.refId === p.id));
  // task dependencies whose deadline lands after this task starts — a "dependency block"
  const blockers = deps.filter((d) => d.type === "task").map((d) => resolveDep(d, tasks, products, task)).filter((r) => r.violated);

  return (
    <div>
      <div className="between" style={{ marginBottom: 8 }}>
        <div className="field-label" style={{ margin: 0 }}>Depends on</div>
        <div className="tagpicker" ref={ref}>
          <button className="btn btn-sm btn-ghost" onClick={() => setOpen((o) => !o)}><Icon name="plus" size={13} /> Add</button>
          {open && (
            <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 240 }}>
              <div className="dep-menu-label">Within this project · tasks</div>
              {otherTasks.length === 0 && <div className="dep-menu-empty">No other tasks</div>}
              {otherTasks.map((t) => {
                const conflict = wouldConflict(t.id);
                return (
                  <button key={t.id} className="tagpicker-opt" onClick={() => {
                    if (conflict && !confirm(`“${task.title}” starts before “${t.title}” ends. Add this dependency anyway?`)) return;
                    addDep({ type: "task", refId: t.id });
                  }}>
                    <span className={"status-dot s-" + t.status} style={{ margin: 0 }} />
                    <span className="grow">{t.title}</span>
                    {conflict && <span className="dep-menu-warn" title="This task starts before that one ends">⚠</span>}
                  </button>
                );
              })}
              <div className="dep-menu-label">Outside the project</div>
              <button className="tagpicker-opt" onClick={() => addDep({ type: "external", label: "New external dependency", scope: "" })}>
                <Icon name="link" size={14} /><span className="grow">External dependency…</span>
              </button>
            </div>
          )}
        </div>
      </div>
      {blockers.length > 0 && (
        <div className="dep-block-banner" title="Dependency block">
          <Icon name="warn" size={14} />
          <span><b>Dependency block</b> — needs output from {blockers.map((r) => r.name).join(", ")} first.</span>
        </div>
      )}
      {deps.length === 0 && <span className="muted" style={{ fontSize: 13 }}>No dependencies</span>}
      <div className="dep-list">
        {deps.map((d) => {
          const r = resolveDep(d, tasks, products, task);
          return (
            <div key={d.id} className={"dep-item" + (r.external ? " ext" : "") + (r.blocked ? " blocked" : "") + (r.violated ? " violated" : "")}>
              <span className="dep-ico"><Icon name={r.icon} size={14} /></span>
              {d.type === "external" ? (
                <span className="grow" style={{ minWidth: 0 }}>
                  <UI.Editable className="dep-name" value={d.label} onChange={(v) => patchDep(d.id, { label: v || "External dependency" })} placeholder="What is needed?" />
                  <UI.Editable className="dep-scope mono" value={d.scope} onChange={(v) => patchDep(d.id, { scope: v })} placeholder="source / owner…" />
                </span>
              ) : (
                <span className="grow" style={{ minWidth: 0 }}>
                  <span className="dep-name">{r.name}</span>
                  <span className="dep-scope mono">{r.violated ? "needs output from this task first" : r.scope + (r.blocked ? " · blocking" : r.status === "done" ? " · cleared" : "")}</span>
                </span>
              )}
              {r.violated && <span className="dep-flag" style={{ color: "var(--t-red)" }} title="Logical conflict">⚠</span>}
              {r.blocked && !r.violated && <span className="dep-flag" title="Not yet done">●</span>}
              <button className="chip-x" onClick={() => rmDep(d.id)}><Icon name="x" size={12} /></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* Link a task to the risks it remediates */
function RiskLinker({ task, risks }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const linked = risks.filter((r) => (r.taskIds || []).includes(task.id));
  const toggle = (risk) => {
    const cur = risk.taskIds || [];
    Store.patch("risks", risk.id, { taskIds: cur.includes(task.id) ? cur.filter((x) => x !== task.id) : [...cur, task.id] });
  };
  return (
    <div>
      <div className="between" style={{ marginBottom: 8 }}>
        <div className="field-label" style={{ margin: 0 }}>Remediates risk</div>
        <div className="tagpicker" ref={ref}>
          <button className="btn btn-sm btn-ghost" onClick={() => setOpen((o) => !o)}><Icon name="shield" size={13} /> Link</button>
          {open && (
            <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 240 }}>
              {risks.length === 0 && <div className="dep-menu-empty">No risks in this project</div>}
              {risks.map((r) => (
                <button key={r.id} className={"tagpicker-opt" + ((r.taskIds || []).includes(task.id) ? " on" : "")} onClick={() => toggle(r)}>
                  <span className="risk-score sm" style={{ width: 20, height: 20, fontSize: 11, background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
                  <span className="grow">{r.title}</span>
                  {(r.taskIds || []).includes(task.id) && <Icon name="check" size={14} />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      {linked.length === 0 && <span className="muted" style={{ fontSize: 13 }}>Not linked to a risk</span>}
      <div className="dep-list">
        {linked.map((r) => (
          <div key={r.id} className="dep-item risk">
            <span className="dep-ico" style={{ color: scoreColor(r.likelihood, r.impact) }}><Icon name="shield" size={14} /></span>
            <span className="grow" style={{ minWidth: 0 }}>
              <span className="dep-name">{r.title}</span>
              <span className="dep-scope mono">{task.status === "done" ? "this action complete" : "remediation in progress"}</span>
            </span>
            <button className="chip-x" onClick={() => Store.patch("risks", r.id, { taskIds: (r.taskIds || []).filter((x) => x !== task.id) })}><Icon name="x" size={12} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* Multiple assignees — chips + add-by-name with suggestions */
function AssigneePicker({ value, onChange }) {
  const s = Store.getState();
  const [text, setText] = useK("");
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const members = s.members || [];
  const known = [...new Set([
    ...members.map((m) => m.name),
    ...(s.tasks || []).flatMap((t) => assigneesOf(t)),
  ])].filter(Boolean);
  const add = (n) => {
    const name = (n || "").trim();
    if (name && !value.includes(name)) {
      onChange([...value, name]);
      // keep the canonical member list complete
      if (!members.some((m) => m.name.toLowerCase() === name.toLowerCase())) {
        const colors = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
        Store.add("members", { id: Store.uid("mem"), name, role: "", email: "", color: colors[members.length % colors.length] });
      }
    }
    setText(""); setOpen(false);
  };
  const remove = (n) => onChange(value.filter((x) => x !== n));
  const suggestions = known.filter((n) => !value.includes(n) && n.toLowerCase().includes(text.toLowerCase()));

  return (
    <div className="assignee-wrap" ref={ref}>
      <div className="assignee-chips">
        {value.length === 0 && <span className="muted" style={{ fontSize: 13 }}>No one assigned</span>}
        {value.map((n) => (
          <span key={n} className="assignee-chip"><span className="avatar" style={{ width: 18, height: 18, fontSize: 8 }}>{initials(n)}</span>{n}
            <span className="chip-x" onClick={() => remove(n)}><Icon name="x" size={11} /></span>
          </span>
        ))}
      </div>
      <div className="assignee-add">
        <input className="input" style={{ padding: "6px 9px", fontSize: 13 }} value={text} placeholder="Add a person…"
          onFocus={() => setOpen(true)} onChange={(e) => { setText(e.target.value); setOpen(true); }}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); add(text); } }} />
        {open && (text || suggestions.length > 0) && (
          <div className="tagpicker-menu panel" style={{ minWidth: "100%" }}>
            {text.trim() && !known.some((n) => n.toLowerCase() === text.trim().toLowerCase()) && (
              <button className="tagpicker-opt" onClick={() => add(text)}><Icon name="plus" size={13} /><span className="grow">Add “{text.trim()}”</span></button>
            )}
            {suggestions.slice(0, 6).map((n) => (
              <button key={n} className="tagpicker-opt" onClick={() => add(n)}>
                <span className="avatar" style={{ width: 18, height: 18, fontSize: 8 }}>{initials(n)}</span><span className="grow">{n}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Card detail modal ---------------- */
function CardModal({ task, onClose }) {
  const { tags, phases, categories, products, risks, tasks } = Store.useStore();
  const t = Store.getState().tasks.find((x) => x.id === task.id) || task;
  const set = (changes) => Store.patch("tasks", t.id, changes);
  const toggleArr = (key, id) => {
    const cur = t[key] || [];
    set({ [key]: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id] });
  };
  const linked = products.filter((p) => (p.taskIds || []).includes(t.id));

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <UI.Editable className="cm-title" tag="div" value={t.title} multiline
          onChange={(v) => set({ title: v || "Untitled task" })} placeholder="Task title" />
        <button className="btn btn-icon btn-ghost no-print" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="cm-grid">
          <div>
            <div className="cm-section">
              <div className="field-label">Description</div>
              <UI.Editable className="input" tag="div" value={t.desc} multiline
                style={{ minHeight: 90, lineHeight: 1.55 }}
                onChange={(v) => set({ desc: v })} placeholder="Add a description…" />
            </div>
            <div className="cm-section">
              <div className="between" style={{ marginBottom: 8 }}>
                <div className="field-label" style={{ margin: 0 }}>Tags</div>
                <UI.TagPicker options={tags} selected={t.tags || []} onToggle={(id) => toggleArr("tags", id)} placeholder="Tag" />
              </div>
              <div className="wrap">
                {(t.tags || []).length === 0 && <span className="muted" style={{ fontSize: 13 }}>No tags yet</span>}
                {(t.tags || []).map((id) => {
                  const tg = tagById(tags, id); if (!tg) return null;
                  return <UI.Chip key={id} label={tg.label} color={tg.color} dot onRemove={() => toggleArr("tags", id)} />;
                })}
              </div>
            </div>
            <div className="cm-section">
              <DepEditor task={t} tasks={tasks} products={products} set={set} />
            </div>
            <div className="cm-section">
              <RiskLinker task={t} risks={risks} />
            </div>
            {linked.length > 0 && (
              <div className="cm-section">
                <div className="field-label">Linked deliverables</div>
                {linked.map((p) => (
                  <div className="linked-prod" key={p.id}>
                    <Icon name={p.type === "excel" ? "sheet" : p.type === "image" ? "image" : p.type === "slides" ? "slides" : "doc"} size={15} />
                    <span className="grow">{p.name}</span>
                    <Icon name="link" size={13} />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="cm-side">
            <div className="cm-side-block">
              <div className="field-label">Status</div>
              <div className="statusseg">
                {COLUMNS.map((c) => (
                  <button key={c.id} className={t.status === c.id ? "on" : ""} onClick={() => set({ status: c.id })}>{c.title}</button>
                ))}
              </div>
            </div>
            <div className="cm-side-block">
              <div className="field-label">Priority</div>
              <div className="statusseg prioseg">
                {Object.entries(PRIO).map(([k, v]) => (
                  <button key={k} className={t.priority === k ? "on" : ""} style={{ "--prio-c": v.c }} onClick={() => set({ priority: k })}>{v.label}</button>
                ))}
              </div>
            </div>
            <div className="cm-side-block">
              <div className="field-label">Assignees</div>
              <AssigneePicker value={assigneesOf(t)} onChange={(v) => set({ assignees: v, assignee: undefined })} />
            </div>
            <div className="cm-side-block">
              <div className="field-label">Details</div>
              <div className="meta-row">
                <span className="meta-k">Phase</span>
                <PickInline options={phases} value={t.phase} onChange={(v) => set({ phase: v })} />
              </div>
              <div className="meta-row">
                <span className="meta-k">Category</span>
                <PickInline options={categories} value={t.category} onChange={(v) => set({ category: v })} />
              </div>
              <div className="meta-row">
                <span className="meta-k">Start</span>
                <input className="datemini" type="date" value={t.start || ""} onChange={(e) => set({ start: e.target.value })} />
              </div>
              <div className="meta-row">
                <span className="meta-k">End</span>
                <input className="datemini" type="date" value={t.end || ""} onChange={(e) => set({ end: e.target.value })} />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="modal-ft no-print">
        <button className="btn btn-ghost btn-danger" onClick={() => { Store.remove("tasks", t.id); onClose(); }}>
          <Icon name="trash" size={15} /> Delete
        </button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

// inline color-coded picker (phase/category)
function PickInline({ options, value, onChange }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const cur = options.find((o) => o.id === value);
  return (
    <div className="tagpicker" ref={ref}>
      <button className="pick-trigger" onClick={() => setOpen((o) => !o)}>
        {cur ? <UI.Chip label={cur.label} color={cur.color} dot /> : <span className="muted">Set…</span>}
      </button>
      {open && (
        <div className="tagpicker-menu panel" style={{ minWidth: 180 }}>
          <button className="tagpicker-opt" onClick={() => { onChange(null); setOpen(false); }}>
            <span className="chip-dot" style={{ background: "var(--ink-ghost)" }} /><span className="grow">None</span>
          </button>
          {options.map((o) => (
            <button key={o.id} className={"tagpicker-opt" + (value === o.id ? " on" : "")} onClick={() => { onChange(o.id); setOpen(false); }}>
              <span className="chip-dot" style={{ background: "var(--t-" + o.color + ")" }} />
              <span className="grow">{o.label}</span>
              {value === o.id && <Icon name="check" size={14} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Kanban card ---------------- */
function KCard({ task, tags, onOpen, onDragStart, onDragEnd, dragging }) {
  const cardTags = (task.tags || []).map((id) => tagById(tags, id)).filter(Boolean);
  return (
    <div
      className={"kcard" + (dragging ? " dragging" : "")}
      style={{ "--prio": PRIO[task.priority]?.c || "var(--line-strong)" }}
      draggable
      onDragStart={(e) => onDragStart(e, task)}
      onDragEnd={onDragEnd}
      onDoubleClick={() => onOpen(task)}
      title="Double-click to open"
    >
      <div className="kcard-title">{task.title}</div>
      {cardTags.length > 0 && (
        <div className="kcard-tags">
          {cardTags.map((tg) => <UI.Chip key={tg.id} label={tg.label} color={tg.color} dot />)}
        </div>
      )}
      <div className="kcard-foot">
        {(() => {
          const who = assigneesOf(task);
          if (!who.length) return <span className="muted" style={{ fontSize: 12 }}>Unassigned</span>;
          return (<>
            <span className="avatar-stack">{who.slice(0, 3).map((n, i) => <span key={i} className="avatar" title={n}>{initials(n)}</span>)}</span>
            <span className="muted" style={{ fontSize: 12, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{who.length === 1 ? who[0] : who.length + " people"}</span>
          </>);
        })()}
        <span className="prio-tick" style={{ color: PRIO[task.priority]?.c }}>{PRIO[task.priority]?.label}</span>
      </div>
    </div>
  );
}

/* ---------------- Board ---------------- */
function Kanban() {
  const s = Store.useStore();
  const { tasks, tags, phases, categories, members } = s;
  const [open, setOpen] = useK(null);
  const [drag, setDrag] = useK(null);
  const [over, setOver] = useK(null);
  const [q, setQ] = useK("");
  const [fTags, setFTags] = useK([]);
  const [fPhase, setFPhase] = useK([]);
  const [fCat, setFCat] = useK([]);
  const [fWho, setFWho] = useK([]);

  const filtered = useKM(() => {
    return tasks.filter((t) => {
      if (q && !(t.title + " " + (t.desc || "") + " " + assigneesOf(t).join(" ")).toLowerCase().includes(q.toLowerCase())) return false;
      if (fTags.length && !fTags.every((id) => (t.tags || []).includes(id))) return false;
      if (fPhase.length && !fPhase.includes(t.phase)) return false;
      if (fCat.length && !fCat.includes(t.category)) return false;
      if (fWho.length) {
        const who = assigneesOf(t);
        if (!fWho.some((w) => (w === "__unassigned" ? who.length === 0 : who.includes(w)))) return false;
      }
      return true;
    });
  }, [tasks, q, fTags, fPhase, fCat, fWho]);

  const toggle = (arr, set, id) => set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  const anyFilter = q || fTags.length || fPhase.length || fCat.length || fWho.length;

  const onDrop = (status) => {
    if (drag) Store.patch("tasks", drag.id, { status });
    setDrag(null); setOver(null);
  };
  const addTask = (status) => {
    const id = Store.uid("t");
    Store.add("tasks", { id, title: "New task", status, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [] });
    setOpen({ id });
  };

  return (
    <>
      <div className="filterbar no-print">
        <div className="search-box">
          <Icon name="search" size={15} />
          <input placeholder="Search tasks…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="filter-pills">
          {tags.map((tg) => (
            <button key={tg.id} className={"fpill" + (fTags.includes(tg.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + tg.color + ")" }} onClick={() => toggle(fTags, setFTags, tg.id)}>
              <span className="chip-dot" style={{ background: "var(--t-" + tg.color + ")" }} />{tg.label}
            </button>
          ))}
        </div>
        <div className="grow" />
        {anyFilter && (
          <button className="btn btn-sm btn-ghost" onClick={() => { setQ(""); setFTags([]); setFPhase([]); setFCat([]); setFWho([]); }}>
            <Icon name="x" size={13} /> Clear
          </button>
        )}
        <FilterMenu phases={phases} categories={categories} members={members} fPhase={fPhase} setFPhase={setFPhase} fCat={fCat} setFCat={setFCat} fWho={fWho} setFWho={setFWho} />
      </div>

      <div className="view-scroll">
        <div className="kanban">
          {COLUMNS.map((col) => {
            const items = filtered.filter((t) => t.status === col.id);
            return (
              <div
                key={col.id}
                className={"kcol" + (over === col.id ? " drop" : "")}
                onDragOver={(e) => { e.preventDefault(); setOver(col.id); }}
                onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(null); }}
                onDrop={() => onDrop(col.id)}
              >
                <div className="kcol-hd">
                  <span className="kcol-dot" style={{ background: col.color }} />
                  <span className="kcol-title">{col.title}</span>
                  <span className="kcol-count">{items.length}</span>
                </div>
                <div className="kcol-body">
                  {items.map((t) => (
                    <KCard key={t.id} task={t} tags={tags} onOpen={setOpen}
                      dragging={drag?.id === t.id}
                      onDragStart={(e, task) => { setDrag(task); e.dataTransfer.effectAllowed = "move"; }}
                      onDragEnd={() => { setDrag(null); setOver(null); }} />
                  ))}
                  {items.length === 0 && over !== col.id && <div style={{ height: 4 }} />}
                  <button className="kadd" onClick={() => addTask(col.id)}>
                    <Icon name="plus" size={14} /> Add task
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
    </>
  );
}

function FilterMenu({ phases, categories, members, fPhase, setFPhase, fCat, setFCat, fWho, setFWho }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const n = fPhase.length + fCat.length + (fWho ? fWho.length : 0);
  const toggle = (arr, set, id) => set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  return (
    <div className="tagpicker" ref={ref}>
      <button className={"btn btn-sm" + (n ? " btn-primary" : "")} onClick={() => setOpen((o) => !o)}>
        <Icon name="filter" size={14} /> Filter{n ? ` · ${n}` : ""}
      </button>
      {open && (
        <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 200, padding: 12 }}>
          <div className="field-label">Assigned to</div>
          <div className="wrap" style={{ marginBottom: 14 }}>
            {(members || []).map((m) => (
              <button key={m.id} className={"fpill" + (fWho.includes(m.name) ? " on" : "")} style={{ "--t-var": "var(--t-" + (m.color || "indigo") + ")" }} onClick={() => toggle(fWho, setFWho, m.name)}>
                <span className="chip-dot" style={{ background: "var(--t-" + (m.color || "indigo") + ")" }} />{m.name}
              </button>
            ))}
            <button className={"fpill" + (fWho.includes("__unassigned") ? " on" : "")} onClick={() => toggle(fWho, setFWho, "__unassigned")}>
              <span className="chip-dot" style={{ background: "var(--ink-ghost)" }} />Unassigned
            </button>
            {(members || []).length === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No members yet</span>}
          </div>
          <div className="field-label">Phase</div>
          <div className="wrap" style={{ marginBottom: 14 }}>
            {phases.map((p) => (
              <button key={p.id} className={"fpill" + (fPhase.includes(p.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + p.color + ")" }} onClick={() => toggle(fPhase, setFPhase, p.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + p.color + ")" }} />{p.label}
              </button>
            ))}
          </div>
          <div className="field-label">Category</div>
          <div className="wrap">
            {categories.map((c) => (
              <button key={c.id} className={"fpill" + (fCat.includes(c.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + c.color + ")" }} onClick={() => toggle(fCat, setFCat, c.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Kanban, CardModal, PickInline, COLUMNS, PRIO, initials, tagById, resolveDep, assigneesOf, taskMatchesFilter });
