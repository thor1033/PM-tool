/* ============================================================
   RISKS & MITIGATION — register + heatmap + task remediation
   Exposes window.Risks + remediation helpers
   ============================================================ */
const { useState: useR } = React;

const LVL = { low: 1, med: 2, high: 3 };
const LVL_LABEL = { low: "Low", med: "Medium", high: "High" };
const RISK_STATUS = { open: { label: "Open", c: "var(--t-red)" }, monitoring: { label: "Monitoring", c: "var(--t-amber)" }, closed: { label: "Closed", c: "var(--t-green)" } };
const scoreColor = (l, i) => { const s = LVL[l] * LVL[i]; if (s >= 6) return "var(--t-red)"; if (s >= 3) return "var(--t-amber)"; return "var(--t-green)"; };

// remediation state from linked tasks
function remediation(risk, tasks) {
  const ids = risk.taskIds || [];
  const linked = tasks.filter((t) => ids.includes(t.id));
  if (!linked.length) return { state: "none", done: 0, total: 0, linked };
  const done = linked.filter((t) => t.status === "done").length;
  const active = linked.some((t) => t.status === "inprogress");
  let state = "planned";
  if (done === linked.length) state = "remediated";
  else if (done > 0 || active) state = "progress";
  return { state, done, total: linked.length, linked };
}
const REMED = {
  none: { label: "No actions", c: "var(--ink-faint)" },
  planned: { label: "Remediation planned", c: "var(--t-indigo)" },
  progress: { label: "Remediating", c: "var(--t-amber)" },
  remediated: { label: "Remediated", c: "var(--t-green)" },
};

function Risks() {
  const { risks, tasks } = Store.useStore();
  const [open, setOpen] = useR(null);
  const [del, setDel] = useR(null);
  const add = () => { const id = Store.uid("r"); Store.add("risks", { id, title: "New risk", likelihood: "med", impact: "med", mitigation: "", owner: "", status: "open", taskIds: [] }); setOpen(id); };
  const sorted = [...risks].sort((a, b) => LVL[b.likelihood] * LVL[b.impact] - LVL[a.likelihood] * LVL[a.impact]);

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 520, fontSize: 14, lineHeight: 1.55 }}>
            Active risk register, ordered by exposure. Link <b>remediation actions</b> to a risk and it's marked remediated once those tasks are done.
          </p>
          <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add risk</button>
        </div>

        <div className="risk-layout">
          <div className="risk-list">
            {sorted.map((r) => {
              const rem = remediation(r, tasks);
              return (
                <div key={r.id} className="risk-card panel" onClick={() => setOpen(r.id)}>
                  <div className="risk-score" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</div>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="risk-title">{r.title}</div>
                    <p className="risk-mit">{r.mitigation || "No mitigation yet."}</p>
                    <div className="risk-meta">
                      <span className="chip" style={{ "--chip-c": RISK_STATUS[r.status]?.c }}><span className="chip-dot" />{RISK_STATUS[r.status]?.label}</span>
                      <span className="mono muted" style={{ fontSize: 11.5 }}>L:{LVL_LABEL[r.likelihood]} · I:{LVL_LABEL[r.impact]}</span>
                      {r.owner && <span className="muted" style={{ fontSize: 12.5 }}><Icon name="users" size={12} style={{ verticalAlign: -2 }} /> {r.owner}</span>}
                    </div>
                    {rem.state !== "none" && (
                      <div className="remed-row">
                        <span className="remed-chip" style={{ "--rc": REMED[rem.state].c }}>
                          {rem.state === "remediated" ? <Icon name="check" size={12} /> : <Icon name="shield" size={12} />}
                          {REMED[rem.state].label}
                        </span>
                        <div className="remed-bar"><div className="remed-fill" style={{ width: (rem.done / rem.total * 100) + "%", background: REMED[rem.state].c }} /></div>
                        <span className="mono muted" style={{ fontSize: 11 }}>{rem.done}/{rem.total} done</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="risk-side">
            <div className="eyebrow" style={{ marginBottom: 12 }}>Likelihood × Impact</div>
            <Heatmap risks={risks} onOpen={setOpen} />
            <div className="heat-legend">
              <span><i style={{ background: "var(--t-green)" }} /> Low</span>
              <span><i style={{ background: "var(--t-amber)" }} /> Medium</span>
              <span><i style={{ background: "var(--t-red)" }} /> High</span>
            </div>
          </div>
        </div>
      </div>
      {open && <RiskModal id={open} onClose={() => setOpen(null)} onDelete={() => { setDel(open); setOpen(null); }} />}
      {del && <UI.Confirm title="Delete risk?" body="This removes the risk from the register." onConfirm={() => Store.remove("risks", del)} onClose={() => setDel(null)} />}
    </div>
  );
}

function Heatmap({ risks, onOpen }) {
  const cells = [];
  for (let imp = 3; imp >= 1; imp--) {
    for (let lik = 1; lik <= 3; lik++) {
      const here = risks.filter((r) => LVL[r.likelihood] === lik && LVL[r.impact] === imp);
      const lk = Object.keys(LVL).find((k) => LVL[k] === lik), ik = Object.keys(LVL).find((k) => LVL[k] === imp);
      cells.push(
        <div key={lik + "-" + imp} className="heat-cell" style={{ background: "color-mix(in oklch, " + scoreColor(lk, ik) + " 16%, var(--panel))" }}>
          {here.map((r) => (<span key={r.id} className="heat-dot" style={{ background: scoreColor(r.likelihood, r.impact) }} title={r.title} onClick={() => onOpen(r.id)} />))}
        </div>
      );
    }
  }
  return (<div className="heat"><div className="heat-ylabel">Impact →</div><div className="heat-grid">{cells}</div><div className="heat-xlabel">Likelihood →</div></div>);
}

function RiskModal({ id, onClose, onDelete }) {
  const { tasks } = Store.useStore();
  const r = Store.getState().risks.find((x) => x.id === id);
  if (!r) return null;
  const set = (c) => Store.patch("risks", id, c);
  const rem = remediation(r, tasks);
  const toggleTask = (tid) => { const cur = r.taskIds || []; set({ taskIds: cur.includes(tid) ? cur.filter((x) => x !== tid) : [...cur, tid] }); };
  const linkedIds = r.taskIds || [];

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <UI.Editable className="cm-title" style={{ fontSize: 20 }} multiline value={r.title} onChange={(v) => set({ title: v || "Untitled risk" })} placeholder="Risk title" />
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="cm-grid">
          <div>
            <div className="cm-section">
              <div className="field-label">Mitigation plan</div>
              <UI.Editable className="input" tag="div" multiline value={r.mitigation} style={{ minHeight: 80, lineHeight: 1.55 }} onChange={(v) => set({ mitigation: v })} placeholder="How will this be prevented or contained?" />
            </div>
            <div className="cm-section">
              <div className="between" style={{ marginBottom: 8 }}>
                <div className="field-label" style={{ margin: 0 }}>Remediation actions</div>
                {rem.state !== "none" && <span className="remed-chip" style={{ "--rc": REMED[rem.state].c }}>{rem.state === "remediated" ? <Icon name="check" size={12} /> : <Icon name="shield" size={12} />}{REMED[rem.state].label}</span>}
              </div>
              <p className="muted" style={{ fontSize: 12.5, margin: "0 0 8px", lineHeight: 1.5 }}>Tie this risk to the tasks that actively reduce it. It becomes <b>Remediated</b> when all linked tasks are Done.</p>
              <div className="prod-tasklist">
                {tasks.length === 0 && <div className="act-empty">No tasks in this project yet.</div>}
                {tasks.map((t) => (
                  <button key={t.id} className={"prod-taskopt" + (linkedIds.includes(t.id) ? " on" : "")} onClick={() => toggleTask(t.id)}>
                    <span className={"checkbox" + (linkedIds.includes(t.id) ? " on" : "")}>{linkedIds.includes(t.id) && <Icon name="check" size={11} />}</span>
                    <span className="grow" style={{ textAlign: "left" }}>{t.title}</span>
                    <span className={"status-dot s-" + t.status} title={t.status} />
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="cm-side">
            <div><div className="field-label">Likelihood</div><Seg value={r.likelihood} options={LVL_LABEL} onChange={(v) => set({ likelihood: v })} /></div>
            <div><div className="field-label">Impact</div><Seg value={r.impact} options={LVL_LABEL} onChange={(v) => set({ impact: v })} /></div>
            <div><div className="field-label">Exposure</div>
              <div className="risk-expo" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}<span>/ 9</span></div>
            </div>
            <div><div className="field-label">Status</div>
              <div className="statusseg" style={{ flexWrap: "wrap" }}>{Object.entries(RISK_STATUS).map(([k, v]) => (<button key={k} className={r.status === k ? "on" : ""} style={{ "--prio-c": v.c, flex: "1 0 30%" }} onClick={() => set({ status: k })}>{v.label}</button>))}</div>
            </div>
            <div><div className="field-label">Owner</div><UI.Editable className="input" value={r.owner} onChange={(v) => set({ owner: v })} placeholder="Who owns this?" /></div>
          </div>
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost btn-danger" onClick={onDelete}><Icon name="trash" size={15} /> Delete</button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { Risks, LVL, LVL_LABEL, RISK_STATUS, scoreColor, remediation, REMED });
