/* ============================================================
   ICONS + shared small UI components
   Exposes window.Icon, window.UI
   ============================================================ */

const Icon = (function () {
  const S = (p, props = {}) =>
    React.createElement(
      "svg",
      { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", ...props },
      p
    );
  const P = (d, k) => React.createElement("path", { d, key: k });
  const L = (x1, y1, x2, y2, k) => React.createElement("line", { x1, y1, x2, y2, key: k });
  const C = (cx, cy, r, k) => React.createElement("circle", { cx, cy, r, key: k });
  const R = (x, y, w, h, rx, k) => React.createElement("rect", { x, y, width: w, height: h, rx, key: k });

  const paths = {
    home: () => [P("M3 10.5 12 3l9 7.5", "a"), P("M5 9.5V21h14V9.5", "b")],
    board: () => [R(3, 3, 18, 18, 2, "a"), L(9, 3, 9, 21, "b"), L(15, 3, 15, 21, "c")],
    list: () => [L(8, 6, 21, 6, "a"), L(8, 12, 21, 12, "b"), L(8, 18, 21, 18, "c"), C(3.5, 6, 0.6, "d"), C(3.5, 12, 0.6, "e"), C(3.5, 18, 0.6, "f")],
    timeline: () => [L(3, 7, 14, 7, "a"), L(8, 12, 20, 12, "b"), L(5, 17, 16, 17, "c")],
    users: () => [C(9, 8, 3.2, "a"), P("M3.5 20a5.5 5.5 0 0 1 11 0", "b"), P("M16 5.2a3.2 3.2 0 0 1 0 5.8", "c"), P("M17 14.5a5.5 5.5 0 0 1 3.5 5.5", "d")],
    shield: () => [P("M12 3 5 6v6c0 4 3 6.5 7 9 4-2.5 7-5 7-9V6l-7-3Z", "a"), P("M9 12l2 2 4-4", "b")],
    bulb: () => [P("M9 18h6", "a"), P("M10 21h4", "b"), P("M12 3a6 6 0 0 1 4 10.5c-.8.7-1 1.2-1 2.5H9c0-1.3-.2-1.8-1-2.5A6 6 0 0 1 12 3Z", "c")],
    org: () => [R(9, 3, 6, 4, 1, "a"), R(3, 17, 6, 4, 1, "b"), R(15, 17, 6, 4, 1, "c"), P("M12 7v4M6 17v-3h12v3", "d")],
    box: () => [P("M21 8 12 3 3 8l9 5 9-5Z", "a"), P("M3 8v8l9 5 9-5V8", "b"), L(12, 13, 12, 21, "c")],
    doc: () => [P("M14 3H6v18h12V7l-4-4Z", "a"), P("M14 3v4h4", "b")],
    plus: () => [L(12, 5, 12, 19, "a"), L(5, 12, 19, 12, "b")],
    x: () => [L(6, 6, 18, 18, "a"), L(18, 6, 6, 18, "b")],
    filter: () => [P("M3 5h18l-7 8v6l-4-2v-4L3 5Z", "a")],
    search: () => [C(11, 11, 7, "a"), L(20, 20, 16, 16, "b")],
    trash: () => [P("M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13", "a")],
    edit: () => [P("M4 20h4L19 9l-4-4L4 16v4Z", "a"), L(14, 6, 18, 10, "b")],
    copy: () => [R(9, 9, 11, 11, 2, "a"), P("M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1", "b")],
    check: () => [P("M5 12l4 4 10-10", "a")],
    chevR: () => [P("M9 6l6 6-6 6", "a")],
    chevD: () => [P("M6 9l6 6 6-6", "a")],
    drag: () => [C(9, 6, 0.8, "a"), C(15, 6, 0.8, "b"), C(9, 12, 0.8, "c"), C(15, 12, 0.8, "d"), C(9, 18, 0.8, "e"), C(15, 18, 0.8, "f")],
    upload: () => [P("M12 16V4", "a"), P("M7 9l5-5 5 5", "b"), P("M5 16v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3", "c")],
    print: () => [P("M6 9V3h12v6", "a"), P("M6 18H4v-6h16v6h-2", "b"), R(8, 14, 8, 6, 1, "c")],
    link: () => [P("M9 15l6-6", "a"), P("M11 7l1-1a3.5 3.5 0 0 1 5 5l-1 1", "b"), P("M13 17l-1 1a3.5 3.5 0 0 1-5-5l1-1", "c")],
    calendar: () => [R(3, 5, 18, 16, 2, "a"), L(3, 9, 21, 9, "b"), L(8, 3, 8, 6, "c"), L(16, 3, 16, 6, "d")],
    flag: () => [P("M5 21V4M5 4h11l-2 4 2 4H5", "a")],
    bolt: () => [P("M13 2 4 14h7l-1 8 9-12h-7l1-8Z", "a")],
    chat: () => [P("M4 5h16v11H9l-5 4V5Z", "a"), L(8, 9, 16, 9, "b"), L(8, 12.5, 13, 12.5, "c")],
    gauge: () => [P("M4 19a8 8 0 1 1 16 0", "a"), L(12, 19, 16, 11, "b"), C(12, 19, 0.7, "c")],
    gate: () => [R(3, 5, 18, 14, 1.5, "a"), L(8, 5, 8, 19, "b"), L(13, 5, 13, 19, "c"), L(3, 9.6, 21, 9.6, "d"), L(3, 14.3, 21, 14.3, "e")],
    idea: () => [P("M9 18h6", "a"), P("M10 21h4", "b"), P("M12 3a6 6 0 0 1 4 10.5c-.7.7-1 1.2-1 2.5H9c0-1.3-.3-1.8-1-2.5A6 6 0 0 1 12 3Z", "c")],
    spark: () => [P("M12 3l1.7 5.1a3 3 0 0 0 2.2 2.2L21 12l-5.1 1.7a3 3 0 0 0-2.2 2.2L12 21l-1.7-5.1a3 3 0 0 0-2.2-2.2L3 12l5.1-1.7a3 3 0 0 0 2.2-2.2Z", "a")],
    send: () => [P("M22 2 11 13", "a"), P("M22 2 15 22l-4-9-9-4 20-7Z", "b")],
    sort: () => [P("M7 4v16M7 4 3 8M7 4l4 4", "a"), P("M17 20V4M17 20l4-4M17 20l-4-4", "b")],
    dot: () => [C(12, 12, 3, "a")],
    arrowR: () => [L(5, 12, 19, 12, "a"), P("M13 6l6 6-6 6", "b")],
    layers: () => [P("M12 3 3 8l9 5 9-5-9-5Z", "a"), P("M3 13l9 5 9-5", "b")],
    tag: () => [P("M3 11V4h7l11 11-7 7L3 11Z", "a"), C(7.5, 7.5, 1.2, "b")],
    reset: () => [P("M4 12a8 8 0 1 1 2.3 5.6", "a"), P("M4 20v-5h5", "b")],
    clock: () => [C(12, 12, 9, "a"), P("M12 7v5l3.5 2", "b")],
    bell: () => [P("M6 9a6 6 0 0 1 12 0c0 5 2 7 2 7H4s2-2 2-7Z", "a"), P("M10 20a2 2 0 0 0 4 0", "b")],
    settings: () => [C(12, 12, 3, "a"), P("M19.4 15a1.5 1.5 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.5 1.5 0 0 0-2.5.6 1.5 1.5 0 0 0-1 1.4V22a2 2 0 1 1-4 0v-.1a1.5 1.5 0 0 0-2.6-1 1.5 1.5 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.5 1.5 0 0 0-.6-2.5 1.5 1.5 0 0 0-1.4-1H2a2 2 0 1 1 0-4h.1a1.5 1.5 0 0 0 1-2.6 1.5 1.5 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.5 1.5 0 0 0 1.7.3H8a1.5 1.5 0 0 0 1-1.4V2a2 2 0 1 1 4 0v.1a1.5 1.5 0 0 0 1 1.4 1.5 1.5 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.5 1.5 0 0 0-.3 1.7V8a1.5 1.5 0 0 0 1.4 1H22a2 2 0 1 1 0 4h-.1a1.5 1.5 0 0 0-1.4 1Z", "b")],
    file: () => [P("M14 3H6v18h12V7l-4-4Z", "a"), P("M14 3v4h4", "b")],
    image: () => [R(3, 4, 18, 16, 2, "a"), C(8.5, 9.5, 1.5, "b"), P("M21 16l-5-5L5 20", "c")],
    sheet: () => [R(4, 3, 16, 18, 2, "a"), L(4, 9, 20, 9, "b"), L(4, 15, 20, 15, "c"), L(12, 3, 12, 21, "d")],
    slides: () => [R(3, 4, 18, 12, 2, "a"), L(12, 16, 12, 20, "b"), L(8, 20, 16, 20, "c")],
    menu: () => [L(4, 7, 20, 7, "a"), L(4, 12, 20, 12, "b"), L(4, 17, 20, 17, "c")],
    warn: () => [P("M12 4 2 20h20L12 4Z", "a"), L(12, 10, 12, 14, "b"), C(12, 17, 0.6, "c")],
    target: () => [C(12, 12, 8, "a"), C(12, 12, 4, "b"), C(12, 12, 0.7, "c")],
    coin: () => [C(12, 12, 8, "a"), P("M12 8v8M9.5 10a2 2 0 0 1 4 0c0 2.5-4 1.5-4 4a2 2 0 0 0 4 0", "b")],
    scope: () => [P("M3 8V5a2 2 0 0 1 2-2h3", "a"), P("M16 3h3a2 2 0 0 1 2 2v3", "b"), P("M21 16v3a2 2 0 0 1-2 2h-3", "c"), P("M8 21H5a2 2 0 0 1-2-2v-3", "d"), C(12, 12, 2.4, "e")],
    swap: () => [P("M7 4 4 7l3 3", "a"), P("M4 7h13", "b"), P("M17 20l3-3-3-3", "c"), P("M20 17H7", "d")],
    comms: () => [P("M4 5h16v10H9l-4 4v-4H4V5Z", "a"), L(8, 9, 16, 9, "b"), L(8, 12, 13, 12, "c")],
    grid: () => [R(3, 3, 18, 18, 2, "a"), L(3, 9.5, 21, 9.5, "b"), L(9.5, 3, 9.5, 21, "c")],
    gift: () => [R(4, 8, 16, 4, 1, "a"), R(5.5, 12, 13, 9, 1, "b"), L(12, 8, 12, 21, "c"), P("M12 8C12 5.5 10 4 8.7 5S10 8 12 8M12 8c0-2.5 2-4 3.3-3S14 8 12 8", "d")],
    bundle: () => [P("M12 3 3 7.5v9L12 21l9-4.5v-9L12 3Z", "a"), P("M3 7.5 12 12l9-4.5", "b"), L(12, 12, 12, 21, "c"), P("M7.5 5.25 16.5 9.75", "d")],
    megaphone: () => [P("M3 11v2l12 5V6L3 11Z", "a"), P("M15 8.5a4 4 0 0 1 0 7", "b"), L(6, 13, 6, 19, "c")],
    chart: () => [P("M4 4v16h16", "a"), R(7, 12, 3, 5, 0.5, "b"), R(12, 9, 3, 8, 0.5, "c"), R(17, 6, 3, 11, 0.5, "d")],
    persona: () => [C(12, 8, 3.2, "a"), P("M5.5 20a6.5 6.5 0 0 1 13 0", "b")],
    inbound: () => [P("M12 3v10", "a"), P("M8 9l4 4 4-4", "b"), L(4, 19, 20, 19, "c")],
  };

  return function Icon({ name, size = 18, ...rest }) {
    const fn = paths[name];
    if (!fn) return null;
    return S(fn(), { width: size, height: size, ...rest });
  };
})();

/* ---------- shared UI bits ---------- */
const UI = (function () {
  const { useState, useRef, useEffect } = React;

  function Modal({ children, onClose, narrow }) {
    useEffect(() => {
      const h = (e) => e.key === "Escape" && onClose();
      window.addEventListener("keydown", h);
      return () => window.removeEventListener("keydown", h);
    }, [onClose]);
    return (
      <div className="scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
        <div className={"modal" + (narrow ? " narrow" : "")}>{children}</div>
      </div>
    );
  }

  function Chip({ label, color, dot, solid, onRemove }) {
    return (
      <span className={"chip tag-" + (color || "indigo") + (solid ? " solid" : "")}>
        {dot && <span className="chip-dot" />}
        {label}
        {onRemove && (
          <span className="chip-x" onClick={(e) => { e.stopPropagation(); onRemove(); }}>
            <Icon name="x" size={11} />
          </span>
        )}
      </span>
    );
  }

  // inline editable text — pencil icon on hover
  function Editable({ value, onChange, tag = "div", placeholder, className, multiline, noPencil, ...rest }) {
    const ref = useRef(null);
    const Tag = tag;
    const inner = (
      <Tag
        ref={ref}
        className={(className || "") + " editable-field"}
        contentEditable
        suppressContentEditableWarning
        spellCheck={false}
        data-ph={placeholder}
        onBlur={(e) => onChange(e.currentTarget.textContent)}
        onKeyDown={(e) => {
          if (!multiline && e.key === "Enter") { e.preventDefault(); e.currentTarget.blur(); }
        }}
        {...rest}
      >
        {value}
      </Tag>
    );
    if (noPencil || tag === "span") return inner;
    return (
      <div className="editable-wrap">
        {inner}
        <span className="editable-pencil no-print"><Icon name="edit" size={12} /></span>
      </div>
    );
  }

  // multi-select dropdown for tags
  function TagPicker({ options, selected, onToggle, placeholder = "Add…" }) {
    const [open, setOpen] = useState(false);
    const ref = useRef(null);
    useEffect(() => {
      const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
      document.addEventListener("mousedown", h);
      return () => document.removeEventListener("mousedown", h);
    }, []);
    return (
      <div className="tagpicker" ref={ref}>
        <button className="btn btn-sm btn-ghost" onClick={() => setOpen((o) => !o)}>
          <Icon name="plus" size={13} /> {placeholder}
        </button>
        {open && (
          <div className="tagpicker-menu panel">
            {options.map((o) => (
              <button key={o.id} className={"tagpicker-opt" + (selected.includes(o.id) ? " on" : "")} onClick={() => onToggle(o.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + o.color + ")" }} />
                <span className="grow">{o.label}</span>
                {selected.includes(o.id) && <Icon name="check" size={14} />}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  function Confirm({ title, body, confirmLabel = "Delete", onConfirm, onClose }) {
    return (
      <Modal narrow onClose={onClose}>
        <div className="modal-bd">
          <div className="card-hd" style={{ marginBottom: 6 }}>{title}</div>
          <p className="muted" style={{ margin: 0, fontSize: 14, lineHeight: 1.5 }}>{body}</p>
        </div>
        <div className="modal-ft">
          <button className="btn btn-ghost grow" onClick={onClose}>Cancel</button>
          <button className="btn btn-dark btn-danger" onClick={() => { onConfirm(); onClose(); }}>
            {confirmLabel}
          </button>
        </div>
      </Modal>
    );
  }

  return { Modal, Chip, Editable, TagPicker, Confirm };
})();

Object.assign(window, { Icon, UI });
