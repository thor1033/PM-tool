/* ============================================================
   PRODUCT CATALOGUE — local uploads + external shared-drive links
   Exposes window.Catalogue
   ============================================================ */
const { useState: useC, useEffect: useCE, useRef: useCR } = React;

const TYPE_FROM = (file) => {
  const n = (file.name || "").toLowerCase(), t = file.type || "";
  if (t.startsWith("image/")) return "image";
  if (t === "application/pdf" || n.endsWith(".pdf")) return "pdf";
  if (/\.(xlsx|xls|csv)$/.test(n) || t.includes("spreadsheet")) return "excel";
  if (/\.(pptx|ppt|key)$/.test(n) || t.includes("presentation")) return "slides";
  if (/\.(docx|doc|txt|md|rtf)$/.test(n) || t.includes("word")) return "doc";
  return "doc";
};
const TYPE_ICON = { image: "image", pdf: "doc", excel: "sheet", slides: "slides", doc: "file" };
const TYPE_LABEL = { image: "Image", pdf: "PDF", excel: "Spreadsheet", slides: "Presentation", doc: "Document" };
const fmtBytes = (b) => !b ? "" : b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(0) + " KB" : (b / 1048576).toFixed(1) + " MB";

function FileThumb({ product }) {
  const [url, setUrl] = useC(null);
  useCE(() => {
    let u;
    if (product.fileId && product.type === "image") {
      Store.files.get(product.fileId).then((blob) => { if (blob) { u = URL.createObjectURL(blob); setUrl(u); } });
    }
    return () => u && URL.revokeObjectURL(u);
  }, [product.fileId, product.type]);
  if (url) return <div className="cat-thumb img" style={{ backgroundImage: `url(${url})` }} />;
  const isExt = !!product.externalUrl;
  return (
    <div className={"cat-thumb t-" + product.type}>
      <Icon name={TYPE_ICON[product.type] || "file"} size={30} />
      {product.placeholder && <span className="cat-thumb-ph mono">placeholder</span>}
      {isExt && <span className="cat-thumb-ext mono"><Icon name="link" size={10} /> shared drive</span>}
    </div>
  );
}

function Catalogue() {
  const { products } = Store.useStore();
  const [open, setOpen] = useC(null);
  const [over, setOver] = useC(false);
  const [busy, setBusy] = useC(false);
  const [showAddLink, setShowAddLink] = useC(false);
  const inputRef = useCR(null);

  const ingest = async (files) => {
    setBusy(true);
    for (const file of files) {
      if (file.size > 30 * 1048576) { alert(`"${file.name}" is larger than 30 MB and was skipped.`); continue; }
      const fileId = Store.uid("file");
      try {
        await Store.files.put(fileId, file);
        Store.add("products", {
          id: Store.uid("p"), name: file.name, type: TYPE_FROM(file), fileId,
          size: file.size, taskIds: [], phase: null, date: new Date().toISOString().slice(0, 10), note: "", externalUrl: "",
        });
      } catch (e) { alert("Could not store file (browser storage may be full)."); }
    }
    setBusy(false);
  };
  const onDrop = (e) => { e.preventDefault(); setOver(false); if (e.dataTransfer.files.length) ingest([...e.dataTransfer.files]); };

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 560, fontSize: 14, lineHeight: 1.55 }}>
            Every deliverable produced by the project. Upload files locally, or <b>link to your shared drive</b> (SharePoint, OneDrive, Google Drive) so the whole team can access them.
          </p>
          <div className="row no-print" style={{ gap: 8 }}>
            <button className="btn" onClick={() => setShowAddLink(true)}><Icon name="link" size={15} /> Link from drive</button>
            <button className="btn btn-primary" onClick={() => inputRef.current.click()}><Icon name="upload" size={15} /> Upload file</button>
          </div>
          <input ref={inputRef} type="file" multiple hidden onChange={(e) => { ingest([...e.target.files]); e.target.value = ""; }} />
        </div>

        <div className={"cat-drop no-print" + (over ? " over" : "")}
          onDragOver={(e) => { e.preventDefault(); setOver(true); }}
          onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(false); }}
          onDrop={onDrop} onClick={() => inputRef.current.click()}>
          <Icon name={busy ? "reset" : "upload"} size={22} className={busy ? "spin" : ""} />
          <div><b>{busy ? "Storing…" : "Drop files here"}</b> <span className="muted">or click to browse — PDF, Excel, slides, images (≤30 MB, stored locally)</span></div>
        </div>

        <div className="cat-grid">
          {products.map((p) => (
            <div key={p.id} className="cat-card panel" onClick={() => setOpen(p.id)}>
              <FileThumb product={p} />
              <div className="cat-body">
                <div className="cat-name">{p.name}</div>
                <div className="cat-meta">
                  <span className="chip" style={{ "--chip-c": "var(--t-" + ({ image: "pink", pdf: "red", excel: "green", slides: "amber", doc: "blue" }[p.type] || "blue") + ")" }}>{TYPE_LABEL[p.type]}</span>
                  {p.externalUrl && <span className="chip" style={{ "--chip-c": "var(--t-teal)" }}><Icon name="link" size={10} /> Drive</span>}
                  {p.size && !p.externalUrl ? <span className="muted mono" style={{ fontSize: 11 }}>{fmtBytes(p.size)}</span> : null}
                </div>
                <div className="cat-links">
                  <Icon name="link" size={12} />
                  <span className="muted" style={{ fontSize: 12 }}>{(p.taskIds || []).length} linked action{(p.taskIds || []).length === 1 ? "" : "s"}</span>
                </div>
              </div>
            </div>
          ))}
          {products.length === 0 && <div className="empty" style={{ gridColumn: "1/-1" }}><div className="serif">No deliverables yet</div>Upload a file or link one from your shared drive.</div>}
        </div>
      </div>
      {open && <ProductModal id={open} onClose={() => setOpen(null)} />}
      {showAddLink && <AddLinkModal onClose={() => setShowAddLink(false)} />}
    </div>
  );
}

/* ---------- Add external link modal ---------- */
function AddLinkModal({ onClose }) {
  const [name, setName] = useC("");
  const [url, setUrl] = useC("");
  const [type, setType] = useC("doc");
  const submit = () => {
    Store.add("products", {
      id: Store.uid("p"), name: name.trim() || "Untitled", type,
      fileId: null, size: 0, taskIds: [], phase: null,
      date: new Date().toISOString().slice(0, 10), note: "",
      externalUrl: url.trim(),
    });
    onClose();
  };
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 20 }}>Link from shared drive</div>
          <div className="muted" style={{ fontSize: 13 }}>Paste a URL from SharePoint, OneDrive, Google Drive, or any web link. The file stays on the drive — Atlas just links to it.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="field-label">File name</div>
        <input className="input" autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Migration Plan v2.xlsx" style={{ marginBottom: 14 }} />
        <div className="field-label">Shared drive URL</div>
        <input className="input mono" style={{ fontSize: 13, marginBottom: 14 }} value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://company.sharepoint.com/…" />
        <div className="field-label">Type</div>
        <div className="wrap">
          {Object.entries(TYPE_LABEL).map(([k, v]) => (
            <button key={k} className={"fpill" + (type === k ? " on" : "")} style={{ "--t-var": "var(--t-" + ({ image: "pink", pdf: "red", excel: "green", slides: "amber", doc: "blue" }[k] || "blue") + ")" }} onClick={() => setType(k)}>
              <Icon name={TYPE_ICON[k]} size={13} /> {v}
            </button>
          ))}
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <div className="grow" />
        <button className="btn btn-primary" disabled={!url.trim()} onClick={submit}><Icon name="link" size={15} /> Add link</button>
      </div>
    </UI.Modal>
  );
}

/* ---------- Product modal (updated for external links) ---------- */
function ProductModal({ id, onClose }) {
  const { tasks, phases } = Store.useStore();
  const p = Store.getState().products.find((x) => x.id === id);
  const [dlUrl, setDlUrl] = useC(null);
  useCE(() => {
    let u;
    if (p && p.fileId) Store.files.get(p.fileId).then((b) => { if (b) { u = URL.createObjectURL(b); setDlUrl(u); } });
    return () => u && URL.revokeObjectURL(u);
  }, [p?.fileId]);
  if (!p) return null;
  const set = (c) => Store.patch("products", id, c);
  const toggleTask = (tid) => { const cur = p.taskIds || []; set({ taskIds: cur.includes(tid) ? cur.filter((x) => x !== tid) : [...cur, tid] }); };
  const isExt = !!p.externalUrl;

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className={"cat-thumb t-" + p.type} style={{ width: 52, height: 52, flex: "0 0 52px", borderRadius: 10 }}>
          <Icon name={TYPE_ICON[p.type] || "file"} size={24} />
        </div>
        <div className="grow" style={{ minWidth: 0 }}>
          <UI.Editable className="cm-title" style={{ fontSize: 20 }} multiline value={p.name} onChange={(v) => set({ name: v || "Untitled" })} placeholder="File name" />
          <div className="muted mono" style={{ fontSize: 12 }}>
            {TYPE_LABEL[p.type]}
            {p.size && !isExt ? " · " + fmtBytes(p.size) : ""}
            {isExt ? " · shared drive link" : ""}
            {p.placeholder ? " · sample placeholder" : ""}
          </div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        {p.type === "image" && dlUrl && <img src={dlUrl} className="cat-preview" alt={p.name} />}

        {isExt && (
          <div style={{ marginBottom: 18 }}>
            <div className="field-label">Shared drive URL</div>
            <div className="cat-exturl">
              <Icon name="link" size={14} />
              <input className="input mono" style={{ fontSize: 12, flex: 1 }} value={p.externalUrl} onChange={(e) => set({ externalUrl: e.target.value })} placeholder="https://…" />
              <a className="btn btn-sm" href={p.externalUrl} target="_blank" rel="noopener noreferrer"><Icon name="arrowR" size={13} /> Open</a>
            </div>
          </div>
        )}

        <div className="field-label">Notes</div>
        <UI.Editable className="input" tag="div" multiline value={p.note} style={{ minHeight: 60, lineHeight: 1.5, marginBottom: 18 }} onChange={(v) => set({ note: v })} placeholder="What is this deliverable?" />
        <div className="row" style={{ gap: 16, marginBottom: 18 }}>
          <div className="grow"><div className="field-label">Phase</div><PickInline options={phases} value={p.phase} onChange={(v) => set({ phase: v })} /></div>
          <div><div className="field-label">Date</div><input className="datemini" type="date" value={p.date || ""} onChange={(e) => set({ date: e.target.value })} /></div>
        </div>
        <div className="field-label">Linked actions</div>
        <div className="prod-tasklist">
          {tasks.map((t) => (
            <button key={t.id} className={"prod-taskopt" + ((p.taskIds || []).includes(t.id) ? " on" : "")} onClick={() => toggleTask(t.id)}>
              <span className={"checkbox" + ((p.taskIds || []).includes(t.id) ? " on" : "")}>{(p.taskIds || []).includes(t.id) && <Icon name="check" size={11} />}</span>
              <span className="grow" style={{ textAlign: "left" }}>{t.title}</span>
              <span className={"status-dot s-" + t.status} />
            </button>
          ))}
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost btn-danger" onClick={() => { if (p.fileId) Store.files.del(p.fileId); Store.remove("products", id); onClose(); }}><Icon name="trash" size={15} /> Delete</button>
        <div className="grow" />
        {isExt && <a className="btn" href={p.externalUrl} target="_blank" rel="noopener noreferrer"><Icon name="arrowR" size={13} /> Open in drive</a>}
        {dlUrl && !isExt && <a className="btn" href={dlUrl} download={p.name}><Icon name="upload" size={15} style={{ transform: "rotate(180deg)" }} /> Download</a>}
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { Catalogue });
