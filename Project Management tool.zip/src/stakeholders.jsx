/* ============================================================
   PROJECT MEMBERS — canonical people list
   Feeds the org chart, task assignees and the personal view.
   Exposes window.Members (+ legacy Stakeholders alias, Seg)
   ============================================================ */
const { useState: useS } = React;

const MEMBER_COLORS = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];

// where a member's name is referenced across the project
function memberUsage(s, name) {
  const taskCount = (s.tasks || []).filter((t) => assigneesOf(t).includes(name)).length;
  const inOrg = (s.org || []).some((o) => o.name === name);
  return { taskCount, inOrg };
}

function Members() {
  const s = Store.useStore();
  const members = s.members || [];
  const [del, setDel] = useS(null);

  const add = () => {
    const id = Store.uid("mem");
    Store.add("members", { id, name: "New member", role: "", email: "", color: MEMBER_COLORS[members.length % MEMBER_COLORS.length] });
  };
  const patch = (id, c) => Store.patch("members", id, c);
  const removeMember = (m) => {
    Store.removeMember(m.id);
    setDel(null);
  };

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 580, fontSize: 14, lineHeight: 1.55 }}>
            Everyone working on the project. This is the <b>master list</b> — names, roles and colour tags flow from here into task assignees, the capacity view and the roles &amp; org chart. Rename someone and it updates everywhere; recolour them and their tag changes across the tool.
          </p>
          <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add member</button>
        </div>

        <div className="mem-grid">
          {members.map((m) => {
            const use = memberUsage(s, m.name);
            return (
              <div key={m.id} className="mem-card panel">
                <div className="mem-card-top">
                  <span className="avatar mem-avatar" style={{ background: "var(--t-" + (m.color || "indigo") + ")" }}>{initials(m.name)}</span>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <UI.Editable className="mem-name" value={m.name} onChange={(v) => Store.renameMember(m.id, v)} placeholder="Full name" />
                    <UI.Editable className="mem-role" value={m.role} onChange={(v) => patch(m.id, { role: v })} placeholder="Role on the project" />
                  </div>
                  <button className="btn btn-icon btn-ghost btn-danger no-print mem-del" title="Remove member" onClick={() => setDel(m)}><Icon name="trash" size={14} /></button>
                </div>
                <div className="mem-colorpick no-print">
                  {MEMBER_COLORS.map((c) => (
                    <button key={c} className={"mem-swatch" + (m.color === c ? " on" : "")} style={{ background: "var(--t-" + c + ")" }} onClick={() => patch(m.id, { color: c })} />
                  ))}
                </div>
                <div className="mem-email">
                  <Icon name="users" size={13} />
                  <UI.Editable className="mono" value={m.email} onChange={(v) => patch(m.id, { email: v })} placeholder="email@company.example" />
                </div>
                <div className="mem-foot">
                  <span className="mem-stat"><b>{use.taskCount}</b> task{use.taskCount === 1 ? "" : "s"}</span>
                  <span className={"mem-stat" + (use.inOrg ? " on" : "")}>{use.inOrg ? "In org chart" : "Not in org chart"}</span>
                </div>
              </div>
            );
          })}
          {members.length === 0 && (
            <div className="empty" style={{ gridColumn: "1/-1" }}>
              <div className="serif">No members yet</div>Add the people working on this project.
            </div>
          )}
        </div>
      </div>
      {del && (
        <UI.Confirm
          title="Remove member?"
          body={`Remove ${del.name} from the project's member list? This won't unassign them from tasks they're already on.`}
          confirmLabel="Remove"
          onConfirm={() => removeMember(del)}
          onClose={() => setDel(null)}
        />
      )}
    </div>
  );
}

// keep Seg available (used by risks modal)
function Seg({ value, options, onChange }) {
  return (
    <div className="statusseg">
      {Object.entries(options).map(([k, v]) => (
        <button key={k} className={value === k ? "on" : ""} onClick={() => onChange(k)}>{v}</button>
      ))}
    </div>
  );
}

Object.assign(window, { Members, Stakeholders: Members, Seg });
