/* ============================================================
   GLOSSARY — terms + definitions, with global text highlighting
   Exposes window.Glossary, window.setupGlossaryHighlighter
   ============================================================ */
const { useState: useG } = React;

function Glossary() {
  const s = Store.useStore();
  const terms = s.glossary || [];
  const [q, setQ] = useG("");
  const [del, setDel] = useG(null);
  const [bulk, setBulk] = useG(false);

  const add = () => {
    const id = Store.uid("gl");
    Store.add("glossary", { id, term: "New term", definition: "" });
  };
  const patch = (id, c) => Store.patch("glossary", id, c);

  const sorted = [...terms].sort((a, b) => (a.term || "").localeCompare(b.term || ""));
  const filtered = q
    ? sorted.filter((t) => (t.term + " " + (t.definition || "")).toLowerCase().includes(q.toLowerCase()))
    : sorted;

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 600, fontSize: 14, lineHeight: 1.55 }}>
            Project-specific words and their meaning. Every term added here is automatically highlighted everywhere it appears in this project — hover any underlined word to read the definition.
          </p>
          <div className="row no-print" style={{ gap: 8 }}>
            <button className="btn" onClick={() => setBulk(true)}><Icon name="list" size={15} /> Paste list</button>
            <button className="btn btn-primary" onClick={add}><Icon name="plus" size={15} /> Add term</button>
          </div>
        </div>

        <div className="filterbar no-print" style={{ padding: 0, border: "none", background: "transparent", marginBottom: 16 }}>
          <div className="search-box" style={{ minWidth: 260 }}>
            <Icon name="search" size={15} />
            <input placeholder="Search terms…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
        </div>

        <div className="gloss-list">
          {filtered.length === 0 && (
            <div className="empty">
              <div className="serif">{q ? "No matches" : "No terms yet"}</div>
              {q ? "Try a different search." : (
                <div>
                  <p style={{ margin: "4px 0 14px" }}>Add the first term to get started — hover-tooltips appear everywhere you use it.</p>
                  <div className="row" style={{ gap: 8, justifyContent: "center" }}>
                    <button className="btn" onClick={() => setBulk(true)}><Icon name="list" size={14} /> Paste a list</button>
                    <button className="btn btn-primary" onClick={add}><Icon name="plus" size={14} /> Add one</button>
                  </div>
                </div>
              )}
            </div>
          )}
          {filtered.map((t) => (
            <div key={t.id} className="gloss-row panel no-gloss">
              <div className="gloss-row-main">
                <UI.Editable className="gloss-term-text serif" value={t.term} onChange={(v) => patch(t.id, { term: v || "(unnamed)" })} placeholder="Term" />
                <UI.Editable className="gloss-def" tag="div" multiline value={t.definition} onChange={(v) => patch(t.id, { definition: v })} placeholder="What does this term mean in this project?" />
              </div>
              <button className="btn btn-icon btn-ghost btn-danger no-print gloss-del" title="Remove" onClick={() => setDel(t)}><Icon name="trash" size={14} /></button>
            </div>
          ))}
        </div>
      </div>
      {del && (
        <UI.Confirm
          title="Remove term?"
          body={`Remove "${del.term}" from the glossary?`}
          confirmLabel="Remove"
          onConfirm={() => { Store.remove("glossary", del.id); setDel(null); }}
          onClose={() => setDel(null)}
        />
      )}
      {bulk && <BulkImport onClose={() => setBulk(false)} existing={terms} />}
    </div>
  );
}

/* ============================================================
   BULK IMPORT — paste a comma-separated list of terms
   Accepts:
     term1, term2, term3                   (just terms)
     term: definition, term: definition    (with definitions)
     One per line is fine too — separator can be comma or newline.
   ============================================================ */
function parseBulk(text) {
  if (!text) return [];
  // split on newlines first, then on commas — but only on commas NOT inside a definition.
  // simple heuristic: a "term: definition" entry ends at the next ", " followed by capital letter
  // safer approach: split on newlines OR semicolons OR commas-followed-by-space-and-letter
  const entries = text
    .split(/[\n;]+|,(?=\s*[A-Za-z])/)
    .map((s) => s.trim())
    .filter(Boolean);
  return entries.map((raw) => {
    // first colon, dash or en-dash separates term from definition
    const m = raw.match(/^([^:\u2013\u2014\-]+?)\s*[:\u2013\u2014\-]\s*(.+)$/);
    if (m) return { term: m[1].trim(), definition: m[2].trim() };
    return { term: raw.trim(), definition: "" };
  }).filter((e) => e.term);
}

function BulkImport({ onClose, existing }) {
  const [text, setText] = useG("");
  const [skipDupes, setSkipDupes] = useG(true);
  const parsed = parseBulk(text);
  const knownLower = new Set((existing || []).map((t) => (t.term || "").toLowerCase()));
  const newOnes = parsed.filter((p) => !skipDupes || !knownLower.has(p.term.toLowerCase()));
  const dupeCount = parsed.length - newOnes.length;

  const submit = () => {
    newOnes.forEach((p) => {
      Store.add("glossary", { id: Store.uid("gl"), term: p.term, definition: p.definition });
    });
    onClose();
  };

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="list" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Add many terms at once</div>
          <div className="muted" style={{ fontSize: 13 }}>Paste a comma-separated list. Add definitions with <span className="mono">term: definition</span>.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="field-label">Terms</div>
        <textarea
          className="textarea"
          rows={6}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={"SSO, ETL, UAT, CI/CD\n\nor with definitions, one per line:\nSSO: Single sign-on across all tools\nETL: Extract, Transform, Load pipeline\nhypercare: Intensive support window after go-live"}
          style={{ fontFamily: "var(--font-mono)", fontSize: 13, lineHeight: 1.55 }}
          autoFocus
        />
        <label className="sync-check" style={{ marginTop: 10 }}>
          <input type="checkbox" checked={skipDupes} onChange={(e) => setSkipDupes(e.target.checked)} />
          Skip terms that already exist
        </label>
        {parsed.length > 0 && (
          <div className="bulk-preview">
            <div className="bulk-preview-hd">
              Will add <b>{newOnes.length}</b> term{newOnes.length === 1 ? "" : "s"}
              {dupeCount > 0 && <span className="muted"> · {dupeCount} duplicate{dupeCount === 1 ? "" : "s"} skipped</span>}
            </div>
            <div className="bulk-preview-list">
              {newOnes.slice(0, 8).map((p, i) => (
                <div key={i} className="bulk-preview-item">
                  <span className="bulk-preview-term">{p.term}</span>
                  {p.definition && <span className="bulk-preview-def">— {p.definition}</span>}
                </div>
              ))}
              {newOnes.length > 8 && <div className="muted" style={{ fontSize: 12 }}>…and {newOnes.length - 8} more</div>}
            </div>
          </div>
        )}
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <div className="grow" />
        <button className="btn btn-primary" disabled={newOnes.length === 0} onClick={submit}>
          <Icon name="plus" size={15} /> Add {newOnes.length || ""} term{newOnes.length === 1 ? "" : "s"}
        </button>
      </div>
    </UI.Modal>
  );
}

/* ============================================================
   GLOBAL HIGHLIGHTER — walks the DOM and wraps glossary terms
   ============================================================ */
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

let glossPending = false;
let glossObserver = null;
let glossTooltipEl = null;
let lastGlossSig = "";

function ensureGlossTooltip() {
  if (glossTooltipEl) return glossTooltipEl;
  const el = document.createElement("div");
  el.className = "gloss-tip";
  el.style.display = "none";
  document.body.appendChild(el);
  glossTooltipEl = el;

  document.addEventListener("pointerover", (e) => {
    const mark = e.target.closest && e.target.closest(".gloss-mark");
    if (!mark) return;
    const def = mark.dataset.glossDef;
    const term = mark.dataset.glossTerm;
    if (!def) return;
    el.innerHTML = '<div class="gloss-tip-term">' + term + '</div><div class="gloss-tip-def">' + def.replace(/&/g, "&amp;").replace(/</g, "&lt;") + "</div>";
    el.style.display = "block";
    const r = mark.getBoundingClientRect();
    const w = el.offsetWidth, h = el.offsetHeight;
    let left = r.left + r.width / 2 - w / 2;
    let top = r.top - h - 8;
    if (top < 8) top = r.bottom + 8;
    left = Math.max(8, Math.min(window.innerWidth - w - 8, left));
    el.style.left = left + "px";
    el.style.top = top + "px";
  });
  document.addEventListener("pointerout", (e) => {
    const mark = e.target.closest && e.target.closest(".gloss-mark");
    if (mark && (!e.relatedTarget || !mark.contains(e.relatedTarget))) {
      el.style.display = "none";
    }
  });
  document.addEventListener("scroll", () => { el.style.display = "none"; }, true);
  return el;
}

function scanAndMark() {
  const state = (Store.getState && Store.getState()) || null;
  if (!state) return;
  const raw = (state.glossary || []).filter((g) => g.term && g.term.trim());
  // sort longest first so multi-word terms win over single-word substrings
  const terms = raw.slice().sort((a, b) => b.term.length - a.term.length);

  // remove existing marks if no terms
  const sig = terms.map((t) => t.term + "::" + (t.definition || "")).join("|");
  if (sig === lastGlossSig && document.querySelector(".gloss-mark")) {
    return; // nothing changed and marks already in place
  }
  lastGlossSig = sig;

  // unwrap any existing marks first (definitions might have changed)
  document.querySelectorAll(".gloss-mark").forEach((m) => {
    const parent = m.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(m.textContent), m);
    parent.normalize();
  });

  if (!terms.length) return;

  const defMap = new Map();
  terms.forEach((t) => defMap.set(t.term.toLowerCase(), t.definition || ""));
  const pattern = new RegExp("\\b(" + terms.map((t) => escapeRegex(t.term)).join("|") + ")\\b", "gi");

  const root = document.getElementById("root");
  if (!root) return;
  const SKIP_TAGS = new Set(["INPUT", "TEXTAREA", "SELECT", "SCRIPT", "STYLE", "OPTION", "BUTTON", "H1", "H2", "H3", "H4", "H5", "H6"]);
  const TITLE_SEL = 'h1,h2,h3,h4,h5,h6,[class*="title"],[class*="-name"],[class*="eyebrow"],[class*="-label"]';

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      let el = node.parentElement;
      while (el && el !== root) {
        if (el.isContentEditable) return NodeFilter.FILTER_REJECT;
        if (el.classList) {
          if (el.classList.contains("gloss-mark")) return NodeFilter.FILTER_REJECT;
          if (el.classList.contains("no-gloss")) return NodeFilter.FILTER_REJECT;
          if (el.classList.contains("gloss-tip")) return NodeFilter.FILTER_REJECT;
        }
        if (SKIP_TAGS.has(el.tagName)) return NodeFilter.FILTER_REJECT;
        if (el.matches && el.matches(TITLE_SEL)) return NodeFilter.FILTER_REJECT;
        el = el.parentElement;
      }
      pattern.lastIndex = 0;
      return pattern.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    },
  });

  const targets = [];
  let n;
  while ((n = walker.nextNode())) targets.push(n);

  targets.forEach((node) => {
    const text = node.nodeValue;
    pattern.lastIndex = 0;
    const parts = [];
    let last = 0;
    let m;
    while ((m = pattern.exec(text)) !== null) {
      if (m.index > last) parts.push({ t: text.slice(last, m.index), match: false });
      parts.push({ t: m[0], match: true });
      last = m.index + m[0].length;
    }
    if (last < text.length) parts.push({ t: text.slice(last), match: false });
    if (parts.length <= 1) return;

    const frag = document.createDocumentFragment();
    parts.forEach((part) => {
      if (part.match) {
        const span = document.createElement("span");
        span.className = "gloss-mark";
        span.dataset.glossTerm = part.t;
        span.dataset.glossDef = defMap.get(part.t.toLowerCase()) || "";
        span.textContent = part.t;
        frag.appendChild(span);
      } else {
        frag.appendChild(document.createTextNode(part.t));
      }
    });
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
  });
}

function scheduleScan() {
  if (glossPending) return;
  glossPending = true;
  setTimeout(() => {
    glossPending = false;
    try { scanAndMark(); } catch (e) { /* swallow */ }
  }, 250);
}

function setupGlossaryHighlighter() {
  ensureGlossTooltip();
  // initial scan after first paint
  scheduleScan();
  // observe DOM changes (React rerenders, navigation)
  if (glossObserver) glossObserver.disconnect();
  const root = document.getElementById("root");
  if (!root) return;
  glossObserver = new MutationObserver((mutations) => {
    // ignore mutations that ONLY touched gloss spans
    let real = false;
    for (const m of mutations) {
      if (m.target && m.target.classList && m.target.classList.contains("gloss-mark")) continue;
      real = true;
      break;
    }
    if (real) {
      // force re-evaluation against signature each call
      lastGlossSig = "";
      scheduleScan();
    }
  });
  glossObserver.observe(root, { childList: true, subtree: true, characterData: true });
}

Object.assign(window, { Glossary, setupGlossaryHighlighter });
