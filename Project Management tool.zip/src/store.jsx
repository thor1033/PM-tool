/* ============================================================
   STORE — multi-project state, persistence, file storage, seed
   Exposes window.Store
   v2: root { version, activeId, projects[] }; each project holds
       the full working set (tasks, risks, … businessCase).
   ============================================================ */
(function () {
  const KEY = "atlas.pm.v2";
  const uid = (p = "id") => p + "_" + Math.random().toString(36).slice(2, 9);
  const D = (y, m, d) => `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

  // ---------- shared taxonomy ----------
  function defaultTaxonomy() {
    return {
      tags: [],
      phases: [],
      categories: [],
    };
  }

  function blankBusinessCase() {
    return {
      purpose: "", problem: "",
      perspOurs: "", perspUsers: "", perspStakeholders: "", worsening: "", opportunities: "",
      outcomes: [],
      effProcess: "", effSystem: "", effBehaviour: "", effLeadership: "",
      financial: [
        { label: "Programme cost (one-off)", value: "", note: "" },
        { label: "Annual run cost", value: "", note: "" },
        { label: "Annual saving", value: "", note: "" },
        { label: "Payback period", value: "", note: "" },
      ],
      justification: "", effective: "",
    };
  }
  function blankScope() { return { inScope: [], outScope: [] }; }
  function blankChangePlan() { return { groups: [] }; }

  // ---------- fully-seeded sample project (Helios) ----------
  function heliosData() {
    const tax = {
      tags: [
        { id: "tg_fe", label: "Frontend", color: "blue" },
        { id: "tg_be", label: "Backend", color: "indigo" },
        { id: "tg_infra", label: "Infra", color: "teal" },
        { id: "tg_sec", label: "Security", color: "red" },
        { id: "tg_ux", label: "UX", color: "pink" },
        { id: "tg_data", label: "Data", color: "amber" },
        { id: "tg_docs", label: "Docs", color: "green" },
      ],
      phases: [
        { id: "ph_disc", label: "Discovery", color: "teal" },
        { id: "ph_design", label: "Design", color: "pink" },
        { id: "ph_build", label: "Build", color: "blue" },
        { id: "ph_launch", label: "Launch", color: "amber" },
      ],
      categories: [],
    };
    const T = {}; // friendly handles for cross-links
    const mk = (key, o) => { const id = uid("t"); T[key] = id; return { id, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o }; };
    const tasks = [
      mk("interviews", { title: "Stakeholder discovery interviews", status: "done", tags: ["tg_ux"], phase: "ph_disc", category: "ct_enable", priority: "med", assignees: ["Maya Rossi"], start: D(2026, 1, 6), end: D(2026, 1, 17), desc: "Run interviews with department leads to map current pain points and system usage." }),
      mk("audit", { title: "Audit legacy data schema", status: "done", tags: ["tg_data", "tg_be"], phase: "ph_disc", category: "ct_migr", priority: "high", assignees: ["Dev Patel"], start: D(2026, 1, 13), end: D(2026, 1, 28), desc: "Document the existing schema, identify orphaned tables and PII fields requiring special handling." }),
      mk("arch", { title: "Define target architecture", status: "inprogress", tags: ["tg_infra", "tg_be"], phase: "ph_design", category: "ct_plat", priority: "high", assignees: ["Dev Patel"], start: D(2026, 2, 2), end: D(2026, 2, 20), desc: "Produce the reference architecture covering services, data flow and the cloud landing zone." }),
      mk("ds", { title: "Design system & component library", status: "inprogress", tags: ["tg_ux", "tg_fe"], phase: "ph_design", category: "ct_plat", priority: "med", assignees: ["Maya Rossi"], start: D(2026, 2, 9), end: D(2026, 3, 6), desc: "Establish tokens, core components and accessibility baseline for the new portal." }),
      mk("threat", { title: "Security & threat model review", status: "inprogress", tags: ["tg_sec"], phase: "ph_design", category: "ct_compl", priority: "high", assignees: ["Sam Kaur"], start: D(2026, 2, 23), end: D(2026, 3, 6), desc: "Threat-model the proposed architecture; produce a register of controls and residual risks." }),
      mk("auth", { title: "Build authentication service", status: "backlog", tags: ["tg_be", "tg_sec"], phase: "ph_build", category: "ct_plat", priority: "high", assignees: ["Dev Patel"], start: D(2026, 3, 9), end: D(2026, 3, 27), desc: "SSO + role-based access, session handling and audit logging." }),
      mk("migrate", { title: "Migrate customer records", status: "backlog", tags: ["tg_data"], phase: "ph_build", category: "ct_migr", priority: "high", assignees: ["Dev Patel"], start: D(2026, 3, 16), end: D(2026, 4, 10), desc: "ETL pipeline with validation, dry-run and rollback plan for the customer dataset." }),
      mk("portal", { title: "Portal frontend — core flows", status: "backlog", tags: ["tg_fe", "tg_ux"], phase: "ph_build", category: "ct_plat", priority: "med", assignees: ["Lina Meyer"], start: D(2026, 3, 23), end: D(2026, 4, 24), desc: "Implement dashboard, search and record-detail flows against the new API." }),
      mk("landing", { title: "Provision production landing zone", status: "backlog", tags: ["tg_infra"], phase: "ph_build", category: "ct_plat", priority: "med", assignees: ["Sam Kaur"], start: D(2026, 4, 6), end: D(2026, 4, 20), desc: "IaC for networking, monitoring and the CI/CD release pipeline." }),
      mk("uat", { title: "User acceptance testing", status: "backlog", tags: ["tg_ux", "tg_docs"], phase: "ph_launch", category: "ct_enable", priority: "med", assignees: ["Maya Rossi"], start: D(2026, 4, 27), end: D(2026, 5, 8), desc: "Coordinate UAT with pilot departments, triage findings and sign-off." }),
      mk("cutover", { title: "Cutover & go-live runbook", status: "backlog", tags: ["tg_infra", "tg_docs"], phase: "ph_launch", category: "ct_migr", priority: "high", assignees: ["Sam Kaur"], start: D(2026, 5, 11), end: D(2026, 5, 22), desc: "Final cutover plan, comms, rollback criteria and hypercare schedule." }),
      mk("training", { title: "Training & enablement materials", status: "backlog", tags: ["tg_docs"], phase: "ph_launch", category: "ct_enable", priority: "low", assignees: ["Lina Meyer"], start: D(2026, 5, 4), end: D(2026, 5, 20), desc: "Quick-start guides, recorded walkthroughs and an admin handbook." }),
    ];
    const dep = (k, ...ds) => { const t = tasks.find((x) => x.id === T[k]); t.deps = ds; };
    dep("arch", { id: uid("d"), type: "task", refId: T.audit }, { id: uid("d"), type: "task", refId: T.interviews });
    dep("auth", { id: uid("d"), type: "task", refId: T.arch }, { id: uid("d"), type: "external", label: "Identity-provider licence", scope: "Vendor — Oktagon Inc." });
    dep("migrate", { id: uid("d"), type: "task", refId: T.audit });
    dep("portal", { id: uid("d"), type: "task", refId: T.auth }, { id: uid("d"), type: "task", refId: T.ds });
    dep("landing", { id: uid("d"), type: "external", label: "Cloud account approval", scope: "Finance Office" });
    dep("uat", { id: uid("d"), type: "task", refId: T.portal }, { id: uid("d"), type: "external", label: "Pilot users released", scope: "Other project — CRM Sunset" });

    const milestones = [
      { id: uid("ms"), title: "Discovery sign-off", type: "milestone", date: D(2026, 1, 30), category: "ct_enable", note: "Steering committee confirms discovery findings and greenlights Design." },
      { id: uid("ms"), title: "Architecture gate", type: "gate", date: D(2026, 2, 24), category: "ct_plat", note: "Go/no-go: target architecture must pass security and cost review before Build starts." },
      { id: uid("ms"), title: "Migration dry-run pass", type: "milestone", date: D(2026, 4, 6), category: "ct_migr", note: "ETL pipeline completes a full dry-run with < 2 % exception rate." },
      { id: uid("ms"), title: "UAT gate", type: "gate", date: D(2026, 5, 9), category: "ct_enable", note: "Go/no-go: UAT findings must be triaged and critical issues resolved before cutover planning." },
      { id: uid("ms"), title: "Go-live", type: "milestone", date: D(2026, 5, 25), category: "ct_plat", note: "Production cutover and hypercare begin." },
    ];

    const risks = [
      { id: uid("r"), title: "Legacy data quality worse than expected", likelihood: "high", impact: "high", mitigation: "Early profiling sprint; phased migration with validation gates and a rollback snapshot.", owner: "Dev Patel", status: "open", taskIds: [T.audit, T.migrate] },
      { id: uid("r"), title: "Key user availability during UAT", likelihood: "med", impact: "high", mitigation: "Book UAT windows now; secure backfill cover with department leads in writing.", owner: "Maya Rossi", status: "open", taskIds: [T.uat] },
      { id: uid("r"), title: "Compliance sign-off delays go-live", likelihood: "med", impact: "high", mitigation: "Engage Compliance from Design phase; maintain a live controls register.", owner: "Sam Kaur", status: "monitoring", taskIds: [T.threat] },
      { id: uid("r"), title: "Scope creep from adjacent teams", likelihood: "high", impact: "med", mitigation: "Strict change-control board; park requests in a phase-2 backlog.", owner: "Marcus L.", status: "open", taskIds: [] },
      { id: uid("r"), title: "Cloud cost overrun", likelihood: "low", impact: "med", mitigation: "Budget alerts and right-sizing review at end of Build phase.", owner: "Sam Kaur", status: "monitoring", taskIds: [] },
    ];
    const stakeholders = [
      { id: uid("s"), name: "Helen Vos", title: "VP, Operations", role: "Executive Sponsor", responsibility: "Owns the business case, unblocks funding and resolves cross-department conflicts.", influence: "high", interest: "high", contact: "h.vos@company.example" },
      { id: uid("s"), name: "Marcus Lindqvist", title: "Head of IT", role: "Project Owner", responsibility: "Accountable for delivery, scope and the technical decision record.", influence: "high", interest: "high", contact: "m.lindqvist@company.example" },
      { id: uid("s"), name: "Priya Nadar", title: "Compliance Lead", role: "Advisor", responsibility: "Signs off on data handling, retention and regulatory controls.", influence: "med", interest: "high", contact: "p.nadar@company.example" },
      { id: uid("s"), name: "Tom Berger", title: "Customer Service Lead", role: "Key User", responsibility: "Represents frontline users; coordinates UAT and adoption in the call centre.", influence: "med", interest: "high", contact: "t.berger@company.example" },
      { id: uid("s"), name: "Finance Office", title: "Budget Control", role: "Gatekeeper", responsibility: "Approves spend against milestones and tracks benefit realisation.", influence: "med", interest: "med", contact: "finance@company.example" },
    ];
    const findings = [
      { id: uid("f"), title: "62% of support tickets stem from manual data entry", category: "ct_enable", summary: "Process analysis of 1,200 tickets shows the majority are caused by duplicate or mistyped records in the legacy system. Automation here yields the largest support reduction.", source: "Support analytics, Q4" },
      { id: uid("f"), title: "Three shadow spreadsheets hold authoritative data", category: "ct_migr", summary: "Critical pricing and entitlement data lives outside the system of record. These must be ingested or the migration will lose authoritative state.", source: "Discovery interviews" },
      { id: uid("f"), title: "No single sign-on across tools", category: "ct_compl", summary: "Users maintain 4–6 separate logins. SSO is both a security win and the most requested usability improvement.", source: "User survey, n=84" },
      { id: uid("f"), title: "Peak load is 4× average at month-end", category: "ct_plat", summary: "Reporting and reconciliation create predictable spikes. Target architecture must autoscale to avoid the current month-end slowdowns.", source: "Infra telemetry" },
    ];
    const org = [
      { id: "o_sponsor", name: "Helen Vos", role: "Executive Sponsor", parent: null, note: "Steering committee chair", accent: "purple" },
      { id: "o_owner", name: "Marcus Lindqvist", role: "Project Owner", parent: "o_sponsor", note: "Single point of accountability", accent: "indigo" },
      { id: "o_pm", name: "You", role: "Project Manager", parent: "o_owner", note: "Day-to-day delivery & this tool", accent: "blue" },
      { id: "o_tech", name: "Dev Patel", role: "Tech Lead", parent: "o_pm", note: "Architecture & backend", accent: "teal" },
      { id: "o_design", name: "Maya Rossi", role: "Design Lead", parent: "o_pm", note: "UX & enablement", accent: "pink" },
      { id: "o_infra", name: "Sam Kaur", role: "Infra & Security", parent: "o_tech", note: "Landing zone, CI/CD, controls", accent: "green" },
      { id: "o_fe", name: "Lina Meyer", role: "Frontend Engineer", parent: "o_tech", note: "Portal & components", accent: "amber" },
    ];
    const products = [
      { id: uid("p"), name: "Discovery Report", type: "pdf", fileId: null, taskIds: [T.interviews], phase: "ph_disc", date: D(2026, 1, 20), note: "Synthesis of interviews and current-state analysis.", placeholder: true },
      { id: uid("p"), name: "Target Architecture Diagram", type: "image", fileId: null, taskIds: [T.arch], phase: "ph_design", date: D(2026, 2, 22), note: "Reference architecture, v0.9.", placeholder: true },
      { id: "PROD_MIGPLAN", name: "Migration Plan.xlsx", type: "excel", fileId: null, taskIds: [T.audit, T.migrate], phase: "ph_design", date: D(2026, 2, 28), note: "Table-by-table mapping and sequencing.", placeholder: true },
    ];
    const businessCase = {
      purpose: "Replace the end-of-life legacy customer platform with a secure, scalable portal that consolidates fragmented tools into a single system of record.",
      problem: "The current platform is unsupported, has no single sign-on, and depends on manual data entry that drives the majority of support tickets. Authoritative data lives in uncontrolled spreadsheets, creating compliance and continuity risk.",
      perspOurs: "For IT, the legacy platform is an unsupported continuity and compliance liability that absorbs a disproportionate share of the support budget.",
      perspUsers: "Frontline users juggle four to six separate logins and re-key data by hand — slow, error-prone and the top source of frustration in surveys.",
      perspStakeholders: "Compliance cannot evidence current data-retention controls, while Operations sees month-end slowdowns erode service levels.",
      worsening: "Every quarter more authoritative data drifts into uncontrolled spreadsheets, and the unsupported platform steadily raises the probability of an unplanned outage.",
      opportunities: "Consolidating the tools behind single sign-on is the most requested usability win and unlocks the automation that removes the largest category of support tickets.",
      outcomes: [
        "Reduce data-entry support tickets by 50% within two quarters of go-live.",
        "Achieve single sign-on across all customer-facing tools.",
        "Bring all authoritative data under a governed system of record.",
        "Eliminate month-end performance degradation through autoscaling.",
      ],
      effProcess: "Manual data-entry steps are replaced by validated intake. A new data-governance procedure (QMS / Cortex document) defines ownership, retention and the change-control path.",
      effSystem: "A new portal with SSO, a governed system of record, a validated migration pipeline and autoscaling infrastructure — plus a reusable component library and admin templates.",
      effBehaviour: "Frontline users work from a single portal and trust it as the source of truth; admins manage access and data through governed workflows instead of spreadsheets.",
      effLeadership: "Data-ownership accountability is set at department-lead level, the steering committee governs scope, and all key users complete enablement training before go-live.",
      financial: [
        { label: "Programme cost (one-off)", value: "€480,000", note: "Build, migration, licensing" },
        { label: "Annual run cost", value: "€120,000", note: "Cloud + support, replaces €165k legacy" },
        { label: "Annual saving", value: "€210,000", note: "Support effort + legacy retirement" },
        { label: "Payback period", value: "~2.4 years", note: "Excluding risk-avoidance value" },
      ],
      justification: "Beyond the direct saving, the legacy platform is a continuity and compliance liability: it is unsupported and cannot meet current data-retention obligations. Doing nothing increases the probability of an unplanned outage and a regulatory finding. The proposed programme is the lowest-risk path that also delivers measurable efficiency gains.",
      effective: "Delivery is phased — Discovery, Design, Build, Launch — with a go/no-go gate at the end of each phase. Benefits are tracked against the four target outcomes, reviewed monthly by the steering committee with the Finance Office validating realised savings.",
    };
    const scope = {
      inScope: [
        "Migration of the customer records dataset to the new system of record",
        "Single sign-on across all customer-facing tools",
        "New portal core flows: dashboard, search and record detail",
        "Production landing zone, monitoring and CI/CD pipeline",
        "UAT with pilot departments and go-live",
      ],
      outScope: [
        "Finance / ERP integration (deferred to phase 2)",
        "Native mobile applications",
        "Archive data older than seven years",
        "External partner portals",
        "Decommissioning of unrelated legacy systems",
      ],
    };
    const assessment = [
      { id: uid("as"), area: "Identity & access", asIs: "4–6 separate logins per user; no single sign-on.", toBe: "One single sign-on across every customer-facing tool." },
      { id: uid("as"), area: "Data ownership", asIs: "Authoritative data spread across uncontrolled spreadsheets.", toBe: "One governed system of record with clear ownership." },
      { id: uid("as"), area: "Support load", asIs: "Majority of tickets caused by manual data entry.", toBe: "50% fewer data-entry tickets via validated intake." },
      { id: uid("as"), area: "Performance", asIs: "Month-end slowdowns at ~4× average load.", toBe: "Autoscaling removes month-end degradation." },
      { id: uid("as"), area: "Platform support", asIs: "Legacy platform end-of-life and unsupported.", toBe: "Supported, patched cloud platform." },
    ];
    const commPlan = [
      { id: uid("cm"), audience: "All platform users", purpose: "Explain what is changing and how to work the new way.", messages: ["Users move from the legacy task planner to the new portal", "What the new flow looks like day-to-day", "Where to find support material and who to ask"], channels: ["Email", "Intranet"], timing: "Before go-live (≤ 1 week)", date: D(2026, 5, 18), owner: "Maya Rossi", deliverables: ["Launch email (drafted — needs sponsor input)", "Quick-start guide"] },
      { id: uid("cm"), audience: "All employees", purpose: "Inform everyone that the new system reduces request processing time.", messages: ["A new platform is live", "The benefit — faster, more reliable service", "Where to find it (via the portal)", "Where support material lives"], channels: ["Intranet article", "Info screens"], timing: "Launch week", date: D(2026, 5, 25), owner: "Lina Meyer", deliverables: ["Intranet article (done)", "Portal guide link", "Info-screen slide (sent)"] },
      { id: uid("cm"), audience: "Leadership team", purpose: "Ensure leaders actively and visibly champion the change.", messages: ["The change and its benefit (faster processing)", "Why we are doing it now", "Where to find it", "Where support material lives"], channels: ["Email", "Monthly leadership meeting"], timing: "Launch week", date: D(2026, 5, 22), owner: "Marcus Lindqvist", deliverables: ["Approved comms", "Leadership update deck"] },
      { id: uid("cm"), audience: "Senior management", purpose: "Inform of the change and ownership of processing-time delays.", messages: ["Summary of discovery findings", "Executive summary of what changes", "A tool that lets us set and track KPIs", "One-page summary of the new process"], channels: ["Email", "Meeting"], timing: "Post-launch, at the general meeting", date: D(2026, 6, 8), owner: "Helen Vos", deliverables: ["Presented slides"] },
    ];
    const changePlan = { groups: [
      { id: uid("cg"), label: "Delivery team", accent: "indigo", rows: [
        { id: uid("cr"), component: "Training package", description: "WHY the change, today vs. tomorrow, roles & responsibilities, how to use the new portal, retiring the old planner, practical exercises with dashboards and task types.", deliverables: ["Slide deck (why + how)", "User guides (new workflow)", "Training material"], owner: "Maya Rossi" },
        { id: uid("cr"), component: "New-joiner package", description: "Page on the portal with all flows and training for new employees' onboarding.", deliverables: ["User onboarding page"], owner: "Lina Meyer" },
        { id: uid("cr"), component: "Management follow-up", description: "Managers reinforce new behaviour through routines & KPIs, communication discipline and dashboards to secure team readiness.", deliverables: ["Check-in meeting plan", "Behaviour reinforcement guidance", "Dashboard usage guide"], owner: "Sam Kaur" },
        { id: uid("cr"), component: "Post-go-live support", description: "Monthly feedback review → fix → roll out, plus refresher training.", deliverables: ["Feedback analysis", "Continuous improvement log", "Ownership map (who handles what)"], owner: "Maya Rossi" },
      ] },
      { id: uid("cg"), label: "Organisation-wide", accent: "teal", rows: [
        { id: uid("cr"), component: "All-staff communication", description: "Inform the organisation of the new system and ways of working.", deliverables: ["Change announcement (intranet news)", "User-friendly portal for easy adoption"], owner: "Lina Meyer" },
        { id: uid("cr"), component: "Stakeholder communication", description: "Department managers, SMEs and requesters — organisation-wide messaging.", deliverables: ["Change announcement (email, webinars)", "Stakeholder-specific message packs", "Change timeline"], owner: "Marcus Lindqvist" },
        { id: uid("cr"), component: "Feedback loop", description: "Mechanism for reporting issues and proposing improvements.", deliverables: ["Feedback form / template", "'You said → we did' updates"], owner: "Maya Rossi" },
      ] },
    ] };
    const members = [
      { id: "mem_you", name: "You", role: "Project Manager", email: "", color: "blue" },
      { id: "mem_marcus", name: "Marcus Lindqvist", role: "Project Owner", email: "m.lindqvist@company.example", color: "indigo" },
      { id: "mem_helen", name: "Helen Vos", role: "Executive Sponsor", email: "h.vos@company.example", color: "purple" },
      { id: "mem_dev", name: "Dev Patel", role: "Tech Lead", email: "d.patel@company.example", color: "teal" },
      { id: "mem_maya", name: "Maya Rossi", role: "Design Lead", email: "m.rossi@company.example", color: "pink" },
      { id: "mem_sam", name: "Sam Kaur", role: "Infra & Security", email: "s.kaur@company.example", color: "green" },
      { id: "mem_lina", name: "Lina Meyer", role: "Frontend Engineer", email: "l.meyer@company.example", color: "amber" },
      { id: "mem_priya", name: "Priya Nadar", role: "Compliance Lead", email: "p.nadar@company.example", color: "red" },
      { id: "mem_tom", name: "Tom Berger", role: "Customer Service Lead", email: "t.berger@company.example", color: "blue" },
    ];
    const glossary = [
      { id: "gl_sso", term: "SSO", definition: "Single sign-on — one login that authenticates the user across all customer-facing tools." },
      { id: "gl_etl", term: "ETL", definition: "Extract, Transform, Load — the pipeline that moves data from the legacy system into the new system of record." },
      { id: "gl_uat", term: "UAT", definition: "User Acceptance Testing — pilot users exercise the system end-to-end and sign off before go-live." },
      { id: "gl_cicd", term: "CI/CD", definition: "Continuous Integration and Continuous Deployment — the automated build, test and release pipeline." },
      { id: "gl_qms", term: "QMS", definition: "Quality Management System — the controlled set of procedures that govern how we work." },
      { id: "gl_cortex", term: "Cortex", definition: "The internal document management system where governed procedures and policies live." },
      { id: "gl_hypercare", term: "hypercare", definition: "The intensive support window immediately after go-live where the project team is on standby to triage issues fast." },
      { id: "gl_landingzone", term: "landing zone", definition: "A pre-configured, governed cloud environment (networking, identity, monitoring) ready to host workloads." },
    ];
    return { meta: { project: "Helios Platform Modernisation", code: "PRJ-2026-014" }, tasks, members, stakeholders, risks, findings, org, products, businessCase, scope, assessment, commPlan, changePlan, milestones, glossary, ...tax };
  }

  // ---------- a lighter second sample ----------
  function intranetData() {
    const tax = defaultTaxonomy();
    const t = (o) => ({ id: uid("t"), tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o });
    const tasks = [
      t({ title: "Content audit of current intranet", status: "done", phase: "ph_disc", category: "ct_enable", assignees: ["Noah Frank"], start: D(2026, 2, 2), end: D(2026, 2, 13), tags: ["tg_docs"] }),
      t({ title: "Information architecture workshop", status: "inprogress", phase: "ph_design", category: "ct_plat", assignees: ["Aïsha Bello"], start: D(2026, 2, 16), end: D(2026, 2, 27), tags: ["tg_ux"], priority: "high" }),
      t({ title: "Search relevance tuning", status: "backlog", phase: "ph_build", category: "ct_plat", assignees: ["Noah Frank"], start: D(2026, 3, 9), end: D(2026, 3, 20), tags: ["tg_be"] }),
      t({ title: "Editor onboarding guide", status: "backlog", phase: "ph_launch", category: "ct_enable", assignees: ["Aïsha Bello"], start: D(2026, 3, 23), end: D(2026, 4, 3), tags: ["tg_docs"], priority: "low" }),
    ];
    const org = [
      { id: "o_owner", name: "Aïsha Bello", role: "Project Owner", parent: null, note: "Comms & internal tooling", accent: "indigo" },
      { id: "o_eng", name: "Noah Frank", role: "Engineer", parent: "o_owner", note: "Build & search", accent: "teal" },
    ];
    const risks = [
      { id: uid("r"), title: "Low editor adoption after launch", likelihood: "med", impact: "med", mitigation: "Champions programme and office hours in first month.", owner: "Aïsha Bello", status: "open", taskIds: [tasks[3].id] },
    ];
    const members = [
      { id: "mem_aisha", name: "Aïsha Bello", role: "Content Lead", email: "", color: "teal" },
    ];
    return { meta: { project: "Intranet Refresh", code: "PRJ-2026-021" }, tasks, members, stakeholders: [], risks, findings: [], org, products: [], businessCase: blankBusinessCase(), scope: blankScope(), assessment: [], commPlan: [], changePlan: blankChangePlan(), milestones: [], ...tax };
  }

  function makeProject(color, data, ageDays = 0, parentId = null) {
    return { id: uid("prj"), color, parentId, createdAt: Date.now() - ageDays * 86400000, updatedAt: Date.now() - Math.floor(ageDays / 2) * 86400000, ...data };
  }

  // a lightweight subproject under Helios, to demonstrate grouping
  function migrationData() {
    const tax = defaultTaxonomy();
    const t = (o) => ({ id: uid("t"), tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o });
    const tasks = [
      t({ title: "Profile legacy data quality", status: "done", phase: "ph_disc", category: "ct_migr", assignees: ["Dev Patel"], start: D(2026, 2, 2), end: D(2026, 2, 13), tags: ["tg_data"], priority: "high" }),
      t({ title: "Build ETL mapping spec", status: "inprogress", phase: "ph_design", category: "ct_migr", assignees: ["Dev Patel", "Lina Meyer"], start: D(2026, 2, 16), end: D(2026, 3, 6), tags: ["tg_data", "tg_be"], priority: "high" }),
      t({ title: "Dry-run migration in staging", status: "backlog", phase: "ph_build", category: "ct_migr", assignees: ["Dev Patel"], start: D(2026, 3, 9), end: D(2026, 3, 27), tags: ["tg_data"], priority: "med" }),
      t({ title: "Reconciliation & sign-off report", status: "backlog", phase: "ph_launch", category: "ct_compl", assignees: ["Sam Kaur"], start: D(2026, 3, 30), end: D(2026, 4, 10), tags: ["tg_docs"], priority: "med" }),
    ];
    const risks = [
      { id: uid("r"), title: "Source data exceeds validation tolerance", likelihood: "high", impact: "high", mitigation: "Tighten cleansing rules; gate cutover on a <2% exception rate.", owner: "Dev Patel", status: "open", taskIds: [tasks[0].id, tasks[2].id] },
    ];
    const org = [
      { id: "o_lead", name: "Dev Patel", role: "Migration Lead", parent: null, note: "Owns the data workstream", accent: "teal" },
      { id: "o_eng", name: "Lina Meyer", role: "Data Engineer", parent: "o_lead", note: "ETL & validation", accent: "amber" },
    ];
    return { meta: { project: "Customer Data Migration", code: "" }, tasks, members: [{ id: "mem_dev2", name: "Dev Patel", role: "Migration Lead", email: "", color: "teal" }, { id: "mem_lina2", name: "Lina Meyer", role: "Data Engineer", email: "", color: "amber" }], stakeholders: [], risks, findings: [], org, products: [], businessCase: blankBusinessCase(), scope: blankScope(), assessment: [], commPlan: [], changePlan: blankChangePlan(), milestones: [], ...tax };
  }

  // ---------- fully-populated demo project: every field filled (Meridian) ----------
  function showcaseData() {
    const tax = {
      tags: [
        { id: "tg_ios", label: "iOS", color: "blue" },
        { id: "tg_droid", label: "Android", color: "green" },
        { id: "tg_api", label: "API", color: "indigo" },
        { id: "tg_sec", label: "Security", color: "red" },
        { id: "tg_ux", label: "UX", color: "pink" },
        { id: "tg_data", label: "Analytics", color: "amber" },
        { id: "tg_legal", label: "Legal", color: "teal" },
      ],
      phases: [
        { id: "ph_disc", label: "Discovery", color: "teal" },
        { id: "ph_design", label: "Design", color: "pink" },
        { id: "ph_build", label: "Build", color: "blue" },
        { id: "ph_beta", label: "Beta", color: "indigo" },
        { id: "ph_launch", label: "Launch", color: "amber" },
      ],
      categories: [
        { id: "ct_research", label: "Customer Research", color: "teal" },
        { id: "ct_product", label: "Product & Design", color: "pink" },
        { id: "ct_eng", label: "Engineering", color: "blue" },
        { id: "ct_risk", label: "Risk & Compliance", color: "red" },
        { id: "ct_gtm", label: "Go-to-Market", color: "amber" },
      ],
    };
    const T = {};
    const mk = (key, o) => { const id = uid("t"); T[key] = id; return { id, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o }; };
    const tasks = [
      mk("interviews", { title: "Customer interviews & needs analysis", status: "done", tags: ["tg_ux", "tg_data"], phase: "ph_disc", category: "ct_research", priority: "med", assignees: ["Elena Duarte", "Tom\u00e1s Silva"], start: D(2026, 1, 12), end: D(2026, 1, 23), desc: "Twenty depth interviews with target segments to map jobs-to-be-done, current banking frustrations and willingness to switch." }),
      mk("benchmark", { title: "Market & competitor benchmark", status: "done", tags: ["tg_data"], phase: "ph_disc", category: "ct_research", priority: "med", assignees: ["Nina Petrova"], start: D(2026, 1, 19), end: D(2026, 1, 30), desc: "Feature and pricing teardown of eight challenger banks; identify the gaps Meridian can own at launch." }),
      mk("principles", { title: "Product principles & brand kit", status: "done", tags: ["tg_ux"], phase: "ph_design", category: "ct_product", priority: "low", assignees: ["Tom\u00e1s Silva"], start: D(2026, 2, 2), end: D(2026, 2, 20), desc: "Define the five product principles, tone of voice, colour system and the icon set used across both apps." }),
      mk("flows", { title: "Design account & payment flows", status: "inprogress", tags: ["tg_ux", "tg_ios"], phase: "ph_design", category: "ct_product", priority: "high", assignees: ["Tom\u00e1s Silva", "Elena Duarte"], start: D(2026, 2, 16), end: D(2026, 3, 13), desc: "End-to-end flows for onboarding, account opening, payments and card freeze \u2014 prototyped and usability-tested." }),
      mk("api", { title: "Core banking API integration", status: "inprogress", tags: ["tg_api", "tg_sec"], phase: "ph_build", category: "ct_eng", priority: "high", assignees: ["Raj Malhotra", "Sophie Tran"], start: D(2026, 3, 2), end: D(2026, 4, 3), desc: "Integrate the core-banking ledger, payments rail and KYC provider behind a unified internal API." }),
      mk("ios", { title: "iOS app \u2014 onboarding & dashboard", status: "backlog", tags: ["tg_ios"], phase: "ph_build", category: "ct_eng", priority: "high", assignees: ["Sophie Tran"], start: D(2026, 3, 16), end: D(2026, 4, 24), desc: "Native iOS build of onboarding, the account dashboard and the payments flow against the new API." }),
      mk("android", { title: "Android app \u2014 onboarding & dashboard", status: "backlog", tags: ["tg_droid"], phase: "ph_build", category: "ct_eng", priority: "high", assignees: ["Marcus Webb"], start: D(2026, 3, 23), end: D(2026, 5, 1), desc: "Native Android build at feature parity with iOS, sharing the same design system and API contract." }),
      mk("security", { title: "Security audit & penetration test", status: "inprogress", tags: ["tg_sec"], phase: "ph_build", category: "ct_risk", priority: "high", assignees: ["Aisha Khan"], start: D(2026, 3, 9), end: D(2026, 3, 27), desc: "Third-party penetration test of the API and mobile clients; produce a remediation register with severities." }),
      mk("compliance", { title: "Regulatory & KYC sign-off", status: "backlog", tags: ["tg_legal", "tg_sec"], phase: "ph_beta", category: "ct_risk", priority: "high", assignees: ["David Olsen"], start: D(2026, 4, 6), end: D(2026, 4, 24), desc: "Evidence KYC/AML controls, complete the regulator's pre-launch checklist and obtain written sign-off." }),
      mk("beta", { title: "Closed beta with 500 customers", status: "backlog", tags: ["tg_data", "tg_ux"], phase: "ph_beta", category: "ct_product", priority: "med", assignees: ["Elena Duarte", "Nina Petrova"], start: D(2026, 5, 4), end: D(2026, 5, 29), desc: "Invite-only beta to validate onboarding conversion, crash-free rate and the support load before launch." }),
      mk("gtm", { title: "Launch campaign & app-store release", status: "backlog", tags: ["tg_data"], phase: "ph_launch", category: "ct_gtm", priority: "high", assignees: ["Carla Mendes"], start: D(2026, 6, 1), end: D(2026, 6, 26), desc: "Coordinate the app-store submission, paid acquisition campaign, PR and the referral programme for launch." }),
    ];
    const dep = (k, ...ds) => { const t = tasks.find((x) => x.id === T[k]); t.deps = ds; };
    dep("flows", { id: uid("d"), type: "task", refId: T.interviews }, { id: uid("d"), type: "task", refId: T.benchmark });
    dep("api", { id: uid("d"), type: "task", refId: T.flows }, { id: uid("d"), type: "external", label: "Core-banking sandbox access", scope: "Vendor \u2014 Thought Machine" });
    dep("ios", { id: uid("d"), type: "task", refId: T.api }, { id: uid("d"), type: "task", refId: T.flows });
    dep("android", { id: uid("d"), type: "task", refId: T.api }, { id: uid("d"), type: "task", refId: T.flows });
    dep("security", { id: uid("d"), type: "task", refId: T.api });
    dep("compliance", { id: uid("d"), type: "task", refId: T.security }, { id: uid("d"), type: "external", label: "FCA reference number", scope: "Regulator \u2014 FCA" });
    dep("beta", { id: uid("d"), type: "task", refId: T.ios }, { id: uid("d"), type: "task", refId: T.android });
    dep("gtm", { id: uid("d"), type: "task", refId: T.beta }, { id: uid("d"), type: "task", refId: T.compliance });

    const milestones = [
      { id: uid("ms"), title: "Discovery complete", type: "milestone", date: D(2026, 1, 30), category: "ct_research", note: "Research synthesis signed off; product direction agreed with the sponsor." },
      { id: uid("ms"), title: "Design sign-off", type: "gate", date: D(2026, 3, 13), category: "ct_product", note: "Go/no-go: core flows must pass usability testing before engineering commits to the build." },
      { id: uid("ms"), title: "Security clearance", type: "gate", date: D(2026, 3, 30), category: "ct_risk", note: "Go/no-go: all critical and high pen-test findings resolved before beta." },
      { id: uid("ms"), title: "Beta exit", type: "gate", date: D(2026, 5, 30), category: "ct_product", note: "Go/no-go: crash-free rate \u2265 99.5% and onboarding conversion \u2265 60% to proceed to launch." },
      { id: uid("ms"), title: "Public launch", type: "milestone", date: D(2026, 6, 26), category: "ct_gtm", note: "Apps live in both stores; acquisition campaign switched on." },
    ];
    const risks = [
      { id: uid("r"), title: "Regulatory sign-off slips and delays launch", likelihood: "med", impact: "high", mitigation: "Engage the regulator from Discovery; keep a live controls register and book the review slot now.", owner: "David Olsen", status: "open", taskIds: [T.compliance] },
      { id: uid("r"), title: "Core-banking vendor API unstable in sandbox", likelihood: "high", impact: "high", mitigation: "Build an anti-corruption layer; contract SLAs on sandbox uptime and a named vendor engineer.", owner: "Raj Malhotra", status: "open", taskIds: [T.api] },
      { id: uid("r"), title: "Critical pen-test finding forces rework", likelihood: "med", impact: "high", mitigation: "Threat-model early; run an interim security review at mid-build rather than only at the end.", owner: "Aisha Khan", status: "monitoring", taskIds: [T.security] },
      { id: uid("r"), title: "Beta onboarding conversion below target", likelihood: "med", impact: "med", mitigation: "Instrument every step; run weekly funnel reviews and A/B test the two highest-drop screens.", owner: "Elena Duarte", status: "open", taskIds: [T.beta, T.flows] },
      { id: uid("r"), title: "App-store review rejection at submission", likelihood: "low", impact: "med", mitigation: "Pre-submit a TestFlight build for review; follow the financial-app guidelines checklist.", owner: "Carla Mendes", status: "monitoring", taskIds: [T.gtm] },
    ];
    const stakeholders = [
      { id: uid("s"), name: "Helena Brandt", title: "Chief Product Officer", role: "Executive Sponsor", responsibility: "Owns the launch mandate, secures budget and arbitrates scope across business units.", influence: "high", interest: "high", contact: "h.brandt@meridian.example" },
      { id: uid("s"), name: "Raj Malhotra", title: "Engineering Lead", role: "Project Owner", responsibility: "Accountable for technical delivery, the API contract and the release pipeline.", influence: "high", interest: "high", contact: "r.malhotra@meridian.example" },
      { id: uid("s"), name: "David Olsen", title: "Head of Compliance", role: "Gatekeeper", responsibility: "Approves KYC/AML controls and holds the regulatory sign-off for go-live.", influence: "high", interest: "high", contact: "d.olsen@meridian.example" },
      { id: uid("s"), name: "Carla Mendes", title: "Marketing Lead", role: "Key User", responsibility: "Plans acquisition and launch comms; represents the growth perspective.", influence: "med", interest: "high", contact: "c.mendes@meridian.example" },
      { id: uid("s"), name: "Finance Committee", title: "Budget Control", role: "Advisor", responsibility: "Reviews spend against milestones and validates the business-case benefits.", influence: "med", interest: "med", contact: "finance@meridian.example" },
    ];
    const findings = [
      { id: uid("f"), title: "73% would switch banks for faster onboarding", category: "ct_research", summary: "Interview and survey data show account-opening friction is the single biggest switching trigger for the target segment \u2014 onboarding speed is our sharpest wedge.", source: "Customer interviews + survey, n=420" },
      { id: uid("f"), title: "Instant notifications are the top requested feature", category: "ct_product", summary: "Across competitors, real-time payment notifications drive daily engagement. Absent at launch, retention suffers; present, it becomes a habit loop.", source: "Competitor benchmark" },
      { id: uid("f"), title: "KYC drop-off concentrates on document capture", category: "ct_risk", summary: "Industry data and our prototype tests both show the ID-scan step loses ~30% of users. This is the flow to over-invest in.", source: "Prototype usability tests" },
      { id: uid("f"), title: "Vendor sandbox latency averages 1.8s", category: "ct_eng", summary: "Early integration spikes show the core-banking sandbox is slow and occasionally times out, threatening the dashboard's perceived speed.", source: "Integration spike, week 9" },
    ];
    const org = [
      { id: "o_sponsor", name: "Helena Brandt", role: "Executive Sponsor", parent: null, note: "Chief Product Officer", accent: "purple" },
      { id: "o_owner", name: "Raj Malhotra", role: "Project Owner", parent: "o_sponsor", note: "Engineering Lead & delivery owner", accent: "indigo" },
      { id: "o_pm", name: "You", role: "Project Manager", parent: "o_owner", note: "Day-to-day delivery & this tool", accent: "blue" },
      { id: "o_product", name: "Elena Duarte", role: "Product Lead", parent: "o_pm", note: "Discovery, flows & beta", accent: "pink" },
      { id: "o_design", name: "Tom\u00e1s Silva", role: "Lead Designer", parent: "o_product", note: "Brand kit & product design", accent: "teal" },
      { id: "o_ios", name: "Sophie Tran", role: "iOS Engineer", parent: "o_owner", note: "iOS app & API", accent: "blue" },
      { id: "o_android", name: "Marcus Webb", role: "Android Engineer", parent: "o_owner", note: "Android app", accent: "green" },
      { id: "o_sec", name: "Aisha Khan", role: "Security Architect", parent: "o_owner", note: "Pen-test & controls", accent: "red" },
      { id: "o_compliance", name: "David Olsen", role: "Compliance Officer", parent: "o_pm", note: "KYC/AML & regulator", accent: "amber" },
      { id: "o_growth", name: "Carla Mendes", role: "Marketing Lead", parent: "o_pm", note: "Launch & acquisition", accent: "purple" },
    ];
    const products = [
      { id: uid("p"), name: "Discovery Insights.pdf", type: "pdf", fileId: null, taskIds: [T.interviews, T.benchmark], phase: "ph_disc", date: D(2026, 1, 31), note: "Research synthesis: segments, jobs-to-be-done and the switching triggers.", placeholder: true },
      { id: uid("p"), name: "Core Flows Prototype", type: "image", fileId: null, taskIds: [T.flows], phase: "ph_design", date: D(2026, 3, 12), note: "Prototype screens for onboarding, payments and card controls.", placeholder: true },
      { id: "PROD_API_SPEC", name: "API Contract.xlsx", type: "excel", fileId: null, taskIds: [T.api, T.ios, T.android], phase: "ph_build", date: D(2026, 3, 6), note: "Endpoint-by-endpoint contract shared across iOS, Android and the backend.", placeholder: true },
      { id: uid("p"), name: "Launch Plan.pptx", type: "slides", fileId: null, taskIds: [T.gtm], phase: "ph_launch", date: D(2026, 5, 20), note: "Go-to-market deck: channels, budget, timeline and success metrics.", externalUrl: "https://drive.example.com/meridian/launch-plan", placeholder: false },
    ];
    const businessCase = {
      purpose: "Launch Meridian, a mobile-first challenger bank, to win switchers frustrated by slow onboarding and poor everyday banking apps.",
      problem: "Incumbent banks make account opening slow and painful, lack real-time notifications, and bury everyday tasks. Our target segment is actively shopping for a faster, clearer alternative but no current offering fully owns the onboarding-speed promise.",
      perspOurs: "For the business, mobile banking is the fastest-growing acquisition channel and the cheapest to serve \u2014 every account opened in-app costs a fraction of a branch-assisted one.",
      perspUsers: "Customers want to open an account in minutes from their phone, see money move in real time, and freeze a card instantly \u2014 not wait days or call a branch.",
      perspStakeholders: "Compliance needs demonstrable KYC/AML controls; Growth needs a differentiated story; Finance needs a credible path to cost-per-acquisition targets.",
      worsening: "Challenger competitors ship monthly and are compounding their lead; every quarter we delay raises acquisition cost and cedes the onboarding-speed position we could still own.",
      opportunities: "Owning fast onboarding plus instant notifications creates a daily habit loop, lowers cost-to-serve, and opens cross-sell into savings and credit once trust is established.",
      outcomes: [
        "Open a verified account in under five minutes, end to end.",
        "Reach 50,000 funded accounts within two quarters of launch.",
        "Achieve a crash-free session rate of at least 99.5%.",
        "Keep blended cost-per-funded-account under \u20ac25.",
      ],
      effProcess: "Account opening moves from a multi-day, document-heavy process to a guided in-app flow with automated identity verification and instant provisioning.",
      effSystem: "A unified internal API fronts the core-banking ledger, payments rail and KYC provider; native iOS and Android apps share one design system and one contract.",
      effBehaviour: "Customers self-serve everyday banking from the app and trust real-time notifications instead of calling support; the team ships behind feature flags on a weekly cadence.",
      effLeadership: "A single delivery owner is accountable end to end, Compliance is embedded from Discovery, and a weekly steering forum governs scope against the four target outcomes.",
      financial: [
        { label: "Build cost (one-off)", value: "\u20ac1.6M", note: "Apps, API, integration, security" },
        { label: "Annual run cost", value: "\u20ac540,000", note: "Cloud, vendor fees, support" },
        { label: "Acquisition budget (yr 1)", value: "\u20ac900,000", note: "Paid + referral programme" },
        { label: "Breakeven", value: "~Q3 2027", note: "At 50k funded accounts" },
      ],
      justification: "The mobile channel is where the market is moving and where unit economics are strongest. A focused launch that owns onboarding speed is the lowest-risk route to a defensible position; delaying only raises acquisition cost as competitors compound their lead.",
      effective: "Delivery is phased \u2014 Discovery, Design, Build, Beta, Launch \u2014 each ending in a go/no-go gate. Benefits are tracked against the four outcomes and reviewed weekly, with Finance validating cost-per-account and Compliance holding the launch gate.",
    };
    const scope = {
      inScope: [
        "Native iOS and Android apps at feature parity",
        "In-app account opening with automated KYC",
        "Current account, payments and instant card controls",
        "Real-time payment notifications",
        "Closed beta and public launch in the home market",
      ],
      outScope: [
        "Savings and lending products (phase 2)",
        "Web banking application",
        "Business / joint accounts",
        "International markets and multi-currency",
        "Branch or call-centre servicing",
      ],
    };
    const assessment = [
      { id: uid("as"), area: "Account opening", asIs: "Multi-day, document-heavy, branch-assisted.", toBe: "Under five minutes, fully in-app." },
      { id: uid("as"), area: "Notifications", asIs: "Batch statements, no real-time alerts.", toBe: "Instant push on every transaction." },
      { id: uid("as"), area: "Card controls", asIs: "Call the bank to freeze a lost card.", toBe: "Freeze and unfreeze instantly in-app." },
      { id: uid("as"), area: "Platform", asIs: "No mobile offering of our own.", toBe: "Native iOS + Android on a shared design system." },
      { id: uid("as"), area: "Cost to serve", asIs: "High, branch-and-phone heavy.", toBe: "Low, self-service digital servicing." },
    ];
    const commPlan = [
      { id: uid("cm"), audience: "Beta customers", purpose: "Recruit and prepare the 500 closed-beta participants.", messages: ["What the beta is and what we expect", "How to install and give feedback", "What is and isn't live yet"], channels: ["Email", "In-app message"], timing: "Two weeks before beta", date: D(2026, 4, 20), owner: "Elena Duarte", deliverables: ["Beta invite email (drafted)", "In-app onboarding card"] },
      { id: uid("cm"), audience: "Internal staff", purpose: "Prepare support and the wider company for launch.", messages: ["Launch date and what's shipping", "How to answer common customer questions", "Where the runbook and FAQ live"], channels: ["All-hands", "Intranet"], timing: "Launch week", date: D(2026, 6, 22), owner: "Raj Malhotra", deliverables: ["All-hands slide", "Support FAQ (done)"] },
      { id: uid("cm"), audience: "Prospective customers", purpose: "Drive awareness and app installs at launch.", messages: ["Open an account in five minutes", "Real-time money, instant card controls", "Refer a friend and both get rewarded"], channels: ["Paid social", "App stores", "PR"], timing: "Launch day onward", date: D(2026, 6, 26), owner: "Carla Mendes", deliverables: ["Campaign creative", "App-store listing", "Press release (drafted)"] },
      { id: uid("cm"), audience: "Regulator", purpose: "Evidence readiness and confirm sign-off ahead of launch.", messages: ["Controls register and pen-test results", "KYC/AML evidence pack", "Launch date and rollback plan"], channels: ["Formal submission", "Review meeting"], timing: "Before the launch gate", date: D(2026, 4, 22), owner: "David Olsen", deliverables: ["Evidence pack (submitted)", "Sign-off letter"] },
    ];
    const changePlan = { groups: [
      { id: uid("cg"), label: "Customer-facing", accent: "pink", rows: [
        { id: uid("cr"), component: "Onboarding education", description: "Teach new customers how to open an account, fund it and use card controls, reducing KYC drop-off.", deliverables: ["In-app tooltips", "Help-centre articles", "Explainer videos"], owner: "Tom\u00e1s Silva" },
        { id: uid("cr"), component: "Support readiness", description: "Equip the support team to handle launch-week volume and the most common questions.", deliverables: ["Support FAQ", "Macro responses", "Escalation runbook"], owner: "Elena Duarte" },
      ] },
      { id: uid("cg"), label: "Internal", accent: "indigo", rows: [
        { id: uid("cr"), component: "Weekly release ritual", description: "Embed a feature-flagged weekly release cadence with clear go/no-go criteria.", deliverables: ["Release checklist", "On-call rota", "Crash-free dashboard"], owner: "Raj Malhotra" },
        { id: uid("cr"), component: "Compliance routine", description: "Keep KYC/AML controls evidenced and current as the product evolves.", deliverables: ["Live controls register", "Monthly compliance review"], owner: "David Olsen" },
      ] },
    ] };
    const members = [
      { id: "mem_you", name: "You", role: "Project Manager", email: "", color: "blue" },
      { id: "mem_raj", name: "Raj Malhotra", role: "Engineering Lead", email: "r.malhotra@meridian.example", color: "indigo" },
      { id: "mem_helena", name: "Helena Brandt", role: "Executive Sponsor", email: "h.brandt@meridian.example", color: "purple" },
      { id: "mem_elena", name: "Elena Duarte", role: "Product Lead", email: "e.duarte@meridian.example", color: "pink" },
      { id: "mem_tomas", name: "Tom\u00e1s Silva", role: "Lead Designer", email: "t.silva@meridian.example", color: "teal" },
      { id: "mem_sophie", name: "Sophie Tran", role: "iOS Engineer", email: "s.tran@meridian.example", color: "blue" },
      { id: "mem_marcus", name: "Marcus Webb", role: "Android Engineer", email: "m.webb@meridian.example", color: "green" },
      { id: "mem_aisha", name: "Aisha Khan", role: "Security Architect", email: "a.khan@meridian.example", color: "red" },
      { id: "mem_david", name: "David Olsen", role: "Compliance Officer", email: "d.olsen@meridian.example", color: "amber" },
      { id: "mem_carla", name: "Carla Mendes", role: "Marketing Lead", email: "c.mendes@meridian.example", color: "purple" },
      { id: "mem_nina", name: "Nina Petrova", role: "Data Analyst", email: "n.petrova@meridian.example", color: "amber" },
    ];
    const glossary = [
      { id: "gl_kyc", term: "KYC", definition: "Know Your Customer \u2014 the identity checks required before a customer can open and use an account." },
      { id: "gl_aml", term: "AML", definition: "Anti-Money-Laundering \u2014 controls that detect and prevent illicit funds moving through the bank." },
      { id: "gl_cpa", term: "CPA", definition: "Cost Per Acquisition \u2014 the blended marketing spend to acquire one funded account." },
      { id: "gl_crash", term: "crash-free rate", definition: "The percentage of app sessions that complete without a crash \u2014 a core quality gate for launch." },
      { id: "gl_flag", term: "feature flag", definition: "A switch that turns functionality on or off remotely, letting us ship code dark and release gradually." },
      { id: "gl_acl", term: "anti-corruption layer", definition: "An internal API that isolates our apps from the quirks and instability of the external core-banking vendor." },
      { id: "gl_funded", term: "funded account", definition: "An opened account that has received its first deposit \u2014 our primary measure of real activation." },
    ];
    return { meta: { project: "Meridian Mobile Banking Launch", code: "PRJ-2026-031" }, tasks, members, stakeholders, risks, findings, org, products, businessCase, scope, assessment, commPlan, changePlan, milestones, glossary, ...tax };
  }

  function seedRoot() {
    const demo = makeProject("blue", showcaseData(), 6); demo.demoTag = "showcase-meridian-v1";
    const p1 = makeProject("purple", heliosData(), 48);
    const p2 = makeProject("teal", intranetData(), 12);
    const p3 = makeProject("indigo", migrationData(), 20, null);
    p3.parentId = p1.id;
    return { version: 2, activeId: demo.id, projects: [demo, p1, p3, p2], demoSeeded: true };
  }
  // (seedRoot also seeds the AI consulting project for brand-new workspaces via ensureAIConsulting on load)

  // non-destructively add the fully-populated demo to an existing workspace, once
  function ensureShowcase(root) {
    if (root.demoSeeded) return root;
    const demo = makeProject("blue", showcaseData(), 6); demo.demoTag = "showcase-meridian-v1";
    root.projects = [demo, ...root.projects];
    root.activeId = demo.id;
    root.demoSeeded = true;
    try { localStorage.setItem(KEY, JSON.stringify(root)); } catch (e) {}
    return root;
  }

  // ---------- AI consulting start-up: risk register + scope ----------
  function aiConsultingData() {
    const tax = {
      tags: [
        { id: "tg_pkg", label: "Tool Suite", color: "blue" },
        { id: "tg_adv", label: "Advisory", color: "teal" },
        { id: "tg_legal", label: "Compliance", color: "red" },
        { id: "tg_sales", label: "Sales", color: "amber" },
      ],
      phases: [
        { id: "ph_found", label: "Foundation", color: "teal" },
        { id: "ph_build", label: "Build", color: "blue" },
        { id: "ph_launch", label: "Launch", color: "amber" },
        { id: "ph_scale", label: "Scale", color: "indigo" },
      ],
      categories: [
        { id: "ct_product", label: "Product & Tool Suite", color: "blue" },
        { id: "ct_consult", label: "Consulting Delivery", color: "teal" },
        { id: "ct_gtm", label: "Go-to-Market & Sales", color: "amber" },
        { id: "ct_ops", label: "Operations & Compliance", color: "red" },
        { id: "ct_talent", label: "People & Talent", color: "purple" },
      ],
    };
    const T = {};
    const mk = (key, o) => { const id = uid("t"); T[key] = id; return { id, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], comments: [], custom: {}, ...o }; };
    const tasks = [
      mk("suite", { title: "Define & package the modular AI tool suite", status: "inprogress", tags: ["tg_pkg"], phase: "ph_found", category: "ct_product", priority: "high", assignees: ["CTO"], start: D(2026, 6, 1), end: D(2026, 7, 15), desc: "Decide which AI tools make up the start-up package (assistant, document automation, analytics, RAG knowledge base, workflow automation) and how each is scoped and individually priced." }),
      mk("method", { title: "Build the AI readiness assessment methodology", status: "inprogress", tags: ["tg_adv"], phase: "ph_found", category: "ct_consult", priority: "high", assignees: ["Lead Consultant"], start: D(2026, 6, 8), end: D(2026, 7, 10), desc: "A repeatable way to assess a client's as-is processes, data maturity and readiness, then present options for where and how AI could help." }),
      mk("compliance", { title: "Data governance & EU AI Act compliance framework", status: "inprogress", tags: ["tg_legal"], phase: "ph_found", category: "ct_ops", priority: "high", assignees: ["Compliance Lead"], start: D(2026, 6, 15), end: D(2026, 7, 22), desc: "Define how client data is handled, build the EU AI Act / GDPR compliance checklist applied to every engagement and tool." }),
      mk("talent", { title: "Recruit AI engineering & consulting talent", status: "inprogress", tags: [], phase: "ph_found", category: "ct_talent", priority: "high", assignees: ["Founder"], start: D(2026, 6, 1), end: D(2026, 8, 15), desc: "Hire (or contract) the engineers and consultants needed to deliver both the tool suite and assessment engagements." }),
      mk("pricing", { title: "Pricing model for individually-priced services", status: "backlog", tags: ["tg_sales"], phase: "ph_build", category: "ct_gtm", priority: "high", assignees: ["Head of Growth"], start: D(2026, 7, 1), end: D(2026, 7, 25), desc: "Set \u00e0-la-carte pricing for each tool and service, plus bundle logic so the package reads as a coherent suite." }),
      mk("vendors", { title: "Set up model & cloud vendor partnerships", status: "backlog", tags: ["tg_pkg"], phase: "ph_build", category: "ct_product", priority: "med", assignees: ["CTO"], start: D(2026, 7, 6), end: D(2026, 8, 7), desc: "Establish provider relationships (model APIs, cloud) with terms, SLAs and fallbacks across more than one vendor." }),
      mk("integration", { title: "Shared data layer & SSO across the tool suite", status: "backlog", tags: ["tg_pkg"], phase: "ph_build", category: "ct_product", priority: "high", assignees: ["CTO"], start: D(2026, 7, 20), end: D(2026, 9, 4), desc: "Make the tools genuinely complementary: shared identity, shared data layer and consistent UX so the suite is more than separate apps." }),
      mk("playbook", { title: "Client onboarding & delivery playbook", status: "backlog", tags: ["tg_adv"], phase: "ph_build", category: "ct_consult", priority: "med", assignees: ["Lead Consultant"], start: D(2026, 7, 13), end: D(2026, 8, 14), desc: "Standard statement of work, phase gates, success metrics and a defined path from assessment to a production deployment." }),
      mk("entry", { title: "Productised fixed-fee 'AI readiness' offer", status: "backlog", tags: ["tg_sales", "tg_adv"], phase: "ph_launch", category: "ct_gtm", priority: "med", assignees: ["Head of Growth"], start: D(2026, 7, 20), end: D(2026, 8, 10), desc: "A low-friction, fixed-fee assessment as the front door \u2014 shortens the sales cycle and creates a path into the larger suite." }),
      mk("marketing", { title: "Launch marketing & lead generation", status: "backlog", tags: ["tg_sales"], phase: "ph_launch", category: "ct_gtm", priority: "med", assignees: ["Head of Growth"], start: D(2026, 8, 17), end: D(2026, 9, 18), desc: "Positioning, website, case-study pipeline and outbound to generate the first qualified leads." }),
    ];
    const dep = (k, ...ds) => { const t = tasks.find((x) => x.id === T[k]); t.deps = ds; };
    dep("integration", { id: uid("d"), type: "task", refId: T.suite }, { id: uid("d"), type: "task", refId: T.vendors });
    dep("playbook", { id: uid("d"), type: "task", refId: T.method });
    dep("entry", { id: uid("d"), type: "task", refId: T.method }, { id: uid("d"), type: "task", refId: T.pricing });
    dep("marketing", { id: uid("d"), type: "task", refId: T.entry });

    const milestones = [
      { id: uid("ms"), title: "Compliance framework signed off", type: "gate", date: D(2026, 7, 22), category: "ct_ops", note: "Go/no-go: no client engagement starts until the data-handling & EU AI Act framework is approved." },
      { id: uid("ms"), title: "Tool suite v1 live", type: "milestone", date: D(2026, 9, 10), category: "ct_product", note: "First integrated version of the packaged tool suite available to clients." },
      { id: uid("ms"), title: "First paying client", type: "milestone", date: D(2026, 9, 25), category: "ct_gtm", note: "First signed assessment or tool engagement \u2014 proof the offer sells." },
    ];
    const risks = [
      { id: uid("r"), title: "Clients expect AI to do more than is realistic", likelihood: "high", impact: "high", status: "open", owner: "Lead Consultant", mitigation: "Use the readiness assessment to set realistic, evidence-based expectations; scope every engagement with explicit success criteria and a defined production path.", taskIds: [T.method, T.playbook] },
      { id: uid("r"), title: "Client AI projects stall in 'POC purgatory' and never reach production", likelihood: "high", impact: "high", status: "open", owner: "Lead Consultant", mitigation: "Define the production path and success metrics up front; phase-gate engagements with a go/no-go before each stage so pilots are designed to ship.", taskIds: [T.method, T.playbook] },
      { id: uid("r"), title: "Heavy dependency on third-party model/cloud vendors (price hikes, API changes, outages)", likelihood: "high", impact: "high", status: "open", owner: "CTO", mitigation: "Abstract providers behind an internal layer; contract SLAs; keep a tested fallback model and more than one vendor relationship.", taskIds: [T.vendors, T.integration] },
      { id: uid("r"), title: "Long sales cycles strain start-up cash flow", likelihood: "high", impact: "high", status: "open", owner: "Head of Growth", mitigation: "Lead with the productised fixed-fee assessment as a low-friction entry; pursue retainers; manage runway against a conservative pipeline.", taskIds: [T.entry, T.marketing] },
      { id: uid("r"), title: "Regulatory non-compliance (EU AI Act / GDPR)", likelihood: "med", impact: "high", status: "open", owner: "Compliance Lead", mitigation: "Build the compliance framework before first delivery; legal review of each tool; signed data-processing agreements with every client.", taskIds: [T.compliance] },
      { id: uid("r"), title: "Client data breach or mishandling", likelihood: "med", impact: "high", status: "monitoring", owner: "Compliance Lead", mitigation: "Encryption in transit and at rest, least-privilege access, data-retention limits, and a SOC 2 roadmap; periodic penetration testing.", taskIds: [T.compliance] },
      { id: uid("r"), title: "Scarcity & churn of skilled AI talent", likelihood: "med", impact: "high", status: "open", owner: "Founder", mitigation: "Blend permanent hires with a vetted contractor network; competitive equity; partner with universities for a junior pipeline.", taskIds: [T.talent] },
      { id: uid("r"), title: "The tool suite isn't actually integrated \u2014 the 'complementary' promise fails", likelihood: "med", impact: "high", status: "open", owner: "CTO", mitigation: "Design a shared data layer and SSO from the start; publish a reference architecture; integration-test the suite as a whole, not tool by tool.", taskIds: [T.suite, T.integration] },
      { id: uid("r"), title: "Consulting engagements suffer scope creep", likelihood: "high", impact: "med", status: "open", owner: "Lead Consultant", mitigation: "Tight statements of work with fixed per-phase deliverables and a formal change-control process for anything extra.", taskIds: [T.playbook] },
      { id: uid("r"), title: "Commoditisation \u2014 larger players undercut on price", likelihood: "med", impact: "med", status: "monitoring", owner: "Head of Growth", mitigation: "Differentiate on assessment quality, integration and trusted local delivery rather than raw tooling; focus on a few niche verticals.", taskIds: [T.pricing] },
    ];
    const scope = {
      inScope: [
        "AI readiness assessment of a client's current (as-is) processes and data",
        "AI opportunity mapping and a prioritised adoption roadmap with options",
        "A modular suite of complementary AI tools, each priced individually",
        "Integration of selected tools into the client's existing systems",
        "Staff training and change management for AI adoption",
        "Data governance, privacy and EU AI Act compliance advisory",
        "Ongoing support, monitoring and model-performance reviews",
      ],
      outScope: [
        "Training bespoke foundation models from scratch",
        "Hardware or on-prem GPU infrastructure procurement",
        "General (non-AI) IT consulting or custom software development",
        "Clinical, legal or safety-critical certification of AI systems",
        "24/7 managed operations (not offered at launch)",
        "Large-scale manual data labelling (outsourced to partners)",
      ],
    };
    const assessment = [
      { id: uid("as"), area: "AI adoption", asIs: "Companies are curious about AI but don't know where it fits.", toBe: "A clear, prioritised roadmap grounded in their real processes." },
      { id: uid("as"), area: "Tooling", asIs: "Point AI tools bought ad hoc, poorly integrated.", toBe: "A complementary suite that shares data and identity." },
      { id: uid("as"), area: "Compliance", asIs: "Unclear how AI use squares with GDPR / the EU AI Act.", toBe: "A documented, defensible compliance position per use case." },
    ];
    const members = [
      { id: "mem_you", name: "Founder", role: "Founder & CEO", email: "", color: "blue" },
      { id: "mem_cto", name: "CTO", role: "Co-founder, Engineering", email: "", color: "indigo" },
      { id: "mem_consult", name: "Lead Consultant", role: "Consulting delivery", email: "", color: "teal" },
      { id: "mem_comp", name: "Compliance Lead", role: "Risk & compliance", email: "", color: "red" },
      { id: "mem_growth", name: "Head of Growth", role: "Sales & marketing", email: "", color: "amber" },
    ];
    const org = [
      { id: "o_founder", name: "Founder", role: "Founder & CEO", parent: null, note: "Single point of accountability", accent: "blue" },
      { id: "o_cto", name: "CTO", role: "Co-founder, Engineering", parent: "o_founder", note: "Tool suite & integration", accent: "indigo" },
      { id: "o_consult", name: "Lead Consultant", role: "Consulting Delivery", parent: "o_founder", note: "Assessments & engagements", accent: "teal" },
      { id: "o_comp", name: "Compliance Lead", role: "Risk & Compliance", parent: "o_founder", note: "Governance & EU AI Act", accent: "red" },
      { id: "o_growth", name: "Head of Growth", role: "Sales & Marketing", parent: "o_founder", note: "Pricing, pipeline & launch", accent: "amber" },
    ];
    const businessCase = Object.assign(blankBusinessCase(), {
      purpose: "An AI consulting start-up with two offerings: a modular suite of complementary AI tools priced \u00e0 la carte, and a consulting practice that assesses a client's as-is processes and maps the right path to AI adoption.",
      problem: "Most companies starting out with AI don't know which tools fit their processes, how to adopt them responsibly, or how to get past pilots into production. They buy disconnected point tools and struggle with compliance.",
    });
    return { meta: { project: "AI Consulting Start-up", code: "AIC-2026" }, tasks, members, stakeholders: [], risks, findings: [], org, products: [], businessCase, scope, assessment, commPlan: [], changePlan: blankChangePlan(), milestones, customFields: [], baseline: null, automations: [], activity: [], suggestDismiss: {}, financials: blankFinancials(), glossary: [], ...tax };
  }

  // non-destructively add the AI consulting project once, and open it
  function ensureAIConsulting(root) {
    if (root.aiSeeded) return root;
    const proj = makeProject("teal", aiConsultingData(), 0);
    root.projects = [proj, ...root.projects];
    root.activeId = proj.id;
    root.aiSeeded = true;
    try { localStorage.setItem(KEY, JSON.stringify(root)); } catch (e) {}
    return root;
  }

  function blankProject(name, code, color, parentId = null) {
    const tax = defaultTaxonomy();
    return makeProject(color || "indigo", {
      meta: { project: name || "Untitled project", code: code || "" },
      tasks: [], members: [], stakeholders: [], risks: [], findings: [], products: [],
      org: [{ id: "o_owner", name: "Project Owner", role: "Project Owner", parent: null, note: "Single point of accountability", accent: "indigo" }],
      businessCase: blankBusinessCase(), scope: blankScope(), assessment: [], commPlan: [], changePlan: blankChangePlan(), milestones: [], ...tax,
    }, 0, parentId);
  }

  // ---------- persistence ----------
  function normalize(root) {
    root.projects = (root.projects || []).map((p) => ({
      ...p,
      scope: p.scope && Array.isArray(p.scope.inScope) ? p.scope : { inScope: [], outScope: [] },
      assessment: Array.isArray(p.assessment) ? p.assessment : [],
      commPlan: Array.isArray(p.commPlan) ? p.commPlan : [],
      changePlan: p.changePlan && Array.isArray(p.changePlan.groups) ? p.changePlan : { groups: [] },
      milestones: Array.isArray(p.milestones) ? p.milestones : [],
      glossary: Array.isArray(p.glossary) ? p.glossary : [],
      externals: Array.isArray(p.externals) ? p.externals : [],
      members: Array.isArray(p.members) && p.members.length ? p.members
        : (() => {
            // backfill from org names + stakeholders + assignees so the canonical list is complete
            const seen = new Map();
            const accents = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
            let i = 0;
            const addPerson = (name, role) => {
              const key = (name || "").trim(); if (!key || seen.has(key)) return;
              seen.set(key, { id: "mem_" + Math.random().toString(36).slice(2, 9), name: key, role: role || "", email: "", color: accents[i++ % accents.length] });
            };
            (p.org || []).forEach((o) => addPerson(o.name, o.role));
            (p.stakeholders || []).forEach((st) => addPerson(st.name, st.role));
            (p.tasks || []).forEach((t) => (Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : [])).forEach((n) => addPerson(n, "")));
            return [...seen.values()];
          })(),
      businessCase: { ...blankBusinessCase(), ...(p.businessCase || {}) },
    }));
    // link org cards to canonical members (by existing memberId, else by name)
    root.projects = root.projects.map((p) => ({
      ...p,
      org: (p.org || []).map((o) => {
        if (o.memberId && (p.members || []).some((m) => m.id === o.memberId)) return o;
        const m = (p.members || []).find((x) => x.name && x.name === o.name);
        return m ? { ...o, memberId: m.id } : { ...o, memberId: o.memberId || null };
      }),
      // hard sync: drop task assignees who are no longer in the member list
      tasks: (() => {
        const memberNames = new Set((p.members || []).map((m) => m.name));
        return (p.tasks || []).map((t) => {
          const as = Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []);
          const kept = as.filter((a) => memberNames.has(a));
          return kept.length === as.length ? t : { ...t, assignees: kept, assignee: undefined };
        });
      })(),
    }));
    return root;
  }
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { const r = JSON.parse(raw); if (r && r.version === 2) return ensureAIConsulting(ensureShowcase(normalize(r))); }
    } catch (e) { console.warn("load failed", e); }
    const s = seedRoot();
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
    return s;
  }

  let root = load();
  const listeners = new Set();
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(root)); } catch (e) { console.warn("persist failed (quota?)", e); } }
  function emit() { listeners.forEach((l) => l()); }

  function active() { return root.projects.find((p) => p.id === root.activeId) || null; }

  // ----- per-project state API (used by all views) -----
  function getState() { return active(); }
  function setState(updater) {
    const proj = active(); if (!proj) return;
    const next = typeof updater === "function" ? updater(proj) : { ...proj, ...updater };
    next.updatedAt = Date.now();
    root = { ...root, rev: (root.rev || 0) + 1, savedAt: Date.now(), projects: root.projects.map((p) => (p.id === proj.id ? next : p)) };
    persist(); emit();
  }
  function update(key, fn) { setState((s) => ({ ...s, [key]: fn(s[key]) })); }
  function add(key, item) { update(key, (arr) => [...arr, item]); }
  function patch(key, id, changes) { update(key, (arr) => arr.map((x) => (x.id === id ? { ...x, ...changes } : x))); }
  function remove(key, id) { update(key, (arr) => arr.filter((x) => x.id !== id)); }

  // ----- member helpers: the member list is the single source of truth -----
  function renameMember(id, newName) {
    const nm = (newName || "").trim() || "Unnamed";
    setState((s) => {
      const m = (s.members || []).find((x) => x.id === id); if (!m) return s;
      const old = m.name;
      const members = s.members.map((x) => (x.id === id ? { ...x, name: nm } : x));
      if (old === nm) return { ...s, members };
      const assigneesOf = (t) => Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []);
      const tasks = (s.tasks || []).map((t) => {
        let ch = t;
        const as = assigneesOf(t);
        if (as.includes(old)) ch = { ...ch, assignees: as.map((a) => (a === old ? nm : a)) };
        if ((t.comments || []).some((c) => c.author === old)) ch = { ...ch, comments: t.comments.map((c) => (c.author === old ? { ...c, author: nm } : c)) };
        return ch;
      });
      const risks = (s.risks || []).map((r) => (r.owner === old ? { ...r, owner: nm } : r));
      const org = (s.org || []).map((o) => (o.memberId === id || o.name === old ? { ...o, name: nm } : o));
      const commPlan = (s.commPlan || []).map((c) => (c.owner === old ? { ...c, owner: nm } : c));
      const changePlan = s.changePlan && Array.isArray(s.changePlan.groups)
        ? { ...s.changePlan, groups: s.changePlan.groups.map((g) => ({ ...g, rows: (g.rows || []).map((r) => (r.owner === old ? { ...r, owner: nm } : r)) })) }
        : s.changePlan;
      try {
        ["atlas.view." + s.id, "atlas.commentAs." + s.id, "atlas.ws.who." + s.id].forEach((k) => {
          if (localStorage.getItem(k) === old) localStorage.setItem(k, nm);
        });
      } catch (e) {}
      return { ...s, members, tasks, risks, org, commPlan, changePlan };
    });
  }
  function removeMember(id) {
    setState((s) => {
      const m = (s.members || []).find((x) => x.id === id);
      const nm = m ? m.name : null;
      const assigneesOf = (t) => Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []);
      const members = (s.members || []).filter((x) => x.id !== id);
      const tasks = nm ? (s.tasks || []).map((t) => {
        const as = assigneesOf(t);
        return as.includes(nm) ? { ...t, assignees: as.filter((a) => a !== nm), assignee: undefined } : t;
      }) : (s.tasks || []);
      let org = s.org || [];
      const card = org.find((o) => o.memberId === id || (nm && o.name === nm));
      if (card) org = org.filter((o) => o.id !== card.id).map((o) => (o.parent === card.id ? { ...o, parent: card.parent } : o));
      const risks = nm ? (s.risks || []).map((r) => (r.owner === nm ? { ...r, owner: "" } : r)) : (s.risks || []);
      const commPlan = nm ? (s.commPlan || []).map((c) => (c.owner === nm ? { ...c, owner: "" } : c)) : (s.commPlan || []);
      const changePlan = nm && s.changePlan && Array.isArray(s.changePlan.groups)
        ? { ...s.changePlan, groups: s.changePlan.groups.map((g) => ({ ...g, rows: (g.rows || []).map((r) => (r.owner === nm ? { ...r, owner: "" } : r)) })) }
        : s.changePlan;
      return { ...s, members, tasks, org, risks, commPlan, changePlan };
    });
  }

  // ----- root / project-management API -----
  function getRoot() { return root; }
  function setRoot(next) { root = { ...next, rev: (next.rev != null ? next.rev : (root.rev || 0) + 1), savedAt: next.savedAt || Date.now() }; persist(); emit(); }
  const projects = {
    list: () => root.projects,
    open: (id) => setRoot({ ...root, activeId: id }),
    close: () => setRoot({ ...root, activeId: null }),
    create: (name, code, color, parentId) => {
      const p = blankProject(name, code, color, parentId || null);
      setRoot({ ...root, projects: [...root.projects, p], activeId: p.id });
      return p.id;
    },
    rename: (id, name, code) => setRoot({ ...root, projects: root.projects.map((p) => p.id === id ? { ...p, meta: { ...p.meta, project: name ?? p.meta.project, code: code ?? p.meta.code }, updatedAt: Date.now() } : p) }),
    setColor: (id, color) => setRoot({ ...root, projects: root.projects.map((p) => p.id === id ? { ...p, color } : p) }),
    setParent: (id, parentId) => setRoot({ ...root, projects: root.projects.map((p) => p.id === id ? { ...p, parentId: parentId || null, updatedAt: Date.now() } : p) }),
    remove: (id) => setRoot({ ...root, projects: root.projects.filter((p) => p.id !== id).map((p) => p.parentId === id ? { ...p, parentId: null } : p), activeId: root.activeId === id ? null : root.activeId }),
  };

  function resetAll() { root = seedRoot(); persist(); emit(); }

  // ----- sync helpers -----
  function importRoot(next, opts) {
    if (!next || next.version !== 2 || !Array.isArray(next.projects)) throw new Error("Not a valid Atlas workspace file.");
    // preserve which project this device has open across a sync pull (per-device UI state)
    const keepActive = opts && opts.keepActive ? root.activeId : null;
    let projects = next.projects;
    let activeId = null;
    if (keepActive) {
      const incomingHas = projects.some((p) => p.id === keepActive);
      if (incomingHas) {
        activeId = keepActive;
      } else {
        // The open project isn't in the incoming set (e.g. created locally and not yet
        // pushed). Keep it locally instead of ejecting the user to the portfolio.
        const localProj = root.projects.find((p) => p.id === keepActive);
        if (localProj) { projects = [...projects, localProj]; activeId = keepActive; }
      }
    }
    root = { version: 2, activeId, projects, rev: next.rev || 0, savedAt: next.savedAt || Date.now() };
    persist(); emit();
  }
  function touch() { root = { ...root, rev: (root.rev || 0) + 1, savedAt: Date.now() }; persist(); }

  // ---------- React hooks ----------
  function useStore(selector) {
    const sel = selector || ((s) => s);
    const [, force] = React.useReducer((x) => x + 1, 0);
    React.useEffect(() => { listeners.add(force); return () => listeners.delete(force); }, []);
    return sel(active());
  }
  function useRoot() {
    const [, force] = React.useReducer((x) => x + 1, 0);
    React.useEffect(() => { listeners.add(force); return () => listeners.delete(force); }, []);
    return root;
  }

  // ---------- IndexedDB file store ----------
  const DB_NAME = "atlas.files";
  let dbp = null;
  function db() {
    if (dbp) return dbp;
    dbp = new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = () => r.result.createObjectStore("files");
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return dbp;
  }
  async function putFile(id, blob) { const d = await db(); return new Promise((res, rej) => { const tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(blob, id); tx.oncomplete = () => res(id); tx.onerror = () => rej(tx.error); }); }
  async function getFile(id) { const d = await db(); return new Promise((res, rej) => { const tx = d.transaction("files", "readonly"); const rq = tx.objectStore("files").get(id); rq.onsuccess = () => res(rq.result || null); rq.onerror = () => rej(rq.error); }); }
  async function delFile(id) { const d = await db(); return new Promise((res) => { const tx = d.transaction("files", "readwrite"); tx.objectStore("files").delete(id); tx.oncomplete = () => res(); }); }
  async function allFiles() { const d = await db(); return new Promise((res, rej) => { const tx = d.transaction("files", "readonly"); const st = tx.objectStore("files"); const out = {}; const cur = st.openCursor(); cur.onsuccess = (e) => { const c = e.target.result; if (c) { out[c.key] = c.value; c.continue(); } else res(out); }; cur.onerror = () => rej(cur.error); }); }

  window.Store = {
    uid, getState, setState, update, add, patch, remove, renameMember, removeMember, useStore, useRoot, getRoot, setRoot,
    projects, resetAll, importRoot, touch,
    files: { put: putFile, get: getFile, del: delFile, all: allFiles },
  };
})();
