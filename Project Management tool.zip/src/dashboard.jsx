/* ============================================================
   DASHBOARD — project front page
   View switcher (project / per-person) · tasks · risks · deps
   Exposes window.Dashboard
   ============================================================ */
const { useState: useD, useMemo: useDM } = React;

const STATUS_ORDER = [
{ id: "inprogress", label: "In progress" },
{ id: "backlog", label: "To do" },
{ id: "done", label: "Done" }];


function Dashboard({ go }) {
  const s = Store.useStore();
  const { tasks, risks, products, phases, stakeholders, members, milestones, commPlan, categories } = s;
  const [openTask, setOpenTask] = useD(null);

  const VKEY = "atlas.view." + s.id;
  const [who, setWho] = useD(() => {
    const saved = localStorage.getItem(VKEY) || "";
    return saved;
  });
  const phaseOf = (id) => phases.find((p) => p.id === id);

  const people = useDM(() => {
    const set = new Set();
    (members || []).forEach((m) => m.name && m.name !== "You" && set.add(m.name));
    tasks.forEach((t) => assigneesOf(t).forEach((n) => n && set.add(n)));
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [tasks, members]);

  // if saved person no longer exists, fall back to project view
  const personal = who && people.includes(who);
  const changeWho = (v) => {
    setWho(v);
    if (v) localStorage.setItem(VKEY, v);else localStorage.removeItem(VKEY);
  };

  const viewTasks = personal ? tasks.filter((t) => assigneesOf(t).includes(who)) : tasks;
  const myIds = useDM(() => new Set(viewTasks.map((t) => t.id)), [viewTasks]);
  const viewRisks = personal ? risks.filter((r) => (r.taskIds || []).some((id) => myIds.has(id))) : risks;
  const viewProducts = personal ? products.filter((p) => (p.taskIds || []).some((id) => myIds.has(id))) : products;

  const done = viewTasks.filter((t) => t.status === "done").length;
  const active = viewTasks.filter((t) => t.status === "inprogress");
  const openRisks = viewRisks.filter((r) => r.status !== "closed").length;

  // project view: group active by person
  const byPerson = useDM(() => {
    const out = [];const idx = {};
    active.forEach((t) => {
      const keys = assigneesOf(t).length ? assigneesOf(t) : ["\u2014 Unassigned"];
      keys.forEach((n) => {if (idx[n] == null) {idx[n] = out.length;out.push({ name: n, tasks: [] });}out[idx[n]].tasks.push(t);});
    });
    out.sort((a, b) => (a.name.startsWith("\u2014") ? 1 : 0) - (b.name.startsWith("\u2014") ? 1 : 0) || b.tasks.length - a.tasks.length);
    return out;
  }, [active]);

  // personal view: group all my tasks by status
  const byStatus = useDM(() => STATUS_ORDER.map((st) => ({ ...st, tasks: viewTasks.filter((t) => t.status === st.id) })).filter((g) => g.tasks.length), [viewTasks]);

  const depTasks = viewTasks.filter((t) => (t.deps || []).length && t.status !== "done");
  let blockedCount = 0,extCount = 0;
  depTasks.forEach((t) => (t.deps || []).forEach((d) => {const r = resolveDep(d, tasks, products);if (r.external) extCount++;else if (r.blocked) blockedCount++;}));

  const topRisks = [...viewRisks].sort((a, b) => LVL[b.likelihood] * LVL[b.impact] - LVL[a.likelihood] * LVL[a.impact]).slice(0, 5);
  const firstName = personal ? who.split(/\s+/)[0] : "";

  return (
    <div className="view-scroll">
      <div className="dash">
        <section className="dash-hero">
          <div className="dash-hero-main">
            <div className="eyebrow" style={{ marginBottom: 14 }}>{personal ? "Personal view" : "Project overview"}</div>
            <UI.Editable className="dash-title serif" tag="h1" value={s.meta?.project} onChange={(v) => Store.setState((st) => ({ ...st, meta: { ...st.meta, project: v || "Untitled" } }))} placeholder="Project name" />
            {!personal && <UI.Editable className="dash-lead" tag="p" multiline value={s.businessCase?.purpose || ""} onChange={(v) => Store.setState((st) => ({ ...st, businessCase: { ...st.businessCase, purpose: v } }))} placeholder="Add a business purpose to summarise this project here." />}
            {personal && <p className="dash-lead">Showing only {who}'s tasks and the risks on work they're assigned to.</p>}
            <div className="row" style={{ gap: 10, marginTop: 24, flexWrap: "wrap" }}>
              <button className="btn btn-primary" onClick={() => go("business")}><Icon name="doc" size={15} /> Read the business case</button>
              <button className="btn" onClick={() => go("kanban")}><Icon name="board" size={15} /> Open the board</button>
            </div>
          </div>
          <div className="dash-right">
            <HeroImage projectId={s.id} />
            <div className="dash-viewbox no-print">
            <div className="dash-viewbox-label">View</div>
            <div className="dash-viewselect" style={{ fontFamily: "system-ui" }}>
              {personal && <span className="avatar" style={{ width: 26, height: 26, fontSize: 10 }}>{initials(who)}</span>}
              {!personal && <span className="dash-viewglobe"><Icon name="users" size={16} /></span>}
              <select value={personal ? who : ""} onChange={(e) => changeWho(e.target.value)}>
                <option value="">Project view — everything</option>
                {people.length > 0 && <option disabled>──────────</option>}
                {people.map((p) => <option key={p} value={p}>{p} — personal</option>)}
              </select>
              <Icon name="chevD" size={15} />
            </div>
            <div className="dash-viewhint">{personal ? "Only this person's work" : "Everyone's work"}</div>
            </div>
          </div>
        </section>

        <section className="dash-stats">
          <Stat n={active.length} label="In progress" icon="board" />
          <Stat n={done} label="Completed" icon="check" />
          <Stat n={blockedCount + extCount} label="Dependencies" icon="link" accent={blockedCount > 0} />
          <Stat n={openRisks} label={personal ? "Their risks" : "Open risks"} icon="shield" accent={openRisks > 0} />
          <Stat n={viewProducts.length} label="Deliverables" icon="box" />
        </section>

        <UpcomingTimeline viewTasks={viewTasks} tasks={tasks} products={products} milestones={milestones} commPlan={commPlan} categories={categories} phaseOf={phaseOf} onOpen={setOpenTask} go={go} />

        <div className="dash-cols">
          <section className="dash-panel">
            <div className="dash-panel-hd">
              <span className="card-hd">{personal ? `${firstName}'s tasks` : "In progress now"}</span>
              <button className="btn btn-sm btn-ghost" onClick={() => go(personal ? "actions" : "kanban")}>{personal ? "Actions" : "Board"} <Icon name="arrowR" size={13} /></button>
            </div>

            {!personal &&
            <div className="active-people">
                {active.length === 0 && <div className="dash-empty">Nothing in progress. Move a card into <b>In&nbsp;Progress</b> to see who's working on what.</div>}
                {byPerson.map((grp) =>
              <div key={grp.name} className="person-group">
                    <div className="person-hd">
                      <span className="avatar" style={{ background: grp.name.startsWith("\u2014") ? "var(--ink-ghost)" : "var(--ink)" }}>{grp.name.startsWith("\u2014") ? "?" : initials(grp.name)}</span>
                      <span className="person-name">{grp.name.startsWith("\u2014") ? "Unassigned" : grp.name}</span>
                      <span className="person-count">{grp.tasks.length}</span>
                    </div>
                    <div className="person-tasks">
                      {grp.tasks.map((t) => <TaskLine key={t.id} t={t} ph={phaseOf(t.phase)} onOpen={setOpenTask} />)}
                    </div>
                  </div>
              )}
              </div>
            }

            {personal &&
            <div className="active-people">
                {viewTasks.length === 0 && <div className="dash-empty">{who} isn't assigned to any tasks yet. Assign them on a task card.</div>}
                {byStatus.map((g) =>
              <div key={g.id} className="person-group">
                    <div className="person-hd">
                      <span className={"status-dot s-" + g.id} style={{ width: 10, height: 10, margin: 0 }} />
                      <span className="person-name">{g.label}</span>
                      <span className="person-count">{g.tasks.length}</span>
                    </div>
                    <div className="person-tasks">
                      {g.tasks.map((t) => <TaskLine key={t.id} t={t} ph={phaseOf(t.phase)} onOpen={setOpenTask} />)}
                    </div>
                  </div>
              )}
              </div>
            }
          </section>

          <section className="dash-panel">
            <div className="dash-panel-hd">
              <span className="card-hd">{personal ? `${firstName}'s risks` : "Top risks"}</span>
              <button className="btn btn-sm btn-ghost" onClick={() => go("risks")}>All risks <Icon name="arrowR" size={13} /></button>
            </div>
            <div className="dash-risks">
              {topRisks.length === 0 && <div className="dash-empty">{personal ? "No risks linked to their tasks." : "No risks captured yet."}</div>}
              {topRisks.map((r) => {
                const rem = remediation(r, tasks);
                return (
                  <div key={r.id} className="dash-risk" onClick={() => go("risks")}>
                    <span className="risk-score sm" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="dash-risk-title">{r.title}</span>
                      {rem.state !== "none" && <span className="dash-risk-rem" style={{ color: REMED[rem.state].c }}>{REMED[rem.state].label} · {rem.done}/{rem.total}</span>}
                    </span>
                  </div>);

              })}
            </div>
          </section>
        </div>

        <section className="dash-panel" style={{ marginBottom: 30 }}>
          <div className="dash-panel-hd">
            <span className="card-hd">Dependencies & blockers</span>
            <span className="dep-summary">
              {blockedCount > 0 && <span className="dep-pill blocked"><span className="dep-flag">●</span> {blockedCount} blocking</span>}
              {extCount > 0 && <span className="dep-pill ext"><Icon name="link" size={12} /> {extCount} external</span>}
              {blockedCount + extCount === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No open dependencies</span>}
            </span>
          </div>
          {depTasks.length === 0 && <div className="dash-empty">{personal ? "None of their tasks have open dependencies." : "No open dependencies. Add them on any task card."}</div>}
          <div className="dep-grid">
            {depTasks.map((t) =>
            <div key={t.id} className="dep-card" onClick={() => setOpenTask(t)}>
                <div className="dep-card-task"><span className={"status-dot s-" + t.status} />{t.title}</div>
                <div className="dep-card-needs">
                  {(t.deps || []).map((d) => {
                  const r = resolveDep(d, tasks, products);
                  return <span key={d.id} className={"dep-need" + (r.external ? " ext" : r.blocked ? " blocked" : " ok")} title={r.scope}><Icon name={r.icon} size={11} />{r.name}{r.external && r.scope ? ` (${r.scope})` : ""}</span>;
                })}
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
      {openTask && <CardModal task={openTask} onClose={() => setOpenTask(null)} />}
    </div>);

}

function TaskLine({ t, ph, onOpen }) {
  return (
    <div className="person-task" onClick={() => onOpen(t)}>
      <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
      <span className="person-task-title">{t.title}</span>
      {ph && <span className="person-task-phase">{ph.label}</span>}
    </div>);
}

function UpcomingTimeline({ viewTasks, tasks, products, milestones, commPlan, categories, phaseOf, onOpen, go }) {
  const DAYMS = 86400000;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  // upcoming = not done, dated, ending today or later — soonest first
  const upcoming = (viewTasks || [])
    .filter((t) => t.status !== "done" && t.start && t.end && new Date(t.end) >= today)
    .sort((a, b) => new Date(a.start) - new Date(b.start))
    .slice(0, 8);

  // future markers: milestones, gates, comms ending today or later
  const futureMs = (milestones || []).filter((m) => m.date && new Date(m.date) >= today);
  const futureComms = (commPlan || []).filter((c) => c.date && new Date(c.date) >= today);

  if (!upcoming.length && !futureMs.length && !futureComms.length) {
    return (
      <section className="dash-panel" style={{ marginBottom: 18 }}>
        <div className="dash-panel-hd"><span className="card-hd">Upcoming — the road ahead</span></div>
        <div className="dash-empty">Nothing scheduled ahead. Add dates to actions, gates/milestones or communications to see the road ahead.</div>
      </section>
    );
  }

  let min = Infinity, max = -Infinity;
  upcoming.forEach((t) => { min = Math.min(min, +new Date(t.start)); max = Math.max(max, +new Date(t.end)); });
  futureMs.forEach((m) => { min = Math.min(min, +new Date(m.date)); max = Math.max(max, +new Date(m.date)); });
  futureComms.forEach((c) => { min = Math.min(min, +new Date(c.date)); max = Math.max(max, +new Date(c.date)); });
  min = Math.min(min, +today);
  max = Math.max(max, +today + 7 * DAYMS);
  const span = Math.max(1, (max - min) / DAYMS);
  const pct = (d) => ((+new Date(d) - min) / DAYMS / span) * 100;
  const todayPct = ((+today - min) / DAYMS / span) * 100;
  const catColor = (id) => { const c = (categories || []).find((x) => x.id === id); return c ? "var(--t-" + c.color + ")" : "var(--accent)"; };

  // month ticks
  const ticks = [];
  const d = new Date(min); d.setDate(1);
  while (+d <= max) {
    ticks.push({ label: d.toLocaleDateString("en-GB", { month: "short" }), left: ((+d - min) / DAYMS / span) * 100 });
    d.setMonth(d.getMonth() + 1);
  }

  const gates = futureMs.filter((m) => m.type === "gate");
  const miles = futureMs.filter((m) => m.type !== "gate");
  // tie each gate/milestone to the action it gates: same category, nearest deadline
  const ownerOf = {};
  futureMs.forEach((m) => {
    const sameCat = upcoming.filter((t) => t.category && t.category === m.category);
    if (!sameCat.length) return;
    let best = null, bd = Infinity;
    sameCat.forEach((t) => { const d = Math.abs(+new Date(t.end) - +new Date(m.date)); if (d < bd) { bd = d; best = t; } });
    ownerOf[m.id] = best.id;
  });
  const ownerName = (id) => { const t = upcoming.find((x) => x.id === id); return t ? t.title : ""; };

  return (
    <section className="dash-panel up-panel" style={{ marginBottom: 18 }}>
      <div className="dash-panel-hd">
        <span className="card-hd">Upcoming — the road ahead</span>
        <button className="btn btn-sm btn-ghost" onClick={() => go("actions")}>Full timeline <Icon name="arrowR" size={13} /></button>
      </div>
      <div className="up-track-head">
        {ticks.map((tk, i) => (tk.left >= 0 && tk.left <= 100) && <span key={i} className="up-tick" style={{ left: tk.left + "%" }}>{tk.label}</span>)}
        {/* date ruler: every gate, milestone & comms marker */}
        {gates.map((m) => <span key={m.id} className="up-mk-gate" style={{ left: pct(m.date) + "%" }} title={m.title + " (gate) — " + fmtD(m.date) + (ownerOf[m.id] ? " · gates: " + ownerName(ownerOf[m.id]) : "")}>▐</span>)}
        {miles.map((m) => <span key={m.id} className="up-mk-mile" style={{ left: pct(m.date) + "%", color: catColor(m.category) }} title={m.title + (ownerOf[m.id] ? " · tied to: " + ownerName(ownerOf[m.id]) : "") + " — " + fmtD(m.date)}>◆</span>)}
        {futureComms.map((c) => <span key={c.id} className="up-mk-comm" style={{ left: pct(c.date) + "%" }} title={"Comms: " + (c.audience || "") + " — " + fmtD(c.date)}><Icon name="send" size={10} /></span>)}
        {todayPct >= 0 && todayPct <= 100 && <span className="up-today" style={{ left: todayPct + "%" }}><span className="up-today-pill">Today</span></span>}
      </div>
      <div className="up-rows">
        {todayPct >= 0 && todayPct <= 100 && <div className="up-today-layer"><span className="up-todayline-full" style={{ left: todayPct + "%" }} /></div>}
        {gates.length > 0 && <div className="up-today-layer">{gates.map((m) => { const gl = pct(m.date); return (gl >= 0 && gl <= 100) ? <span key={m.id} className="up-gateline-full" style={{ left: gl + "%" }} title={m.title + " (gate)" + (ownerOf[m.id] ? " — gates: " + ownerName(ownerOf[m.id]) : "")} /> : null; })}</div>}
        {upcoming.map((t) => {
          const left = Math.max(0, pct(t.start));
          const width = Math.max(2.5, pct(t.end) - pct(t.start));
          const deps = (t.deps || []).map((dep) => resolveDep(dep, tasks, products));
          const blockers = deps.filter((r) => r.blocked && !r.external);
          const externals = deps.filter((r) => r.external);
          const risky = blockers.length > 0;
          const rowGates = gates.filter((m) => ownerOf[m.id] === t.id);
          const rowMiles = miles.filter((m) => ownerOf[m.id] === t.id);
          return (
            <div key={t.id} className={"up-row" + (risky ? " risky" : "")} onClick={() => onOpen(t)}>
              <div className="up-label">
                <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                <span className="up-title">{t.title}</span>
                {rowGates.map((m) => <span key={m.id} className="up-tie up-tie-gate" title={"Gate: " + m.title}>▐ gate</span>)}
                {rowMiles.map((m) => <span key={m.id} className="up-tie up-tie-ms" style={{ color: catColor(m.category) }} title={"Milestone: " + m.title}>◆</span>)}
                {risky && <span className="up-warn" title={"Waiting on: " + blockers.map((b) => b.name).join(", ")}><Icon name="warn" size={12} /> {blockers.length}</span>}
                {externals.length > 0 && <span className="up-ext" title={"External: " + externals.map((b) => b.name).join(", ")}><Icon name="link" size={11} /> {externals.length}</span>}
              </div>
              <div className="up-track">
                <span className={"up-bar" + (t.status === "inprogress" ? " active" : "")} style={{ left: left + "%", width: width + "%" }}>
                  <span className="up-bar-dates">{fmtD(t.start)} → {fmtD(t.end)}</span>
                </span>
                {rowGates.map((m) => <span key={m.id} className="up-rowgate" style={{ left: pct(m.date) + "%" }} title={m.title + " (gate) — gates this action"}><span className="up-rowgate-dia">◆</span></span>)}
                {rowMiles.map((m) => <span key={m.id} className="up-rowms" style={{ left: pct(m.date) + "%", color: catColor(m.category) }} title={m.title + " — tied to this action"}>◆</span>)}
              </div>
            </div>
          );
        })}
        {/* gates/milestones with no task rows still need a band to sit on */}
        {!upcoming.length && (gates.length || miles.length || futureComms.length) > 0 && (
          <div className="up-row">
            <div className="up-label"><span className="up-title muted">Key dates</span></div>
            <div className="up-track"></div>
          </div>
        )}
      </div>
      <div className="up-legend">
        <span><span className="up-leg-bar active" /> In progress</span>
        <span><span className="up-leg-bar" /> Upcoming</span>
        <span style={{ color: "var(--accent-deep)" }}>◆ Milestone</span>
        <span style={{ color: "var(--t-red)" }}>▐ Gate</span>
        <span style={{ color: "var(--t-teal)" }}><Icon name="send" size={11} /> Comms</span>
        <span className="up-leg-warn"><Icon name="warn" size={12} /> Waiting on an unfinished task</span>
      </div>
    </section>
  );
}

function Stat({ n, label, icon, accent }) {
  return (
    <div className={"stat" + (accent ? " accent" : "")}>
      <span className="stat-icon"><Icon name={icon} size={17} /></span>
      <span className="stat-n serif">{n}</span>
      <span className="stat-label">{label}</span>
    </div>);

}

function HeroImage({ projectId }) {
  const KEY = "atlas.hero." + projectId;
  const [url, setUrl] = React.useState(null);
  const inputRef = React.useRef(null);
  React.useEffect(() => {
    let u;
    Store.files.get(KEY).then((blob) => {
      if (blob) { u = URL.createObjectURL(blob); setUrl(u); }
    });
    return () => { if (u) URL.revokeObjectURL(u); };
  }, [projectId]);
  const onFile = async (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    await Store.files.put(KEY, file);
    if (url) URL.revokeObjectURL(url);
    setUrl(URL.createObjectURL(file));
  };
  const onDrop = (e) => { e.preventDefault(); if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]); };
  const remove = async () => { await Store.files.del(KEY); if (url) URL.revokeObjectURL(url); setUrl(null); };

  if (url) {
    return (
      <div className="hero-img-wrap">
        <img src={url} className="hero-img" alt="Project cover" />
        <div className="hero-img-actions no-print">
          <button className="btn btn-sm btn-ghost" onClick={() => inputRef.current.click()}><Icon name="edit" size={13} /> Change</button>
          <button className="btn btn-sm btn-ghost btn-danger" onClick={remove}><Icon name="trash" size={13} /></button>
        </div>
        <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => { if (e.target.files[0]) onFile(e.target.files[0]); e.target.value = ""; }} />
      </div>
    );
  }
  return (
    <div className="hero-img-drop no-print" onDragOver={(e) => e.preventDefault()} onDrop={onDrop} onClick={() => inputRef.current.click()}>
      <Icon name="image" size={22} />
      <span>Add a cover image</span>
      <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => { if (e.target.files[0]) onFile(e.target.files[0]); e.target.value = ""; }} />
    </div>
  );
}

Object.assign(window, { Dashboard });