/* ============================================================
   APP SHELL — projects landing + per-project sidebar & routing
   ============================================================ */
const { useState: useApp } = React;

// sections that can be toggled on/off per project
const TOGGLEABLE = {
  comms: "Communication plan",
  change: "Change management",
  scope: "Scope",
  business: "Business case",
  preanalysis: "Pre-analysis",
  catalogue: "Product catalogue",
  org: "Roles & org chart"
};
const DEFAULT_ON = ["comms", "change", "scope", "business", "preanalysis", "catalogue", "org"];

const NAV = [
{ group: "Overview", items: [
  { id: "home", label: "Front page", icon: "home" },
  { id: "scope", label: "Scope", icon: "scope" },
  { id: "business", label: "Business case", icon: "doc" }]
},
{ group: "Delivery", items: [
  { id: "kanban", label: "Kanban board", icon: "board", count: (s) => s.tasks.length },
  { id: "actions", label: "Action list & timeline", icon: "timeline", count: (s) => s.tasks.length },
  { id: "catalogue", label: "Product catalogue", icon: "box", count: (s) => s.products.length }]
},
{ group: "People", items: [
  { id: "members", label: "Project members", icon: "users", count: (s) => (s.members || []).length },
  { id: "org", label: "Roles & org chart", icon: "org" }]
},
{ group: "Change & comms", items: [
  { id: "comms", label: "Communication plan", icon: "comms", count: (s) => (s.commPlan || []).length },
  { id: "change", label: "Change management", icon: "swap", count: (s) => (s.changePlan && s.changePlan.groups || []).reduce((a, g) => a + g.rows.length, 0) }]
},
{ group: "Insight", items: [
  { id: "preanalysis", label: "Pre-analysis", icon: "bulb", count: (s) => s.findings.length },
  { id: "risks", label: "Risks & mitigation", icon: "shield", count: (s) => s.risks.length },
  { id: "kpis", label: "KPIs & progress", icon: "target", count: null },
  { id: "glossary", label: "Glossary", icon: "tag", count: (s) => (s.glossary || []).length }]
}];


const TITLES = {
  home: ["Front page", "Project overview & quick links"],
  scope: ["Scope", "Boundaries and as-is / to-be"],
  business: ["Business case", "Purpose, outcomes & justification"],
  kanban: ["Kanban board", "Backlog → In progress → Done"],
  actions: ["Actions & timeline", "Plan of work by phase"],
  catalogue: ["Product catalogue", "Deliverables produced by the project"],
  members: ["Project members", "Everyone working on the project"],
  org: ["Roles & responsibilities", "Reporting structure"],
  comms: ["Communication plan", "Who hears what, when and how"],
  change: ["Change management plan", "Activities that embed the change"],
  preanalysis: ["Pre-analysis", "Early research findings"],
  risks: ["Risks & mitigation", "What could go wrong, and the plan"],
  kpis: ["KPIs & progress", "Live workload and project-health metrics"],
  glossary: ["Glossary", "Terms used in this project — highlighted everywhere they appear"]
};

function App() {
  const root = Store.useRoot();
  const [view, setView] = useApp(() => location.hash.slice(1) || "home");
  const [showSync, setShowSync] = useApp(false);
  const [showSections, setShowSections] = useApp(false);
  React.useEffect(() => {
    const h = () => setView(location.hash.slice(1) || "home");
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  React.useEffect(() => {if (window.initSync) window.initSync();}, []);
  React.useEffect(() => {if (window.setupGlossaryHighlighter) window.setupGlossaryHighlighter();}, []);
  const go = (v) => {location.hash = v;setView(v);};

  const s = root.activeId ? Store.getState() : null;
  const enabledSections = (s && Array.isArray(s._enabledSections)) ? s._enabledSections : DEFAULT_ON;
  const isSectionOn = (id) => !TOGGLEABLE[id] || enabledSections.includes(id);

  // if current view is toggled off, redirect home
  React.useEffect(() => {
    if (s && TOGGLEABLE[view] && !isSectionOn(view)) go("home");
  }, [enabledSections, view, !!s]);

  // top-level: no active project, or explicit projects route → landing
  if (!root.activeId || view === "projects" || !s) {
    return <ProjectsHome />;
  }

  const [title, sub] = TITLES[view] || ["", ""];
  const parent = s.parentId ? root.projects.find((p) => p.id === s.parentId) : null;

  const toggleSection = (id) => {
    const next = enabledSections.includes(id) ? enabledSections.filter((x) => x !== id) : [...enabledSections, id];
    Store.setState((st) => ({ ...st, _enabledSections: next }));
  };

  const Views = {
    home: window.Dashboard, business: window.BusinessCase, kanban: window.Kanban,
    actions: window.Actions, catalogue: window.Catalogue, members: window.Members, stakeholders: window.Members,
    org: window.OrgChart, preanalysis: window.PreAnalysis, risks: window.Risks, scope: window.ScopePage,
    comms: window.CommPlan, change: window.ChangePlan, glossary: window.Glossary, kpis: window.KPIs
  };
  const Current = Views[view] || (() => <div className="view-pad">Not found</div>);

  return (
    <div className="app">
      <aside className="sidebar no-print">
        <button className="proj-switch" onClick={() => { Store.projects.close(); go("projects"); }}>
          <span className="proj-switch-mark" style={{ background: "var(--t-" + (s.color || "indigo") + ")" }}>{(s.meta?.project || "P")[0]}</span>
          <span className="proj-switch-text">
            <span className="proj-switch-name">{s.meta?.project}</span>
            <span className="proj-switch-code mono">{parent ? "↗ " + parent.meta?.project : "View portfolio"}</span>
          </span>
          <span className="proj-switch-ico"><Icon name="chevD" size={15} /></span>
        </button>
        <button className="all-proj no-print" onClick={() => { Store.projects.close(); go("projects"); }}><Icon name="layers" size={14} /> All projects</button>

        {NAV.map((grp) => {
          const visibleItems = grp.items.filter((it) => isSectionOn(it.id));
          if (!visibleItems.length) return null;
          return (
            <div className="nav-group" key={grp.group}>
              <div className="nav-label">{grp.group}</div>
              {visibleItems.map((it) =>
              <button key={it.id} className={"nav-item" + (view === it.id ? " active" : "")} onClick={() => go(it.id)}>
                  <Icon name={it.icon} />
                  <span className="grow" style={{ textAlign: "left" }}>{it.label}</span>
                  {it.count && <span className="nav-count">{it.count(s)}</span>}
                </button>
              )}
            </div>);

        })}
        <div className="sidebar-foot">
          <button className="sync-badge" onClick={() => setShowSections(true)}>
            <span className="sync-dot" style={{ background: "var(--accent)" }} />
            <span className="grow" style={{ textAlign: "left" }}>add or remove
sections</span>
            <Icon name="layers" size={13} />
          </button>
          <SyncBadge onClick={() => setShowSync(true)} />
        </div>
      </aside>

      <main className="main">
        <header className="topbar no-print">
          <h1>{title}</h1>
          <span className="topbar-sub">{sub}</span>
          <div className="topbar-actions">
            <button className="btn" onClick={() => window.print()} title="Print this view to PDF"><Icon name="print" size={15} /> Print / PDF</button>
          </div>
        </header>
        <div className="print-head print-only">
          <div className="print-head-l">
            <span className="print-brand">Atlas</span>
            <span className="print-proj">{parent ? parent.meta?.project + " / " : ""}{s.meta?.project}</span>
          </div>
          <div className="print-head-r">
            <span className="print-view">{title}</span>
            <span className="print-date">{new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</span>
          </div>
        </div>
        <Current go={go} />
      </main>
      <SyncToast />
      {showSync && <SyncPanel onClose={() => setShowSync(false)} />}
      {showSections && <SectionsModal enabled={enabledSections} onToggle={toggleSection} onClose={() => setShowSections(false)} />}
    </div>);
}

function SectionsModal({ enabled, onToggle, onClose }) {
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Customise sections</div>
          <div className="muted" style={{ fontSize: 13 }}>Turn off sections that aren't relevant to this project. They stay hidden from the sidebar — turn them back on any time.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="sections-list">
          {Object.entries(TOGGLEABLE).map(([id, label]) => {
            const on = enabled.includes(id);
            return (
              <label key={id} className={"section-toggle" + (on ? " on" : "")}>
                <input type="checkbox" checked={on} onChange={() => onToggle(id)} />
                <Icon name={NAV.flatMap((g) => g.items).find((i) => i.id === id)?.icon || "doc"} size={16} />
                <span className="grow">{label}</span>
                {!on && <span className="section-off-label">Hidden</span>}
              </label>);

          })}
        </div>
      </div>
      <div className="modal-ft">
        <span className="muted" style={{ fontSize: 12 }}>Changes apply immediately to this project only.</span>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>);

}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);