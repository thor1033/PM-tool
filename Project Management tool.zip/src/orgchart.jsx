/* ============================================================
   ORG CHART — free-positioned roles, drag-to-connect lines,
   floating (unattached) roles. Exposes window.OrgChart
   ============================================================ */
const { useState: useO, useRef: useOR, useMemo: useOM, useEffect: useOE } = React;

const NODEW = 192, NODEH = 96, HGAP = 48, VGAP = 96, GRID = 96;
const ORG_ACCENTS = ["purple", "indigo", "blue", "teal", "green", "amber", "pink", "red"];

/* tidy-tree fallback positions for nodes that have never been placed */
function autoLayout(nodes) {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, { ...n, children: [] }]));
  const roots = [];
  nodes.forEach((n) => { if (n.parent && byId[n.parent]) byId[n.parent].children.push(byId[n.id]); else roots.push(byId[n.id]); });
  let leaf = 0;
  const place = (node, depth) => {
    node.depth = depth;
    if (!node.children.length) { node.ax = leaf * (NODEW + HGAP); leaf++; }
    else { node.children.forEach((c) => place(c, depth + 1)); node.ax = (node.children[0].ax + node.children[node.children.length - 1].ax) / 2; }
    node.ay = depth * (NODEH + VGAP);
  };
  roots.forEach((r) => { place(r, 0); leaf += 1; });
  return byId;
}

function descendantsOf(nodes, id) {
  const out = new Set([id]); let added = true;
  while (added) { added = false; nodes.forEach((n) => { if (n.parent && out.has(n.parent) && !out.has(n.id)) { out.add(n.id); added = true; } }); }
  return out;
}

function OrgChart() {
  const { org, members } = Store.useStore();
  const wrapRef = useOR(null);
  const [del, setDel] = useO(null);
  const [showMemberMenu, setShowMemberMenu] = useO(false);
  const [live, setLive] = useO(null);       // {id,x,y} while moving
  const [link, setLink] = useO(null);        // {id, x, y, target} while connecting
  const PAD = 40;

  // The member list is the source of truth: a card linked to a member (by
  // memberId) inherits its name, role and colour live. Unlinked cards keep
  // their own values. The note (responsibility) is always card-specific.
  const memById = useOM(() => Object.fromEntries((members || []).map((m) => [m.id, m])), [members]);
  const linkedMember = (n) => (n.memberId ? memById[n.memberId] : (members || []).find((m) => m.name === n.name)) || null;
  const dispName = (n) => { const m = linkedMember(n); return m ? m.name : n.name; };
  const dispRole = (n) => { const m = linkedMember(n); return m ? (m.role || "") : (n.role || ""); };
  const dispAccent = (n) => { const m = linkedMember(n); return m ? (m.color || "indigo") : (n.accent || "indigo"); };

  // Auto-layout: every role's position is DERIVED from the reporting structure
  // (a tidy tree) and recomputed whenever that structure changes. A node only
  // keeps a hand-placed position once the user has explicitly dragged it
  // (its `manual` flag). Re-linking or Auto-arrange clears the flag so the
  // role snaps back to its computed slot.
  const autoPos = useOM(() => {
    const byId = autoLayout(org);
    const out = {};
    org.forEach((n) => {
      const b = byId[n.id] || {};
      out[n.id] = {
        x: Math.max(0, Math.round((b.ax || 0) / GRID) * GRID),
        y: Math.max(0, Math.round((b.ay || 0) / GRID) * GRID),
      };
    });
    return out;
  }, [org]);

  const posOf = (n) => {
    if (live && live.id === n.id) return { x: live.x, y: live.y };
    if (n.manual && n.x != null && n.y != null) return { x: n.x, y: n.y };
    return autoPos[n.id] || { x: n.x || 0, y: n.y || 0 };
  };
  const bounds = useOM(() => {
    let w = 600, h = 360;
    org.forEach((n) => { const p = posOf(n); w = Math.max(w, p.x + NODEW); h = Math.max(h, p.y + NODEH); });
    return { w: w + PAD * 2, h: h + PAD * 2 };
  }, [org, live]);

  const canvasXY = (e) => {
    const r = wrapRef.current.getBoundingClientRect();
    return { x: e.clientX - r.left + wrapRef.current.scrollLeft - PAD, y: e.clientY - r.top + wrapRef.current.scrollTop - PAD };
  };

  /* ---- move a card freely ---- */
  const moveRef = useOR(null);
  const startMove = (e, n) => {
    e.preventDefault(); e.stopPropagation();
    const c = canvasXY(e); const p = posOf(n);
    moveRef.current = { id: n.id, ox: c.x - p.x, oy: c.y - p.y, moved: false };
    setLive({ id: n.id, x: p.x, y: p.y });
    window.addEventListener("pointermove", onMoveMove);
    window.addEventListener("pointerup", onMoveUp);
  };
  const onMoveMove = (e) => {
    const m = moveRef.current; if (!m) return;
    const c = canvasXY(e);
    m.moved = true;
    // snap live preview to the grid so it feels firm while dragging
    m.lastX = Math.max(0, Math.round((c.x - m.ox) / GRID) * GRID);
    m.lastY = Math.max(0, Math.round((c.y - m.oy) / GRID) * GRID);
    setLive({ id: m.id, x: m.lastX, y: m.lastY });
  };
  const onMoveUp = () => {
    window.removeEventListener("pointermove", onMoveMove);
    window.removeEventListener("pointerup", onMoveUp);
    const m = moveRef.current; moveRef.current = null;
    if (m && m.moved && m.lastX != null) {
      const gx = Math.max(0, Math.round(m.lastX / GRID) * GRID);
      const gy = Math.max(0, Math.round(m.lastY / GRID) * GRID);
      Store.patch("org", m.id, { x: gx, y: gy, manual: true });
    }
    setLive(null);
  };

  /* ---- drag-to-connect a reporting line ---- */
  const linkRef = useOR(null);
  const startLink = (e, n) => {
    e.preventDefault(); e.stopPropagation();
    const c = canvasXY(e);
    linkRef.current = { id: n.id, blocked: descendantsOf(org, n.id) };
    setLink({ id: n.id, x: c.x, y: c.y, target: null });
    window.addEventListener("pointermove", onLinkMove);
    window.addEventListener("pointerup", onLinkUp);
  };
  const onLinkMove = (e) => {
    const l = linkRef.current; if (!l) return;
    const c = canvasXY(e);
    let target = null;
    for (const n of org) {
      if (l.blocked.has(n.id)) continue;
      const p = posOf(n);
      if (c.x >= p.x && c.x <= p.x + NODEW && c.y >= p.y && c.y <= p.y + NODEH) { target = n.id; break; }
    }
    l.target = target;
    setLink({ id: l.id, x: c.x, y: c.y, target });
  };
  const onLinkUp = () => {
    window.removeEventListener("pointermove", onLinkMove);
    window.removeEventListener("pointerup", onLinkUp);
    const l = linkRef.current; linkRef.current = null;
    // Re-link: drop any manual placement so the role snaps into its correct
    // auto position under the new manager (or its floating slot).
    if (l) Store.patch("org", l.id, { parent: l.target || null, manual: false, x: null, y: null });
    setLink(null);
  };

  const addRole = (parentId) => {
    const id = Store.uid("o");
    // No fixed coordinates — the auto-layout drops the new role into the right
    // slot (below its parent, or in the floating row) on the next render.
    Store.add("org", { id, name: "New role", role: "", parent: parentId || null, note: "", accent: ORG_ACCENTS[org.length % ORG_ACCENTS.length], manual: false, x: null, y: null });
  };
  // AUTO-SYNC: the member list is the source of truth. Any member without a card
  // is added automatically (deletions are handled in Store.removeMember, which
  // drops the card and the person's task assignments). Manually-added floating
  // roles (no member link) are left alone.
  const memberCardless = (members || []).filter((m) => m.name && !org.some((o) => o.memberId === m.id || o.name === m.name));
  useOE(() => {
    if (!memberCardless.length) return;
    Store.setState((s) => {
      let next = [...s.org];
      const topId = (next.find((n) => !n.parent) || {}).id || null;
      (s.members || []).forEach((m) => {
        if (!m.name) return;
        if (next.some((o) => o.memberId === m.id || o.name === m.name)) return;
        next.push({ id: Store.uid("o"), memberId: m.id, name: m.name, role: m.role || "", parent: topId, note: "", accent: m.color || "indigo", manual: false, x: null, y: null });
      });
      return { ...s, org: next };
    });
  }, [memberCardless.length]);
  const removeNode = (id) => {
    const node = org.find((n) => n.id === id);
    Store.setState((s) => ({ ...s, org: s.org.filter((n) => n.id !== id).map((n) => n.parent === id ? { ...n, parent: node.parent } : n) }));
  };
  // reconcile the chart with the member list: cards to add (members with no card)
  // and cards to drop (roles not tied to any member — usually seed leftovers)
  const memberCardless = (members || []).filter((m) => !org.some((o) => o.memberId === m.id || o.name === m.name));
  const orphanCards = org.filter((o) => !o.memberId && !(members || []).some((m) => m.name === o.name));
  const syncWithMembers = () => {
    Store.setState((s) => {
      let next = [...s.org];
      orphanCards.forEach((orph) => {
        next = next.filter((n) => n.id !== orph.id).map((n) => (n.parent === orph.id ? { ...n, parent: orph.parent } : n));
      });
      const topId = (next.find((n) => !n.parent) || {}).id || null;
      memberCardless.forEach((m) => {
        next.push({ id: Store.uid("o"), memberId: m.id, name: m.name, role: m.role || "", parent: topId, note: "", accent: m.color || "indigo", manual: false, x: null, y: null });
      });
      return { ...s, org: next };
    });
    setSyncOpen(false);
  };
  const addMemberNode = (m) => {
    const id = Store.uid("o");
    Store.add("org", { id, memberId: m.id, name: m.name, role: m.role || "", parent: null, note: "", accent: m.color || ORG_ACCENTS[org.length % ORG_ACCENTS.length], manual: false, x: null, y: null });
    setShowMemberMenu(false);
  };

  // snap everything back to the computed layout (drop all manual placements)
  const tidyUp = () => Store.setState((s) => ({ ...s, org: s.org.map((n) => ({ ...n, manual: false, x: null, y: null })) }));
  const anyManual = org.some((n) => n.manual);

  // shared horizontal trunk per parent: each parent's children share one horizontal line
  // drawn at a fixed offset below the parent's bottom edge.
  const TRUNK_OFFSET = 36;
  const connPoint = (n, which) => { const p = posOf(n); return which === "bottom" ? { x: p.x + NODEW / 2, y: p.y + NODEH } : { x: p.x + NODEW / 2, y: p.y }; };
  // build per-parent trunk paths (one combined SVG path each)
  const trunkPaths = useOM(() => {
    const byParent = new Map();
    org.forEach((n) => {
      if (!n.parent) return;
      const p = org.find((x) => x.id === n.parent); if (!p) return;
      if (!byParent.has(p.id)) byParent.set(p.id, { parent: p, children: [] });
      byParent.get(p.id).children.push(n);
    });
    const paths = [];
    byParent.forEach(({ parent, children }) => {
      const a = connPoint(parent, "bottom");
      const trunkY = a.y + TRUNK_OFFSET;
      const stemX = a.x;
      const childPoints = children.map((c) => connPoint(c, "top"));
      const leftX = Math.min(stemX, ...childPoints.map((p) => p.x));
      const rightX = Math.max(stemX, ...childPoints.map((p) => p.x));
      let d = `M${stemX + PAD},${a.y + PAD} V${trunkY + PAD}`;
      if (leftX !== rightX) d += ` M${leftX + PAD},${trunkY + PAD} H${rightX + PAD}`;
      childPoints.forEach((cp) => { d += ` M${cp.x + PAD},${trunkY + PAD} V${cp.y + PAD}`; });
      paths.push({ key: parent.id, d, color: "var(--t-" + dispAccent(parent) + ")" });
    });
    return paths;
  }, [org, live, PAD]);

  return (
    <div className="view-scroll">
      <div className="view-pad">
        <div className="between" style={{ marginBottom: 16, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 600, fontSize: 14, lineHeight: 1.55 }}>
            Roles arrange themselves automatically by who reports to whom. Cards marked <b>member</b> inherit their name, role &amp; colour from the <b>Members</b> page. Drag the <b>link handle</b> onto another role to set its manager — or onto empty space to leave it <b>floating</b>. Drag the <b>move grip</b> to fine-tune; <b>Auto-arrange</b> snaps everything back.
          </p>
          <div className="row no-print" style={{ gap: 8 }}>
            <button className="btn" onClick={tidyUp} disabled={!anyManual} title={anyManual ? "Snap every role back to its automatic position" : "Everything is already auto-arranged"}><Icon name="org" size={15} /> Auto-arrange</button>
            <button className="btn" onClick={() => addRole(null)}><Icon name="plus" size={15} /> Add floating role</button>
          </div>
        </div>

        <div className="org-wrap panel" ref={wrapRef}>
          <div className="org-canvas org-grid" style={{ width: bounds.w, height: bounds.h }}>
            <svg className="org-lines" width={bounds.w} height={bounds.h}>
              {trunkPaths.map((p) => <path key={p.key} d={p.d} className="org-line" stroke={p.color} />)}
              {link && (() => {
                const src = org.find((x) => x.id === link.id); if (!src) return null;
                const a = connPoint(src, "bottom");
                const b = { x: link.x - NODEW / 2, y: link.y };
                const trunkY = a.y + TRUNK_OFFSET;
                return <path d={`M${a.x + PAD},${a.y + PAD} V${trunkY + PAD} H${b.x + PAD} V${b.y + PAD}`} className="org-line live" />;
              })()}
            </svg>
            {org.map((n) => {
              const p = posOf(n);
              const floating = !n.parent && !org.some((c) => c.parent === n.id);
              const mem = linkedMember(n);
              return (
                <div key={n.id}
                  className={"org-node" + (link?.target === n.id ? " target" : "") + (live?.id === n.id ? " moving" : "") + (floating ? " floating" : "")}
                  style={{ left: p.x + PAD, top: p.y + PAD, width: NODEW, "--node-c": "var(--t-" + dispAccent(n) + ")" }}>
                  <div className="org-node-bar" />
                  <div className="org-node-hd">
                    <span className="org-grip" onPointerDown={(e) => startMove(e, n)} title="Drag to move"><Icon name="drag" size={15} /></span>
                    {mem && <span className="org-member-tag" title="Linked to a project member — edit name, role & colour on the Members page"><Icon name="users" size={11} /> member</span>}
                    {floating && <span className="org-float-tag mono">floating</span>}
                    <div className="org-actions no-print">
                      <button className="org-act" title="Add report under this role" onClick={() => addRole(n.id)}><Icon name="plus" size={13} /></button>
                      <button className="org-act" title="Remove" onClick={() => setDel(n.id)}><Icon name="x" size={13} /></button>
                    </div>
                  </div>
                  {mem ? (
                    <React.Fragment>
                      <div className="org-name org-name-ro" title="Edit on the Members page">{dispName(n)}</div>
                      <div className="org-role org-role-ro">{dispRole(n) || <span className="org-role-empty">No role set</span>}</div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      <UI.Editable className="org-name" value={n.name} onChange={(v) => Store.patch("org", n.id, { name: v || "Unnamed" })} placeholder="Name" />
                      <UI.Editable className="org-role" value={n.role} onChange={(v) => Store.patch("org", n.id, { role: v })} placeholder="Role" />
                    </React.Fragment>
                  )}
                  <UI.Editable className="org-note" value={n.note} onChange={(v) => Store.patch("org", n.id, { note: v })} placeholder="responsibility…" />
                  <span className="org-link no-print" onPointerDown={(e) => startLink(e, n)} title="Drag onto a role to set who this reports to (or drop on empty to float)">
                    <Icon name="link" size={13} />
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {del && <UI.Confirm title="Remove this role?" body="Any direct reports move up to this role's manager (or become floating)." confirmLabel="Remove" onConfirm={() => removeNode(del)} onClose={() => setDel(null)} />}
    </div>
  );
}

Object.assign(window, { OrgChart });
