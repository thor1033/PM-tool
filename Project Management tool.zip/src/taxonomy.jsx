/* ============================================================
   TAXONOMY EDITOR — edit categories, tags, phases
   Exposes window.TaxonomyEditor
   ============================================================ */
const { useState: useTx } = React;

const TAX_COLORS = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];

function TaxonomyEditor({ onClose }) {
  const s = Store.useStore();
  const [tab, setTab] = useTx("categories");

  const TABS = [
    { id: "categories", label: "Categories", key: "categories", hint: "Group actions by theme (Platform, Migration, etc.)" },
    { id: "tags", label: "Tags", key: "tags", hint: "Label tasks with skills or topics (Frontend, Security, etc.)" },
    { id: "phases", label: "Phases", key: "phases", hint: "Timeline phases (Discovery, Design, Build, Launch)" },
  ];
  const cur = TABS.find((t) => t.id === tab);

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="tag" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Edit taxonomy</div>
          <div className="muted" style={{ fontSize: 13 }}>Add, rename, recolour or remove categories, tags and phases.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="sync-tabs">
        {TABS.map((t) => (
          <button key={t.id} className={tab === t.id ? "on" : ""} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="modal-bd">
        <p className="muted" style={{ fontSize: 13, lineHeight: 1.5, margin: "0 0 16px" }}>{cur.hint}</p>
        <TaxList storeKey={cur.key} items={s[cur.key] || []} />
      </div>
      <div className="modal-ft">
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

function TaxList({ storeKey, items }) {
  const [confirm, setConfirm] = useTx(null);

  const add = () => {
    const id = Store.uid(storeKey.slice(0, 2));
    Store.update(storeKey, (arr) => [...arr, { id, label: "New " + storeKey.slice(0, -1), color: TAX_COLORS[arr.length % TAX_COLORS.length] }]);
  };
  const patch = (id, changes) => {
    Store.update(storeKey, (arr) => arr.map((x) => (x.id === id ? { ...x, ...changes } : x)));
  };
  const remove = (id) => {
    Store.update(storeKey, (arr) => arr.filter((x) => x.id !== id));
    // clean up references in tasks
    if (storeKey === "categories") {
      Store.update("tasks", (arr) => arr.map((t) => t.category === id ? { ...t, category: null } : t));
      Store.update("milestones", (arr) => arr.map((m) => m.category === id ? { ...m, category: null } : m));
    } else if (storeKey === "tags") {
      Store.update("tasks", (arr) => arr.map((t) => ({ ...t, tags: (t.tags || []).filter((x) => x !== id) })));
    } else if (storeKey === "phases") {
      Store.update("tasks", (arr) => arr.map((t) => t.phase === id ? { ...t, phase: null } : t));
    }
    setConfirm(null);
  };
  const moveUp = (i) => {
    if (i === 0) return;
    Store.update(storeKey, (arr) => { const n = [...arr]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; return n; });
  };
  const moveDown = (i) => {
    Store.update(storeKey, (arr) => { if (i >= arr.length - 1) return arr; const n = [...arr]; [n[i], n[i + 1]] = [n[i + 1], n[i]]; return n; });
  };

  return (
    <div className="tax-list">
      {items.length === 0 && <div className="tax-empty">No {storeKey} yet. Add one below.</div>}
      {items.map((item, i) => (
        <div key={item.id} className="tax-row">
          <div className="tax-color-pick">
            {TAX_COLORS.map((c) => (
              <button key={c} className={"tax-swatch" + (item.color === c ? " on" : "")} style={{ background: "var(--t-" + c + ")" }} onClick={() => patch(item.id, { color: c })} />
            ))}
          </div>
          <UI.Editable className="tax-name" noPencil value={item.label} onChange={(v) => patch(item.id, { label: v || "Unnamed" })} placeholder="Name" />
          <div className="tax-actions">
            <button className="tax-act" onClick={() => moveUp(i)} disabled={i === 0} title="Move up"><Icon name="chevD" size={13} style={{ transform: "rotate(180deg)" }} /></button>
            <button className="tax-act" onClick={() => moveDown(i)} disabled={i === items.length - 1} title="Move down"><Icon name="chevD" size={13} /></button>
            <button className="tax-act tax-del" onClick={() => setConfirm(item.id)} title="Delete"><Icon name="trash" size={13} /></button>
          </div>
        </div>
      ))}
      <button className="btn btn-sm btn-ghost" style={{ marginTop: 8 }} onClick={add}>
        <Icon name="plus" size={13} /> Add {storeKey.slice(0, -1)}
      </button>
      {confirm && (
        <UI.Confirm
          title={"Delete " + storeKey.slice(0, -1) + "?"}
          body={"Tasks using this " + storeKey.slice(0, -1) + " will become uncategorised. This cannot be undone."}
          confirmLabel="Delete"
          onConfirm={() => remove(confirm)}
          onClose={() => setConfirm(null)}
        />
      )}
    </div>
  );
}

Object.assign(window, { TaxonomyEditor });
