/* ============================================================
   PRE-ANALYSIS — early research findings
   Exposes window.PreAnalysis
   ============================================================ */
const { useState: useP } = React;

function PreAnalysis() {
  const { findings, categories } = Store.useStore();
  const [filter, setFilter] = useP(null);
  const [del, setDel] = useP(null);

  const add = () => {
    Store.add("findings", { id: Store.uid("f"), title: "New finding", summary: "", category: null, source: "" });
  };
  const shown = filter ? findings.filter((f) => f.category === filter) : findings;

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <section className="prean-asis">
          <div className="between" style={{ marginBottom: 14, flexWrap: "wrap", gap: 10 }}>
            <div>
              <h2 className="scope-h serif" style={{ margin: "0 0 3px" }}>As-is assessment</h2>
              <p className="muted" style={{ margin: 0, fontSize: 13.5, lineHeight: 1.5, maxWidth: 560 }}>
                Capture the current state for each area you're studying. The <b>to-be</b> target is added later on the Scope page and in the Business case — they share this same table.
              </p>
            </div>
          </div>
          <AssessmentTable mode="asis" />
        </section>

        <div className="prean-divider" />

        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <div>
            <h2 className="scope-h serif" style={{ margin: "0 0 3px" }}>Findings</h2>
            <p className="muted" style={{ margin: 0, maxWidth: 520, fontSize: 13.5, lineHeight: 1.5 }}>
              Evidence gathered during discovery. These findings shaped the scope, the architecture and the business case.
            </p>
          </div>
          <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add finding</button>
        </div>

        <div className="filter-pills no-print" style={{ marginBottom: 20 }}>
          <button className={"fpill" + (!filter ? " on" : "")} style={{ "--t-var": "var(--accent)" }} onClick={() => setFilter(null)}>All</button>
          {categories.map((c) => (
            <button key={c.id} className={"fpill" + (filter === c.id ? " on" : "")} style={{ "--t-var": "var(--t-" + c.color + ")" }} onClick={() => setFilter(filter === c.id ? null : c.id)}>
              <span className="chip-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}
            </button>
          ))}
        </div>

        <div className="find-grid">
          {shown.map((f, i) => {
            const cat = categories.find((c) => c.id === f.category);
            return (
              <article key={f.id} className="find-card panel">
                <div className="find-num mono">{String(i + 1).padStart(2, "0")}</div>
                <div className="find-body">
                  <div className="find-cat-row">
                    <PickInline options={categories} value={f.category} onChange={(v) => Store.patch("findings", f.id, { category: v })} />
                    <button className="btn btn-icon btn-ghost btn-danger no-print" style={{ marginLeft: "auto" }} onClick={() => setDel(f.id)}><Icon name="trash" size={14} /></button>
                  </div>
                  <UI.Editable className="find-title serif" multiline value={f.title} onChange={(v) => Store.patch("findings", f.id, { title: v || "Untitled finding" })} placeholder="Finding headline" />
                  <UI.Editable className="find-summary" tag="div" multiline value={f.summary} onChange={(v) => Store.patch("findings", f.id, { summary: v })} placeholder="What did the research show, and why does it matter?" />
                  <div className="find-source">
                    <Icon name="search" size={13} />
                    <UI.Editable tag="span" className="mono" value={f.source} onChange={(v) => Store.patch("findings", f.id, { source: v })} placeholder="source" />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        {shown.length === 0 && <div className="empty"><div className="serif">No findings here</div>Try a different category or add one.</div>}
      </div>
      {del && <UI.Confirm title="Delete finding?" body="This removes the research finding." onConfirm={() => Store.remove("findings", del)} onClose={() => setDel(null)} />}
    </div>
  );
}

Object.assign(window, { PreAnalysis });
