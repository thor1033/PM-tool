/* ============================================================
   KPIs — project health & workload metrics
   Exposes window.KPIs
   ============================================================ */
const { useState: useKp, useMemo: useKpM } = React;

const DAY_MS = 86400000;
const startOfWeek = (d) => { const x = new Date(d); const day = (x.getDay() + 6) % 7; x.setDate(x.getDate() - day); x.setHours(0, 0, 0, 0); return x; };
const weekLabel = (d) => d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });

function KPIs() {
  const s = Store.useStore();
  const { tasks, members, categories, risks, milestones } = s;

  // ---------- per-category workload ----------
  const byCat = useKpM(() => {
    const map = new Map();
    categories.forEach((c) => map.set(c.id, { ...c, count: 0, days: 0, done: 0, inprogress: 0 }));
    map.set("__none", { id: "__none", label: "Uncategorised", color: "indigo", count: 0, days: 0, done: 0, inprogress: 0 });
    tasks.forEach((t) => {
      const k = t.category || "__none";
      const row = map.get(k); if (!row) return;
      row.count++;
      if (t.status === "done") row.done++;
      if (t.status === "inprogress") row.inprogress++;
      if (t.start && t.end) {
        row.days += Math.max(1, Math.round((new Date(t.end) - new Date(t.start)) / DAY_MS));
      }
    });
    return [...map.values()].filter((r) => r.count > 0).sort((a, b) => b.days - a.days);
  }, [tasks, categories]);

  // ---------- per-person workload ----------
  const byPerson = useKpM(() => {
    const map = new Map();
    (members || []).forEach((m) => map.set(m.name, { name: m.name, color: m.color || "indigo", role: m.role, count: 0, days: 0, done: 0, inprogress: 0 }));
    tasks.forEach((t) => {
      const who = assigneesOf(t);
      const dur = (t.start && t.end) ? Math.max(1, Math.round((new Date(t.end) - new Date(t.start)) / DAY_MS)) : 0;
      who.forEach((name) => {
        if (!map.has(name)) map.set(name, { name, color: "indigo", role: "", count: 0, days: 0, done: 0, inprogress: 0 });
        const row = map.get(name);
        row.count++;
        if (t.status === "done") row.done++;
        if (t.status === "inprogress") row.inprogress++;
        row.days += dur;
      });
    });
    if (map.size === 0) return [];
    return [...map.values()].filter((r) => r.count > 0).sort((a, b) => b.days - a.days);
  }, [tasks, members]);

  // ---------- per-week workload (4 windowed weeks) ----------
  const byWeek = useKpM(() => {
    const dated = tasks.filter((t) => t.start && t.end);
    const now = new Date();
    const currentStart = startOfWeek(now);
    const offsets = [-1, 0, 1, 2];
    const labels = { [-1]: "Last week", 0: "Current week", 1: "Next week", 2: "In 2 weeks" };
    const tones = { [-1]: "last", 0: "current", 1: "next", 2: "in2" };
    return offsets.map((off) => {
      const wkStart = new Date(+currentStart + off * 7 * DAY_MS);
      const wkEnd = new Date(+wkStart + 7 * DAY_MS);
      const active = dated.filter((t) => new Date(t.start) < wkEnd && new Date(t.end) >= wkStart);
      return {
        key: off,
        label: labels[off],
        tone: tones[off],
        range: wkStart.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) + " – " + new Date(+wkEnd - DAY_MS).toLocaleDateString("en-GB", { day: "numeric", month: "short" }),
        load: active.length,
        done: active.filter((t) => t.status === "done").length,
        inprog: active.filter((t) => t.status === "inprogress").length,
        backlog: active.filter((t) => t.status === "backlog").length,
      };
    });
  }, [tasks]);

  // ---------- progress + risk metrics ----------
  const overview = useKpM(() => {
    const total = tasks.length;
    const done = tasks.filter((t) => t.status === "done").length;
    const inprog = tasks.filter((t) => t.status === "inprogress").length;
    const backlog = tasks.filter((t) => t.status === "backlog").length;
    const completionPct = total ? Math.round(done / total * 100) : 0;
    const openRisks = risks.filter((r) => r.status !== "closed").length;
    const highRisks = risks.filter((r) => r.status !== "closed" && r.likelihood === "high" && r.impact === "high").length;
    const now = Date.now();
    const upcomingMs = (milestones || []).filter((m) => m.date && +new Date(m.date) >= now).sort((a, b) => +new Date(a.date) - +new Date(b.date)).slice(0, 4);
    return { total, done, inprog, backlog, completionPct, openRisks, highRisks, upcomingMs };
  }, [tasks, risks, milestones]);

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <p className="muted" style={{ margin: "0 0 22px", maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
          Live indicators on how the project is tracking — workload distribution, completion, and risk exposure. Everything updates as you edit tasks and risks.
        </p>

        {/* Overview tiles */}
        <div className="kpi-tiles kpi-tiles-big">
          <KpiTile label="Completion" big={overview.completionPct + "%"} sub={`${overview.done} of ${overview.total} tasks done`} accent="green" />
          <KpiTile label="In progress" big={String(overview.inprog)} sub={`${overview.backlog} still in backlog`} accent="blue" />
          <KpiTile label="Open risks" big={String(overview.openRisks)} sub={overview.highRisks ? `${overview.highRisks} high-impact` : "none high-impact"} accent={overview.highRisks ? "red" : "amber"} />
        </div>

        {/* Workload per week — 4-bar chart */}
        <section className="kpi-section">
          <div className="kpi-section-hd">
            <h2 className="kpi-h serif">Workload per week</h2>
            <span className="muted" style={{ fontSize: 13 }}>Tasks active in each week.</span>
          </div>
          {(() => {
            const maxLoad = Math.max(1, ...byWeek.map((w) => w.load));
            return (
              <div className="kpi-weekchart panel">
                <div className="kpi-weekchart-bars">
                  {byWeek.map((w) => (
                    <div key={w.key} className="kpi-weekbar-col">
                      <div className="kpi-weekbar-n mono">{w.load}</div>
                      <div className="kpi-weekbar-track">
                        <div className={"kpi-weekbar-fill " + w.tone} style={{ height: (w.load / maxLoad * 100) + "%" }} />
                      </div>
                      <div className="kpi-weekbar-label">{w.label}</div>
                      <div className="kpi-weekbar-range mono">{w.range}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </section>

        <div className="kpi-cols">
          {/* Per category */}
          <section className="kpi-section">
            <div className="kpi-section-hd">
              <h2 className="kpi-h serif">Workload per category</h2>
              <span className="muted" style={{ fontSize: 13 }}>Planned effort by theme.</span>
            </div>
            {byCat.length === 0 ? (
              <div className="empty" style={{ padding: 20 }}>No categorised tasks yet.</div>
            ) : (
              <div className="kpi-bars panel">
                {byCat.map((c) => {
                  const maxDays = Math.max(...byCat.map((x) => x.days), 1);
                  const pct = (c.days / maxDays) * 100;
                  const donePct = c.count ? (c.done / c.count) * 100 : 0;
                  return (
                    <div key={c.id} className="kpi-bar-row">
                      <div className="kpi-bar-name">
                        <span className="kcol-dot" style={{ background: "var(--t-" + c.color + ")" }} />
                        {c.label}
                      </div>
                      <div className="kpi-bar-track">
                        <div className="kpi-bar-fill" style={{ width: pct + "%", background: "var(--t-" + c.color + ")" }} />
                        <div className="kpi-bar-done" style={{ width: pct * donePct / 100 + "%" }} />
                      </div>
                      <div className="kpi-bar-stats mono">
                        <b>{c.days}d</b> · {c.count} task{c.count === 1 ? "" : "s"}
                        {c.done > 0 && <span className="muted"> · {Math.round(donePct)}% done</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Per person */}
          <section className="kpi-section">
            <div className="kpi-section-hd">
              <h2 className="kpi-h serif">Workload per person</h2>
              <span className="muted" style={{ fontSize: 13 }}>Days of work assigned, sorted by load.</span>
            </div>
            {byPerson.length === 0 ? (
              <div className="empty" style={{ padding: 20 }}>No one is assigned to tasks yet.</div>
            ) : (
              <div className="kpi-bars panel">
                {byPerson.map((p) => {
                  const maxDays = Math.max(...byPerson.map((x) => x.days), 1);
                  const pct = (p.days / maxDays) * 100;
                  return (
                    <div key={p.name} className="kpi-bar-row">
                      <div className="kpi-bar-name">
                        <span className="avatar" style={{ width: 22, height: 22, fontSize: 10, background: "var(--t-" + (p.color || "indigo") + ")" }}>{initials(p.name)}</span>
                        {p.name}
                      </div>
                      <div className="kpi-bar-track">
                        <div className="kpi-bar-fill" style={{ width: pct + "%", background: "var(--t-" + (p.color || "indigo") + ")" }} />
                      </div>
                      <div className="kpi-bar-stats mono">
                        <b>{p.days}d</b> · {p.count} task{p.count === 1 ? "" : "s"}
                        {p.inprogress > 0 && <span style={{ color: "var(--hue-progress)" }}> · {p.inprogress} active</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>

        {/* Upcoming milestones */}
        {overview.upcomingMs.length > 0 && (
          <section className="kpi-section">
            <div className="kpi-section-hd">
              <h2 className="kpi-h serif">Upcoming milestones &amp; gates</h2>
              <span className="muted" style={{ fontSize: 13 }}>Next four checkpoints.</span>
            </div>
            <div className="kpi-ms-list panel">
              {overview.upcomingMs.map((m) => {
                const cat = categories.find((c) => c.id === m.category);
                const days = Math.ceil((+new Date(m.date) - Date.now()) / DAY_MS);
                return (
                  <div key={m.id} className={"kpi-ms " + m.type}>
                    <span className={m.type === "gate" ? "ms-gate-icon" : "ms-mile-icon"}>{m.type === "gate" ? "┃" : "◆"}</span>
                    <div className="grow">
                      <div className="kpi-ms-title">{m.title}</div>
                      {cat && <div className="muted" style={{ fontSize: 12 }}>{cat.label}</div>}
                    </div>
                    <div className="kpi-ms-when mono">
                      <div className="kpi-ms-days">{days === 0 ? "today" : days > 0 ? `in ${days}d` : `${-days}d ago`}</div>
                      <div className="muted" style={{ fontSize: 11 }}>{new Date(m.date).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function KpiTile({ label, big, sub, accent }) {
  return (
    <div className={"kpi-tile accent-" + (accent || "indigo")}>
      <div className="kpi-tile-label">{label}</div>
      <div className="kpi-tile-big serif">{big}</div>
      <div className="kpi-tile-sub">{sub}</div>
    </div>
  );
}

Object.assign(window, { KPIs });
