/* ============================================================
   BUSINESS CASE — structured, printable, OPTIONAL sections
   User chooses which sections appear; numbering is dynamic.
   Exposes window.BusinessCase
   ============================================================ */
const { useState: useBC, useMemo: useBCM } = React;

const BC_SECTIONS = [
  { id: "situation", label: "Situation, challenges & opportunities" },
  { id: "risks", label: "Key risks" },
  { id: "outcomes", label: "Desired outcome & effects" },
  { id: "scope", label: "Scope" },
  { id: "asis", label: "As-is / To-be" },
  { id: "financial", label: "Financial justification" },
];
const ALL_IDS = BC_SECTIONS.map((s) => s.id);

function BusinessCase({ go }) {
  const s = Store.useStore();
  const bc = s.businessCase;
  const set = (c) => Store.setState((st) => ({ ...st, businessCase: { ...st.businessCase, ...c } }));
  const setList = (key, i, v) => set({ [key]: bc[key].map((x, idx) => (idx === i ? v : x)) });
  const addOutcome = () => set({ outcomes: [...(bc.outcomes || []), "New intended outcome"] });
  const removeOutcome = (i) => set({ outcomes: bc.outcomes.filter((_, idx) => idx !== i) });

  // which sections are active — stored alongside the BC
  const active = Array.isArray(bc._sections) ? bc._sections : ALL_IDS;
  const setActive = (ids) => set({ _sections: ids });
  const isOn = (id) => active.includes(id);
  const toggle = (id) => {
    if (isOn(id)) setActive(active.filter((x) => x !== id));
    else {
      // insert in canonical order
      const next = ALL_IDS.filter((x) => active.includes(x) || x === id);
      setActive(next);
    }
  };

  // dynamic numbering for active sections
  const num = useBCM(() => {
    const m = {}; let n = 1;
    ALL_IDS.forEach((id) => { if (active.includes(id)) { m[id] = n++; } });
    return m;
  }, [active]);

  const inactive = BC_SECTIONS.filter((s) => !isOn(s.id));

  const Persp = ({ k, label }) => (
    <div className="bc-persp">
      <div className="bc-persp-label">{label}</div>
      <UI.Editable className="bc-persp-text" tag="div" multiline value={bc[k]} onChange={(v) => set({ [k]: v })} placeholder="…" />
    </div>
  );
  const Effect = ({ k, label, hint }) => (
    <div className="bc-effect">
      <div className="bc-effect-hd">{label}</div>
      <div className="bc-effect-hint">{hint}</div>
      <UI.Editable className="bc-effect-text" tag="div" multiline value={bc[k]} onChange={(v) => set({ [k]: v })} placeholder="…" />
    </div>
  );
  const SectionRemove = ({ id }) => (
    <button className="btn btn-icon btn-ghost btn-danger no-print bc-remove" title="Remove this section" onClick={() => toggle(id)}><Icon name="x" size={15} /></button>
  );

  return (
    <div className="view-scroll">
      <div className="bc-doc">
        <header className="bc-head">
          <div className="bc-eyebrow eyebrow">Business Case</div>
          <UI.Editable className="bc-title serif" multiline value={s.meta?.project} onChange={(v) => Store.setState((st) => ({ ...st, meta: { ...st.meta, project: v } }))} />
          <div className="bc-byline mono">Prepared for the steering committee · Confidential</div>
        </header>

        {isOn("situation") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.situation} · Situation, challenges & opportunities</h2>
              <SectionRemove id="situation" />
            </div>
            <div className="bc-why">Why are we doing this? Why does it matter?</div>
            <UI.Editable className="bc-lead" tag="p" multiline value={bc.purpose} onChange={(v) => set({ purpose: v })} placeholder="Summarise the core reason this project exists." />
            <div className="bc-sub">Seen from each perspective</div>
            <div className="bc-persp-grid">
              <Persp k="perspOurs" label="Ours" />
              <Persp k="perspUsers" label="Users" />
              <Persp k="perspStakeholders" label="Other stakeholders" />
            </div>
            <div className="bc-twocol">
              <div>
                <div className="bc-sub"><Icon name="warn" size={14} /> Situations that create or worsen it</div>
                <UI.Editable className="bc-body" tag="p" multiline value={bc.worsening} onChange={(v) => set({ worsening: v })} placeholder="What makes the challenge harder or more urgent?" />
              </div>
              <div>
                <div className="bc-sub"><Icon name="bulb" size={14} /> Opportunities we can leverage</div>
                <UI.Editable className="bc-body" tag="p" multiline value={bc.opportunities} onChange={(v) => set({ opportunities: v })} placeholder="What can we take advantage of?" />
              </div>
            </div>
          </section>
        )}

        {isOn("risks") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.risks} · Project key risks</h2>
              <SectionRemove id="risks" />
            </div>
            <p className="bc-why" style={{ marginBottom: 14 }}>Pulled live from the Risks & mitigation register.</p>
            <RisksEmbed go={go} />
          </section>
        )}

        {isOn("outcomes") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.outcomes} · Desired outcome & effects</h2>
              <SectionRemove id="outcomes" />
            </div>
            <div className="bc-why">What does good look like? What tangible changes should we observe if this succeeds?</div>
            <ul className="bc-outcomes">
              {(bc.outcomes || []).map((o, i) => (
                <li key={i}>
                  <span className="bc-bullet"><Icon name="target" size={15} /></span>
                  <UI.Editable tag="span" className="grow" multiline value={o} onChange={(v) => setList("outcomes", i, v)} />
                  <button className="btn btn-icon btn-ghost btn-danger no-print" onClick={() => removeOutcome(i)}><Icon name="x" size={13} /></button>
                </li>
              ))}
            </ul>
            <button className="btn btn-sm btn-ghost no-print" onClick={addOutcome}><Icon name="plus" size={13} /> Add outcome / KPI</button>
            <div className="bc-effects">
              <Effect k="effProcess" label="Process" hint="What process changes are needed? New process, QMS / Cortex document?" />
              <Effect k="effSystem" label="System" hint="What system changes or functionalities? Which tools & templates?" />
              <Effect k="effBehaviour" label="Behaviour" hint="What should target users & key roles do, or be able to do?" />
              <Effect k="effLeadership" label="Leadership & Organisation" hint="Changes to leadership, structure, roles & training to succeed." />
            </div>
          </section>
        )}

        {isOn("scope") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.scope} · Scope</h2>
              <SectionRemove id="scope" />
            </div>
            <div className="bc-why">What's within the boundary, and what's explicitly outside?</div>
            <ScopeBoundaries compact />
            <button className="btn btn-sm no-print" style={{ marginTop: 12 }} onClick={() => go && go("scope")}><Icon name="scope" size={14} /> Open the Scope page</button>
          </section>
        )}

        {isOn("asis") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.asis} · As-is / To-be</h2>
              <SectionRemove id="asis" />
            </div>
            <div className="bc-why">Where we are today, and the target state once delivered. Tied to the scope above.</div>
            <AssessmentTable mode="full" />
          </section>
        )}

        {isOn("financial") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.financial} · Financial justification</h2>
              <SectionRemove id="financial" />
            </div>
            <div className="bc-fin">
              {bc.financial.map((f, i) => (
                <div key={i} className="bc-fin-cell">
                  <div className="bc-fin-label">{f.label}</div>
                  <UI.Editable className="bc-fin-value serif" value={f.value} onChange={(v) => setList("financial", i, { ...f, value: v })} placeholder="—" />
                  <div className="bc-fin-note muted">{f.note}</div>
                </div>
              ))}
            </div>
            <UI.Editable className="bc-body" tag="p" multiline value={bc.justification} style={{ marginTop: 18 }} onChange={(v) => set({ justification: v })} placeholder="Why is this the right investment?" />
          </section>
        )}

        {/* add-section bar for inactive ones */}
        {inactive.length > 0 && (
          <div className="bc-add-bar no-print">
            <div className="bc-add-label">Add a section</div>
            <div className="bc-add-pills">
              {inactive.map((sec) => (
                <button key={sec.id} className="bc-add-pill" onClick={() => toggle(sec.id)}>
                  <Icon name="plus" size={13} /> {sec.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <footer className="bc-foot no-print">
          <button className="btn btn-dark" onClick={() => window.print()}><Icon name="print" size={15} /> Print / Save as PDF</button>
        </footer>
      </div>
    </div>
  );
}

Object.assign(window, { BusinessCase });
