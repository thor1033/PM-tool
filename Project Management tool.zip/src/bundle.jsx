
// ======== store.jsx ========
/* ============================================================
   STORE — multi-project state, persistence, file storage, seed
   Exposes window.Store
   v2: root { version, activeId, projects[] }; each project holds
       the full working set (tasks, risks, … businessCase).
   ============================================================ */
(function () {
  const KEY = "atlas.pm.v2";
  const uid = (p = "id") => p + "_" + Math.random().toString(36).slice(2, 9);
  const D = (y, m, d) => `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  const NUDGE_DEFAULTS = { leadStart: 2, leadDue: 3, autoStart: false };
  // pure: derive active reminders from tasks + saved nudge state, for `who` (name or null=everyone)
  function computeNudges(s, who) {
    const cfg = { ...NUDGE_DEFAULTS, ...(s.nudgeConfig || {}) };
    const st = s.nudgeState || {};
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const dayMs = 86400000;
    const asg = (t) => Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []);
    const list = [];
    (s.tasks || []).forEach((t) => {
      if (who && !asg(t).includes(who)) return;
      const owner = asg(t)[0] || "";
      // starting soon: backlog, start date within leadStart days (or already reached)
      if (t.status === "backlog" && t.start) {
        const days = Math.round((new Date(t.start) - today) / dayMs);
        if (days <= cfg.leadStart) {
          const nid = "start:" + t.id + ":" + t.start;
          const g = st[nid];
          if (!(g && (g.done || (g.snoozeUntil && g.snoozeUntil > Date.now())))) {
            list.push({ id: nid, kind: "start", taskId: t.id, title: t.title, owner, days, date: t.start });
          }
        }
      }
      // deadline approaching: not done, end date within leadDue days (or past)
      if (t.status !== "done" && t.end) {
        const days = Math.round((new Date(t.end) - today) / dayMs);
        if (days <= cfg.leadDue) {
          const nid = "due:" + t.id + ":" + t.end;
          const g = st[nid];
          if (!(g && (g.done || (g.snoozeUntil && g.snoozeUntil > Date.now())))) {
            list.push({ id: nid, kind: "due", taskId: t.id, title: t.title, owner, days, date: t.end, status: t.status });
          }
        }
      }
    });
    // most urgent first (overdue/soonest), starts before dues at same urgency
    return list.sort((a, b) => a.days - b.days || (a.kind === "due" ? -1 : 1));
  }

  // ---------- shared taxonomy ----------
  function defaultTaxonomy() {
    return {
      tags: [],
      phases: [],
      categories: [],
    };
  }

  function blankFinancials() {
    return { currency: "€", weighting: "duration", contract: { title: "", party: "", value: 0, signed: "", start: "", end: "", url: "", note: "" }, budget: [] };
  }
  function blankBusinessCase() {
    return {
      purpose: "", problem: "",
      perspOurs: "", perspUsers: "", perspStakeholders: "", worsening: "", opportunities: "",
      outcomes: [],
      effProcess: "", effSystem: "", effBehaviour: "", effLeadership: "",
      financial: [
        { label: "Programme cost (one-off)", value: "", note: "" },
        { label: "Annual run cost", value: "", note: "" },
        { label: "Annual saving", value: "", note: "" },
        { label: "Payback period", value: "", note: "" },
      ],
      justification: "", effective: "",
    };
  }
  function blankScope() { return { inScope: [], outScope: [] }; }
  function blankChangePlan() { return { groups: [] }; }

  // ---------- fully-seeded sample project (Helios) ----------
  function heliosData() {
    const tax = {
      tags: [
        { id: "tg_fe", label: "Frontend", color: "blue" },
        { id: "tg_be", label: "Backend", color: "indigo" },
        { id: "tg_infra", label: "Infra", color: "teal" },
        { id: "tg_sec", label: "Security", color: "red" },
        { id: "tg_ux", label: "UX", color: "pink" },
        { id: "tg_data", label: "Data", color: "amber" },
        { id: "tg_docs", label: "Docs", color: "green" },
      ],
      phases: [
        { id: "ph_disc", label: "Discovery", color: "teal" },
        { id: "ph_design", label: "Design", color: "pink" },
        { id: "ph_build", label: "Build", color: "blue" },
        { id: "ph_launch", label: "Launch", color: "amber" },
      ],
      categories: [],
    };
    const T = {}; // friendly handles for cross-links
    const mk = (key, o) => { const id = uid("t"); T[key] = id; return { id, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o }; };
    const tasks = [
      mk("interviews", { title: "Stakeholder discovery interviews", status: "done", tags: ["tg_ux"], phase: "ph_disc", category: "ct_enable", priority: "med", assignees: ["Maya Rossi"], start: D(2026, 1, 6), end: D(2026, 1, 17), desc: "Run interviews with department leads to map current pain points and system usage." }),
      mk("audit", { title: "Audit legacy data schema", status: "done", tags: ["tg_data", "tg_be"], phase: "ph_disc", category: "ct_migr", priority: "high", assignees: ["Dev Patel"], start: D(2026, 1, 13), end: D(2026, 1, 28), desc: "Document the existing schema, identify orphaned tables and PII fields requiring special handling." }),
      mk("arch", { title: "Define target architecture", status: "inprogress", tags: ["tg_infra", "tg_be"], phase: "ph_design", category: "ct_plat", priority: "high", assignees: ["Dev Patel"], start: D(2026, 2, 2), end: D(2026, 2, 20), desc: "Produce the reference architecture covering services, data flow and the cloud landing zone." }),
      mk("ds", { title: "Design system & component library", status: "inprogress", tags: ["tg_ux", "tg_fe"], phase: "ph_design", category: "ct_plat", priority: "med", assignees: ["Maya Rossi"], start: D(2026, 2, 9), end: D(2026, 3, 6), desc: "Establish tokens, core components and accessibility baseline for the new portal." }),
      mk("threat", { title: "Security & threat model review", status: "inprogress", tags: ["tg_sec"], phase: "ph_design", category: "ct_compl", priority: "high", assignees: ["Sam Kaur"], start: D(2026, 2, 23), end: D(2026, 3, 6), desc: "Threat-model the proposed architecture; produce a register of controls and residual risks." }),
      mk("auth", { title: "Build authentication service", status: "backlog", tags: ["tg_be", "tg_sec"], phase: "ph_build", category: "ct_plat", priority: "high", assignees: ["Dev Patel"], start: D(2026, 3, 9), end: D(2026, 3, 27), desc: "SSO + role-based access, session handling and audit logging." }),
      mk("migrate", { title: "Migrate customer records", status: "backlog", tags: ["tg_data"], phase: "ph_build", category: "ct_migr", priority: "high", assignees: ["Dev Patel"], start: D(2026, 3, 16), end: D(2026, 4, 10), desc: "ETL pipeline with validation, dry-run and rollback plan for the customer dataset." }),
      mk("portal", { title: "Portal frontend — core flows", status: "backlog", tags: ["tg_fe", "tg_ux"], phase: "ph_build", category: "ct_plat", priority: "med", assignees: ["Lina Meyer"], start: D(2026, 3, 23), end: D(2026, 4, 24), desc: "Implement dashboard, search and record-detail flows against the new API." }),
      mk("landing", { title: "Provision production landing zone", status: "backlog", tags: ["tg_infra"], phase: "ph_build", category: "ct_plat", priority: "med", assignees: ["Sam Kaur"], start: D(2026, 4, 6), end: D(2026, 4, 20), desc: "IaC for networking, monitoring and the CI/CD release pipeline." }),
      mk("uat", { title: "User acceptance testing", status: "backlog", tags: ["tg_ux", "tg_docs"], phase: "ph_launch", category: "ct_enable", priority: "med", assignees: ["Maya Rossi"], start: D(2026, 4, 27), end: D(2026, 5, 8), desc: "Coordinate UAT with pilot departments, triage findings and sign-off." }),
      mk("cutover", { title: "Cutover & go-live runbook", status: "backlog", tags: ["tg_infra", "tg_docs"], phase: "ph_launch", category: "ct_migr", priority: "high", assignees: ["Sam Kaur"], start: D(2026, 5, 11), end: D(2026, 5, 22), desc: "Final cutover plan, comms, rollback criteria and hypercare schedule." }),
      mk("training", { title: "Training & enablement materials", status: "backlog", tags: ["tg_docs"], phase: "ph_launch", category: "ct_enable", priority: "low", assignees: ["Lina Meyer"], start: D(2026, 5, 4), end: D(2026, 5, 20), desc: "Quick-start guides, recorded walkthroughs and an admin handbook." }),
    ];
    const dep = (k, ...ds) => { const t = tasks.find((x) => x.id === T[k]); t.deps = ds; };
    dep("arch", { id: uid("d"), type: "task", refId: T.audit }, { id: uid("d"), type: "task", refId: T.interviews });
    dep("auth", { id: uid("d"), type: "task", refId: T.arch }, { id: uid("d"), type: "external", label: "Identity-provider licence", scope: "Vendor — Oktagon Inc." });
    dep("migrate", { id: uid("d"), type: "task", refId: T.audit });
    dep("portal", { id: uid("d"), type: "task", refId: T.auth }, { id: uid("d"), type: "task", refId: T.ds });
    dep("landing", { id: uid("d"), type: "external", label: "Cloud account approval", scope: "Finance Office" });
    dep("uat", { id: uid("d"), type: "task", refId: T.portal }, { id: uid("d"), type: "external", label: "Pilot users released", scope: "Other project — CRM Sunset" });

    const milestones = [
      { id: uid("ms"), title: "Discovery sign-off", type: "milestone", date: D(2026, 1, 30), category: "ct_enable", note: "Steering committee confirms discovery findings and greenlights Design." },
      { id: uid("ms"), title: "Architecture gate", type: "gate", date: D(2026, 2, 24), category: "ct_plat", note: "Go/no-go: target architecture must pass security and cost review before Build starts." },
      { id: uid("ms"), title: "Migration dry-run pass", type: "milestone", date: D(2026, 4, 6), category: "ct_migr", note: "ETL pipeline completes a full dry-run with < 2 % exception rate." },
      { id: uid("ms"), title: "UAT gate", type: "gate", date: D(2026, 5, 9), category: "ct_enable", note: "Go/no-go: UAT findings must be triaged and critical issues resolved before cutover planning." },
      { id: uid("ms"), title: "Go-live", type: "milestone", date: D(2026, 5, 25), category: "ct_plat", note: "Production cutover and hypercare begin." },
    ];

    const risks = [
      { id: uid("r"), title: "Legacy data quality worse than expected", likelihood: "high", impact: "high", mitigation: "Early profiling sprint; phased migration with validation gates and a rollback snapshot.", owner: "Dev Patel", status: "open", taskIds: [T.audit, T.migrate] },
      { id: uid("r"), title: "Key user availability during UAT", likelihood: "med", impact: "high", mitigation: "Book UAT windows now; secure backfill cover with department leads in writing.", owner: "Maya Rossi", status: "open", taskIds: [T.uat] },
      { id: uid("r"), title: "Compliance sign-off delays go-live", likelihood: "med", impact: "high", mitigation: "Engage Compliance from Design phase; maintain a live controls register.", owner: "Sam Kaur", status: "monitoring", taskIds: [T.threat] },
      { id: uid("r"), title: "Scope creep from adjacent teams", likelihood: "high", impact: "med", mitigation: "Strict change-control board; park requests in a phase-2 backlog.", owner: "Marcus L.", status: "open", taskIds: [] },
      { id: uid("r"), title: "Cloud cost overrun", likelihood: "low", impact: "med", mitigation: "Budget alerts and right-sizing review at end of Build phase.", owner: "Sam Kaur", status: "monitoring", taskIds: [] },
    ];
    const stakeholders = [
      { id: uid("s"), name: "Helen Vos", title: "VP, Operations", role: "Executive Sponsor", responsibility: "Owns the business case, unblocks funding and resolves cross-department conflicts.", influence: "high", interest: "high", contact: "h.vos@company.example" },
      { id: uid("s"), name: "Marcus Lindqvist", title: "Head of IT", role: "Project Owner", responsibility: "Accountable for delivery, scope and the technical decision record.", influence: "high", interest: "high", contact: "m.lindqvist@company.example" },
      { id: uid("s"), name: "Priya Nadar", title: "Compliance Lead", role: "Advisor", responsibility: "Signs off on data handling, retention and regulatory controls.", influence: "med", interest: "high", contact: "p.nadar@company.example" },
      { id: uid("s"), name: "Tom Berger", title: "Customer Service Lead", role: "Key User", responsibility: "Represents frontline users; coordinates UAT and adoption in the call centre.", influence: "med", interest: "high", contact: "t.berger@company.example" },
      { id: uid("s"), name: "Finance Office", title: "Budget Control", role: "Gatekeeper", responsibility: "Approves spend against milestones and tracks benefit realisation.", influence: "med", interest: "med", contact: "finance@company.example" },
    ];
    const findings = [
      { id: uid("f"), title: "62% of support tickets stem from manual data entry", category: "ct_enable", summary: "Process analysis of 1,200 tickets shows the majority are caused by duplicate or mistyped records in the legacy system. Automation here yields the largest support reduction.", source: "Support analytics, Q4" },
      { id: uid("f"), title: "Three shadow spreadsheets hold authoritative data", category: "ct_migr", summary: "Critical pricing and entitlement data lives outside the system of record. These must be ingested or the migration will lose authoritative state.", source: "Discovery interviews" },
      { id: uid("f"), title: "No single sign-on across tools", category: "ct_compl", summary: "Users maintain 4–6 separate logins. SSO is both a security win and the most requested usability improvement.", source: "User survey, n=84" },
      { id: uid("f"), title: "Peak load is 4× average at month-end", category: "ct_plat", summary: "Reporting and reconciliation create predictable spikes. Target architecture must autoscale to avoid the current month-end slowdowns.", source: "Infra telemetry" },
    ];
    const org = [
      { id: "o_sponsor", name: "Helen Vos", role: "Executive Sponsor", parent: null, note: "Steering committee chair", accent: "purple" },
      { id: "o_owner", name: "Marcus Lindqvist", role: "Project Owner", parent: "o_sponsor", note: "Single point of accountability", accent: "indigo" },
      { id: "o_pm", name: "You", role: "Project Manager", parent: "o_owner", note: "Day-to-day delivery & this tool", accent: "blue" },
      { id: "o_tech", name: "Dev Patel", role: "Tech Lead", parent: "o_pm", note: "Architecture & backend", accent: "teal" },
      { id: "o_design", name: "Maya Rossi", role: "Design Lead", parent: "o_pm", note: "UX & enablement", accent: "pink" },
      { id: "o_infra", name: "Sam Kaur", role: "Infra & Security", parent: "o_tech", note: "Landing zone, CI/CD, controls", accent: "green" },
      { id: "o_fe", name: "Lina Meyer", role: "Frontend Engineer", parent: "o_tech", note: "Portal & components", accent: "amber" },
    ];
    const products = [
      { id: uid("p"), name: "Discovery Report", type: "pdf", fileId: null, taskIds: [T.interviews], phase: "ph_disc", date: D(2026, 1, 20), note: "Synthesis of interviews and current-state analysis.", placeholder: true },
      { id: uid("p"), name: "Target Architecture Diagram", type: "image", fileId: null, taskIds: [T.arch], phase: "ph_design", date: D(2026, 2, 22), note: "Reference architecture, v0.9.", placeholder: true },
      { id: "PROD_MIGPLAN", name: "Migration Plan.xlsx", type: "excel", fileId: null, taskIds: [T.audit, T.migrate], phase: "ph_design", date: D(2026, 2, 28), note: "Table-by-table mapping and sequencing.", placeholder: true },
    ];
    const businessCase = {
      purpose: "Replace the end-of-life legacy customer platform with a secure, scalable portal that consolidates fragmented tools into a single system of record.",
      problem: "The current platform is unsupported, has no single sign-on, and depends on manual data entry that drives the majority of support tickets. Authoritative data lives in uncontrolled spreadsheets, creating compliance and continuity risk.",
      perspOurs: "For IT, the legacy platform is an unsupported continuity and compliance liability that absorbs a disproportionate share of the support budget.",
      perspUsers: "Frontline users juggle four to six separate logins and re-key data by hand — slow, error-prone and the top source of frustration in surveys.",
      perspStakeholders: "Compliance cannot evidence current data-retention controls, while Operations sees month-end slowdowns erode service levels.",
      worsening: "Every quarter more authoritative data drifts into uncontrolled spreadsheets, and the unsupported platform steadily raises the probability of an unplanned outage.",
      opportunities: "Consolidating the tools behind single sign-on is the most requested usability win and unlocks the automation that removes the largest category of support tickets.",
      outcomes: [
        "Reduce data-entry support tickets by 50% within two quarters of go-live.",
        "Achieve single sign-on across all customer-facing tools.",
        "Bring all authoritative data under a governed system of record.",
        "Eliminate month-end performance degradation through autoscaling.",
      ],
      effProcess: "Manual data-entry steps are replaced by validated intake. A new data-governance procedure (QMS / Cortex document) defines ownership, retention and the change-control path.",
      effSystem: "A new portal with SSO, a governed system of record, a validated migration pipeline and autoscaling infrastructure — plus a reusable component library and admin templates.",
      effBehaviour: "Frontline users work from a single portal and trust it as the source of truth; admins manage access and data through governed workflows instead of spreadsheets.",
      effLeadership: "Data-ownership accountability is set at department-lead level, the steering committee governs scope, and all key users complete enablement training before go-live.",
      financial: [
        { label: "Programme cost (one-off)", value: "€480,000", note: "Build, migration, licensing" },
        { label: "Annual run cost", value: "€120,000", note: "Cloud + support, replaces €165k legacy" },
        { label: "Annual saving", value: "€210,000", note: "Support effort + legacy retirement" },
        { label: "Payback period", value: "~2.4 years", note: "Excluding risk-avoidance value" },
      ],
      justification: "Beyond the direct saving, the legacy platform is a continuity and compliance liability: it is unsupported and cannot meet current data-retention obligations. Doing nothing increases the probability of an unplanned outage and a regulatory finding. The proposed programme is the lowest-risk path that also delivers measurable efficiency gains.",
      effective: "Delivery is phased — Discovery, Design, Build, Launch — with a go/no-go gate at the end of each phase. Benefits are tracked against the four target outcomes, reviewed monthly by the steering committee with the Finance Office validating realised savings.",
    };
    const scope = {
      inScope: [
        "Migration of the customer records dataset to the new system of record",
        "Single sign-on across all customer-facing tools",
        "New portal core flows: dashboard, search and record detail",
        "Production landing zone, monitoring and CI/CD pipeline",
        "UAT with pilot departments and go-live",
      ],
      outScope: [
        "Finance / ERP integration (deferred to phase 2)",
        "Native mobile applications",
        "Archive data older than seven years",
        "External partner portals",
        "Decommissioning of unrelated legacy systems",
      ],
    };
    const assessment = [
      { id: uid("as"), area: "Identity & access", asIs: "4–6 separate logins per user; no single sign-on.", toBe: "One single sign-on across every customer-facing tool." },
      { id: uid("as"), area: "Data ownership", asIs: "Authoritative data spread across uncontrolled spreadsheets.", toBe: "One governed system of record with clear ownership." },
      { id: uid("as"), area: "Support load", asIs: "Majority of tickets caused by manual data entry.", toBe: "50% fewer data-entry tickets via validated intake." },
      { id: uid("as"), area: "Performance", asIs: "Month-end slowdowns at ~4× average load.", toBe: "Autoscaling removes month-end degradation." },
      { id: uid("as"), area: "Platform support", asIs: "Legacy platform end-of-life and unsupported.", toBe: "Supported, patched cloud platform." },
    ];
    const commPlan = [
      { id: uid("cm"), audience: "All platform users", purpose: "Explain what is changing and how to work the new way.", messages: ["Users move from the legacy task planner to the new portal", "What the new flow looks like day-to-day", "Where to find support material and who to ask"], channels: ["Email", "Intranet"], timing: "Before go-live (≤ 1 week)", date: D(2026, 5, 18), owner: "Maya Rossi", deliverables: ["Launch email (drafted — needs sponsor input)", "Quick-start guide"] },
      { id: uid("cm"), audience: "All employees", purpose: "Inform everyone that the new system reduces request processing time.", messages: ["A new platform is live", "The benefit — faster, more reliable service", "Where to find it (via the portal)", "Where support material lives"], channels: ["Intranet article", "Info screens"], timing: "Launch week", date: D(2026, 5, 25), owner: "Lina Meyer", deliverables: ["Intranet article (done)", "Portal guide link", "Info-screen slide (sent)"] },
      { id: uid("cm"), audience: "Leadership team", purpose: "Ensure leaders actively and visibly champion the change.", messages: ["The change and its benefit (faster processing)", "Why we are doing it now", "Where to find it", "Where support material lives"], channels: ["Email", "Monthly leadership meeting"], timing: "Launch week", date: D(2026, 5, 22), owner: "Marcus Lindqvist", deliverables: ["Approved comms", "Leadership update deck"] },
      { id: uid("cm"), audience: "Senior management", purpose: "Inform of the change and ownership of processing-time delays.", messages: ["Summary of discovery findings", "Executive summary of what changes", "A tool that lets us set and track KPIs", "One-page summary of the new process"], channels: ["Email", "Meeting"], timing: "Post-launch, at the general meeting", date: D(2026, 6, 8), owner: "Helen Vos", deliverables: ["Presented slides"] },
    ];
    const changePlan = { groups: [
      { id: uid("cg"), label: "Delivery team", accent: "indigo", rows: [
        { id: uid("cr"), component: "Training package", description: "WHY the change, today vs. tomorrow, roles & responsibilities, how to use the new portal, retiring the old planner, practical exercises with dashboards and task types.", deliverables: ["Slide deck (why + how)", "User guides (new workflow)", "Training material"], owner: "Maya Rossi" },
        { id: uid("cr"), component: "New-joiner package", description: "Page on the portal with all flows and training for new employees' onboarding.", deliverables: ["User onboarding page"], owner: "Lina Meyer" },
        { id: uid("cr"), component: "Management follow-up", description: "Managers reinforce new behaviour through routines & KPIs, communication discipline and dashboards to secure team readiness.", deliverables: ["Check-in meeting plan", "Behaviour reinforcement guidance", "Dashboard usage guide"], owner: "Sam Kaur" },
        { id: uid("cr"), component: "Post-go-live support", description: "Monthly feedback review → fix → roll out, plus refresher training.", deliverables: ["Feedback analysis", "Continuous improvement log", "Ownership map (who handles what)"], owner: "Maya Rossi" },
      ] },
      { id: uid("cg"), label: "Organisation-wide", accent: "teal", rows: [
        { id: uid("cr"), component: "All-staff communication", description: "Inform the organisation of the new system and ways of working.", deliverables: ["Change announcement (intranet news)", "User-friendly portal for easy adoption"], owner: "Lina Meyer" },
        { id: uid("cr"), component: "Stakeholder communication", description: "Department managers, SMEs and requesters — organisation-wide messaging.", deliverables: ["Change announcement (email, webinars)", "Stakeholder-specific message packs", "Change timeline"], owner: "Marcus Lindqvist" },
        { id: uid("cr"), component: "Feedback loop", description: "Mechanism for reporting issues and proposing improvements.", deliverables: ["Feedback form / template", "'You said → we did' updates"], owner: "Maya Rossi" },
      ] },
    ] };
    const members = [
      { id: "mem_you", name: "You", role: "Project Manager", email: "", color: "blue" },
      { id: "mem_marcus", name: "Marcus Lindqvist", role: "Project Owner", email: "m.lindqvist@company.example", color: "indigo" },
      { id: "mem_helen", name: "Helen Vos", role: "Executive Sponsor", email: "h.vos@company.example", color: "purple" },
      { id: "mem_dev", name: "Dev Patel", role: "Tech Lead", email: "d.patel@company.example", color: "teal" },
      { id: "mem_maya", name: "Maya Rossi", role: "Design Lead", email: "m.rossi@company.example", color: "pink" },
      { id: "mem_sam", name: "Sam Kaur", role: "Infra & Security", email: "s.kaur@company.example", color: "green" },
      { id: "mem_lina", name: "Lina Meyer", role: "Frontend Engineer", email: "l.meyer@company.example", color: "amber" },
      { id: "mem_priya", name: "Priya Nadar", role: "Compliance Lead", email: "p.nadar@company.example", color: "red" },
      { id: "mem_tom", name: "Tom Berger", role: "Customer Service Lead", email: "t.berger@company.example", color: "blue" },
    ];
    const glossary = [
      { id: "gl_sso", term: "SSO", definition: "Single sign-on — one login that authenticates the user across all customer-facing tools." },
      { id: "gl_etl", term: "ETL", definition: "Extract, Transform, Load — the pipeline that moves data from the legacy system into the new system of record." },
      { id: "gl_uat", term: "UAT", definition: "User Acceptance Testing — pilot users exercise the system end-to-end and sign off before go-live." },
      { id: "gl_cicd", term: "CI/CD", definition: "Continuous Integration and Continuous Deployment — the automated build, test and release pipeline." },
      { id: "gl_qms", term: "QMS", definition: "Quality Management System — the controlled set of procedures that govern how we work." },
      { id: "gl_cortex", term: "Cortex", definition: "The internal document management system where governed procedures and policies live." },
      { id: "gl_hypercare", term: "hypercare", definition: "The intensive support window immediately after go-live where the project team is on standby to triage issues fast." },
      { id: "gl_landingzone", term: "landing zone", definition: "A pre-configured, governed cloud environment (networking, identity, monitoring) ready to host workloads." },
    ];
    return { meta: { project: "Helios Platform Modernisation", code: "PRJ-2026-014" }, tasks, members, stakeholders, risks, findings, org, products, businessCase, scope, assessment, commPlan, changePlan, milestones, glossary, ...tax };
  }

  // ---------- a lighter second sample ----------
  function intranetData() {
    const tax = defaultTaxonomy();
    const t = (o) => ({ id: uid("t"), tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o });
    const tasks = [
      t({ title: "Content audit of current intranet", status: "done", phase: "ph_disc", category: "ct_enable", assignees: ["Noah Frank"], start: D(2026, 2, 2), end: D(2026, 2, 13), tags: ["tg_docs"] }),
      t({ title: "Information architecture workshop", status: "inprogress", phase: "ph_design", category: "ct_plat", assignees: ["Aïsha Bello"], start: D(2026, 2, 16), end: D(2026, 2, 27), tags: ["tg_ux"], priority: "high" }),
      t({ title: "Search relevance tuning", status: "backlog", phase: "ph_build", category: "ct_plat", assignees: ["Noah Frank"], start: D(2026, 3, 9), end: D(2026, 3, 20), tags: ["tg_be"] }),
      t({ title: "Editor onboarding guide", status: "backlog", phase: "ph_launch", category: "ct_enable", assignees: ["Aïsha Bello"], start: D(2026, 3, 23), end: D(2026, 4, 3), tags: ["tg_docs"], priority: "low" }),
    ];
    const org = [
      { id: "o_owner", name: "Aïsha Bello", role: "Project Owner", parent: null, note: "Comms & internal tooling", accent: "indigo" },
      { id: "o_eng", name: "Noah Frank", role: "Engineer", parent: "o_owner", note: "Build & search", accent: "teal" },
    ];
    const risks = [
      { id: uid("r"), title: "Low editor adoption after launch", likelihood: "med", impact: "med", mitigation: "Champions programme and office hours in first month.", owner: "Aïsha Bello", status: "open", taskIds: [tasks[3].id] },
    ];
    const members = [
      { id: "mem_aisha", name: "Aïsha Bello", role: "Content Lead", email: "", color: "teal" },
    ];
    return { meta: { project: "Intranet Refresh", code: "PRJ-2026-021" }, tasks, members, stakeholders: [], risks, findings: [], org, products: [], businessCase: blankBusinessCase(), scope: blankScope(), assessment: [], commPlan: [], changePlan: blankChangePlan(), milestones: [], ...tax };
  }

  // remove the shipped/pre-defined tags (ids prefixed "tg_"); user-made tags use "ta_" and are kept
  function stripSeedTags(p) {
    const removed = new Set((p.tags || []).filter((t) => String(t.id).startsWith("tg_")).map((t) => t.id));
    if (!removed.size && !(p.tags || []).some((t) => String(t.id).startsWith("tg_"))) return p;
    const tags = (p.tags || []).filter((t) => !removed.has(t.id));
    const tasks = (p.tasks || []).map((t) => (Array.isArray(t.tags) && t.tags.some((id) => removed.has(id)) ? { ...t, tags: t.tags.filter((id) => !removed.has(id)) } : t));
    return { ...p, tags, tasks };
  }

  function makeProject(color, data, ageDays = 0, parentId = null) {
    return stripSeedTags({ id: uid("prj"), color, parentId, createdAt: Date.now() - ageDays * 86400000, updatedAt: Date.now() - Math.floor(ageDays / 2) * 86400000, ...data });
  }

  // a lightweight subproject under Helios, to demonstrate grouping
  function migrationData() {
    const tax = defaultTaxonomy();
    const t = (o) => ({ id: uid("t"), tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o });
    const tasks = [
      t({ title: "Profile legacy data quality", status: "done", phase: "ph_disc", category: "ct_migr", assignees: ["Dev Patel"], start: D(2026, 2, 2), end: D(2026, 2, 13), tags: ["tg_data"], priority: "high" }),
      t({ title: "Build ETL mapping spec", status: "inprogress", phase: "ph_design", category: "ct_migr", assignees: ["Dev Patel", "Lina Meyer"], start: D(2026, 2, 16), end: D(2026, 3, 6), tags: ["tg_data", "tg_be"], priority: "high" }),
      t({ title: "Dry-run migration in staging", status: "backlog", phase: "ph_build", category: "ct_migr", assignees: ["Dev Patel"], start: D(2026, 3, 9), end: D(2026, 3, 27), tags: ["tg_data"], priority: "med" }),
      t({ title: "Reconciliation & sign-off report", status: "backlog", phase: "ph_launch", category: "ct_compl", assignees: ["Sam Kaur"], start: D(2026, 3, 30), end: D(2026, 4, 10), tags: ["tg_docs"], priority: "med" }),
    ];
    const risks = [
      { id: uid("r"), title: "Source data exceeds validation tolerance", likelihood: "high", impact: "high", mitigation: "Tighten cleansing rules; gate cutover on a <2% exception rate.", owner: "Dev Patel", status: "open", taskIds: [tasks[0].id, tasks[2].id] },
    ];
    const org = [
      { id: "o_lead", name: "Dev Patel", role: "Migration Lead", parent: null, note: "Owns the data workstream", accent: "teal" },
      { id: "o_eng", name: "Lina Meyer", role: "Data Engineer", parent: "o_lead", note: "ETL & validation", accent: "amber" },
    ];
    return { meta: { project: "Customer Data Migration", code: "" }, tasks, members: [{ id: "mem_dev2", name: "Dev Patel", role: "Migration Lead", email: "", color: "teal" }, { id: "mem_lina2", name: "Lina Meyer", role: "Data Engineer", email: "", color: "amber" }], stakeholders: [], risks, findings: [], org, products: [], businessCase: blankBusinessCase(), scope: blankScope(), assessment: [], commPlan: [], changePlan: blankChangePlan(), milestones: [], ...tax };
  }

  // ---------- fully-populated demo project: every field filled (Meridian) ----------
  function showcaseData() {
    const tax = {
      tags: [
        { id: "tg_ios", label: "iOS", color: "blue" },
        { id: "tg_droid", label: "Android", color: "green" },
        { id: "tg_api", label: "API", color: "indigo" },
        { id: "tg_sec", label: "Security", color: "red" },
        { id: "tg_ux", label: "UX", color: "pink" },
        { id: "tg_data", label: "Analytics", color: "amber" },
        { id: "tg_legal", label: "Legal", color: "teal" },
      ],
      phases: [
        { id: "ph_disc", label: "Discovery", color: "teal" },
        { id: "ph_design", label: "Design", color: "pink" },
        { id: "ph_build", label: "Build", color: "blue" },
        { id: "ph_beta", label: "Beta", color: "indigo" },
        { id: "ph_launch", label: "Launch", color: "amber" },
      ],
      categories: [
        { id: "ct_research", label: "Customer Research", color: "teal" },
        { id: "ct_product", label: "Product & Design", color: "pink" },
        { id: "ct_eng", label: "Engineering", color: "blue" },
        { id: "ct_risk", label: "Risk & Compliance", color: "red" },
        { id: "ct_gtm", label: "Go-to-Market", color: "amber" },
      ],
    };
    const T = {};
    const mk = (key, o) => { const id = uid("t"); T[key] = id; return { id, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], ...o }; };
    const tasks = [
      mk("interviews", { title: "Customer interviews & needs analysis", status: "done", tags: ["tg_ux", "tg_data"], phase: "ph_disc", category: "ct_research", priority: "med", assignees: ["Elena Duarte", "Tom\u00e1s Silva"], start: D(2026, 1, 12), end: D(2026, 1, 23), desc: "Twenty depth interviews with target segments to map jobs-to-be-done, current banking frustrations and willingness to switch." }),
      mk("benchmark", { title: "Market & competitor benchmark", status: "done", tags: ["tg_data"], phase: "ph_disc", category: "ct_research", priority: "med", assignees: ["Nina Petrova"], start: D(2026, 1, 19), end: D(2026, 1, 30), desc: "Feature and pricing teardown of eight challenger banks; identify the gaps Meridian can own at launch." }),
      mk("principles", { title: "Product principles & brand kit", status: "done", tags: ["tg_ux"], phase: "ph_design", category: "ct_product", priority: "low", assignees: ["Tom\u00e1s Silva"], start: D(2026, 2, 2), end: D(2026, 2, 20), desc: "Define the five product principles, tone of voice, colour system and the icon set used across both apps." }),
      mk("flows", { title: "Design account & payment flows", status: "inprogress", tags: ["tg_ux", "tg_ios"], phase: "ph_design", category: "ct_product", priority: "high", assignees: ["Tom\u00e1s Silva", "Elena Duarte"], start: D(2026, 2, 16), end: D(2026, 3, 13), desc: "End-to-end flows for onboarding, account opening, payments and card freeze \u2014 prototyped and usability-tested." }),
      mk("api", { title: "Core banking API integration", status: "inprogress", tags: ["tg_api", "tg_sec"], phase: "ph_build", category: "ct_eng", priority: "high", assignees: ["Raj Malhotra", "Sophie Tran"], start: D(2026, 3, 2), end: D(2026, 4, 3), desc: "Integrate the core-banking ledger, payments rail and KYC provider behind a unified internal API." }),
      mk("ios", { title: "iOS app \u2014 onboarding & dashboard", status: "backlog", tags: ["tg_ios"], phase: "ph_build", category: "ct_eng", priority: "high", assignees: ["Sophie Tran"], start: D(2026, 3, 16), end: D(2026, 4, 24), desc: "Native iOS build of onboarding, the account dashboard and the payments flow against the new API." }),
      mk("android", { title: "Android app \u2014 onboarding & dashboard", status: "backlog", tags: ["tg_droid"], phase: "ph_build", category: "ct_eng", priority: "high", assignees: ["Marcus Webb"], start: D(2026, 3, 23), end: D(2026, 5, 1), desc: "Native Android build at feature parity with iOS, sharing the same design system and API contract." }),
      mk("security", { title: "Security audit & penetration test", status: "inprogress", tags: ["tg_sec"], phase: "ph_build", category: "ct_risk", priority: "high", assignees: ["Aisha Khan"], start: D(2026, 3, 9), end: D(2026, 3, 27), desc: "Third-party penetration test of the API and mobile clients; produce a remediation register with severities." }),
      mk("compliance", { title: "Regulatory & KYC sign-off", status: "backlog", tags: ["tg_legal", "tg_sec"], phase: "ph_beta", category: "ct_risk", priority: "high", assignees: ["David Olsen"], start: D(2026, 4, 6), end: D(2026, 4, 24), desc: "Evidence KYC/AML controls, complete the regulator's pre-launch checklist and obtain written sign-off." }),
      mk("beta", { title: "Closed beta with 500 customers", status: "backlog", tags: ["tg_data", "tg_ux"], phase: "ph_beta", category: "ct_product", priority: "med", assignees: ["Elena Duarte", "Nina Petrova"], start: D(2026, 5, 4), end: D(2026, 5, 29), desc: "Invite-only beta to validate onboarding conversion, crash-free rate and the support load before launch." }),
      mk("gtm", { title: "Launch campaign & app-store release", status: "backlog", tags: ["tg_data"], phase: "ph_launch", category: "ct_gtm", priority: "high", assignees: ["Carla Mendes"], start: D(2026, 6, 1), end: D(2026, 6, 26), desc: "Coordinate the app-store submission, paid acquisition campaign, PR and the referral programme for launch." }),
    ];
    const dep = (k, ...ds) => { const t = tasks.find((x) => x.id === T[k]); t.deps = ds; };
    dep("flows", { id: uid("d"), type: "task", refId: T.interviews }, { id: uid("d"), type: "task", refId: T.benchmark });
    dep("api", { id: uid("d"), type: "task", refId: T.flows }, { id: uid("d"), type: "external", label: "Core-banking sandbox access", scope: "Vendor \u2014 Thought Machine" });
    dep("ios", { id: uid("d"), type: "task", refId: T.api }, { id: uid("d"), type: "task", refId: T.flows });
    dep("android", { id: uid("d"), type: "task", refId: T.api }, { id: uid("d"), type: "task", refId: T.flows });
    dep("security", { id: uid("d"), type: "task", refId: T.api });
    dep("compliance", { id: uid("d"), type: "task", refId: T.security }, { id: uid("d"), type: "external", label: "FCA reference number", scope: "Regulator \u2014 FCA" });
    dep("beta", { id: uid("d"), type: "task", refId: T.ios }, { id: uid("d"), type: "task", refId: T.android });
    dep("gtm", { id: uid("d"), type: "task", refId: T.beta }, { id: uid("d"), type: "task", refId: T.compliance });

    const milestones = [
      { id: uid("ms"), title: "Discovery complete", type: "milestone", date: D(2026, 1, 30), category: "ct_research", note: "Research synthesis signed off; product direction agreed with the sponsor." },
      { id: uid("ms"), title: "Design sign-off", type: "gate", date: D(2026, 3, 13), category: "ct_product", note: "Go/no-go: core flows must pass usability testing before engineering commits to the build." },
      { id: uid("ms"), title: "Security clearance", type: "gate", date: D(2026, 3, 30), category: "ct_risk", note: "Go/no-go: all critical and high pen-test findings resolved before beta." },
      { id: uid("ms"), title: "Beta exit", type: "gate", date: D(2026, 5, 30), category: "ct_product", note: "Go/no-go: crash-free rate \u2265 99.5% and onboarding conversion \u2265 60% to proceed to launch." },
      { id: uid("ms"), title: "Public launch", type: "milestone", date: D(2026, 6, 26), category: "ct_gtm", note: "Apps live in both stores; acquisition campaign switched on." },
    ];
    const risks = [
      { id: uid("r"), title: "Regulatory sign-off slips and delays launch", likelihood: "med", impact: "high", mitigation: "Engage the regulator from Discovery; keep a live controls register and book the review slot now.", owner: "David Olsen", status: "open", taskIds: [T.compliance] },
      { id: uid("r"), title: "Core-banking vendor API unstable in sandbox", likelihood: "high", impact: "high", mitigation: "Build an anti-corruption layer; contract SLAs on sandbox uptime and a named vendor engineer.", owner: "Raj Malhotra", status: "open", taskIds: [T.api] },
      { id: uid("r"), title: "Critical pen-test finding forces rework", likelihood: "med", impact: "high", mitigation: "Threat-model early; run an interim security review at mid-build rather than only at the end.", owner: "Aisha Khan", status: "monitoring", taskIds: [T.security] },
      { id: uid("r"), title: "Beta onboarding conversion below target", likelihood: "med", impact: "med", mitigation: "Instrument every step; run weekly funnel reviews and A/B test the two highest-drop screens.", owner: "Elena Duarte", status: "open", taskIds: [T.beta, T.flows] },
      { id: uid("r"), title: "App-store review rejection at submission", likelihood: "low", impact: "med", mitigation: "Pre-submit a TestFlight build for review; follow the financial-app guidelines checklist.", owner: "Carla Mendes", status: "monitoring", taskIds: [T.gtm] },
    ];
    const stakeholders = [
      { id: uid("s"), name: "Helena Brandt", title: "Chief Product Officer", role: "Executive Sponsor", responsibility: "Owns the launch mandate, secures budget and arbitrates scope across business units.", influence: "high", interest: "high", contact: "h.brandt@meridian.example" },
      { id: uid("s"), name: "Raj Malhotra", title: "Engineering Lead", role: "Project Owner", responsibility: "Accountable for technical delivery, the API contract and the release pipeline.", influence: "high", interest: "high", contact: "r.malhotra@meridian.example" },
      { id: uid("s"), name: "David Olsen", title: "Head of Compliance", role: "Gatekeeper", responsibility: "Approves KYC/AML controls and holds the regulatory sign-off for go-live.", influence: "high", interest: "high", contact: "d.olsen@meridian.example" },
      { id: uid("s"), name: "Carla Mendes", title: "Marketing Lead", role: "Key User", responsibility: "Plans acquisition and launch comms; represents the growth perspective.", influence: "med", interest: "high", contact: "c.mendes@meridian.example" },
      { id: uid("s"), name: "Finance Committee", title: "Budget Control", role: "Advisor", responsibility: "Reviews spend against milestones and validates the business-case benefits.", influence: "med", interest: "med", contact: "finance@meridian.example" },
    ];
    const findings = [
      { id: uid("f"), title: "73% would switch banks for faster onboarding", category: "ct_research", summary: "Interview and survey data show account-opening friction is the single biggest switching trigger for the target segment \u2014 onboarding speed is our sharpest wedge.", source: "Customer interviews + survey, n=420" },
      { id: uid("f"), title: "Instant notifications are the top requested feature", category: "ct_product", summary: "Across competitors, real-time payment notifications drive daily engagement. Absent at launch, retention suffers; present, it becomes a habit loop.", source: "Competitor benchmark" },
      { id: uid("f"), title: "KYC drop-off concentrates on document capture", category: "ct_risk", summary: "Industry data and our prototype tests both show the ID-scan step loses ~30% of users. This is the flow to over-invest in.", source: "Prototype usability tests" },
      { id: uid("f"), title: "Vendor sandbox latency averages 1.8s", category: "ct_eng", summary: "Early integration spikes show the core-banking sandbox is slow and occasionally times out, threatening the dashboard's perceived speed.", source: "Integration spike, week 9" },
    ];
    const org = [
      { id: "o_sponsor", name: "Helena Brandt", role: "Executive Sponsor", parent: null, note: "Chief Product Officer", accent: "purple" },
      { id: "o_owner", name: "Raj Malhotra", role: "Project Owner", parent: "o_sponsor", note: "Engineering Lead & delivery owner", accent: "indigo" },
      { id: "o_pm", name: "You", role: "Project Manager", parent: "o_owner", note: "Day-to-day delivery & this tool", accent: "blue" },
      { id: "o_product", name: "Elena Duarte", role: "Product Lead", parent: "o_pm", note: "Discovery, flows & beta", accent: "pink" },
      { id: "o_design", name: "Tom\u00e1s Silva", role: "Lead Designer", parent: "o_product", note: "Brand kit & product design", accent: "teal" },
      { id: "o_ios", name: "Sophie Tran", role: "iOS Engineer", parent: "o_owner", note: "iOS app & API", accent: "blue" },
      { id: "o_android", name: "Marcus Webb", role: "Android Engineer", parent: "o_owner", note: "Android app", accent: "green" },
      { id: "o_sec", name: "Aisha Khan", role: "Security Architect", parent: "o_owner", note: "Pen-test & controls", accent: "red" },
      { id: "o_compliance", name: "David Olsen", role: "Compliance Officer", parent: "o_pm", note: "KYC/AML & regulator", accent: "amber" },
      { id: "o_growth", name: "Carla Mendes", role: "Marketing Lead", parent: "o_pm", note: "Launch & acquisition", accent: "purple" },
    ];
    const products = [
      { id: uid("p"), name: "Discovery Insights.pdf", type: "pdf", fileId: null, taskIds: [T.interviews, T.benchmark], phase: "ph_disc", date: D(2026, 1, 31), note: "Research synthesis: segments, jobs-to-be-done and the switching triggers.", placeholder: true },
      { id: uid("p"), name: "Core Flows Prototype", type: "image", fileId: null, taskIds: [T.flows], phase: "ph_design", date: D(2026, 3, 12), note: "Prototype screens for onboarding, payments and card controls.", placeholder: true },
      { id: "PROD_API_SPEC", name: "API Contract.xlsx", type: "excel", fileId: null, taskIds: [T.api, T.ios, T.android], phase: "ph_build", date: D(2026, 3, 6), note: "Endpoint-by-endpoint contract shared across iOS, Android and the backend.", placeholder: true },
      { id: uid("p"), name: "Launch Plan.pptx", type: "slides", fileId: null, taskIds: [T.gtm], phase: "ph_launch", date: D(2026, 5, 20), note: "Go-to-market deck: channels, budget, timeline and success metrics.", externalUrl: "https://drive.example.com/meridian/launch-plan", placeholder: false },
    ];
    const businessCase = {
      purpose: "Launch Meridian, a mobile-first challenger bank, to win switchers frustrated by slow onboarding and poor everyday banking apps.",
      problem: "Incumbent banks make account opening slow and painful, lack real-time notifications, and bury everyday tasks. Our target segment is actively shopping for a faster, clearer alternative but no current offering fully owns the onboarding-speed promise.",
      perspOurs: "For the business, mobile banking is the fastest-growing acquisition channel and the cheapest to serve \u2014 every account opened in-app costs a fraction of a branch-assisted one.",
      perspUsers: "Customers want to open an account in minutes from their phone, see money move in real time, and freeze a card instantly \u2014 not wait days or call a branch.",
      perspStakeholders: "Compliance needs demonstrable KYC/AML controls; Growth needs a differentiated story; Finance needs a credible path to cost-per-acquisition targets.",
      worsening: "Challenger competitors ship monthly and are compounding their lead; every quarter we delay raises acquisition cost and cedes the onboarding-speed position we could still own.",
      opportunities: "Owning fast onboarding plus instant notifications creates a daily habit loop, lowers cost-to-serve, and opens cross-sell into savings and credit once trust is established.",
      outcomes: [
        "Open a verified account in under five minutes, end to end.",
        "Reach 50,000 funded accounts within two quarters of launch.",
        "Achieve a crash-free session rate of at least 99.5%.",
        "Keep blended cost-per-funded-account under \u20ac25.",
      ],
      effProcess: "Account opening moves from a multi-day, document-heavy process to a guided in-app flow with automated identity verification and instant provisioning.",
      effSystem: "A unified internal API fronts the core-banking ledger, payments rail and KYC provider; native iOS and Android apps share one design system and one contract.",
      effBehaviour: "Customers self-serve everyday banking from the app and trust real-time notifications instead of calling support; the team ships behind feature flags on a weekly cadence.",
      effLeadership: "A single delivery owner is accountable end to end, Compliance is embedded from Discovery, and a weekly steering forum governs scope against the four target outcomes.",
      financial: [
        { label: "Build cost (one-off)", value: "\u20ac1.6M", note: "Apps, API, integration, security" },
        { label: "Annual run cost", value: "\u20ac540,000", note: "Cloud, vendor fees, support" },
        { label: "Acquisition budget (yr 1)", value: "\u20ac900,000", note: "Paid + referral programme" },
        { label: "Breakeven", value: "~Q3 2027", note: "At 50k funded accounts" },
      ],
      justification: "The mobile channel is where the market is moving and where unit economics are strongest. A focused launch that owns onboarding speed is the lowest-risk route to a defensible position; delaying only raises acquisition cost as competitors compound their lead.",
      effective: "Delivery is phased \u2014 Discovery, Design, Build, Beta, Launch \u2014 each ending in a go/no-go gate. Benefits are tracked against the four outcomes and reviewed weekly, with Finance validating cost-per-account and Compliance holding the launch gate.",
    };
    const scope = {
      inScope: [
        "Native iOS and Android apps at feature parity",
        "In-app account opening with automated KYC",
        "Current account, payments and instant card controls",
        "Real-time payment notifications",
        "Closed beta and public launch in the home market",
      ],
      outScope: [
        "Savings and lending products (phase 2)",
        "Web banking application",
        "Business / joint accounts",
        "International markets and multi-currency",
        "Branch or call-centre servicing",
      ],
    };
    const assessment = [
      { id: uid("as"), area: "Account opening", asIs: "Multi-day, document-heavy, branch-assisted.", toBe: "Under five minutes, fully in-app." },
      { id: uid("as"), area: "Notifications", asIs: "Batch statements, no real-time alerts.", toBe: "Instant push on every transaction." },
      { id: uid("as"), area: "Card controls", asIs: "Call the bank to freeze a lost card.", toBe: "Freeze and unfreeze instantly in-app." },
      { id: uid("as"), area: "Platform", asIs: "No mobile offering of our own.", toBe: "Native iOS + Android on a shared design system." },
      { id: uid("as"), area: "Cost to serve", asIs: "High, branch-and-phone heavy.", toBe: "Low, self-service digital servicing." },
    ];
    const commPlan = [
      { id: uid("cm"), audience: "Beta customers", purpose: "Recruit and prepare the 500 closed-beta participants.", messages: ["What the beta is and what we expect", "How to install and give feedback", "What is and isn't live yet"], channels: ["Email", "In-app message"], timing: "Two weeks before beta", date: D(2026, 4, 20), owner: "Elena Duarte", deliverables: ["Beta invite email (drafted)", "In-app onboarding card"] },
      { id: uid("cm"), audience: "Internal staff", purpose: "Prepare support and the wider company for launch.", messages: ["Launch date and what's shipping", "How to answer common customer questions", "Where the runbook and FAQ live"], channels: ["All-hands", "Intranet"], timing: "Launch week", date: D(2026, 6, 22), owner: "Raj Malhotra", deliverables: ["All-hands slide", "Support FAQ (done)"] },
      { id: uid("cm"), audience: "Prospective customers", purpose: "Drive awareness and app installs at launch.", messages: ["Open an account in five minutes", "Real-time money, instant card controls", "Refer a friend and both get rewarded"], channels: ["Paid social", "App stores", "PR"], timing: "Launch day onward", date: D(2026, 6, 26), owner: "Carla Mendes", deliverables: ["Campaign creative", "App-store listing", "Press release (drafted)"] },
      { id: uid("cm"), audience: "Regulator", purpose: "Evidence readiness and confirm sign-off ahead of launch.", messages: ["Controls register and pen-test results", "KYC/AML evidence pack", "Launch date and rollback plan"], channels: ["Formal submission", "Review meeting"], timing: "Before the launch gate", date: D(2026, 4, 22), owner: "David Olsen", deliverables: ["Evidence pack (submitted)", "Sign-off letter"] },
    ];
    const changePlan = { groups: [
      { id: uid("cg"), label: "Customer-facing", accent: "pink", rows: [
        { id: uid("cr"), component: "Onboarding education", description: "Teach new customers how to open an account, fund it and use card controls, reducing KYC drop-off.", deliverables: ["In-app tooltips", "Help-centre articles", "Explainer videos"], owner: "Tom\u00e1s Silva" },
        { id: uid("cr"), component: "Support readiness", description: "Equip the support team to handle launch-week volume and the most common questions.", deliverables: ["Support FAQ", "Macro responses", "Escalation runbook"], owner: "Elena Duarte" },
      ] },
      { id: uid("cg"), label: "Internal", accent: "indigo", rows: [
        { id: uid("cr"), component: "Weekly release ritual", description: "Embed a feature-flagged weekly release cadence with clear go/no-go criteria.", deliverables: ["Release checklist", "On-call rota", "Crash-free dashboard"], owner: "Raj Malhotra" },
        { id: uid("cr"), component: "Compliance routine", description: "Keep KYC/AML controls evidenced and current as the product evolves.", deliverables: ["Live controls register", "Monthly compliance review"], owner: "David Olsen" },
      ] },
    ] };
    const members = [
      { id: "mem_you", name: "You", role: "Project Manager", email: "", color: "blue" },
      { id: "mem_raj", name: "Raj Malhotra", role: "Engineering Lead", email: "r.malhotra@meridian.example", color: "indigo" },
      { id: "mem_helena", name: "Helena Brandt", role: "Executive Sponsor", email: "h.brandt@meridian.example", color: "purple" },
      { id: "mem_elena", name: "Elena Duarte", role: "Product Lead", email: "e.duarte@meridian.example", color: "pink" },
      { id: "mem_tomas", name: "Tom\u00e1s Silva", role: "Lead Designer", email: "t.silva@meridian.example", color: "teal" },
      { id: "mem_sophie", name: "Sophie Tran", role: "iOS Engineer", email: "s.tran@meridian.example", color: "blue" },
      { id: "mem_marcus", name: "Marcus Webb", role: "Android Engineer", email: "m.webb@meridian.example", color: "green" },
      { id: "mem_aisha", name: "Aisha Khan", role: "Security Architect", email: "a.khan@meridian.example", color: "red" },
      { id: "mem_david", name: "David Olsen", role: "Compliance Officer", email: "d.olsen@meridian.example", color: "amber" },
      { id: "mem_carla", name: "Carla Mendes", role: "Marketing Lead", email: "c.mendes@meridian.example", color: "purple" },
      { id: "mem_nina", name: "Nina Petrova", role: "Data Analyst", email: "n.petrova@meridian.example", color: "amber" },
    ];
    const glossary = [
      { id: "gl_kyc", term: "KYC", definition: "Know Your Customer \u2014 the identity checks required before a customer can open and use an account." },
      { id: "gl_aml", term: "AML", definition: "Anti-Money-Laundering \u2014 controls that detect and prevent illicit funds moving through the bank." },
      { id: "gl_cpa", term: "CPA", definition: "Cost Per Acquisition \u2014 the blended marketing spend to acquire one funded account." },
      { id: "gl_crash", term: "crash-free rate", definition: "The percentage of app sessions that complete without a crash \u2014 a core quality gate for launch." },
      { id: "gl_flag", term: "feature flag", definition: "A switch that turns functionality on or off remotely, letting us ship code dark and release gradually." },
      { id: "gl_acl", term: "anti-corruption layer", definition: "An internal API that isolates our apps from the quirks and instability of the external core-banking vendor." },
      { id: "gl_funded", term: "funded account", definition: "An opened account that has received its first deposit \u2014 our primary measure of real activation." },
    ];
    const financials = {
      currency: "€", weighting: "duration",
      contract: { title: "Build & Launch SOW", party: "Northbridge Digital Ltd", value: 1600000, signed: D(2026, 1, 8), start: D(2026, 1, 12), end: D(2026, 6, 26), url: "https://drive.example.com/meridian/contract-sow", note: "Fixed-scope statement of work for the build, integration and launch. Run costs billed separately." },
      budget: [
        { id: uid("bg"), label: "Engineering & build", amount: 760000, note: "iOS, Android, API integration" },
        { id: uid("bg"), label: "Product & design", amount: 240000, note: "Research, flows, brand kit" },
        { id: uid("bg"), label: "Security & compliance", amount: 180000, note: "Pen-test, KYC/AML, sign-off" },
        { id: uid("bg"), label: "Go-to-market", amount: 300000, note: "Launch campaign, app stores, PR" },
        { id: uid("bg"), label: "Contingency", amount: 120000, note: "~8% reserve" },
      ],
    };
    return { meta: { project: "Meridian Mobile Banking Launch", code: "PRJ-2026-031" }, tasks, members, stakeholders, risks, findings, org, products, businessCase, scope, assessment, commPlan, changePlan, milestones, glossary, financials, ...tax };
  }

  function seedRoot() {
    const demo = makeProject("blue", showcaseData(), 6); demo.demoTag = "showcase-meridian-v1";
    const p1 = makeProject("purple", heliosData(), 48);
    const p2 = makeProject("teal", intranetData(), 12);
    const p3 = makeProject("indigo", migrationData(), 20, null);
    p3.parentId = p1.id;
    const ai = makeProject("teal", aiConsultingData(), 0);
    return { version: 2, activeId: ai.id, projects: [ai, demo, p1, p3, p2], demoSeeded: true, aiSeeded: true };
  }

  // non-destructively add the fully-populated demo to an existing workspace, once
  function ensureShowcase(root) {
    if (root.demoSeeded) return root;
    const demo = makeProject("blue", showcaseData(), 6); demo.demoTag = "showcase-meridian-v1";
    root.projects = [demo, ...root.projects];
    root.activeId = demo.id;
    root.demoSeeded = true;
    try { localStorage.setItem(KEY, JSON.stringify(root)); } catch (e) {}
    return root;
  }

  // ---------- AI consulting start-up: risk register + scope ----------
  function aiConsultingData() {
    const tax = {
      tags: [
        { id: "tg_pkg", label: "Tool Suite", color: "blue" },
        { id: "tg_adv", label: "Advisory", color: "teal" },
        { id: "tg_legal", label: "Compliance", color: "red" },
        { id: "tg_sales", label: "Sales", color: "amber" },
      ],
      phases: [
        { id: "ph_found", label: "Foundation", color: "teal" },
        { id: "ph_build", label: "Build", color: "blue" },
        { id: "ph_launch", label: "Launch", color: "amber" },
        { id: "ph_scale", label: "Scale", color: "indigo" },
      ],
      categories: [
        { id: "ct_product", label: "Product & Tool Suite", color: "blue" },
        { id: "ct_consult", label: "Consulting Delivery", color: "teal" },
        { id: "ct_gtm", label: "Go-to-Market & Sales", color: "amber" },
        { id: "ct_ops", label: "Operations & Compliance", color: "red" },
        { id: "ct_talent", label: "People & Talent", color: "purple" },
      ],
    };
    const T = {};
    const mk = (key, o) => { const id = uid("t"); T[key] = id; return { id, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [], comments: [], custom: {}, ...o }; };
    const tasks = [
      mk("suite", { title: "Define & package the modular AI tool suite", status: "inprogress", tags: ["tg_pkg"], phase: "ph_found", category: "ct_product", priority: "high", assignees: ["CTO"], start: D(2026, 6, 1), end: D(2026, 7, 15), desc: "Decide which AI tools make up the start-up package (assistant, document automation, analytics, RAG knowledge base, workflow automation) and how each is scoped and individually priced." }),
      mk("method", { title: "Build the AI readiness assessment methodology", status: "inprogress", tags: ["tg_adv"], phase: "ph_found", category: "ct_consult", priority: "high", assignees: ["Lead Consultant"], start: D(2026, 6, 8), end: D(2026, 7, 10), desc: "A repeatable way to assess a client's as-is processes, data maturity and readiness, then present options for where and how AI could help." }),
      mk("compliance", { title: "Data governance & EU AI Act compliance framework", status: "inprogress", tags: ["tg_legal"], phase: "ph_found", category: "ct_ops", priority: "high", assignees: ["Compliance Lead"], start: D(2026, 6, 15), end: D(2026, 7, 22), desc: "Define how client data is handled, build the EU AI Act / GDPR compliance checklist applied to every engagement and tool." }),
      mk("talent", { title: "Recruit AI engineering & consulting talent", status: "inprogress", tags: [], phase: "ph_found", category: "ct_talent", priority: "high", assignees: ["Founder"], start: D(2026, 6, 1), end: D(2026, 8, 15), desc: "Hire (or contract) the engineers and consultants needed to deliver both the tool suite and assessment engagements." }),
      mk("pricing", { title: "Pricing model for individually-priced services", status: "backlog", tags: ["tg_sales"], phase: "ph_build", category: "ct_gtm", priority: "high", assignees: ["Head of Growth"], start: D(2026, 7, 1), end: D(2026, 7, 25), desc: "Set à-la-carte pricing for each tool and service, plus bundle logic so the package reads as a coherent suite." }),
      mk("vendors", { title: "Set up model & cloud vendor partnerships", status: "backlog", tags: ["tg_pkg"], phase: "ph_build", category: "ct_product", priority: "med", assignees: ["CTO"], start: D(2026, 7, 6), end: D(2026, 8, 7), desc: "Establish provider relationships (model APIs, cloud) with terms, SLAs and fallbacks across more than one vendor." }),
      mk("integration", { title: "Shared data layer & SSO across the tool suite", status: "backlog", tags: ["tg_pkg"], phase: "ph_build", category: "ct_product", priority: "high", assignees: ["CTO"], start: D(2026, 7, 20), end: D(2026, 9, 4), desc: "Make the tools genuinely complementary: shared identity, shared data layer and consistent UX so the suite is more than separate apps." }),
      mk("playbook", { title: "Client onboarding & delivery playbook", status: "backlog", tags: ["tg_adv"], phase: "ph_build", category: "ct_consult", priority: "med", assignees: ["Lead Consultant"], start: D(2026, 7, 13), end: D(2026, 8, 14), desc: "Standard statement of work, phase gates, success metrics and a defined path from assessment to a production deployment." }),
      mk("entry", { title: "Productised fixed-fee 'AI readiness' offer", status: "backlog", tags: ["tg_sales", "tg_adv"], phase: "ph_launch", category: "ct_gtm", priority: "med", assignees: ["Head of Growth"], start: D(2026, 7, 20), end: D(2026, 8, 10), desc: "A low-friction, fixed-fee assessment as the front door — shortens the sales cycle and creates a path into the larger suite." }),
      mk("marketing", { title: "Launch marketing & lead generation", status: "backlog", tags: ["tg_sales"], phase: "ph_launch", category: "ct_gtm", priority: "med", assignees: ["Head of Growth"], start: D(2026, 8, 17), end: D(2026, 9, 18), desc: "Positioning, website, case-study pipeline and outbound to generate the first qualified leads." }),
    ];
    const dep = (k, ...ds) => { const t = tasks.find((x) => x.id === T[k]); t.deps = ds; };
    dep("integration", { id: uid("d"), type: "task", refId: T.suite }, { id: uid("d"), type: "task", refId: T.vendors });
    dep("playbook", { id: uid("d"), type: "task", refId: T.method });
    dep("entry", { id: uid("d"), type: "task", refId: T.method }, { id: uid("d"), type: "task", refId: T.pricing });
    dep("marketing", { id: uid("d"), type: "task", refId: T.entry });

    const milestones = [
      { id: uid("ms"), title: "Compliance framework signed off", type: "gate", date: D(2026, 7, 22), category: "ct_ops", note: "Go/no-go: no client engagement starts until the data-handling & EU AI Act framework is approved." },
      { id: uid("ms"), title: "Tool suite v1 live", type: "milestone", date: D(2026, 9, 10), category: "ct_product", note: "First integrated version of the packaged tool suite available to clients." },
      { id: uid("ms"), title: "First paying client", type: "milestone", date: D(2026, 9, 25), category: "ct_gtm", note: "First signed assessment or tool engagement — proof the offer sells." },
    ];
    const risks = [
      { id: uid("r"), title: "Clients expect AI to do more than is realistic", likelihood: "high", impact: "high", status: "open", owner: "Lead Consultant", mitigation: "Use the readiness assessment to set realistic, evidence-based expectations; scope every engagement with explicit success criteria and a defined production path.", taskIds: [T.method, T.playbook] },
      { id: uid("r"), title: "Client AI projects stall in 'POC purgatory' and never reach production", likelihood: "high", impact: "high", status: "open", owner: "Lead Consultant", mitigation: "Define the production path and success metrics up front; phase-gate engagements with a go/no-go before each stage so pilots are designed to ship.", taskIds: [T.method, T.playbook] },
      { id: uid("r"), title: "Heavy dependency on third-party model/cloud vendors (price hikes, API changes, outages)", likelihood: "high", impact: "high", status: "open", owner: "CTO", mitigation: "Abstract providers behind an internal layer; contract SLAs; keep a tested fallback model and more than one vendor relationship.", taskIds: [T.vendors, T.integration] },
      { id: uid("r"), title: "Long sales cycles strain start-up cash flow", likelihood: "high", impact: "high", status: "open", owner: "Head of Growth", mitigation: "Lead with the productised fixed-fee assessment as a low-friction entry; pursue retainers; manage runway against a conservative pipeline.", taskIds: [T.entry, T.marketing] },
      { id: uid("r"), title: "Regulatory non-compliance (EU AI Act / GDPR)", likelihood: "med", impact: "high", status: "open", owner: "Compliance Lead", mitigation: "Build the compliance framework before first delivery; legal review of each tool; signed data-processing agreements with every client.", taskIds: [T.compliance] },
      { id: uid("r"), title: "Client data breach or mishandling", likelihood: "med", impact: "high", status: "monitoring", owner: "Compliance Lead", mitigation: "Encryption in transit and at rest, least-privilege access, data-retention limits, and a SOC 2 roadmap; periodic penetration testing.", taskIds: [T.compliance] },
      { id: uid("r"), title: "Scarcity & churn of skilled AI talent", likelihood: "med", impact: "high", status: "open", owner: "Founder", mitigation: "Blend permanent hires with a vetted contractor network; competitive equity; partner with universities for a junior pipeline.", taskIds: [T.talent] },
      { id: uid("r"), title: "The tool suite isn't actually integrated — the 'complementary' promise fails", likelihood: "med", impact: "high", status: "open", owner: "CTO", mitigation: "Design a shared data layer and SSO from the start; publish a reference architecture; integration-test the suite as a whole, not tool by tool.", taskIds: [T.suite, T.integration] },
      { id: uid("r"), title: "Consulting engagements suffer scope creep", likelihood: "high", impact: "med", status: "open", owner: "Lead Consultant", mitigation: "Tight statements of work with fixed per-phase deliverables and a formal change-control process for anything extra.", taskIds: [T.playbook] },
      { id: uid("r"), title: "Commoditisation — larger players undercut on price", likelihood: "med", impact: "med", status: "monitoring", owner: "Head of Growth", mitigation: "Differentiate on assessment quality, integration and trusted local delivery rather than raw tooling; focus on a few niche verticals.", taskIds: [T.pricing] },
    ];
    const scope = {
      inScope: [
        "AI readiness assessment of a client's current (as-is) processes and data",
        "AI opportunity mapping and a prioritised adoption roadmap with options",
        "A modular suite of complementary AI tools, each priced individually",
        "Integration of selected tools into the client's existing systems",
        "Staff training and change management for AI adoption",
        "Data governance, privacy and EU AI Act compliance advisory",
        "Ongoing support, monitoring and model-performance reviews",
      ],
      outScope: [
        "Training bespoke foundation models from scratch",
        "Hardware or on-prem GPU infrastructure procurement",
        "General (non-AI) IT consulting or custom software development",
        "Clinical, legal or safety-critical certification of AI systems",
        "24/7 managed operations (not offered at launch)",
        "Large-scale manual data labelling (outsourced to partners)",
      ],
    };
    const assessment = [
      { id: uid("as"), area: "AI adoption", asIs: "Companies are curious about AI but don't know where it fits.", toBe: "A clear, prioritised roadmap grounded in their real processes." },
      { id: uid("as"), area: "Tooling", asIs: "Point AI tools bought ad hoc, poorly integrated.", toBe: "A complementary suite that shares data and identity." },
      { id: uid("as"), area: "Compliance", asIs: "Unclear how AI use squares with GDPR / the EU AI Act.", toBe: "A documented, defensible compliance position per use case." },
    ];
    const members = [
      { id: "mem_you", name: "Founder", role: "Founder & CEO", email: "", color: "blue" },
      { id: "mem_cto", name: "CTO", role: "Co-founder, Engineering", email: "", color: "indigo" },
      { id: "mem_consult", name: "Lead Consultant", role: "Consulting delivery", email: "", color: "teal" },
      { id: "mem_comp", name: "Compliance Lead", role: "Risk & compliance", email: "", color: "red" },
      { id: "mem_growth", name: "Head of Growth", role: "Sales & marketing", email: "", color: "amber" },
    ];
    const org = [
      { id: "o_founder", name: "Founder", role: "Founder & CEO", parent: null, note: "Single point of accountability", accent: "blue" },
      { id: "o_cto", name: "CTO", role: "Co-founder, Engineering", parent: "o_founder", note: "Tool suite & integration", accent: "indigo" },
      { id: "o_consult", name: "Lead Consultant", role: "Consulting Delivery", parent: "o_founder", note: "Assessments & engagements", accent: "teal" },
      { id: "o_comp", name: "Compliance Lead", role: "Risk & Compliance", parent: "o_founder", note: "Governance & EU AI Act", accent: "red" },
      { id: "o_growth", name: "Head of Growth", role: "Sales & Marketing", parent: "o_founder", note: "Pricing, pipeline & launch", accent: "amber" },
    ];
    const businessCase = Object.assign(blankBusinessCase(), {
      purpose: "An AI consulting start-up with two offerings: a modular suite of complementary AI tools priced à la carte, and a consulting practice that assesses a client's as-is processes and maps the right path to AI adoption.",
      problem: "Most companies starting out with AI don't know which tools fit their processes, how to adopt them responsibly, or how to get past pilots into production. They buy disconnected point tools and struggle with compliance.",
    });
    const bmcNotes = {
      partners: "Our delivery leans on a few key partnerships. We stay embedded in the local startup community to source early clients and referrals and to be present where new companies form. We depend on the large model owners (foundation-model and cloud providers) whose APIs power our tools — actively managing terms, SLAs and fallbacks there is critical. And we maintain investor relations to fund growth through longer enterprise sales cycles and to open doors to enterprise introductions.",
      activities: "Our work centres on winning and keeping clients. Sales and communication — pitching, running the AI-readiness assessment, and translating technical possibilities into clear business value using relatable analogies — is what turns interest into signed engagements. Once a client is onboard, ongoing maintenance and account management keeps the tools performing and the relationship healthy, which drives renewals and expansion.",
      resources: "We rely on seed funding to sustain the team through longer enterprise sales cycles, enough cloud and hosting capacity to run client workloads reliably, and strong documentation — our assessment methodology, delivery playbooks and client-facing materials — that lets us deliver consistently and scale beyond the founders.",
      value: "We offer two complementary things: a modular suite of AI tools priced individually, and a consultancy practice that assesses a client's processes and maps the right path to AI adoption. Together they take a company from 'curious about AI' to concrete, integrated, governed tools running in production.",
      relationships: "We build relationships in several modes depending on the client: consulting-based relationships for assessment and advisory work, contractual relationships for defined delivery engagements, and subscription-based relationships for ongoing tool access. Across all of them we favour close, hands-on collaboration over arm's-length delivery.",
      channels: "We reach clients mainly through enterprise communication systems and direct email outreach, supported by warm referrals from our startup-community and investor networks.",
      segments: "We serve three main segments. Enterprise organisations, where we run department-specific local implementations, strong up-front pre-analysis, and full overhauls of existing tooling. SMVs (small and mid-sized businesses) that need targeted, affordable automation with fast ROI. And startups, who take the suite package and value our help with maturity, strategy and early set-up.",
      costs: "Our main costs are infrastructure and operations: servers and hosting, CVR-registry and other API calls, website hosting, the underlying model subscription fees that power the tools, and advertising to generate a steady pipeline of leads.",
      revenue: "Revenue comes from two streams. Recurring subscription fees for the tool suite across several tiers, and consultancy fees charged at an hourly rate plus an ongoing maintenance fee once a solution is live.",
    };
    const bmc = { _mode: {} };
    Object.keys(bmcNotes).forEach((k) => { bmc[k + "_note"] = bmcNotes[k]; bmc._mode[k] = "notes"; });
    const startup = { mission: {}, valueProp: {}, features: { groups: [] }, bmc, lean: {}, market: {}, personas: [], gtm: {} };
    return { meta: { project: "AI Consulting Start-up", code: "AIC-2026" }, startupKit: true, startup, tasks, members, stakeholders: [], risks, findings: [], org, products: [], businessCase, scope, assessment, commPlan: [], changePlan: blankChangePlan(), milestones, customFields: [], baseline: null, automations: [], activity: [], suggestDismiss: {}, financials: blankFinancials(), glossary: [], ...tax };
  }

  // non-destructively add the AI consulting project once, and open it
  function ensureAIConsulting(root) {
    if (root.aiSeeded) return root;
    const proj = makeProject("teal", aiConsultingData(), 0);
    root.projects = [proj, ...root.projects];
    root.activeId = proj.id;
    root.aiSeeded = true;
    try { localStorage.setItem(KEY, JSON.stringify(root)); } catch (e) {}
    return root;
  }

  function blankProject(name, code, color, parentId = null) {
    const tax = defaultTaxonomy();
    return makeProject(color || "indigo", {
      meta: { project: name || "Untitled project", code: code || "" },
      tasks: [], members: [], stakeholders: [], risks: [], findings: [], products: [],
      org: [{ id: "o_owner", name: "Project Owner", role: "Project Owner", parent: null, note: "Single point of accountability", accent: "indigo" }],
      businessCase: blankBusinessCase(), scope: blankScope(), assessment: [], commPlan: [], changePlan: blankChangePlan(), milestones: [],
      customFields: [], baseline: null, automations: [], activity: [], suggestDismiss: {}, financials: blankFinancials(), ...tax,
    }, 0, parentId);
  }

  // ---------- persistence ----------
  function normalize(root) {
    root.projects = (root.projects || []).map((p0) => { const p = stripSeedTags(p0); const out = ({
      ...p,
      scope: p.scope && Array.isArray(p.scope.inScope) ? p.scope : { inScope: [], outScope: [] },
      assessment: Array.isArray(p.assessment) ? p.assessment : [],
      commPlan: Array.isArray(p.commPlan) ? p.commPlan : [],
      changePlan: p.changePlan && Array.isArray(p.changePlan.groups) ? p.changePlan : { groups: [] },
      milestones: Array.isArray(p.milestones) ? p.milestones : [],
      glossary: Array.isArray(p.glossary) ? p.glossary : [],
      externals: Array.isArray(p.externals) ? p.externals : [],
      members: Array.isArray(p.members) && p.members.length ? p.members
        : (() => {
            // backfill from org names + stakeholders + assignees so the canonical list is complete
            const seen = new Map();
            const accents = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
            let i = 0;
            const addPerson = (name, role) => {
              const key = (name || "").trim(); if (!key || seen.has(key)) return;
              seen.set(key, { id: "mem_" + Math.random().toString(36).slice(2, 9), name: key, role: role || "", email: "", color: accents[i++ % accents.length] });
            };
            (p.org || []).forEach((o) => addPerson(o.name, o.role));
            (p.stakeholders || []).forEach((st) => addPerson(st.name, st.role));
            (p.tasks || []).forEach((t) => (Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : [])).forEach((n) => addPerson(n, "")));
            return [...seen.values()];
          })(),
      businessCase: { ...blankBusinessCase(), ...(p.businessCase || {}) },
      financials: (() => { const f = p.financials || {}; const b = blankFinancials(); return { ...b, ...f, contract: { ...b.contract, ...(f.contract || {}) }, budget: Array.isArray(f.budget) ? f.budget : [] }; })(),
      customFields: Array.isArray(p.customFields) ? p.customFields : [],
      baseline: p.baseline && p.baseline.bars ? p.baseline : null,
      automations: Array.isArray(p.automations) ? p.automations : [],
      activity: Array.isArray(p.activity) ? p.activity : [],
      suggestDismiss: p.suggestDismiss && typeof p.suggestDismiss === "object" ? p.suggestDismiss : {},
      startup: (() => { const d = { mission: {}, valueProp: {}, features: { groups: [] }, bmc: {}, lean: {}, market: {}, personas: [], gtm: {} }; return { ...d, ...(p.startup || {}) }; })(),
    });
    // start-up kit projects: surface the strategy sections (and any duplicate keeps them)
    if (out.startupKit || (out.meta && out.meta.code === "AIC-2026")) {
      out.startupKit = true;
      const cur = Array.isArray(out._enabledSections) ? out._enabledSections : ["comms", "change", "scope", "business", "financials", "preanalysis", "catalogue", "org", "capacity"];
      out._enabledSections = [...new Set([...cur, "mission", "valueprop", "features", "bmc", "lean", "market", "personas", "gtm"])];
    }
    // link org cards to canonical members (by existing memberId, else by matching name)
    out.org = (out.org || []).map((o) => {
      if (o.memberId && out.members.some((m) => m.id === o.memberId)) return o;
      const m = out.members.find((x) => x.name && x.name === o.name);
      return m ? { ...o, memberId: m.id } : { ...o, memberId: o.memberId || null };
    });
    // hard sync: drop task assignees who are no longer in the member list
    {
      const memberNames = new Set((out.members || []).map((m) => m.name));
      out.tasks = (out.tasks || []).map((t) => {
        const as = Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []);
        const kept = as.filter((a) => memberNames.has(a));
        return kept.length === as.length ? t : { ...t, assignees: kept, assignee: undefined };
      });
    }
    return out; });
    return root;
  }
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { const r = JSON.parse(raw); if (r && r.version === 2) return ensureAIConsulting(ensureShowcase(normalize(r))); }
    } catch (e) { console.warn("load failed", e); }
    const s = seedRoot();
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
    return s;
  }

  let root = load();
  const listeners = new Set();
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(root)); } catch (e) { console.warn("persist failed (quota?)", e); } }
  function emit() { listeners.forEach((l) => l()); }

  function active() { return root.projects.find((p) => p.id === root.activeId) || null; }

  // ----- automations engine (loop-safe: one synchronous pass per change) -----
  function autoActivity(rule, task, kind) {
    return { id: uid("act"), ts: Date.now(), ruleId: rule.id, taskId: task.id, kind: kind || rule.trigger, text: automationSummary(rule), task: task.title };
  }
  function applyAutoAction(task, action, value) {
    if (action === "set_status") return { ...task, status: value };
    if (action === "set_priority") return { ...task, priority: value };
    if (action === "add_tag") return value ? { ...task, tags: [...new Set([...(task.tags || []), value])] } : task;
    if (action === "assign") {
      const who = Array.isArray(task.assignees) ? task.assignees : (task.assignee ? [task.assignee] : []);
      return value ? { ...task, assignees: [...new Set([...who, value])], assignee: undefined } : task;
    }
    return task; // "notify" / log-only: no task mutation
  }
  function automationSummary(r) {
    const trg = r.trigger === "status" ? ("moved to " + (r.triggerValue || "…")) : r.trigger === "created" ? "created" : "overdue";
    const act = r.action === "set_status" ? ("set status → " + (r.actionValue || "…"))
      : r.action === "set_priority" ? ("set priority → " + (r.actionValue || "…"))
      : r.action === "add_tag" ? "add a tag"
      : r.action === "assign" ? ("assign " + (r.actionValue || "someone"))
      : "flag for review";
    return "When a task is " + trg + ", " + act + ".";
  }
  // status + created triggers, evaluated against the pre-change task set
  function applyAutomations(prev, next) {
    const rules = (next.automations || []).filter((r) => r.enabled !== false && (r.trigger === "status" || r.trigger === "created"));
    if (!rules.length) return next;
    const prevById = new Map((prev.tasks || []).map((t) => [t.id, t]));
    let tasks = next.tasks;
    const fired = [];
    next.tasks.forEach((t) => {
      const before = prevById.get(t.id);
      rules.forEach((r) => {
        let trig = false;
        if (r.trigger === "status") trig = t.status === r.triggerValue && (!before || before.status !== r.triggerValue);
        else if (r.trigger === "created") trig = !before;
        if (!trig) return;
        tasks = tasks.map((x) => (x.id === t.id ? applyAutoAction(x, r.action, r.actionValue) : x));
        fired.push(autoActivity(r, t));
      });
    });
    if (!fired.length) return next;
    return { ...next, tasks, activity: [...fired, ...(next.activity || [])].slice(0, 120) };
  }
  // overdue trigger: swept on mount / after date edits, deduped per rule via firedTaskIds
  function runOverdueAutomations(proj) {
    const rules = (proj.automations || []).filter((r) => r.enabled !== false && r.trigger === "overdue");
    if (!rules.length) return proj;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    let tasks = proj.tasks, activity = proj.activity || [], autos = proj.automations, changed = false;
    rules.forEach((r) => {
      const fired = new Set(r.firedTaskIds || []);
      (proj.tasks || []).forEach((t) => {
        if (t.status === "done" || !t.end || new Date(t.end) >= today || fired.has(t.id)) return;
        tasks = tasks.map((x) => (x.id === t.id ? applyAutoAction(x, r.action, r.actionValue) : x));
        activity = [autoActivity(r, t, "overdue"), ...activity].slice(0, 120);
        fired.add(t.id); changed = true;
        autos = autos.map((rr) => (rr.id === r.id ? { ...rr, firedTaskIds: [...fired] } : rr));
      });
    });
    return changed ? { ...proj, tasks, activity, automations: autos } : proj;
  }

  // ----- per-project state API (used by all views) -----
  function getState() { return active(); }
  // ----- audit trail: a differ at the single choke point records EVERY change -----
  let auditMuted = false;
  function muteAudit(v) { auditMuted = !!v; }
  const AUDIT_CAP = 800;
  function auditPush(next, entries) {
    if (!entries.length) return next;
    const act = [...(next.activity || [])];
    const cut = Date.now() - 300000; // coalesce rapid re-edits of the same thing (5 min)
    entries.forEach((e) => {
      const i = act.findIndex((a) => a.ts > cut && ((e.key && a.key === e.key) || a.text === e.text));
      if (i >= 0) act[i] = { ...act[i], text: e.text, ts: e.ts };
      else act.unshift(e);
    });
    return { ...next, activity: act.slice(0, AUDIT_CAP) };
  }
  function auditDiff(prev, next) {
    if (auditMuted) return next;
    try {
      const out = [];
      const E = (text, key) => out.push({ id: uid("act"), ts: Date.now(), kind: "edit", text, key: key || null });
      const byId = (arr) => { const m = new Map(); (arr || []).forEach((x) => x && x.id && m.set(x.id, x)); return m; };
      const diffList = (key, label, nameOf, onEdit) => {
        if (prev[key] === next[key]) return;
        const pm = byId(prev[key]), nm = byId(next[key]);
        nm.forEach((x, id) => { const p = pm.get(id); if (!p) E("Added " + label + " \u201c" + nameOf(x) + "\u201d"); else if (p !== x && onEdit) onEdit(p, x); });
        pm.forEach((x, id) => { if (!nm.has(id)) E("Removed " + label + " \u201c" + nameOf(x) + "\u201d"); });
      };
      const STL = { backlog: "To do", inprogress: "In progress", done: "Done" };
      if (prev.tasks !== next.tasks) {
        const pm = byId(prev.tasks), nm = byId(next.tasks);
        nm.forEach((t, id) => {
          const p = pm.get(id);
          if (!p) { E((t.parentId ? "Added subtask \u201c" : "Created task \u201c") + t.title + "\u201d"); return; }
          if (p === t) return;
          if (p.title !== t.title) E("Renamed task \u201c" + p.title + "\u201d \u2192 \u201c" + t.title + "\u201d", "t.title." + id);
          if (p.status !== t.status) E("\u201c" + t.title + "\u201d \u2192 " + (STL[t.status] || t.status));
          if (p.start !== t.start || p.end !== t.end) E("Rescheduled \u201c" + t.title + "\u201d to " + (t.start || "?") + " \u2192 " + (t.end || "?"), "t.dates." + id);
          if (p.priority !== t.priority) E("\u201c" + t.title + "\u201d priority \u2192 " + t.priority, "t.prio." + id);
          if (JSON.stringify(p.assignees || []) !== JSON.stringify(t.assignees || [])) E("Assignees on \u201c" + t.title + "\u201d \u2192 " + ((t.assignees || []).join(", ") || "none"), "t.asg." + id);
          if (p.category !== t.category) E("Moved \u201c" + t.title + "\u201d to another track", "t.cat." + id);
          if ((p.deps || []).length !== (t.deps || []).length) E("Dependencies on \u201c" + t.title + "\u201d \u2192 " + (t.deps || []).length, "t.deps." + id);
          if ((p.comments || []).length < (t.comments || []).length) E("Comment added on \u201c" + t.title + "\u201d");
          if (p.desc !== t.desc) E("Edited description of \u201c" + t.title + "\u201d", "t.desc." + id);
          if (p.parentId !== t.parentId) E(t.parentId ? "Made \u201c" + t.title + "\u201d a subtask" : "Promoted \u201c" + t.title + "\u201d to a task", "t.par." + id);
        });
        pm.forEach((t, id) => { if (!nm.has(id)) E("Deleted task \u201c" + t.title + "\u201d"); });
      }
      diffList("risks", "risk", (x) => x.title, (p, x) => E((p.status !== x.status && x.status === "closed" ? "Closed risk \u201c" : "Edited risk \u201c") + x.title + "\u201d", "r." + x.id));
      diffList("members", "member", (x) => x.name, (p, x) => { if (p.name !== x.name) E("Renamed member " + p.name + " \u2192 " + x.name, "m.name." + x.id); else if (p.role !== x.role) E(x.name + " role \u2192 " + (x.role || "\u2014"), "m.role." + x.id); });
      diffList("milestones", "milestone/gate", (x) => x.title, (p, x) => { if (p.date !== x.date) E("Moved \u201c" + x.title + "\u201d to " + (x.date || "no date"), "ms." + x.id); else E("Edited \u201c" + x.title + "\u201d", "ms." + x.id); });
      diffList("findings", "insight", (x) => x.title, (p, x) => E("Edited insight \u201c" + x.title + "\u201d", "f." + x.id));
      diffList("glossary", "glossary term", (x) => x.term, (p, x) => E("Edited definition of \u201c" + x.term + "\u201d", "gl." + x.id));
      diffList("products", "deliverable", (x) => x.name, (p, x) => E("Edited deliverable \u201c" + x.name + "\u201d", "pr." + x.id));
      diffList("categories", "track", (x) => x.label, (p, x) => { if (p.label !== x.label) E("Renamed track \u201c" + p.label + "\u201d \u2192 \u201c" + x.label + "\u201d", "ct." + x.id); });
      diffList("stakeholders", "stakeholder", (x) => x.name);
      if (prev.scope !== next.scope && prev.scope && next.scope) {
        ["inScope", "outScope"].forEach((k) => {
          const a = prev.scope[k] || [], b = next.scope[k] || [];
          b.filter((x) => !a.includes(x)).forEach((x) => E("Added to " + (k === "inScope" ? "in scope" : "out of scope") + ": " + x, "sc." + k));
          a.filter((x) => !b.includes(x)).forEach((x) => E("Removed from " + (k === "inScope" ? "in scope" : "out of scope") + ": " + x, "sc." + k));
        });
      }
      if (prev.startup !== next.startup && prev.startup && next.startup) {
        const L = { mission: "Mission, vision & values", valueProp: "Value proposition", features: "Feature suite", bmc: "Business Model Canvas", lean: "Lean canvas", market: "Market & competition", personas: "Customer personas", gtm: "Go-to-market" };
        Object.keys(L).forEach((k) => { if (prev.startup[k] !== next.startup[k] && JSON.stringify(prev.startup[k]) !== JSON.stringify(next.startup[k])) E("Updated " + L[k], "su." + k); });
      }
      if (prev.org !== next.org) E("Updated the org chart", "org");
      if (prev.businessCase !== next.businessCase) E("Edited the business case", "bc");
      if (prev.financials !== next.financials) E("Updated financials", "fin");
      if (prev.commPlan !== next.commPlan) E("Updated the communication plan", "comms");
      if (prev.changePlan !== next.changePlan) E("Updated the change plan", "chg");
      if (prev.meta && next.meta && prev.meta.project !== next.meta.project) E("Renamed project \u2192 \u201c" + next.meta.project + "\u201d", "meta");
      return auditPush(next, out.slice(0, 30));
    } catch (e) { return next; }
  }

  function setState(updater) {
    const proj = active(); if (!proj) return;
    let next = typeof updater === "function" ? updater(proj) : { ...proj, ...updater };
    if (next === proj) return; // no-op (e.g. an automation sweep that found nothing)
    // run automations whenever the task set changed
    if (next.tasks && next.tasks !== proj.tasks) {
      next = applyAutomations(proj, next);
      next = runOverdueAutomations(next);
    }
    next = auditDiff(proj, next);
    next.updatedAt = Date.now();
    root = { ...root, rev: (root.rev || 0) + 1, savedAt: Date.now(), projects: root.projects.map((p) => (p.id === proj.id ? next : p)) };
    persist(); emit();
  }
  function update(key, fn) { setState((s) => ({ ...s, [key]: fn(s[key]) })); }
  function add(key, item) { update(key, (arr) => [...arr, item]); }
  function patch(key, id, changes) { update(key, (arr) => arr.map((x) => (x.id === id ? { ...x, ...changes } : x))); }
  function remove(key, id) { update(key, (arr) => arr.filter((x) => x.id !== id)); }
  // delete a task plus any of its subtasks, and scrub dependency references to them
  function removeTask(id) {
    setState((s) => {
      const gone = new Set([id, ...(s.tasks || []).filter((t) => t.parentId === id).map((t) => t.id)]);
      const tasks = s.tasks.filter((t) => !gone.has(t.id))
        .map((t) => (t.deps || []).some((d) => d.type === "task" && gone.has(d.refId))
          ? { ...t, deps: t.deps.filter((d) => !(d.type === "task" && gone.has(d.refId))) } : t);
      const products = (s.products || []).map((p) => (p.taskIds || []).some((x) => gone.has(x)) ? { ...p, taskIds: p.taskIds.filter((x) => !gone.has(x)) } : p);
      const risks = (s.risks || []).map((r) => (r.taskIds || []).some((x) => gone.has(x)) ? { ...r, taskIds: r.taskIds.filter((x) => !gone.has(x)) } : r);
      return { ...s, tasks, products, risks };
    });
  }

  // ----- member helpers: the member list is the single source of truth -----
  // renaming a member propagates everywhere their NAME is stored (assignees,
  // comment authors, risk owners). Org-chart cards linked by memberId inherit
  // live, so they need no rename. Capacity is name-keyed, so it stays in sync.
  function renameMember(id, newName) {
    const nm = (newName || "").trim() || "Unnamed";
    setState((s) => {
      const m = (s.members || []).find((x) => x.id === id); if (!m) return s;
      const old = m.name;
      const members = s.members.map((x) => (x.id === id ? { ...x, name: nm } : x));
      if (old === nm) return { ...s, members };
      const tasks = (s.tasks || []).map((t) => {
        let ch = t;
        const as = assigneesOf(t);
        if (as.includes(old)) ch = { ...ch, assignees: as.map((a) => (a === old ? nm : a)) };
        if ((t.comments || []).some((c) => c.author === old)) ch = { ...ch, comments: t.comments.map((c) => (c.author === old ? { ...c, author: nm } : c)) };
        return ch;
      });
      const risks = (s.risks || []).map((r) => (r.owner === old ? { ...r, owner: nm } : r));
      const org = (s.org || []).map((o) => (o.memberId === id || o.name === old ? { ...o, name: nm } : o));
      const commPlan = (s.commPlan || []).map((c) => (c.owner === old ? { ...c, owner: nm } : c));
      const changePlan = s.changePlan && Array.isArray(s.changePlan.groups)
        ? { ...s.changePlan, groups: s.changePlan.groups.map((g) => ({ ...g, rows: (g.rows || []).map((r) => (r.owner === old ? { ...r, owner: nm } : r)) })) }
        : s.changePlan;
      // keep the saved per-viewer selections pointing at this person
      try {
        ["atlas.view." + s.id, "atlas.commentAs." + s.id, "atlas.ws.who." + s.id].forEach((k) => {
          if (localStorage.getItem(k) === old) localStorage.setItem(k, nm);
        });
      } catch (e) {}
      return { ...s, members, tasks, risks, org, commPlan, changePlan };
    });
  }
  // removing a member is a hard sync: drop them from task assignees and remove
  // removing a member detaches their work everywhere: task assignments, the
  // org-chart card (reports lift to its manager), and ownership of risks, comms
  // and change rows. Capacity is derived, so it updates automatically. Comment
  // authorship is left as a historical record.
  function removeMember(id) {
    setState((s) => {
      const m = (s.members || []).find((x) => x.id === id);
      const nm = m ? m.name : null;
      const members = (s.members || []).filter((x) => x.id !== id);
      const tasks = nm ? (s.tasks || []).map((t) => {
        const as = assigneesOf(t);
        return as.includes(nm) ? { ...t, assignees: as.filter((a) => a !== nm), assignee: undefined } : t;
      }) : (s.tasks || []);
      let org = s.org || [];
      const card = org.find((o) => o.memberId === id || (nm && o.name === nm));
      if (card) org = org.filter((o) => o.id !== card.id).map((o) => (o.parent === card.id ? { ...o, parent: card.parent } : o));
      const risks = nm ? (s.risks || []).map((r) => (r.owner === nm ? { ...r, owner: "" } : r)) : (s.risks || []);
      const commPlan = nm ? (s.commPlan || []).map((c) => (c.owner === nm ? { ...c, owner: "" } : c)) : (s.commPlan || []);
      const changePlan = nm && s.changePlan && Array.isArray(s.changePlan.groups)
        ? { ...s.changePlan, groups: s.changePlan.groups.map((g) => ({ ...g, rows: (g.rows || []).map((r) => (r.owner === nm ? { ...r, owner: "" } : r)) })) }
        : s.changePlan;
      return { ...s, members, tasks, org, risks, commPlan, changePlan };
    });
  }

  // ----- root / project-management API -----
  function getRoot() { return root; }
  function setRoot(next) { root = { ...next, rev: (next.rev != null ? next.rev : (root.rev || 0) + 1), savedAt: next.savedAt || Date.now() }; persist(); emit(); }
  const projects = {
    list: () => root.projects,
    open: (id) => setRoot({ ...root, activeId: id }),
    close: () => setRoot({ ...root, activeId: null }),
    create: (name, code, color, parentId) => {
      const p = blankProject(name, code, color, parentId || null);
      setRoot({ ...root, projects: [...root.projects, p], activeId: p.id });
      return p.id;
    },
    // clone the *structure* of an existing project into a fresh one
    createFromTemplate: (srcId, opts) => {
      const src = root.projects.find((p) => p.id === srcId);
      const o = opts || {};
      const base = blankProject(o.name || "Untitled project", "", o.color || (src && src.color) || "indigo", o.parentId || null);
      if (src) {
        // always: taxonomy, custom fields, section config, org skeleton
        base.tags = (src.tags || []).map((x) => ({ ...x }));
        base.phases = (src.phases || []).map((x) => ({ ...x }));
        base.categories = (src.categories || []).map((x) => ({ ...x }));
        base.customFields = (src.customFields || []).map((x) => ({ ...x }));
        base.automations = (src.automations || []).map((x) => ({ ...x, id: uid("au"), firedTaskIds: [] }));
        if (Array.isArray(src._enabledSections)) base._enabledSections = [...src._enabledSections];
        base.org = (src.org || []).map((x) => ({ ...x }));
        if (o.includeContent) {
          base.businessCase = JSON.parse(JSON.stringify(src.businessCase || {}));
          base.scope = JSON.parse(JSON.stringify(src.scope || { inScope: [], outScope: [] }));
          base.assessment = (src.assessment || []).map((x) => ({ ...x }));
          base.commPlan = (src.commPlan || []).map((c) => ({ ...c, date: "" }));
          base.changePlan = JSON.parse(JSON.stringify(src.changePlan || { groups: [] }));
          base.glossary = (src.glossary || []).map((x) => ({ ...x }));
        }
        if (o.includeTasks) {
          base.tasks = (src.tasks || []).map((t) => ({ ...t, id: uid("t"), status: "backlog", start: "", end: "", assignees: [], assignee: undefined, deps: [], comments: [], custom: { ...(t.custom || {}) } }));
          base.milestones = (src.milestones || []).map((m) => ({ ...m, id: uid("ms"), date: "" }));
        }
      }
      setRoot({ ...root, projects: [...root.projects, base], activeId: base.id });
      return base.id;
    },
    rename: (id, name, code) => setRoot({ ...root, projects: root.projects.map((p) => p.id === id ? { ...p, meta: { ...p.meta, project: name ?? p.meta.project, code: code ?? p.meta.code }, updatedAt: Date.now() } : p) }),
    setColor: (id, color) => setRoot({ ...root, projects: root.projects.map((p) => p.id === id ? { ...p, color } : p) }),
    setParent: (id, parentId) => setRoot({ ...root, projects: root.projects.map((p) => p.id === id ? { ...p, parentId: parentId || null, updatedAt: Date.now() } : p) }),
    remove: (id) => setRoot({ ...root, projects: root.projects.filter((p) => p.id !== id).map((p) => p.parentId === id ? { ...p, parentId: null } : p), activeId: root.activeId === id ? null : root.activeId }),
  };

  function sweepAutomations() { setState((s) => runOverdueAutomations(s)); }

  // ----- nudges: time-based reminders (task starting soon / deadline approaching) -----
  function nudgeAct(nid, how, extraDays) {
    setState((s) => {
      const ns = { ...(s.nudgeState || {}) };
      if (how === "snooze") ns[nid] = { snoozeUntil: Date.now() + (extraDays || 3) * 86400000 };
      else ns[nid] = { done: how };            // "dismissed" | "acted"
      return { ...s, nudgeState: ns };
    });
  }
  function setNudgeConfig(patch) {
    setState((s) => ({ ...s, nudgeConfig: { ...NUDGE_DEFAULTS, ...(s.nudgeConfig || {}), ...patch } }));
  }
  function sweepNudges() {
    setState((s) => {
      const cfg = { ...NUDGE_DEFAULTS, ...(s.nudgeConfig || {}) };
      if (!cfg.autoStart) return s;
      const today = new Date(); today.setHours(0, 0, 0, 0);
      let changed = false;
      const tasks = (s.tasks || []).map((t) => {
        if (t.status === "backlog" && t.start && new Date(t.start) <= today) { changed = true; return { ...t, status: "inprogress" }; }
        return t;
      });
      return changed ? { ...s, tasks } : s;
    });
  }
  // push a task's start/end forward by N days and cascade the same shift to every
  // task that (transitively) depends on it, so the whole downstream chain moves too
  function pushTaskStart(taskId, days) {
    if (!days) return;
    const shift = (iso) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || "")) return iso; const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + days); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
    setState((s) => {
      const tasks = s.tasks || [];
      // build downstream set: successors depend on their predecessor via deps[].refId
      const affected = new Set([taskId]);
      let grew = true;
      while (grew) {
        grew = false;
        tasks.forEach((t) => {
          if (affected.has(t.id)) return;
          if ((t.deps || []).some((d) => d.type === "task" && affected.has(d.refId))) { affected.add(t.id); grew = true; }
        });
      }
      return { ...s, tasks: tasks.map((t) => affected.has(t.id) ? { ...t, start: shift(t.start), end: shift(t.end) } : t) };
    });
  }
  // shift only the DOWNSTREAM chain (dependents of a task), not the task itself
  function pushDependents(taskId, days) {
    if (!days) return;
    const shift = (iso) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || "")) return iso; const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + days); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
    setState((s) => {
      const tasks = s.tasks || [];
      const affected = new Set([taskId]);
      let grew = true;
      while (grew) {
        grew = false;
        tasks.forEach((t) => {
          if (affected.has(t.id)) return;
          if ((t.deps || []).some((d) => d.type === "task" && affected.has(d.refId))) { affected.add(t.id); grew = true; }
        });
      }
      affected.delete(taskId);
      return { ...s, tasks: tasks.map((t) => affected.has(t.id) ? { ...t, start: shift(t.start), end: shift(t.end) } : t) };
    });
  }

  // ----- change-impact analysis: what else does this edit affect? -----
  // Pure. Called AFTER an edit is applied, with what changed; returns suggestions
  // the UI offers as one-click follow-ups (never applied automatically).
  function impactOf(taskId, change) {
    const s = getState(); if (!s) return [];
    const tasks = s.tasks || [];
    const t = tasks.find((x) => x.id === taskId); if (!t) return [];
    const out = [];
    const dayMs = 86400000;
    const downstream = (id) => {
      const aff = new Set([id]); let grew = true;
      while (grew) { grew = false; tasks.forEach((x) => { if (!aff.has(x.id) && (x.deps || []).some((d) => d.type === "task" && aff.has(d.refId))) { aff.add(x.id); grew = true; } }); }
      aff.delete(id); return tasks.filter((x) => aff.has(x.id));
    };
    // 1) end date moved LATER -> dependents that now start before this finishes
    if (change.end && change.prevEnd && new Date(change.end) > new Date(change.prevEnd)) {
      const days = Math.round((new Date(change.end) - new Date(change.prevEnd)) / dayMs);
      const deps = downstream(t.id).filter((x) => x.start);
      const clashing = deps.filter((x) => new Date(x.start) < new Date(change.end));
      if (deps.length) {
        out.push({
          kind: "push", days, count: deps.length,
          text: "This now finishes " + days + "d later" + (clashing.length ? " — " + clashing.length + " dependent task" + (clashing.length === 1 ? "" : "s") + " would start before it's done" : " — " + deps.length + " task" + (deps.length === 1 ? "" : "s") + " depend on it"),
          action: "Push dependents +" + days + "d",
          apply: () => pushDependents(t.id, days),
        });
      }
    }
    // 2) marked done while subtasks are unfinished
    if (change.status === "done") {
      const openSubs = tasks.filter((x) => x.parentId === t.id && x.status !== "done");
      if (openSubs.length) {
        out.push({
          kind: "subs", count: openSubs.length,
          text: openSubs.length + " subtask" + (openSubs.length === 1 ? " is" : "s are") + " still unfinished",
          action: "Mark subtasks done",
          apply: () => setState((st) => ({ ...st, tasks: st.tasks.map((x) => x.parentId === t.id ? { ...x, status: "done" } : x) })),
        });
      }
      // 3) tasks that were waiting on this one are now unblocked (informational)
      const waiting = tasks.filter((x) => x.status !== "done" && (x.deps || []).some((d) => d.type === "task" && d.refId === t.id));
      if (waiting.length) {
        out.push({ kind: "info", text: "Unblocks " + waiting.length + " waiting task" + (waiting.length === 1 ? "" : "s") + ": " + waiting.slice(0, 3).map((x) => "“" + x.title + "”").join(", ") + (waiting.length > 3 ? "…" : "") });
      }
    }
    // 4) reopened (done -> not done) while other tasks depend on it
    if (change.status && change.status !== "done" && change.prevStatus === "done") {
      const dependents = tasks.filter((x) => x.status !== "done" && (x.deps || []).some((d) => d.type === "task" && d.refId === t.id));
      if (dependents.length) out.push({ kind: "info", warn: true, text: "Re-blocks " + dependents.length + " task" + (dependents.length === 1 ? "" : "s") + " that depend on this" });
    }
    return out;
  }

  // ----- smart suggestions: likely-but-unconfirmed task relationships -----
  // Surfaces "does B follow A?" when one action ends just before another starts in
  // the same category and they aren't already linked. Answers are remembered so we
  // never re-ask (suggestDismiss: key -> 'parallel' | 'linked' | 'dismissed').
  function smartSuggestions(proj) {
    if (!proj) return [];
    const tasks = proj.tasks || [];
    const dismissed = proj.suggestDismiss || {};
    const GAP = 10; // days between A-end and B-start to still feel sequential
    const dependsOn = (b, aId) => (b.deps || []).some((d) => d.type === "task" && d.refId === aId);
    const byCat = {};
    tasks.forEach((t) => { const k = t.category || "_none"; (byCat[k] = byCat[k] || []).push(t); });
    const out = [];
    Object.values(byCat).forEach((list) => {
      const dated = list.filter((t) => t.start && t.end && t.status !== "done");
      dated.forEach((a) => dated.forEach((b) => {
        if (a.id === b.id) return;
        const gap = (+new Date(b.start) - +new Date(a.end)) / 86400000;
        if (gap < -1 || gap > GAP) return;            // B must start around when A ends
        if (dependsOn(b, a.id) || dependsOn(a, b.id)) return; // already linked either way
        const key = "dep:" + a.id + ">" + b.id;
        if (dismissed[key]) return;
        out.push({ id: key, kind: "dep", aId: a.id, bId: b.id, a: a.title, b: b.title, gap: Math.round(gap), aEnd: a.end, bStart: b.start, category: a.category });
      }));
    });
    // stable order: soonest hand-off first
    return out.sort((x, y) => new Date(x.bStart) - new Date(y.bStart));
  }

  function resetAll() { root = seedRoot(); persist(); emit(); }

  // ----- sync helpers -----
  function importRoot(next, opts) {
    if (!next || next.version !== 2 || !Array.isArray(next.projects)) throw new Error("Not a valid Atlas workspace file.");
    // preserve which project this device has open across a sync pull (per-device UI state)
    const keepActive = opts && opts.keepActive ? root.activeId : null;
    let projects = next.projects;
    let activeId = null;
    if (keepActive) {
      const incomingHas = projects.some((p) => p.id === keepActive);
      if (incomingHas) {
        activeId = keepActive;
      } else {
        // The open project isn't in the incoming set (e.g. created locally and not yet
        // pushed). Keep it locally instead of ejecting the user to the portfolio.
        const localProj = root.projects.find((p) => p.id === keepActive);
        if (localProj) { projects = [...projects, localProj]; activeId = keepActive; }
      }
    }
    root = { version: 2, activeId, projects, rev: next.rev || 0, savedAt: next.savedAt || Date.now() };
    persist(); emit();
  }
  function touch() { root = { ...root, rev: (root.rev || 0) + 1, savedAt: Date.now() }; persist(); }

  // ---------- React hooks ----------
  function useStore(selector) {
    const sel = selector || ((s) => s);
    const [, force] = React.useReducer((x) => x + 1, 0);
    React.useEffect(() => { listeners.add(force); return () => listeners.delete(force); }, []);
    return sel(active());
  }
  function useRoot() {
    const [, force] = React.useReducer((x) => x + 1, 0);
    React.useEffect(() => { listeners.add(force); return () => listeners.delete(force); }, []);
    return root;
  }

  // ---------- IndexedDB file store ----------
  const DB_NAME = "atlas.files";
  let dbp = null;
  function db() {
    if (dbp) return dbp;
    dbp = new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = () => r.result.createObjectStore("files");
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return dbp;
  }
  async function putFile(id, blob) { const d = await db(); return new Promise((res, rej) => { const tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(blob, id); tx.oncomplete = () => res(id); tx.onerror = () => rej(tx.error); }); }
  async function getFile(id) { const d = await db(); return new Promise((res, rej) => { const tx = d.transaction("files", "readonly"); const rq = tx.objectStore("files").get(id); rq.onsuccess = () => res(rq.result || null); rq.onerror = () => rej(rq.error); }); }
  async function delFile(id) { const d = await db(); return new Promise((res) => { const tx = d.transaction("files", "readwrite"); tx.objectStore("files").delete(id); tx.oncomplete = () => res(); }); }
  async function allFiles() { const d = await db(); return new Promise((res, rej) => { const tx = d.transaction("files", "readonly"); const st = tx.objectStore("files"); const out = {}; const cur = st.openCursor(); cur.onsuccess = (e) => { const c = e.target.result; if (c) { out[c.key] = c.value; c.continue(); } else res(out); }; cur.onerror = () => rej(cur.error); }); }

  window.Store = {
    uid, getState, setState, update, add, patch, remove, removeTask, renameMember, removeMember, useStore, useRoot, getRoot, setRoot, muteAudit,
    projects, resetAll, importRoot, touch, sweepAutomations, sweepNudges, nudgeAct, setNudgeConfig, pushTaskStart, pushDependents, impactOf,
    computeNudges: (who) => computeNudges(getState() || {}, who), nudgeConfig: () => ({ ...NUDGE_DEFAULTS, ...((getState() || {}).nudgeConfig || {}) }),
    smartSuggestions,
    dismissSuggestion: (key, how) => setState((s) => ({ ...s, suggestDismiss: { ...(s.suggestDismiss || {}), [key]: how || "dismissed" } })),
    linkTasks: (bId, aId) => setState((s) => ({
      ...s,
      tasks: s.tasks.map((t) => (t.id === bId && !(t.deps || []).some((d) => d.type === "task" && d.refId === aId)
        ? { ...t, deps: [...(t.deps || []), { id: uid("d"), type: "task", refId: aId }] } : t)),
      suggestDismiss: { ...(s.suggestDismiss || {}), ["dep:" + aId + ">" + bId]: "linked" },
    })),
    files: { put: putFile, get: getFile, del: delFile, all: allFiles },
  };
})();


// ======== icons.jsx ========
/* ============================================================
   ICONS + shared small UI components
   Exposes window.Icon, window.UI
   ============================================================ */

const Icon = (function () {
  const S = (p, props = {}) =>
    React.createElement(
      "svg",
      { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", ...props },
      p
    );
  const P = (d, k) => React.createElement("path", { d, key: k });
  const L = (x1, y1, x2, y2, k) => React.createElement("line", { x1, y1, x2, y2, key: k });
  const C = (cx, cy, r, k) => React.createElement("circle", { cx, cy, r, key: k });
  const R = (x, y, w, h, rx, k) => React.createElement("rect", { x, y, width: w, height: h, rx, key: k });

  const paths = {
    home: () => [P("M3 10.5 12 3l9 7.5", "a"), P("M5 9.5V21h14V9.5", "b")],
    board: () => [R(3, 3, 18, 18, 2, "a"), L(9, 3, 9, 21, "b"), L(15, 3, 15, 21, "c")],
    list: () => [L(8, 6, 21, 6, "a"), L(8, 12, 21, 12, "b"), L(8, 18, 21, 18, "c"), C(3.5, 6, 0.6, "d"), C(3.5, 12, 0.6, "e"), C(3.5, 18, 0.6, "f")],
    timeline: () => [L(3, 7, 14, 7, "a"), L(8, 12, 20, 12, "b"), L(5, 17, 16, 17, "c")],
    users: () => [C(9, 8, 3.2, "a"), P("M3.5 20a5.5 5.5 0 0 1 11 0", "b"), P("M16 5.2a3.2 3.2 0 0 1 0 5.8", "c"), P("M17 14.5a5.5 5.5 0 0 1 3.5 5.5", "d")],
    shield: () => [P("M12 3 5 6v6c0 4 3 6.5 7 9 4-2.5 7-5 7-9V6l-7-3Z", "a"), P("M9 12l2 2 4-4", "b")],
    bulb: () => [P("M9 18h6", "a"), P("M10 21h4", "b"), P("M12 3a6 6 0 0 1 4 10.5c-.8.7-1 1.2-1 2.5H9c0-1.3-.2-1.8-1-2.5A6 6 0 0 1 12 3Z", "c")],
    org: () => [R(9, 3, 6, 4, 1, "a"), R(3, 17, 6, 4, 1, "b"), R(15, 17, 6, 4, 1, "c"), P("M12 7v4M6 17v-3h12v3", "d")],
    box: () => [P("M21 8 12 3 3 8l9 5 9-5Z", "a"), P("M3 8v8l9 5 9-5V8", "b"), L(12, 13, 12, 21, "c")],
    doc: () => [P("M14 3H6v18h12V7l-4-4Z", "a"), P("M14 3v4h4", "b")],
    plus: () => [L(12, 5, 12, 19, "a"), L(5, 12, 19, 12, "b")],
    x: () => [L(6, 6, 18, 18, "a"), L(18, 6, 6, 18, "b")],
    filter: () => [P("M3 5h18l-7 8v6l-4-2v-4L3 5Z", "a")],
    search: () => [C(11, 11, 7, "a"), L(20, 20, 16, 16, "b")],
    trash: () => [P("M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13", "a")],
    edit: () => [P("M4 20h4L19 9l-4-4L4 16v4Z", "a"), L(14, 6, 18, 10, "b")],
    copy: () => [R(9, 9, 11, 11, 2, "a"), P("M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1", "b")],
    check: () => [P("M5 12l4 4 10-10", "a")],
    chevR: () => [P("M9 6l6 6-6 6", "a")],
    chevD: () => [P("M6 9l6 6 6-6", "a")],
    drag: () => [C(9, 6, 0.8, "a"), C(15, 6, 0.8, "b"), C(9, 12, 0.8, "c"), C(15, 12, 0.8, "d"), C(9, 18, 0.8, "e"), C(15, 18, 0.8, "f")],
    upload: () => [P("M12 16V4", "a"), P("M7 9l5-5 5 5", "b"), P("M5 16v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3", "c")],
    print: () => [P("M6 9V3h12v6", "a"), P("M6 18H4v-6h16v6h-2", "b"), R(8, 14, 8, 6, 1, "c")],
    link: () => [P("M9 15l6-6", "a"), P("M11 7l1-1a3.5 3.5 0 0 1 5 5l-1 1", "b"), P("M13 17l-1 1a3.5 3.5 0 0 1-5-5l1-1", "c")],
    calendar: () => [R(3, 5, 18, 16, 2, "a"), L(3, 9, 21, 9, "b"), L(8, 3, 8, 6, "c"), L(16, 3, 16, 6, "d")],
    flag: () => [P("M5 21V4M5 4h11l-2 4 2 4H5", "a")],
    star: () => [P("M12 3.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8L12 17l-5.3 2.6 1-5.8L3.5 9.7l5.9-.9L12 3.5Z", "a")],
    "star-fill": () => [React.createElement("path", { d: "M12 3.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8L12 17l-5.3 2.6 1-5.8L3.5 9.7l5.9-.9L12 3.5Z", key: "a", fill: "currentColor" })],
    bolt: () => [P("M13 2 4 14h7l-1 8 9-12h-7l1-8Z", "a")],
    chat: () => [P("M4 5h16v11H9l-5 4V5Z", "a"), L(8, 9, 16, 9, "b"), L(8, 12.5, 13, 12.5, "c")],
    gauge: () => [P("M4 19a8 8 0 1 1 16 0", "a"), L(12, 19, 16, 11, "b"), C(12, 19, 0.7, "c")],
    gate: () => [R(3, 5, 18, 14, 1.5, "a"), L(8, 5, 8, 19, "b"), L(13, 5, 13, 19, "c"), L(3, 9.6, 21, 9.6, "d"), L(3, 14.3, 21, 14.3, "e")],
    idea: () => [P("M9 18h6", "a"), P("M10 21h4", "b"), P("M12 3a6 6 0 0 1 4 10.5c-.7.7-1 1.2-1 2.5H9c0-1.3-.3-1.8-1-2.5A6 6 0 0 1 12 3Z", "c")],
    spark: () => [P("M12 3l1.7 5.1a3 3 0 0 0 2.2 2.2L21 12l-5.1 1.7a3 3 0 0 0-2.2 2.2L12 21l-1.7-5.1a3 3 0 0 0-2.2-2.2L3 12l5.1-1.7a3 3 0 0 0 2.2-2.2Z", "a")],
    send: () => [P("M22 2 11 13", "a"), P("M22 2 15 22l-4-9-9-4 20-7Z", "b")],
    sort: () => [P("M7 4v16M7 4 3 8M7 4l4 4", "a"), P("M17 20V4M17 20l4-4M17 20l-4-4", "b")],
    dot: () => [C(12, 12, 3, "a")],
    arrowR: () => [L(5, 12, 19, 12, "a"), P("M13 6l6 6-6 6", "b")],
    layers: () => [P("M12 3 3 8l9 5 9-5-9-5Z", "a"), P("M3 13l9 5 9-5", "b")],
    tag: () => [P("M3 11V4h7l11 11-7 7L3 11Z", "a"), C(7.5, 7.5, 1.2, "b")],
    reset: () => [P("M4 12a8 8 0 1 1 2.3 5.6", "a"), P("M4 20v-5h5", "b")],
    clock: () => [C(12, 12, 9, "a"), P("M12 7v5l3.5 2", "b")],
    bell: () => [P("M6 9a6 6 0 0 1 12 0c0 5 2 7 2 7H4s2-2 2-7Z", "a"), P("M10 20a2 2 0 0 0 4 0", "b")],
    settings: () => [C(12, 12, 3, "a"), P("M19.4 15a1.5 1.5 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.5 1.5 0 0 0-2.5.6 1.5 1.5 0 0 0-1 1.4V22a2 2 0 1 1-4 0v-.1a1.5 1.5 0 0 0-2.6-1 1.5 1.5 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.5 1.5 0 0 0-.6-2.5 1.5 1.5 0 0 0-1.4-1H2a2 2 0 1 1 0-4h.1a1.5 1.5 0 0 0 1-2.6 1.5 1.5 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.5 1.5 0 0 0 1.7.3H8a1.5 1.5 0 0 0 1-1.4V2a2 2 0 1 1 4 0v.1a1.5 1.5 0 0 0 1 1.4 1.5 1.5 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.5 1.5 0 0 0-.3 1.7V8a1.5 1.5 0 0 0 1.4 1H22a2 2 0 1 1 0 4h-.1a1.5 1.5 0 0 0-1.4 1Z", "b")],
    file: () => [P("M14 3H6v18h12V7l-4-4Z", "a"), P("M14 3v4h4", "b")],
    image: () => [R(3, 4, 18, 16, 2, "a"), C(8.5, 9.5, 1.5, "b"), P("M21 16l-5-5L5 20", "c")],
    sheet: () => [R(4, 3, 16, 18, 2, "a"), L(4, 9, 20, 9, "b"), L(4, 15, 20, 15, "c"), L(12, 3, 12, 21, "d")],
    slides: () => [R(3, 4, 18, 12, 2, "a"), L(12, 16, 12, 20, "b"), L(8, 20, 16, 20, "c")],
    menu: () => [L(4, 7, 20, 7, "a"), L(4, 12, 20, 12, "b"), L(4, 17, 20, 17, "c")],
    warn: () => [P("M12 4 2 20h20L12 4Z", "a"), L(12, 10, 12, 14, "b"), C(12, 17, 0.6, "c")],
    target: () => [C(12, 12, 8, "a"), C(12, 12, 4, "b"), C(12, 12, 0.7, "c")],
    coin: () => [C(12, 12, 8, "a"), P("M12 8v8M9.5 10a2 2 0 0 1 4 0c0 2.5-4 1.5-4 4a2 2 0 0 0 4 0", "b")],
    scope: () => [P("M3 8V5a2 2 0 0 1 2-2h3", "a"), P("M16 3h3a2 2 0 0 1 2 2v3", "b"), P("M21 16v3a2 2 0 0 1-2 2h-3", "c"), P("M8 21H5a2 2 0 0 1-2-2v-3", "d"), C(12, 12, 2.4, "e")],
    swap: () => [P("M7 4 4 7l3 3", "a"), P("M4 7h13", "b"), P("M17 20l3-3-3-3", "c"), P("M20 17H7", "d")],
    comms: () => [P("M4 5h16v10H9l-4 4v-4H4V5Z", "a"), L(8, 9, 16, 9, "b"), L(8, 12, 13, 12, "c")],
    grid: () => [R(3, 3, 18, 18, 2, "a"), L(3, 9.5, 21, 9.5, "b"), L(9.5, 3, 9.5, 21, "c")],
    gift: () => [R(4, 8, 16, 4, 1, "a"), R(5.5, 12, 13, 9, 1, "b"), L(12, 8, 12, 21, "c"), P("M12 8C12 5.5 10 4 8.7 5S10 8 12 8M12 8c0-2.5 2-4 3.3-3S14 8 12 8", "d")],
    bundle: () => [P("M12 3 3 7.5v9L12 21l9-4.5v-9L12 3Z", "a"), P("M3 7.5 12 12l9-4.5", "b"), L(12, 12, 12, 21, "c"), P("M7.5 5.25 16.5 9.75", "d")],
    megaphone: () => [P("M3 11v2l12 5V6L3 11Z", "a"), P("M15 8.5a4 4 0 0 1 0 7", "b"), L(6, 13, 6, 19, "c")],
    chart: () => [P("M4 4v16h16", "a"), R(7, 12, 3, 5, 0.5, "b"), R(12, 9, 3, 8, 0.5, "c"), R(17, 6, 3, 11, 0.5, "d")],
    persona: () => [C(12, 8, 3.2, "a"), P("M5.5 20a6.5 6.5 0 0 1 13 0", "b")],
    inbound: () => [P("M12 3v10", "a"), P("M8 9l4 4 4-4", "b"), L(4, 19, 20, 19, "c")],
  };

  return function Icon({ name, size = 18, ...rest }) {
    const fn = paths[name];
    if (!fn) return null;
    return S(fn(), { width: size, height: size, ...rest });
  };
})();

/* ---------- shared UI bits ---------- */
const UI = (function () {
  const { useState, useRef, useEffect } = React;

  function Modal({ children, onClose, narrow, wide }) {
    useEffect(() => {
      const h = (e) => e.key === "Escape" && onClose();
      window.addEventListener("keydown", h);
      return () => window.removeEventListener("keydown", h);
    }, [onClose]);
    return (
      <div className="scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
        <div className={"modal" + (narrow ? " narrow" : "") + (wide ? " wide" : "")}>{children}</div>
      </div>
    );
  }

  function Chip({ label, color, dot, solid, onRemove }) {
    return (
      <span className={"chip tag-" + (color || "indigo") + (solid ? " solid" : "")}>
        {dot && <span className="chip-dot" />}
        {label}
        {onRemove && (
          <span className="chip-x" onClick={(e) => { e.stopPropagation(); onRemove(); }}>
            <Icon name="x" size={11} />
          </span>
        )}
      </span>
    );
  }

  // inline editable text — pencil icon on hover
  function Editable({ value, onChange, tag = "div", placeholder, className, multiline, noPencil, ...rest }) {
    const ref = useRef(null);
    const Tag = tag;
    const inner = (
      <Tag
        ref={ref}
        className={(className || "") + " editable-field"}
        contentEditable
        suppressContentEditableWarning
        spellCheck={false}
        data-ph={placeholder}
        onBlur={(e) => onChange(e.currentTarget.textContent)}
        onKeyDown={(e) => {
          if (!multiline && e.key === "Enter") { e.preventDefault(); e.currentTarget.blur(); }
        }}
        {...rest}
      >
        {value}
      </Tag>
    );
    if (noPencil || tag === "span") return inner;
    return (
      <div className="editable-wrap">
        {inner}
        <span className="editable-pencil no-print"><Icon name="edit" size={12} /></span>
      </div>
    );
  }

  // multi-select dropdown for tags
  function TagPicker({ options, selected, onToggle, placeholder = "Add…" }) {
    const [open, setOpen] = useState(false);
    const ref = useRef(null);
    useEffect(() => {
      const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
      document.addEventListener("mousedown", h);
      return () => document.removeEventListener("mousedown", h);
    }, []);
    return (
      <div className="tagpicker" ref={ref}>
        <button className="btn btn-sm btn-ghost" onClick={() => setOpen((o) => !o)}>
          <Icon name="plus" size={13} /> {placeholder}
        </button>
        {open && (
          <div className="tagpicker-menu panel">
            {options.map((o) => (
              <button key={o.id} className={"tagpicker-opt" + (selected.includes(o.id) ? " on" : "")} onClick={() => onToggle(o.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + o.color + ")" }} />
                <span className="grow">{o.label}</span>
                {selected.includes(o.id) && <Icon name="check" size={14} />}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  function Confirm({ title, body, confirmLabel = "Delete", onConfirm, onClose }) {
    return (
      <Modal narrow onClose={onClose}>
        <div className="modal-bd">
          <div className="card-hd" style={{ marginBottom: 6 }}>{title}</div>
          <p className="muted" style={{ margin: 0, fontSize: 14, lineHeight: 1.5 }}>{body}</p>
        </div>
        <div className="modal-ft">
          <button className="btn btn-ghost grow" onClick={onClose}>Cancel</button>
          <button className="btn btn-dark btn-danger" onClick={() => { onConfirm(); onClose(); }}>
            {confirmLabel}
          </button>
        </div>
      </Modal>
    );
  }

  return { Modal, Chip, Editable, TagPicker, Confirm };
})();

Object.assign(window, { Icon, UI });


// ======== kanban.jsx ========
/* ============================================================
   KANBAN BOARD + CARD DETAIL MODAL + FILTER BAR
   Exposes window.Kanban, window.CardModal
   ============================================================ */
const { useState: useK, useMemo: useKM } = React;

const COLUMNS = [
  { id: "backlog", title: "Backlog", color: "var(--hue-backlog)" },
  { id: "inprogress", title: "In Progress", color: "var(--hue-progress)" },
  { id: "done", title: "Done", color: "var(--hue-done)" },
];
const PRIO = { high: { c: "var(--t-red)", label: "High" }, med: { c: "var(--t-amber)", label: "Med" }, low: { c: "var(--t-green)", label: "Low" } };

function initials(name) {
  if (!name) return "?";
  return name.split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
}
function tagById(tags, id) { return tags.find((t) => t.id === id); }
function assigneesOf(t) { return Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []); }
// shared task filter: category + assignee ("__unassigned" token matches tasks with no one assigned)
function taskMatchesFilter(t, fCat, fWho) {
  if (fCat && fCat.length && !fCat.includes(t.category)) return false;
  if (fWho && fWho.length) {
    const who = assigneesOf(t);
    const ok = fWho.some((w) => (w === "__unassigned" ? who.length === 0 : who.includes(w)));
    if (!ok) return false;
  }
  return true;
}

/* resolve a dependency to a display descriptor */
function resolveDep(dep, tasks, products, self, externals) {
  if (dep.type === "task") {
    const t = tasks.find((x) => x.id === dep.refId);
    const blocked = t && t.status !== "done";
    // "Dependency block": this task starts before the task it needs output from finishes
    const violated = !!(blocked && self && self.start && t && t.end && new Date(self.start) < new Date(t.end));
    return { icon: "board", name: t ? t.title : "(removed task)", status: t?.status, blocked, violated, scope: "Task", external: false };
  }
  if (dep.type === "deliverable") {
    const p = products.find((x) => x.id === dep.refId);
    return { icon: "box", name: p ? p.name : "(removed deliverable)", scope: "Deliverable", external: false };
  }
  if (dep.type === "ext") {
    const e = (externals || []).find((x) => x.id === dep.refId);
    if (!e) return { icon: "inbound", name: "(removed external input)", scope: "External", external: true, extRef: true, blocked: false, violated: false };
    const blocked = e.status !== "received";
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const overdue = !!(blocked && e.due && new Date(e.due) < today);
    // dependency block: this task starts before the external input is expected and it isn't in yet
    const startsBefore = !!(blocked && self && self.start && e.due && new Date(self.start) < new Date(e.due));
    return { icon: "inbound", name: e.title || "External input", scope: e.party || "External party", external: true, extRef: true, blocked, violated: overdue || startsBefore, status: e.status, due: e.due, overdue };
  }
  return { icon: "link", name: dep.label || "External dependency", scope: dep.scope || "External", external: true };
}

/* Dependency editor inside the card modal */
function DepEditor({ task, tasks, products, externals, set }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const exts = externals || [];
  const deps = task.deps || [];
  const addDep = (d) => { set({ deps: [...deps, { id: Store.uid("d"), ...d }] }); setOpen(false); };
  const rmDep = (id) => set({ deps: deps.filter((x) => x.id !== id) });
  const patchDep = (id, c) => set({ deps: deps.map((x) => (x.id === id ? { ...x, ...c } : x)) });
  const otherTasks = tasks.filter((x) => x.id !== task.id && !deps.some((d) => d.type === "task" && d.refId === x.id));
  const freeExts = exts.filter((e) => !deps.some((d) => d.type === "ext" && d.refId === e.id));
  // create a brand-new external input in the register and depend on it
  const addNewExternal = () => {
    const id = Store.uid("ext");
    Store.add("externals", { id, title: "New external input", party: "", owner: "", due: "", status: "pending", note: "" });
    addDep({ type: "ext", refId: id });
  };
  // detect if adding a task as a dep would create a conflict (this task starts before that task ends)
  const wouldConflict = (otherId) => {
    const other = tasks.find((x) => x.id === otherId);
    if (!other || other.status === "done") return false;
    return task.start && other.end && new Date(task.start) < new Date(other.end);
  };
  const freeProducts = products.filter((p) => !deps.some((d) => d.type === "deliverable" && d.refId === p.id));
  // dependencies (internal or external) that land too late — a "dependency block"
  const blockers = deps.map((d) => resolveDep(d, tasks, products, task, exts)).filter((r) => r.violated);

  return (
    <div>
      <div className="between" style={{ marginBottom: 8 }}>
        <div className="field-label" style={{ margin: 0 }}>Depends on</div>
        <div className="tagpicker" ref={ref}>
          <button className="btn btn-sm btn-ghost" onClick={() => setOpen((o) => !o)}><Icon name="plus" size={13} /> Add</button>
          {open && (
            <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 240 }}>
              <div className="dep-menu-label">Within this project · tasks</div>
              {otherTasks.length === 0 && <div className="dep-menu-empty">No other tasks</div>}
              {otherTasks.map((t) => {
                const conflict = wouldConflict(t.id);
                return (
                  <button key={t.id} className="tagpicker-opt" onClick={() => {
                    if (conflict && !confirm(`“${task.title}” starts before “${t.title}” ends. Add this dependency anyway?`)) return;
                    addDep({ type: "task", refId: t.id });
                  }}>
                    <span className={"status-dot s-" + t.status} style={{ margin: 0 }} />
                    <span className="grow">{t.title}</span>
                    {conflict && <span className="dep-menu-warn" title="This task starts before that one ends">⚠</span>}
                  </button>
                );
              })}
              <div className="dep-menu-label">Outside the project</div>
              <button className="tagpicker-opt" onClick={() => addDep({ type: "external", label: "External dependency", scope: "" })}>
                <Icon name="link" size={14} /><span className="grow">External dependency…</span>
              </button>
            </div>
          )}
        </div>
      </div>
      {blockers.length > 0 && (
        <div className="dep-block-banner" title="Dependency block">
          <Icon name="warn" size={14} />
          <span><b>Dependency block</b> — needs {blockers.map((r) => r.name).join(", ")} first.</span>
        </div>
      )}
      {deps.length === 0 && <span className="muted" style={{ fontSize: 13 }}>No dependencies</span>}
      <div className="dep-list">
        {deps.map((d) => {
          const r = resolveDep(d, tasks, products, task, exts);
          return (
            <div key={d.id} className={"dep-item" + (r.external ? " ext" : "") + (r.blocked ? " blocked" : "") + (r.violated ? " violated" : "")}>
              <span className="dep-ico"><Icon name={r.icon} size={14} /></span>
              {d.type === "external" ? (
                <span className="grow" style={{ minWidth: 0 }}>
                  <UI.Editable className="dep-name" value={d.label} onChange={(v) => patchDep(d.id, { label: v || "External dependency" })} placeholder="What is needed?" />
                  <UI.Editable className="dep-scope mono" value={d.scope} onChange={(v) => patchDep(d.id, { scope: v })} placeholder="source / owner…" />
                </span>
              ) : d.type === "ext" ? (
                <span className="grow" style={{ minWidth: 0 }}>
                  <span className="dep-name">{r.name}</span>
                  <span className="dep-scope mono">{r.scope}{r.overdue ? " · overdue" : r.status === "received" ? " · received" : r.due ? " · due " + fmtD(r.due) : " · pending"}</span>
                </span>
              ) : (
                <span className="grow" style={{ minWidth: 0 }}>
                  <span className="dep-name">{r.name}</span>
                  <span className="dep-scope mono">{r.violated ? "needs output from this task first" : r.scope + (r.blocked ? " · blocking" : r.status === "done" ? " · cleared" : "")}</span>
                </span>
              )}
              {r.violated && <span className="dep-flag" style={{ color: "var(--t-red)" }} title="Logical conflict">⚠</span>}
              {r.blocked && !r.violated && <span className="dep-flag" title="Not yet done">●</span>}
              <button className="chip-x" onClick={() => rmDep(d.id)}><Icon name="x" size={12} /></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* Link a task to the risks it remediates */
function RiskLinker({ task, risks }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const linked = risks.filter((r) => (r.taskIds || []).includes(task.id));
  const toggle = (risk) => {
    const cur = risk.taskIds || [];
    Store.patch("risks", risk.id, { taskIds: cur.includes(task.id) ? cur.filter((x) => x !== task.id) : [...cur, task.id] });
  };
  return (
    <div>
      <div className="between" style={{ marginBottom: 8 }}>
        <div className="field-label" style={{ margin: 0 }}>Remediates risk</div>
        <div className="tagpicker" ref={ref}>
          <button className="btn btn-sm btn-ghost" onClick={() => setOpen((o) => !o)}><Icon name="shield" size={13} /> Link</button>
          {open && (
            <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 240 }}>
              {risks.length === 0 && <div className="dep-menu-empty">No risks in this project</div>}
              {risks.map((r) => (
                <button key={r.id} className={"tagpicker-opt" + ((r.taskIds || []).includes(task.id) ? " on" : "")} onClick={() => toggle(r)}>
                  <span className="risk-score sm" style={{ width: 20, height: 20, fontSize: 11, background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
                  <span className="grow">{r.title}</span>
                  {(r.taskIds || []).includes(task.id) && <Icon name="check" size={14} />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      {linked.length === 0 && <span className="muted" style={{ fontSize: 13 }}>Not linked to a risk</span>}
      <div className="dep-list">
        {linked.map((r) => (
          <div key={r.id} className="dep-item risk">
            <span className="dep-ico" style={{ color: scoreColor(r.likelihood, r.impact) }}><Icon name="shield" size={14} /></span>
            <span className="grow" style={{ minWidth: 0 }}>
              <span className="dep-name">{r.title}</span>
              <span className="dep-scope mono">{task.status === "done" ? "this action complete" : "remediation in progress"}</span>
            </span>
            <button className="chip-x" onClick={() => Store.patch("risks", r.id, { taskIds: (r.taskIds || []).filter((x) => x !== task.id) })}><Icon name="x" size={12} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* Multiple assignees — chips + add-by-name with suggestions */
function AssigneePicker({ value, onChange }) {
  const s = Store.getState();
  const [text, setText] = useK("");
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const members = s.members || [];
  const known = [...new Set([
    ...members.map((m) => m.name),
    ...(s.tasks || []).flatMap((t) => assigneesOf(t)),
  ])].filter(Boolean);
  const add = (n) => {
    const name = (n || "").trim();
    if (name && !value.includes(name)) {
      onChange([...value, name]);
      // keep the canonical member list complete
      if (!members.some((m) => m.name.toLowerCase() === name.toLowerCase())) {
        const colors = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
        Store.add("members", { id: Store.uid("mem"), name, role: "", email: "", color: colors[members.length % colors.length] });
      }
    }
    setText(""); setOpen(false);
  };
  const remove = (n) => onChange(value.filter((x) => x !== n));
  const suggestions = known.filter((n) => !value.includes(n) && n.toLowerCase().includes(text.toLowerCase()));

  return (
    <div className="assignee-wrap" ref={ref}>
      <div className="assignee-chips">
        {value.length === 0 && <span className="muted" style={{ fontSize: 13 }}>No one assigned</span>}
        {value.map((n) => (
          <span key={n} className="assignee-chip"><span className="avatar" style={{ width: 18, height: 18, fontSize: 8 }}>{initials(n)}</span>{n}
            <span className="chip-x" onClick={() => remove(n)}><Icon name="x" size={11} /></span>
          </span>
        ))}
      </div>
      <div className="assignee-add">
        <input className="input" style={{ padding: "6px 9px", fontSize: 13 }} value={text} placeholder="Add a person…"
          onFocus={() => setOpen(true)} onChange={(e) => { setText(e.target.value); setOpen(true); }}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); add(text); } }} />
        {open && (text || suggestions.length > 0) && (
          <div className="tagpicker-menu panel" style={{ minWidth: "100%" }}>
            {text.trim() && !known.some((n) => n.toLowerCase() === text.trim().toLowerCase()) && (
              <button className="tagpicker-opt" onClick={() => add(text)}><Icon name="plus" size={13} /><span className="grow">Add “{text.trim()}”</span></button>
            )}
            {suggestions.slice(0, 6).map((n) => (
              <button key={n} className="tagpicker-opt" onClick={() => add(n)}>
                <span className="avatar" style={{ width: 18, height: 18, fontSize: 8 }}>{initials(n)}</span><span className="grow">{n}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* inline smart prompt — asks whether two near-adjacent actions are sequential or parallel */
function SuggestionPrompt({ task }) {
  const s = Store.useStore();
  const mine = Store.smartSuggestions(s).filter((sg) => sg.bId === task.id || sg.aId === task.id).slice(0, 2);
  if (!mine.length) return null;
  return (
    <div className="cm-section">
      {mine.map((sg) => {
        const follows = sg.bId === task.id; // this task starts after the other
        return (
          <div className="sg-prompt" key={sg.id}>
            <span className="sg-q-ico"><Icon name="idea" size={15} /></span>
            <div className="sg-q-main">
              <div className="sg-q-text">
                {follows
                  ? <React.Fragment>This starts right after <b>{sg.a}</b> finishes. Is it waiting on it, or can they run in parallel?</React.Fragment>
                  : <React.Fragment><b>{sg.b}</b> starts right after this finishes. Does it wait on this, or run in parallel?</React.Fragment>}
              </div>
              <div className="sg-q-actions">
                <button className="btn btn-sm btn-primary" onClick={() => Store.linkTasks(sg.bId, sg.aId)}><Icon name="link" size={12} /> Sequential — link them</button>
                <button className="btn btn-sm btn-ghost" onClick={() => Store.dismissSuggestion(sg.id, "parallel")}>They run in parallel</button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------- Card detail modal ---------------- */
function CardModal({ task, onClose }) {
  const { tags, phases, categories, products, risks, tasks, customFields, members, externals } = Store.useStore();
  const t = Store.getState().tasks.find((x) => x.id === task.id) || task;
  const set = (changes) => Store.patch("tasks", t.id, changes);
  const [impacts, setImpacts] = useK([]);
  // impact-aware setter: applies the change, then computes what else it affects
  // and offers those as one-click suggestions (never applied automatically)
  const setAware = (changes) => {
    const prev = { prevEnd: t.end, prevStatus: t.status };
    set(changes);
    setTimeout(() => setImpacts(Store.impactOf(t.id, { ...changes, ...prev })), 30);
  };
  const toggleArr = (key, id) => {
    const cur = t[key] || [];
    set({ [key]: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id] });
  };
  const linked = products.filter((p) => (p.taskIds || []).includes(t.id));
  const parent = t.parentId ? tasks.find((x) => x.id === t.parentId) : null;
  const subs = tasks.filter((x) => x.parentId === t.id);
  const [subOpen, setSubOpen] = useK(null);
  const addSubtask = () => {
    const id = Store.uid("t");
    // inherit the shape of the parent so a subtask starts pre-filled
    Store.add("tasks", { id, title: "New subtask", status: "backlog", parentId: t.id,
      tags: [...(t.tags || [])], priority: t.priority || "med", assignees: [...assigneesOf(t)],
      desc: "", phase: t.phase || null, category: t.category || null, origin: t.origin || null,
      start: "", end: "", deps: [], comments: [], custom: {} });
    setSubOpen({ id });
  };
  const subDone = subs.filter((x) => x.status === "done").length;

  return (
    <UI.Modal onClose={onClose} wide>
      <div className="modal-hd">
        <UI.Editable className="cm-title" tag="div" value={t.title} multiline
          onChange={(v) => set({ title: v || "Untitled task" })} placeholder="Task title" />
        <button className="btn btn-icon btn-ghost no-print" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        {parent && (
          <button className="cm-parent-banner" onClick={() => setSubOpen(parent)} title="Open parent task">
            <Icon name="layers" size={13} /> Subtask of <b>{parent.title}</b> <Icon name="arrowR" size={12} />
          </button>
        )}
        {impacts.length > 0 && (
          <div className="cm-impact no-print">
            <div className="cm-impact-hd"><Icon name="idea" size={14} /> This change affects other parts of the plan</div>
            {impacts.map((im, i) => (
              <div key={i} className={"cm-impact-row" + (im.warn ? " warn" : "")}>
                <span className="grow">{im.text}</span>
                {im.apply && <button className="btn btn-sm btn-primary" onClick={() => { im.apply(); setImpacts((arr) => arr.filter((_, j) => j !== i)); }}>{im.action}</button>}
                <button className="btn btn-sm btn-ghost" onClick={() => setImpacts((arr) => arr.filter((_, j) => j !== i))}>{im.apply ? "Ignore" : "OK"}</button>
              </div>
            ))}
          </div>
        )}
        <div className="cm-grid">
          <div>
            <div className="cm-section">
              <div className="field-label">Description</div>
              <UI.Editable className="input" tag="div" value={t.desc} multiline
                style={{ minHeight: 90, lineHeight: 1.55 }}
                onChange={(v) => set({ desc: v })} placeholder="Add a description…" />
            </div>
            <SuggestionPrompt task={t} />
            <div className="cm-section">
              <div className="between" style={{ marginBottom: 8 }}>
                <div className="field-label" style={{ margin: 0 }}>Subtasks {subs.length > 0 && <span className="sub-count">{subDone}/{subs.length}</span>}</div>
                <button className="btn btn-sm btn-ghost" onClick={addSubtask}><Icon name="plus" size={13} /> Add subtask</button>
              </div>
              {subs.length === 0 && <span className="muted" style={{ fontSize: 13 }}>Break this action into smaller subtasks. They inherit this task's category, phase, owners and priority.</span>}
              {subs.length > 0 && (
                <div className="sub-list">
                  {subs.map((st) => (
                    <div key={st.id} className="sub-row">
                      <button className={"sub-check s-" + st.status} title={st.status === "done" ? "Mark not done" : "Mark done"} onClick={() => Store.patch("tasks", st.id, { status: st.status === "done" ? "backlog" : "done" })}>{st.status === "done" ? <Icon name="check" size={12} /> : null}</button>
                      <button className="sub-title" onClick={() => setSubOpen(st)}>{st.title}</button>
                      {assigneesOf(st).length > 0 && <span className="sub-who">{initials(assigneesOf(st)[0])}</span>}
                      {st.end && <span className="sub-date mono">{fmtD(st.end)}</span>}
                      <button className="sub-del" title="Delete subtask" onClick={() => Store.removeTask(st.id)}><Icon name="x" size={12} /></button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="cm-section">
              <div className="between" style={{ marginBottom: 8 }}>
                <div className="field-label" style={{ margin: 0 }}>Tags</div>
                <UI.TagPicker options={tags} selected={t.tags || []} onToggle={(id) => toggleArr("tags", id)} placeholder="Tag" />
              </div>
              <div className="wrap">
                {(t.tags || []).length === 0 && <span className="muted" style={{ fontSize: 13 }}>No tags yet</span>}
                {(t.tags || []).map((id) => {
                  const tg = tagById(tags, id); if (!tg) return null;
                  return <UI.Chip key={id} label={tg.label} color={tg.color} dot onRemove={() => toggleArr("tags", id)} />;
                })}
              </div>
            </div>
            <div className="cm-section">
              <DepEditor task={t} tasks={tasks} products={products} externals={externals} set={set} />
            </div>
            <div className="cm-section">
              <RiskLinker task={t} risks={risks} />
            </div>
            {linked.length > 0 && (
              <div className="cm-section">
                <div className="field-label">Linked deliverables</div>
                {linked.map((p) => (
                  <div className="linked-prod" key={p.id}>
                    <Icon name={p.type === "excel" ? "sheet" : p.type === "image" ? "image" : p.type === "slides" ? "slides" : "doc"} size={15} />
                    <span className="grow">{p.name}</span>
                    <Icon name="link" size={13} />
                  </div>
                ))}
              </div>
            )}
            <div className="cm-section">
              <TaskComments task={t} members={members || []} projectId={Store.getState().id} />
            </div>
          </div>

          <div className="cm-side">
            <div className="cm-side-block">
              <div className="field-label">Status</div>
              <div className="statusseg">
                {COLUMNS.map((c) => (
                  <button key={c.id} className={t.status === c.id ? "on" : ""} onClick={() => setAware({ status: c.id })}>{c.title}</button>
                ))}
              </div>
            </div>
            <div className="cm-side-block">
              <div className="field-label">Priority</div>
              <div className="statusseg prioseg">
                {Object.entries(PRIO).map(([k, v]) => (
                  <button key={k} className={t.priority === k ? "on" : ""} style={{ "--prio-c": v.c }} onClick={() => set({ priority: k })}>{v.label}</button>
                ))}
              </div>
            </div>
            <div className="cm-side-block">
              <div className="field-label">Assignees</div>
              <AssigneePicker value={assigneesOf(t)} onChange={(v) => set({ assignees: v, assignee: undefined })} />
            </div>
            <div className="cm-side-block">
              <div className="field-label">Details</div>
              <div className="meta-row">
                <span className="meta-k">Phase</span>
                <PickInline options={phases} value={t.phase} onChange={(v) => set({ phase: v })} />
              </div>
              <div className="meta-row">
                <span className="meta-k">Category</span>
                <PickInline options={categories} value={t.category} onChange={(v) => set({ category: v })} />
              </div>
              <div className="meta-row">
                <span className="meta-k">Start</span>
                <input className="datemini" type="date" value={t.start || ""} onChange={(e) => set({ start: e.target.value })} />
              </div>
              <div className="meta-row">
                <span className="meta-k">End</span>
                <input className="datemini" type="date" value={t.end || ""} onChange={(e) => setAware({ end: e.target.value })} />
              </div>
            </div>
            {(customFields || []).length > 0 && (
              <div className="cm-side-block">
                <div className="field-label">Custom fields</div>
                <CustomFieldInputs fields={customFields} values={t.custom || {}}
                  onChange={(fid, v) => set({ custom: { ...(t.custom || {}), [fid]: v } })} />
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="modal-ft no-print">
        <button className="btn btn-ghost btn-danger" onClick={() => { Store.removeTask(t.id); onClose(); }}>
          <Icon name="trash" size={15} /> Delete{subs.length > 0 ? ` (+${subs.length} subtask${subs.length === 1 ? "" : "s"})` : ""}
        </button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
      {subOpen && <CardModal task={subOpen} onClose={() => setSubOpen(null)} />}
    </UI.Modal>
  );
}

// task discussion — anyone on the team can comment; count shows on cards everywhere
function TaskComments({ task, members, projectId }) {
  const key = "atlas.commentAs." + (projectId || "");
  const memberNames = (members || []).map((m) => m.name);
  const [author, setAuthor] = useK(() => localStorage.getItem(key) || localStorage.getItem("atlas.view." + projectId) || (memberNames.includes("You") ? "You" : (memberNames[0] || "You")));
  const [text, setText] = useK("");
  const comments = task.comments || [];
  const authors = [...new Set(["You", ...memberNames])];
  const colorOf = (name) => (members.find((m) => m.name === name) || {}).color || "indigo";
  const post = () => {
    const body = text.trim(); if (!body) return;
    const c = { id: Store.uid("cmt"), author, color: colorOf(author), text: body, ts: Date.now() };
    Store.patch("tasks", task.id, { comments: [...comments, c] });
    setText(""); localStorage.setItem(key, author);
  };
  const del = (id) => Store.patch("tasks", task.id, { comments: comments.filter((c) => c.id !== id) });
  const when = (ts) => new Date(ts).toLocaleDateString("en-GB", { day: "numeric", month: "short" }) + " · " + new Date(ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  return (
    <div>
      <div className="field-label">Discussion {comments.length > 0 && <span className="cmt-count">{comments.length}</span>}</div>
      <div className="cmt-thread">
        {comments.length === 0 && <div className="cmt-empty">No comments yet. Start the conversation — anyone on the team can chime in.</div>}
        {comments.map((c) => (
          <div className="cmt" key={c.id}>
            <span className="avatar cmt-av" style={{ background: "var(--t-" + (c.color || "indigo") + ")" }}>{initials(c.author)}</span>
            <div className="cmt-main">
              <div className="cmt-head"><span className="cmt-author">{c.author}</span><span className="cmt-when mono">{when(c.ts)}</span>
                <button className="cmt-del no-print" title="Delete comment" onClick={() => del(c.id)}><Icon name="x" size={11} /></button>
              </div>
              <div className="cmt-text">{c.text}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="cmt-compose no-print">
        <span className="avatar cmt-av" style={{ background: "var(--t-" + colorOf(author) + ")" }}>{initials(author)}</span>
        <div className="cmt-compose-main">
          <textarea className="cmt-input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Write a comment…"
            onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") post(); }} rows={2} />
          <div className="cmt-compose-row">
            <label className="cmt-as">as
              <select value={author} onChange={(e) => setAuthor(e.target.value)}>
                {authors.map((a) => <option key={a} value={a}>{a}</option>)}
              </select>
            </label>
            <div className="grow" />
            <button className="btn btn-sm btn-primary" onClick={post} disabled={!text.trim()}><Icon name="send" size={13} /> Post</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// custom-field inputs (project-defined fields, shown in the task modal)
function CustomFieldInputs({ fields, values, onChange }) {
  return (
    <div className="cf-inputs">
      {fields.map((f) => {
        const v = values[f.id];
        return (
          <div className="cf-row" key={f.id}>
            <span className="cf-label">{f.label}</span>
            {f.type === "select" ? (
              <select className="cf-input" value={v || ""} onChange={(e) => onChange(f.id, e.target.value)}>
                <option value="">—</option>
                {(f.options || []).map((o, i) => <option key={i} value={o}>{o}</option>)}
              </select>
            ) : f.type === "checkbox" ? (
              <label className="cf-check"><input type="checkbox" checked={!!v} onChange={(e) => onChange(f.id, e.target.checked)} /> {v ? "Yes" : "No"}</label>
            ) : f.type === "date" ? (
              <input className="cf-input datemini" type="date" value={v || ""} onChange={(e) => onChange(f.id, e.target.value)} />
            ) : f.type === "number" ? (
              <input className="cf-input" type="number" value={v == null ? "" : v} onChange={(e) => onChange(f.id, e.target.value === "" ? "" : Number(e.target.value))} placeholder="—" />
            ) : (
              <input className="cf-input" type="text" value={v || ""} onChange={(e) => onChange(f.id, e.target.value)} placeholder="—" />
            )}
          </div>
        );
      })}
    </div>
  );
}

// inline color-coded picker (phase/category)
function PickInline({ options, value, onChange }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const cur = options.find((o) => o.id === value);
  return (
    <div className="tagpicker" ref={ref}>
      <button className="pick-trigger" onClick={() => setOpen((o) => !o)}>
        {cur ? <UI.Chip label={cur.label} color={cur.color} dot /> : <span className="muted">Set…</span>}
      </button>
      {open && (
        <div className="tagpicker-menu panel" style={{ minWidth: 180 }}>
          <button className="tagpicker-opt" onClick={() => { onChange(null); setOpen(false); }}>
            <span className="chip-dot" style={{ background: "var(--ink-ghost)" }} /><span className="grow">None</span>
          </button>
          {options.map((o) => (
            <button key={o.id} className={"tagpicker-opt" + (value === o.id ? " on" : "")} onClick={() => { onChange(o.id); setOpen(false); }}>
              <span className="chip-dot" style={{ background: "var(--t-" + o.color + ")" }} />
              <span className="grow">{o.label}</span>
              {value === o.id && <Icon name="check" size={14} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* comment-count badge shown on cards & rows everywhere */
function CommentBadge({ task, className }) {
  const n = (task.comments || []).length;
  if (!n) return null;
  return <span className={"cmt-badge " + (className || "")} title={n + " comment" + (n === 1 ? "" : "s")}><Icon name="chat" size={11} /> {n}</span>;
}

/* ---------------- Kanban card ---------------- */
function KCard({ task, tags, onOpen, onDragStart, onDragEnd, dragging }) {
  const cardTags = (task.tags || []).map((id) => tagById(tags, id)).filter(Boolean);
  const all = Store.getState().tasks;
  const parent = task.parentId ? all.find((x) => x.id === task.parentId) : null;
  const kids = all.filter((x) => x.parentId === task.id);
  return (
    <div
      className={"kcard" + (dragging ? " dragging" : "") + (parent ? " kcard-sub" : "")}
      style={{ "--prio": PRIO[task.priority]?.c || "var(--line-strong)" }}
      draggable
      onDragStart={(e) => onDragStart(e, task)}
      onDragEnd={onDragEnd}
      onDoubleClick={() => onOpen(task)}
      title="Double-click to open"
    >
      {parent && <div className="kcard-parent" title={"Subtask of " + parent.title}><Icon name="layers" size={10} /> {parent.title}</div>}
      <div className="kcard-title">{task.title}</div>
      {cardTags.length > 0 && (
        <div className="kcard-tags">
          {cardTags.map((tg) => <UI.Chip key={tg.id} label={tg.label} color={tg.color} dot />)}
        </div>
      )}
      <div className="kcard-foot">
        {(() => {
          const who = assigneesOf(task);
          if (!who.length) return <span className="muted" style={{ fontSize: 12 }}>Unassigned</span>;
          return (<>
            <span className="avatar-stack">{who.slice(0, 3).map((n, i) => <span key={i} className="avatar" title={n}>{initials(n)}</span>)}</span>
            <span className="muted" style={{ fontSize: 12, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{who.length === 1 ? who[0] : who.length + " people"}</span>
          </>);
        })()}
        <span className="prio-tick" style={{ color: PRIO[task.priority]?.c }}>{PRIO[task.priority]?.label}</span>
      </div>
      {kids.length > 0 && (
        <div className="kcard-subs">
          <div className="kcard-subs-hd"><Icon name="layers" size={10} /> {kids.filter((k) => k.status === "done").length}/{kids.length} subtasks</div>
          {kids.map((k) => (
            <div key={k.id} className="kcard-sub-row" onClick={(e) => { e.stopPropagation(); onOpen(k); }} title={k.title}>
              <button className={"sub-check s-" + k.status} title={k.status === "done" ? "Mark not done" : "Mark done"} onClick={(e) => { e.stopPropagation(); Store.patch("tasks", k.id, { status: k.status === "done" ? "backlog" : "done" }); }}>{k.status === "done" ? <Icon name="check" size={10} /> : null}</button>
              <span className={"kcard-sub-name" + (k.status === "done" ? " done" : "")}>{k.title}</span>
              {assigneesOf(k).length > 0 && <span className="kcard-sub-who" title={assigneesOf(k)[0]}>{initials(assigneesOf(k)[0])}</span>}
            </div>
          ))}
        </div>
      )}
      {(task.comments || []).length > 0 && <div className="kcard-cmtrow"><CommentBadge task={task} /></div>}
    </div>
  );
}

/* ---------------- Board ---------------- */
function Kanban() {
  const s = Store.useStore();
  const { tasks, tags, phases, categories, members } = s;
  const [open, setOpen] = useK(null);
  const [drag, setDrag] = useK(null);
  const [over, setOver] = useK(null);
  const [q, setQ] = useK("");
  const [fTags, setFTags] = useK([]);
  const [fPhase, setFPhase] = useK([]);
  const [fCat, setFCat] = useK([]);
  const [fWho, setFWho] = useK([]);

  const filtered = useKM(() => {
    return tasks.filter((t) => {
      if (q && !(t.title + " " + (t.desc || "") + " " + assigneesOf(t).join(" ")).toLowerCase().includes(q.toLowerCase())) return false;
      if (fTags.length && !fTags.every((id) => (t.tags || []).includes(id))) return false;
      if (fPhase.length && !fPhase.includes(t.phase)) return false;
      if (fCat.length && !fCat.includes(t.category)) return false;
      if (fWho.length) {
        const who = assigneesOf(t);
        if (!fWho.some((w) => (w === "__unassigned" ? who.length === 0 : who.includes(w)))) return false;
      }
      return true;
    });
  }, [tasks, q, fTags, fPhase, fCat, fWho]);

  const toggle = (arr, set, id) => set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  const anyFilter = q || fTags.length || fPhase.length || fCat.length || fWho.length;

  const onDrop = (status) => {
    if (drag) Store.patch("tasks", drag.id, { status });
    setDrag(null); setOver(null);
  };
  const addTask = (status) => {
    const id = Store.uid("t");
    Store.add("tasks", { id, title: "New task", status, tags: [], priority: "med", assignees: [], desc: "", phase: null, category: null, start: "", end: "", deps: [] });
    setOpen({ id });
  };

  return (
    <>
      <div className="filterbar no-print">
        <div className="search-box">
          <Icon name="search" size={15} />
          <input placeholder="Search tasks…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="filter-pills">
          {tags.map((tg) => (
            <button key={tg.id} className={"fpill" + (fTags.includes(tg.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + tg.color + ")" }} onClick={() => toggle(fTags, setFTags, tg.id)}>
              <span className="chip-dot" style={{ background: "var(--t-" + tg.color + ")" }} />{tg.label}
            </button>
          ))}
        </div>
        <div className="grow" />
        {anyFilter && (
          <button className="btn btn-sm btn-ghost" onClick={() => { setQ(""); setFTags([]); setFPhase([]); setFCat([]); setFWho([]); }}>
            <Icon name="x" size={13} /> Clear
          </button>
        )}
        <FilterMenu phases={phases} categories={categories} members={members} fPhase={fPhase} setFPhase={setFPhase} fCat={fCat} setFCat={setFCat} fWho={fWho} setFWho={setFWho} />
      </div>

      <div className="view-scroll">
        <div className="kanban">
          {COLUMNS.map((col) => {
            const visibleIds = new Set(filtered.map((t) => t.id));
            const items = filtered.filter((t) => t.status === col.id && !(t.parentId && visibleIds.has(t.parentId)));
            return (
              <div
                key={col.id}
                className={"kcol" + (over === col.id ? " drop" : "")}
                onDragOver={(e) => { e.preventDefault(); setOver(col.id); }}
                onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(null); }}
                onDrop={() => onDrop(col.id)}
              >
                <div className="kcol-hd">
                  <span className="kcol-dot" style={{ background: col.color }} />
                  <span className="kcol-title">{col.title}</span>
                  <span className="kcol-count">{items.length}</span>
                </div>
                <div className="kcol-body">
                  {items.map((t) => (
                    <KCard key={t.id} task={t} tags={tags} onOpen={setOpen}
                      dragging={drag?.id === t.id}
                      onDragStart={(e, task) => { setDrag(task); e.dataTransfer.effectAllowed = "move"; }}
                      onDragEnd={() => { setDrag(null); setOver(null); }} />
                  ))}
                  {items.length === 0 && over !== col.id && <div style={{ height: 4 }} />}
                  <button className="kadd" onClick={() => addTask(col.id)}>
                    <Icon name="plus" size={14} /> Add task
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
    </>
  );
}

function FilterMenu({ phases, categories, members, fPhase, setFPhase, fCat, setFCat, fWho, setFWho }) {
  const [open, setOpen] = useK(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const n = fPhase.length + fCat.length + (fWho ? fWho.length : 0);
  const toggle = (arr, set, id) => set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  return (
    <div className="tagpicker" ref={ref}>
      <button className={"btn btn-sm" + (n ? " btn-primary" : "")} onClick={() => setOpen((o) => !o)}>
        <Icon name="filter" size={14} /> Filter{n ? ` · ${n}` : ""}
      </button>
      {open && (
        <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 200, padding: 12 }}>
          <div className="field-label">Assigned to</div>
          <div className="wrap" style={{ marginBottom: 14 }}>
            {(members || []).map((m) => (
              <button key={m.id} className={"fpill" + (fWho.includes(m.name) ? " on" : "")} style={{ "--t-var": "var(--t-" + (m.color || "indigo") + ")" }} onClick={() => toggle(fWho, setFWho, m.name)}>
                <span className="chip-dot" style={{ background: "var(--t-" + (m.color || "indigo") + ")" }} />{m.name}
              </button>
            ))}
            <button className={"fpill" + (fWho.includes("__unassigned") ? " on" : "")} onClick={() => toggle(fWho, setFWho, "__unassigned")}>
              <span className="chip-dot" style={{ background: "var(--ink-ghost)" }} />Unassigned
            </button>
            {(members || []).length === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No members yet</span>}
          </div>
          <div className="field-label">Phase</div>
          <div className="wrap" style={{ marginBottom: 14 }}>
            {phases.map((p) => (
              <button key={p.id} className={"fpill" + (fPhase.includes(p.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + p.color + ")" }} onClick={() => toggle(fPhase, setFPhase, p.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + p.color + ")" }} />{p.label}
              </button>
            ))}
          </div>
          <div className="field-label">Category</div>
          <div className="wrap">
            {categories.map((c) => (
              <button key={c.id} className={"fpill" + (fCat.includes(c.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + c.color + ")" }} onClick={() => toggle(fCat, setFCat, c.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Kanban, CardModal, PickInline, COLUMNS, PRIO, initials, tagById, resolveDep, assigneesOf, taskMatchesFilter });


// ======== actions.jsx ========
/* ============================================================
   ACTION LIST + DRAG/DROP TIMELINE
   Grouped by CATEGORY · milestones & gates
   Exposes window.Actions
   ============================================================ */
const { useState: useA, useRef: useAR, useMemo: useAM } = React;

const DAY = 86400000;
const fmtD = (s) => { if (!s) return "—"; const d = new Date(s); return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" }); };
const toISO = (d) => d.toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / DAY);

function Actions() {
  const { categories, members } = Store.useStore();
  const [mode, setMode] = useA(localStorage.getItem("atlas.actions.mode") || "list");
  const [sort, setSort] = useA(localStorage.getItem("atlas.actions.sort") || "category");
  const [showTax, setShowTax] = useA(false);
  const [fCat, setFCat] = useA([]);
  const [fWho, setFWho] = useA([]);
  const setM = (m) => { setMode(m); localStorage.setItem("atlas.actions.mode", m); };
  const setS = (s) => { setSort(s); localStorage.setItem("atlas.actions.sort", s); };
  return (
    <>
      <div className="filterbar no-print" style={{ justifyContent: "space-between" }}>
        <div className="row" style={{ gap: 10 }}>
          <div className="seg-toggle">
            <button className={mode === "list" ? "on" : ""} onClick={() => setM("list")}><Icon name="list" size={15} /> Action list</button>
            <button className={mode === "board" ? "on" : ""} onClick={() => setM("board")}><Icon name="board" size={15} /> Kanban</button>
            <button className={mode === "timeline" ? "on" : ""} onClick={() => setM("timeline")}><Icon name="timeline" size={15} /> Timeline</button>
            <button className={mode === "calendar" ? "on" : ""} onClick={() => setM("calendar")}><Icon name="calendar" size={15} /> Calendar</button>
          </div>
        </div>
        <div className="row" style={{ gap: 8 }}>
          <ActionsFilter categories={categories} members={members} fCat={fCat} setFCat={setFCat} fWho={fWho} setFWho={setFWho} />
          <button className="btn btn-sm" onClick={() => setShowTax(true)} title="Edit categories, tags & phases"><Icon name="tag" size={14} /> Edit categories</button>
          {mode !== "calendar" && mode !== "board" && (
          <label className="sortby" title="Choose how actions are organised">
            <Icon name="sort" size={14} />
            <span className="sortby-label">Sort by</span>
            <select value={sort} onChange={(e) => setS(e.target.value)}>
              <option value="category">Category</option>
              <option value="sequence">Sequence (date &amp; dependencies)</option>
            </select>
            <Icon name="chevD" size={13} />
          </label>
          )}
        </div>
      </div>
      <div className="view-scroll">
        {mode === "list" ? <ActionList sort={sort} fCat={fCat} fWho={fWho} />
          : mode === "board" ? <Kanban embedded />
          : mode === "calendar" ? <CalendarView fCat={fCat} fWho={fWho} />
          : <Timeline sort={sort} fCat={fCat} fWho={fWho} />}
      </div>
      {showTax && <TaxonomyEditor onClose={() => setShowTax(false)} />}
    </>
  );
}

/* Filter by assigned-to + category (shared by the list & timeline views) */
function ActionsFilter({ categories, members, fCat, setFCat, fWho, setFWho }) {
  const [open, setOpen] = useA(false);
  const ref = useAR(null);
  React.useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const n = fCat.length + fWho.length;
  const toggle = (arr, set, id) => set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]);
  return (
    <div className="tagpicker" ref={ref}>
      <button className={"btn btn-sm" + (n ? " btn-primary" : "")} onClick={() => setOpen((o) => !o)}>
        <Icon name="filter" size={14} /> Filter{n ? ` · ${n}` : ""}
      </button>
      {open && (
        <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 210, padding: 12 }}>
          <div className="between" style={{ marginBottom: 8 }}>
            <div className="field-label" style={{ margin: 0 }}>Assigned to</div>
            {n > 0 && <button className="btn btn-sm btn-ghost" style={{ padding: "1px 6px" }} onClick={() => { setFCat([]); setFWho([]); }}>Clear</button>}
          </div>
          <div className="wrap" style={{ marginBottom: 14 }}>
            {(members || []).map((m) => (
              <button key={m.id} className={"fpill" + (fWho.includes(m.name) ? " on" : "")} style={{ "--t-var": "var(--t-" + (m.color || "indigo") + ")" }} onClick={() => toggle(fWho, setFWho, m.name)}>
                <span className="chip-dot" style={{ background: "var(--t-" + (m.color || "indigo") + ")" }} />{m.name}
              </button>
            ))}
            <button className={"fpill" + (fWho.includes("__unassigned") ? " on" : "")} onClick={() => toggle(fWho, setFWho, "__unassigned")}>
              <span className="chip-dot" style={{ background: "var(--ink-ghost)" }} />Unassigned
            </button>
            {(members || []).length === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No members yet</span>}
          </div>
          <div className="field-label">Category</div>
          <div className="wrap">
            {categories.map((c) => (
              <button key={c.id} className={"fpill" + (fCat.includes(c.id) ? " on" : "")} style={{ "--t-var": "var(--t-" + c.color + ")" }} onClick={() => toggle(fCat, setFCat, c.id)}>
                <span className="chip-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}
              </button>
            ))}
            {categories.length === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No categories yet</span>}
          </div>
        </div>
      )}
    </div>
  );
}

/* order tasks by start date, then by dependency (predecessors first), undated last */
function sequenceTasks(tasks) {
  const byId = Object.fromEntries(tasks.map((t) => [t.id, t]));
  const keyOf = (t) => {
    if (t.start) return new Date(t.start).getTime();
    // inherit from latest predecessor end if undated
    let best = Infinity;
    (t.deps || []).forEach((d) => { if (d.type === "task" && byId[d.refId] && byId[d.refId].end) best = Math.min(best, new Date(byId[d.refId].end).getTime() + 1); });
    return best;
  };
  return [...tasks].sort((a, b) => {
    const ka = keyOf(a), kb = keyOf(b);
    if (ka !== kb) return ka - kb;
    return (a.title || "").localeCompare(b.title || "");
  });
}

/* ============================================================
   ACTION LIST — grouped by category
   ============================================================ */
/* interleave gates among a category's actions, positioned by date
   (a gate sits after every action that ends on/before the gate's date) */
function interleaveGates(items, gates) {
  const rows = items.map((t, i) => ({ task: t, i }));
  if (!gates || !gates.length) return rows;
  const idxFor = (gt) => {
    if (!gt.date) return items.length;
    const gd = +new Date(gt.date);
    return items.filter((t) => t.end && +new Date(t.end) <= gd).length;
  };
  const gs = gates.map((gt) => ({ gate: gt, _i: Math.min(idxFor(gt), items.length) }))
    .sort((a, b) => a._i - b._i || new Date(a.gate.date || 0) - new Date(b.gate.date || 0));
  const out = []; let gi = 0;
  for (let i = 0; i <= items.length; i++) {
    while (gi < gs.length && gs[gi]._i === i) { out.push({ gate: gs[gi].gate }); gi++; }
    if (i < items.length) out.push(rows[i]);
  }
  return out;
}

/* a gate rendered inline between actions — a checkpoint the work above must clear */
function GateBar({ gate, onOpen }) {
  const { categories } = Store.useStore();
  const cat = categories.find((c) => c.id === gate.category);
  const overdue = gate.date && new Date(gate.date) < new Date();
  return (
    <div className="gate-bar" onClick={onOpen} title="Gate — everything above must pass before work below proceeds. Click to edit.">
      <span className="gate-bar-ico"><Icon name="gate" size={15} /></span>
      <span className="gate-bar-main">
        <span className="gate-bar-title">{gate.title}<span className="gate-bar-tag">GATE</span></span>
        <span className="gate-bar-sub">Checkpoint · everything above must pass before continuing</span>
      </span>
      {cat && <span className="gate-bar-cat" style={{ color: "var(--t-" + cat.color + ")", borderColor: "color-mix(in oklch, var(--t-" + cat.color + ") 40%, transparent)" }}><span className="chip-dot" style={{ background: "var(--t-" + cat.color + ")" }} />{cat.label}</span>}
      <span className={"gate-bar-date mono" + (overdue ? " over" : "")}>{gate.date ? fmtD(gate.date) : "no date"}</span>
    </div>
  );
}

function ActionList({ sort, fCat = [], fWho = [] }) {
  const { tasks, phases, categories, tags, milestones } = Store.useStore();
  const [open, setOpen] = useA(null);
  const [msEdit, setMsEdit] = useA(null);
  const [dragId, setDragId] = useA(null);
  const [overKey, setOverKey] = useA(null);
  const [delCat, setDelCat] = useA(null);
  const [delTask, setDelTask] = useA(null);
  const [openSubs, setOpenSubs] = useA(() => { try { return new Set(JSON.parse(localStorage.getItem("atlas.actions.opensubs") || "[]")); } catch (e) { return new Set(); } });
  const toggleSubs = (id) => setOpenSubs((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); try { localStorage.setItem("atlas.actions.opensubs", JSON.stringify([...n])); } catch (e) {} return n; });
  const removeCategory = (id) => {
    Store.update("categories", (arr) => arr.filter((x) => x.id !== id));
    Store.update("tasks", (arr) => arr.map((t) => t.category === id ? { ...t, category: null } : t));
    Store.update("milestones", (arr) => arr.map((m) => m.category === id ? { ...m, category: null } : m));
    Store.update("findings", (arr) => (arr || []).map((f) => f.category === id ? { ...f, category: null } : f));
    setDelCat(null);
  };
  const CKEY = "atlas.actions.expanded";
  const [expanded, setExpanded] = useA(() => { try { return new Set(JSON.parse(localStorage.getItem(CKEY) || "[]")); } catch (e) { return new Set(); } });
  const toggleCollapse = (key) => setExpanded((prev) => { const n = new Set(prev); n.has(key) ? n.delete(key) : n.add(key); try { localStorage.setItem(CKEY, JSON.stringify([...n])); } catch (e) {} return n; });
  // tasks that pass the assigned-to / category filter (dependency lookups still use the full list)
  const visible = useAM(() => tasks.filter((t) => taskMatchesFilter(t, fCat, fWho)), [tasks, fCat, fWho]);
  const filterActive = fCat.length > 0 || fWho.length > 0;

  const addCategory = () => {
    const colors = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
    const id = Store.uid("ct");
    Store.update("categories", (arr) => [...arr, { id, label: "New category", color: colors[arr.length % colors.length] }]);
  };
  // move a task into a bucket; beforeId = drop before that task, else append to bucket end
  const moveTask = (id, group, beforeId) => {
    Store.setState((st) => {
      const arr = [...st.tasks];
      const di = arr.findIndex((x) => x.id === id);
      if (di < 0) return st;
      const [dragged] = arr.splice(di, 1);
      const updated = { ...dragged, category: group.catId, origin: group.origin || null };
      if (beforeId && beforeId !== id) {
        const bi = arr.findIndex((x) => x.id === beforeId);
        arr.splice(bi < 0 ? arr.length : bi, 0, updated);
      } else {
        // append after the last task already in this bucket
        const inBucket = (x) => group.catId ? x.category === group.catId : group.origin ? x.origin === group.origin : (!x.category || !categories.find((c) => c.id === x.category)) && x.origin !== "comms" && x.origin !== "change";
        let lastIdx = -1;
        arr.forEach((x, i) => { if (inBucket(x)) lastIdx = i; });
        arr.splice(lastIdx + 1, 0, updated);
      }
      return { ...st, tasks: arr };
    });
  };

  const groups = useAM(() => {
    const inCat = (t) => t.category && categories.find((c) => c.id === t.category);
    // a task is top-level unless its parent is also visible (subtasks render under their parent)
    const isTop = (t) => !t.parentId || !visible.some((x) => x.id === t.parentId);
    const g = categories.map((c) => ({
      key: c.id, label: c.label, color: c.color, catId: c.id, origin: null,
      items: visible.filter((t) => t.category === c.id && isTop(t)),
      ms: milestones.filter((m) => m.category === c.id),
    }));
    const un = visible.filter((t) => !inCat(t) && isTop(t));
    const comms = un.filter((t) => t.origin === "comms");
    const change = un.filter((t) => t.origin === "change");
    const other = un.filter((t) => t.origin !== "comms" && t.origin !== "change");
    const unMs = milestones.filter((m) => !m.category || !categories.find((c) => c.id === m.category));
    if (other.length || unMs.length) g.push({ key: "_un", label: "Uncategorised", color: null, catId: null, origin: null, items: other, ms: unMs });
    // communications + change management sit together at the very bottom
    if (comms.length) g.push({ key: "_comms", label: "Communications", color: "teal", catId: null, origin: "comms", items: comms, ms: [] });
    if (change.length) g.push({ key: "_change", label: "Change management", color: "purple", catId: null, origin: "change", items: change, ms: [] });
    // when a filter is active, hide buckets that have nothing matching
    return filterActive ? g.filter((x) => x.items.length || x.ms.length) : g;
  }, [visible, categories, milestones, filterActive]);

  const addTo = (catId, origin) => {
    const id = Store.uid("t");
    Store.add("tasks", { id, title: "New action", status: "backlog", tags: [], priority: "med", assignees: [], desc: "", phase: null, category: catId, origin: origin || null, start: "", end: "", deps: [] });
    setOpen({ id });
  };
  // add a subtask inline from the list; inherits the parent's shape
  const addSubtask = (parent) => {
    const id = Store.uid("t");
    Store.add("tasks", { id, title: "New subtask", status: "backlog", parentId: parent.id,
      tags: [...(parent.tags || [])], priority: parent.priority || "med", assignees: [...assigneesOf(parent)],
      desc: "", phase: parent.phase || null, category: parent.category || null, origin: parent.origin || null,
      start: "", end: "", deps: [], comments: [], custom: {} });
    setOpen({ id });
  };
  const addMs = (catId) => {
    const id = Store.uid("ms");
    const cat = catId || (categories[0] && categories[0].id) || null;
    Store.add("milestones", { id, title: "New milestone", type: "milestone", date: toISO(new Date()), category: cat, note: "" });
    setMsEdit(id);
  };

  const ownerText = (t) => assigneesOf(t).length ? (assigneesOf(t).length === 1 ? assigneesOf(t)[0] : assigneesOf(t).length + " people") : "—";
  const subtasksOf = (id) => visible.filter((x) => x.parentId === id);

  /* ---- SEQUENCE VIEW: flat, ordered by date & dependencies ---- */
  if (sort === "sequence") {
    const ordered = sequenceTasks(visible);
    const blocked = (t) => (t.deps || []).some((d) => { if (d.type !== "task") return false; const p = tasks.find((x) => x.id === d.refId); return p && p.status !== "done" && t.start && p.end && new Date(t.start) < new Date(p.end); });
    return (
      <div className="view-pad view-wide">
        <div className="act-group">
          <div className="act-group-hd">
            <span className="kcol-dot" style={{ background: "var(--accent)" }} />
            <span className="act-group-title">In sequence</span>
            <span className="kcol-count">{ordered.length} actions · earliest first</span>
            <div className="grow" />
            <button className="btn btn-sm btn-ghost" onClick={() => addTo(null, null)}><Icon name="plus" size={13} /> Add</button>
          </div>
          <div className="act-table">
            <div className="act-head act-head-seq">
              <div>#</div><div>Action</div><div>Category</div><div>Depends on</div><div>Owner</div><div>Dates</div><div>Status</div>
            </div>
            {ordered.length === 0 && <div className="act-empty">No actions yet.</div>}
            {ordered.map((t, i) => {
              const cat = categories.find((c) => c.id === t.category);
              const deps = (t.deps || []).filter((d) => d.type === "task").map((d) => tasks.find((x) => x.id === d.refId)).filter(Boolean);
              const isBlocked = blocked(t);
              return (
                <div key={t.id} className={"act-row act-row-seq" + (isBlocked ? " act-row-blocked" : "")} title={isBlocked ? "Dependency block" : undefined} onClick={() => setOpen(t)}>
                  <div className="seq-num mono">{i + 1}</div>
                  <div className="act-cell-title">
                    <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                    {t.title}<CommentBadge task={t} />
                  </div>
                  <div>{cat ? <UI.Chip label={cat.label} color={cat.color} dot />: t.origin === "comms" ? <UI.Chip label="Communications" color="teal" dot /> : t.origin === "change" ? <UI.Chip label="Change mgmt" color="purple" dot /> : <span className="muted">—</span>}</div>
                  <div className="seq-deps">
                    {deps.length === 0 ? <span className="muted" style={{ fontSize: 12.5 }}>—</span>
                      : deps.map((p) => <span key={p.id} className={"seq-dep" + (p.status !== "done" ? " open" : "")} title={p.title}>{p.status !== "done" ? "⛔ " : "✓ "}{p.title}</span>)}
                  </div>
                  <div className="muted" style={{ fontSize: 13 }}>{ownerText(t)}</div>
                  <div className="muted mono" style={{ fontSize: 12 }}>{fmtD(t.start)} → {fmtD(t.end)}</div>
                  <div><span className={"status-dot s-" + t.status} />{COLUMNS.find((c) => c.id === t.status)?.title}</div>
                </div>
              );
            })}
          </div>
        </div>
        {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      </div>
    );
  }

  /* ---- CATEGORY VIEW ---- */
  return (
    <div className="view-pad view-wide">
      <div className="act-cat-toolbar no-print">
        <button className="btn btn-sm btn-primary" onClick={addCategory}><Icon name="plus" size={14} /> Add category</button>
        <span className="muted" style={{ fontSize: 12.5 }}>Drag actions between categories to re-bucket them · order top-to-bottom = sequence</span>
      </div>
      {/* tasks grouped by category, milestones pinned at top */}
      {groups.map((g) => { const gates = (g.ms || []).filter((m) => m.type === "gate"); const markers = (g.ms || []).filter((m) => m.type !== "gate"); const isCollapsed = !expanded.has(g.key); return (
        <div key={g.key} className={"act-group act-track" + (isCollapsed ? " collapsed" : "")}>
          <div className="act-group-hd act-track-hd" onClick={() => toggleCollapse(g.key)}>
            <button className="act-collapse no-print" title={isCollapsed ? "Expand" : "Collapse"}><Icon name="chevD" size={15} style={{ transform: isCollapsed ? "rotate(-90deg)" : "none" }} /></button>
            <span className="act-track-label">Track</span>
            <span className="kcol-dot" style={{ background: g.color ? "var(--t-" + g.color + ")" : "var(--ink-ghost)" }} />
            {g.catId
              ? <UI.Editable className="act-group-title act-cat-edit" value={g.label} onClick={(e) => e.stopPropagation()} onChange={(v) => Store.update("categories", (arr) => arr.map((c) => c.id === g.catId ? { ...c, label: v || "Untitled" } : c))} placeholder="Track" />
              : <span className="act-group-title">{g.label}</span>}
            <span className="act-count-badge">{g.items.length}</span>
            <span className="kcol-count">{g.ms.length ? g.ms.length + " marker" + (g.ms.length === 1 ? "" : "s") : ""}</span>
            <div className="grow" />
            {g.catId && <button className="btn btn-sm btn-ghost" onClick={(e) => { e.stopPropagation(); addMs(g.catId); }}><Icon name="flag" size={13} /> Gate / milestone</button>}
            <button className="btn btn-sm btn-ghost" onClick={(e) => { e.stopPropagation(); addTo(g.catId, g.origin); }}><Icon name="plus" size={13} /> Add</button>
            {g.catId && <button className="btn btn-icon btn-ghost act-track-del" title="Delete track" onClick={(e) => { e.stopPropagation(); setDelCat({ id: g.catId, label: g.label, count: g.items.length }); }}><Icon name="trash" size={14} /></button>}
          </div>
          {!isCollapsed && <React.Fragment>
          {/* milestones pinned at top; gates render inline between actions below */}
          {markers.length > 0 && (
            <div className="ms-pinned">
              {markers.map((ms) => (
                <div key={ms.id} className={"ms-pin " + ms.type} onClick={() => setMsEdit(ms.id)}>
                  <span className="ms-mile-icon">◆</span>
                  <span className="ms-pin-title">{ms.title}</span>
                  <span className="ms-type-chip milestone">Milestone</span>
                  <span className="muted mono" style={{ fontSize: 11 }}>{fmtD(ms.date)}</span>
                </div>
              ))}
            </div>
          )}
          <div className={"act-table" + (overKey === g.key ? " act-table-over" : "")}
            onDragOver={(e) => { if (dragId) { e.preventDefault(); setOverKey(g.key); } }}
            onDragLeave={(e) => { if (e.currentTarget === e.target) setOverKey(null); }}
            onDrop={(e) => { if (dragId) { e.preventDefault(); moveTask(dragId, g, null); } setDragId(null); setOverKey(null); }}>
            <div className="act-head act-head-drag">
              <div></div><div>Task</div><div>Tags</div><div>Owner</div><div>Dates</div><div>Status</div>
            </div>
            {g.items.length === 0 && <div className="act-empty">{dragId ? "Drop here to add to this category" : "No actions in this category yet."}</div>}
            {interleaveGates(g.items, gates).map((row) => {
              if (row.gate) return <GateBar key={row.gate.id} gate={row.gate} onOpen={() => setMsEdit(row.gate.id)} />;
              const t = row.task; const i = row.i;
              const kids = subtasksOf(t.id);
              return (
                <React.Fragment key={t.id}>
                <div className={"act-row act-row-drag" + (dragId === t.id ? " act-row-dragging" : "")}
                  draggable
                  onDragStart={(e) => { setDragId(t.id); e.dataTransfer.effectAllowed = "move"; }}
                  onDragEnd={() => { setDragId(null); setOverKey(null); }}
                  onDragOver={(e) => { if (dragId && dragId !== t.id) e.preventDefault(); }}
                  onDrop={(e) => { if (dragId) { e.preventDefault(); e.stopPropagation(); moveTask(dragId, g, t.id); } setDragId(null); setOverKey(null); }}
                  onClick={() => setOpen(t)}>
                  <div className="act-drag-cell"><span className="act-seq-n">{i + 1}</span><span className="act-grip"><Icon name="drag" size={14} /></span></div>
                  <div className="act-cell-title">
                    <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                    {t.title}<CommentBadge task={t} />
                    {kids.length > 0 && <button className="sub-toggle no-print" title={(openSubs.has(t.id) ? "Hide" : "Show") + " " + kids.length + " subtask" + (kids.length === 1 ? "" : "s")} onClick={(e) => { e.stopPropagation(); toggleSubs(t.id); }}><Icon name="chevD" size={12} style={{ transform: openSubs.has(t.id) ? "none" : "rotate(-90deg)" }} /><span className="sub-badge"><Icon name="layers" size={10} /> {kids.filter((k) => k.status === "done").length}/{kids.length}</span></button>}
                    <button className="act-add-sub no-print" title="Add subtask" onClick={(e) => { e.stopPropagation(); addSubtask(t); }}><Icon name="plus" size={12} /></button>
                  </div>
                  <div className="wrap">
                    {(t.tags || []).slice(0, 4).map((id) => { const tg = tags.find((x) => x.id === id); return tg ? <UI.Chip key={id} label={tg.label} color={tg.color} /> : null; })}
                    {(t.tags || []).length === 0 && <span className="muted">—</span>}
                  </div>
                  <div className="muted" style={{ fontSize: 13 }}>{ownerText(t)}</div>
                  <div className="muted mono" style={{ fontSize: 12 }}>{fmtD(t.start)} → {fmtD(t.end)}</div>
                  <div><span className={"status-dot s-" + t.status} />{COLUMNS.find((c) => c.id === t.status)?.title}</div>
                  <button className="act-row-del no-print" title="Delete task" onClick={(e) => { e.stopPropagation(); setDelTask({ id: t.id, title: t.title, subs: kids.length }); }}><Icon name="trash" size={13} /></button>
                </div>
                {openSubs.has(t.id) && kids.map((k) => {
                  return (
                    <div key={k.id} className="act-row act-row-sub" onClick={() => setOpen(k)}>
                      <div className="act-drag-cell"><span className="sub-connector">↳</span></div>
                      <div className="act-cell-title act-cell-sub">
                        <span className="prio-pip" style={{ background: PRIO[k.priority]?.c }} />
                        {k.title}<CommentBadge task={k} />
                      </div>
                      <div className="wrap">
                        {(k.tags || []).slice(0, 4).map((id) => { const tg = tags.find((x) => x.id === id); return tg ? <UI.Chip key={id} label={tg.label} color={tg.color} /> : null; })}
                        {(k.tags || []).length === 0 && <span className="muted">—</span>}
                      </div>
                      <div className="muted" style={{ fontSize: 13 }}>{ownerText(k)}</div>
                      <div className="muted mono" style={{ fontSize: 12 }}>{fmtD(k.start)} → {fmtD(k.end)}</div>
                      <div><span className={"status-dot s-" + k.status} />{COLUMNS.find((c) => c.id === k.status)?.title}</div>
                      <button className="act-row-del no-print" title="Delete subtask" onClick={(e) => { e.stopPropagation(); setDelTask({ id: k.id, title: k.title, subs: 0 }); }}><Icon name="trash" size={13} /></button>
                    </div>
                  );
                })}
                </React.Fragment>
              );
            })}
            <button className="act-add-row no-print" onClick={() => addTo(g.catId, g.origin)}><Icon name="plus" size={14} /> Add action</button>
          </div>
          </React.Fragment>}
        </div>
      ); })}
      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      {msEdit && <MilestoneModal id={msEdit} onClose={() => setMsEdit(null)} />}
      {delCat && <UI.Confirm title={"Delete track “" + delCat.label + "”?"} body={delCat.count ? delCat.count + " task" + (delCat.count === 1 ? "" : "s") + " will become uncategorised (they aren't deleted). This can't be undone." : "This removes the track. It has no tasks."} confirmLabel="Delete" onConfirm={() => removeCategory(delCat.id)} onClose={() => setDelCat(null)} />}
      {delTask && <UI.Confirm title="Delete task?" body={"“" + delTask.title + "”" + (delTask.subs ? " and its " + delTask.subs + " subtask" + (delTask.subs === 1 ? "" : "s") : "") + " will be permanently deleted. This can't be undone."} confirmLabel="Delete" onConfirm={() => { Store.removeTask(delTask.id); setDelTask(null); }} onClose={() => setDelTask(null)} />}
    </div>
  );
}

/* ============================================================
   MILESTONE/GATE MODAL
   ============================================================ */
function MilestoneModal({ id, onClose }) {
  const { categories } = Store.useStore();
  const ms = Store.getState().milestones.find((x) => x.id === id);
  if (!ms) return null;
  const set = (c) => Store.patch("milestones", id, c);
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <span className={ms.type === "gate" ? "ms-gate-icon big" : "ms-mile-icon big"}>{ms.type === "gate" ? "┃" : "◆"}</span>
        <div className="grow">
          <UI.Editable className="cm-title" style={{ fontSize: 20 }} multiline value={ms.title} onChange={(v) => set({ title: v || "Untitled" })} placeholder="Name" />
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="row" style={{ gap: 16, marginBottom: 18 }}>
          <div className="grow">
            <div className="field-label">Type</div>
            <div className="statusseg" style={{ maxWidth: 220 }}>
              <button className={ms.type === "milestone" ? "on" : ""} onClick={() => set({ type: "milestone" })}>◆ Milestone</button>
              <button className={ms.type === "gate" ? "on" : ""} onClick={() => set({ type: "gate", category: ms.category || (categories[0] && categories[0].id) || null })}>┃ Gate</button>
            </div>
          </div>
          <div>
            <div className="field-label">Date</div>
            <input className="datemini" type="date" value={ms.date || ""} onChange={(e) => set({ date: e.target.value })} />
          </div>
        </div>
        <div className="field-label">Category {ms.type === "gate" && <span style={{ color: "var(--t-red)" }}>· required for gates</span>}</div>
        <PickInline options={categories} value={ms.category} onChange={(v) => set({ category: v })} />
        {ms.type === "gate" && !ms.category && <div className="ms-warn">A gate validates a category's work — pick the category it gates.</div>}
        <div style={{ marginTop: 16 }}>
          <div className="field-label">Note</div>
          <UI.Editable className="input" tag="div" multiline value={ms.note} style={{ minHeight: 60, lineHeight: 1.5 }} onChange={(v) => set({ note: v })} placeholder="What does this mark?" />
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost btn-danger" onClick={() => { Store.remove("milestones", id); onClose(); }}><Icon name="trash" size={15} /> Delete</button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

/* ============================================================
   TIMELINE (Gantt) — grouped by category + milestones & gates
   ============================================================ */
function Timeline({ sort, fCat = [], fWho = [] }) {
  const { tasks, categories, milestones, commPlan, baseline } = Store.useStore();
  const [open, setOpen] = useA(null);
  const [msEdit, setMsEdit] = useA(null);
  const [showCP, setShowCP] = useA(false);
  const scrollRef = useAR(null);
  const DAYW = 13;

  const dated = tasks.filter((t) => t.start && t.end && taskMatchesFilter(t, fCat, fWho));
  // critical path: longest-duration chain through task→task dependencies
  const cp = useAM(() => {
    const dur = (t) => Math.max(1, daysBetween(t.start, t.end));
    const map = new Map(dated.map((t) => [t.id, t]));
    const memo = new Map(), visiting = new Set();
    const longest = (id) => {
      if (memo.has(id)) return memo.get(id);
      if (visiting.has(id)) return { len: 0, next: null };
      visiting.add(id);
      const t = map.get(id); let best = { len: dur(t), next: null };
      dated.forEach((s) => {
        if ((s.deps || []).some((d) => d.type === "task" && d.refId === id)) {
          const r = longest(s.id);
          if (dur(t) + r.len > best.len) best = { len: dur(t) + r.len, next: s.id };
        }
      });
      visiting.delete(id); memo.set(id, best); return best;
    };
    let start = null, len = -1;
    dated.forEach((t) => { const r = longest(t.id); if (r.len > len) { len = r.len; start = t.id; } });
    const path = new Set(); let cur = start;
    while (cur) { path.add(cur); cur = memo.get(cur).next; }
    return path;
  }, [dated]);
  const setBaseline = () => Store.setState((s) => ({ ...s, baseline: { at: Date.now(), bars: Object.fromEntries((s.tasks || []).filter((t) => t.start && t.end).map((t) => [t.id, { start: t.start, end: t.end }])) } }));
  const clearBaseline = () => Store.setState((s) => ({ ...s, baseline: null }));
  const datedMs = milestones.filter((m) => m.date);
  const datedComms = (commPlan || []).filter((c) => c.date);
  const allDates = [...dated.map((t) => [t.start, t.end]).flat(), ...datedMs.map((m) => m.date), ...datedComms.map((c) => c.date)];

  const range = useAM(() => {
    if (!allDates.length) { const now = new Date(); return { min: now, max: new Date(+now + 60 * DAY) }; }
    let min = Infinity, max = -Infinity;
    allDates.forEach((d) => { const v = +new Date(d); if (v < min) min = v; if (v > max) max = v; });
    const now = Date.now();
    min = Math.min(min, now); max = Math.max(max, now);
    min -= 4 * DAY; max += 8 * DAY;
    return { min: new Date(min), max: new Date(max) };
  }, [tasks, milestones]);

  const totalDays = Math.max(1, daysBetween(range.min, range.max));
  const totalW = totalDays * DAYW;

  const months = useAM(() => {
    const out = []; const d = new Date(range.min); d.setDate(1);
    while (d < range.max) {
      const start = new Date(Math.max(+d, +range.min));
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
      const end = new Date(Math.min(+next, +range.max));
      out.push({ label: d.toLocaleDateString("en-GB", { month: "short", year: "2-digit" }), left: daysBetween(range.min, start) * DAYW, width: daysBetween(start, end) * DAYW });
      d.setMonth(d.getMonth() + 1);
    }
    return out;
  }, [range]);

  const todayLeft = (() => { const now = new Date(); if (now < range.min || now > range.max) return null; return daysBetween(range.min, now) * DAYW; })();
  const nowTs = Date.now();

  // default the scroll to the "today" line so current work is in view
  React.useEffect(() => {
    if (scrollRef.current && todayLeft != null) {
      scrollRef.current.scrollLeft = Math.max(0, todayLeft - 160);
    }
  }, [todayLeft]);

  const groups = (() => {
    const inCat = (t) => t.category && categories.find((c) => c.id === t.category);
    if (sort === "sequence") {
      return [{ key: "_seq", label: "All actions · in sequence", color: null, items: sequenceTasks(dated) }];
    }
    const arr = categories.map((c) => ({ key: c.id, label: c.label, color: c.color, items: dated.filter((t) => t.category === c.id) }));
    const un = dated.filter((t) => !inCat(t));
    arr.push({ key: "_un", label: "Uncategorised", color: null, items: un.filter((t) => t.origin !== "comms" && t.origin !== "change") });
    arr.push({ key: "_comms", label: "Communications", color: "teal", items: un.filter((t) => t.origin === "comms") });
    arr.push({ key: "_change", label: "Change management", color: "purple", items: un.filter((t) => t.origin === "change") });
    return arr.filter((g) => g.items.length);
  })();

  /* drag */
  const dragRef = useAR(null);
  const onBarDown = (e, task, kind) => {
    e.preventDefault(); e.stopPropagation();
    dragRef.current = { task, kind, startX: e.clientX, start0: new Date(task.start), end0: new Date(task.end), moved: false };
    document.body.style.cursor = kind === "move" ? "grabbing" : "ew-resize";
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };
  const onMove = (e) => {
    const d = dragRef.current; if (!d) return;
    const deltaDays = Math.round((e.clientX - d.startX) / DAYW);
    if (deltaDays !== 0) d.moved = true;
    let s = new Date(d.start0), en = new Date(d.end0);
    if (d.kind === "move") { s = new Date(+d.start0 + deltaDays * DAY); en = new Date(+d.end0 + deltaDays * DAY); }
    else if (d.kind === "l") { s = new Date(Math.min(+d.start0 + deltaDays * DAY, +d.end0 - DAY)); }
    else if (d.kind === "r") { en = new Date(Math.max(+d.end0 + deltaDays * DAY, +d.start0 + DAY)); }
    const el = document.getElementById("bar-" + d.task.id);
    if (el) { el.style.left = daysBetween(range.min, s) * DAYW + "px"; el.style.width = Math.max(DAYW, daysBetween(s, en) * DAYW) + "px"; }
    d.preview = { start: toISO(s), end: toISO(en) };
  };
  const onUp = () => {
    const d = dragRef.current;
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    document.body.style.cursor = "";
    if (d && d.moved && d.preview) Store.patch("tasks", d.task.id, d.preview);
    dragRef.current = null;
  };

  if (!dated.length && !datedMs.length && !datedComms.length) {
    return <div className="view-pad view-wide"><div className="empty"><div className="serif">No dated actions yet</div>Add start and end dates to actions to see them on the timeline.</div></div>;
  }

  // compute layout for every rendered task so we can draw dependency arrows on top
  const taskLayout = new Map();
  let yCursor = 38; // header row height
  groups.forEach((g) => {
    yCursor += 34; // phase row
    g.items.forEach((t) => {
      const barLeft = daysBetween(range.min, t.start) * DAYW;
      const barWidth = Math.max(DAYW, daysBetween(t.start, t.end) * DAYW);
      taskLayout.set(t.id, { rowY: yCursor + 21, barLeft, barWidth });
      yCursor += 42;
    });
  });
  const depLines = [];
  const depCatColor = (task) => { const c = categories.find((x) => x.id === task.category); return c ? "var(--t-" + c.color + ")" : "var(--accent-deep)"; };
  tasks.forEach((t) => {
    if (!t.start || !t.end || !taskLayout.has(t.id)) return;
    (t.deps || []).forEach((d) => {
      if (d.type !== "task") return;
      const pred = tasks.find((x) => x.id === d.refId);
      if (!pred || !pred.start || !pred.end || !taskLayout.has(pred.id)) return;
      const pL = taskLayout.get(pred.id);
      const dL = taskLayout.get(t.id);
      const violated = pred.status !== "done" && new Date(t.start) < new Date(pred.end);
      depLines.push({
        key: d.id || (pred.id + "-" + t.id),
        from: { x: pL.barLeft + pL.barWidth, y: pL.rowY },
        to:   { x: dL.barLeft, y: dL.rowY },
        violated,
        color: depCatColor(pred),
        depTask: t,
        critical: cp.has(pred.id) && cp.has(t.id),
        title: (violated ? "⚠ Dependency block — " + t.title + " starts " + fmtD(t.start) + " but “" + pred.title + "” isn't finished until " + fmtD(pred.end) : pred.title + " → " + t.title) + " · double-click to inspect",
      });
    });
  });

  return (
    <div className="view-pad">
      <div className="gantt-toolbar no-print">
        {baseline ? (
          <React.Fragment>
            <span className="gantt-bl-note"><span className="gantt-bl-key" /> Baseline set {new Date(baseline.at).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}</span>
            <button className="btn btn-sm btn-ghost" onClick={setBaseline}>Update</button>
            <button className="btn btn-sm btn-ghost btn-danger" onClick={clearBaseline}>Clear</button>
          </React.Fragment>
        ) : (
          <button className="btn btn-sm" onClick={setBaseline} title="Snapshot today's dates to compare slippage against later"><Icon name="flag" size={13} /> Set baseline</button>
        )}
        <div className="grow" />
        <button className={"btn btn-sm" + (showCP ? " btn-primary" : "")} onClick={() => setShowCP((v) => !v)} title="Highlight the longest dependency chain"><Icon name="target" size={13} /> Critical path</button>
      </div>
      <div className="gantt panel" ref={scrollRef}>
        <div className="gantt-inner" style={{ width: totalW + 260 }}>
          {/* dependency arrows overlay — positioned over the track area */}
          {depLines.length > 0 && (
            <svg className="gantt-deps" style={{ left: 260, width: totalW, height: yCursor + 20 }}>
              <defs>
                <marker id="gd-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M0,0 L10,5 L0,10 z" fill="currentColor" />
                </marker>
                <marker id="gd-arrow-bad" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M0,0 L10,5 L0,10 z" fill="var(--t-red)" />
                </marker>
              </defs>
              {depLines.map((line) => {
                // smooth S-curve from the end of the predecessor to the start of the
                // dependent — far calmer to read than boxy elbows
                const dx = Math.max(34, Math.abs(line.to.x - line.from.x) * 0.5);
                const path = `M${line.from.x},${line.from.y} C${line.from.x + dx},${line.from.y} ${line.to.x - dx},${line.to.y} ${line.to.x - 4},${line.to.y}`;
                return (
                  <path key={line.key} d={path}
                    className={"gantt-dep" + (line.violated ? " violated" : "") + (showCP && line.critical ? " critical" : "")}
                    style={line.violated ? undefined : { stroke: line.color, color: line.color }}
                    onDoubleClick={() => setOpen(line.depTask)}
                    markerEnd={line.violated ? "url(#gd-arrow-bad)" : "url(#gd-arrow)"}>
                    <title>{line.title}</title>
                  </path>
                );
              })}
            </svg>
          )}
          {/* header */}
          <div className="gantt-row gantt-header">
            <div className="gantt-label gantt-corner">Category / Action</div>
            <div className="gantt-track" style={{ width: totalW }}>
              {months.map((m, i) => <div key={i} className="gantt-month" style={{ left: m.left, width: m.width }}>{m.label}</div>)}
              {todayLeft != null && <div className="gantt-today" style={{ left: todayLeft }}><span>Today</span></div>}
              {/* milestones & gates in header track */}
              {datedMs.map((ms) => {
                const left = daysBetween(range.min, ms.date) * DAYW;
                const cat = categories.find((c) => c.id === ms.category);
                if (ms.type === "gate") {
                  return <div key={ms.id} className="gantt-gate" style={{ left }} title={ms.title + " (gate) — " + fmtD(ms.date)} onClick={() => setMsEdit(ms.id)} />;
                }
                return <div key={ms.id} className="gantt-milestone" style={{ left, "--ms-c": cat ? "var(--t-" + cat.color + ")" : "var(--accent)" }} title={ms.title + " — " + fmtD(ms.date)} onClick={() => setMsEdit(ms.id)}>◆</div>;
              })}
              {/* communications in header track */}
              {datedComms.map((c) => {
                const left = daysBetween(range.min, c.date) * DAYW;
                return <div key={c.id} className="gantt-comm" style={{ left }} title={"Comms: " + (c.audience || "audience") + " — " + fmtD(c.date)}><Icon name="send" size={11} /></div>;
              })}
            </div>
          </div>
          {/* rows by category */}
          {groups.map((g) => (
            <React.Fragment key={g.key}>
              <div className="gantt-row gantt-phaserow">
                <div className="gantt-label">
                  <span className="kcol-dot" style={{ background: g.color ? "var(--t-" + g.color + ")" : "var(--ink-ghost)" }} />
                  <strong>{g.label}</strong>
                </div>
                <div className="gantt-track gantt-phasetrack" style={{ width: totalW }} />
              </div>
              {g.items.map((t) => {
                const left = daysBetween(range.min, t.start) * DAYW;
                const width = Math.max(DAYW, daysBetween(t.start, t.end) * DAYW);
                const cat = categories.find((c) => c.id === t.category);
                const color = cat ? "var(--t-" + cat.color + ")" : "var(--accent)";
                return (
                  <div className="gantt-row" key={t.id}>
                    <div className="gantt-label gantt-tasklabel" onClick={() => setOpen(t)} title={t.title}>{t.title}</div>
                    <div className="gantt-track" style={{ width: totalW }}>
                      {todayLeft != null && <div className="gantt-todayline" style={{ left: todayLeft }} />}
                      {datedMs.filter((ms) => ms.type === "gate").map((ms) => <div key={ms.id} className="gantt-gateline" style={{ left: daysBetween(range.min, ms.date) * DAYW }} />)}
                      {datedMs.filter((ms) => ms.type === "milestone").map((ms) => <div key={ms.id} className="gantt-msline" style={{ left: daysBetween(range.min, ms.date) * DAYW }} />)}
                      {datedComms.map((c) => <div key={c.id} className="gantt-commline" style={{ left: daysBetween(range.min, c.date) * DAYW }} />)}
                      {baseline && baseline.bars[t.id] && (
                        <div className="gantt-baseline" style={{ left: daysBetween(range.min, baseline.bars[t.id].start) * DAYW, width: Math.max(DAYW, daysBetween(baseline.bars[t.id].start, baseline.bars[t.id].end) * DAYW) }} title={"Baseline: " + fmtD(baseline.bars[t.id].start) + " → " + fmtD(baseline.bars[t.id].end)} />
                      )}
                      <div id={"bar-" + t.id} className={"gantt-bar" + (t.status === "done" ? " done" : "") + (+new Date(t.end) < nowTs ? " past" : "") + (showCP && cp.has(t.id) ? " critical" : "")}
                        style={{ left, width, "--bar-c": color }}
                        onPointerDown={(e) => onBarDown(e, t, "move")}
                        onDoubleClick={() => setOpen(t)} title={t.title + " · " + fmtD(t.start) + " → " + fmtD(t.end)}>
                        <span className="gantt-handle l" onPointerDown={(e) => onBarDown(e, t, "l")} />
                        <span className="gantt-handle r" onPointerDown={(e) => onBarDown(e, t, "r")} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      {msEdit && <MilestoneModal id={msEdit} onClose={() => setMsEdit(null)} />}
    </div>
  );
}

/* ============================================================
   CALENDAR — month grid of task deadlines, milestones & comms
   ============================================================ */
function CalendarView({ fCat = [], fWho = [] }) {
  const { tasks, milestones, categories, commPlan } = Store.useStore();
  const [cursor, setCursor] = useA(() => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); return d; });
  const [open, setOpen] = useA(null);
  const [msEdit, setMsEdit] = useA(null);
  const year = cursor.getFullYear(), month = cursor.getMonth();
  const monthLabel = cursor.toLocaleDateString("en-GB", { month: "long", year: "numeric" });
  const key = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const first = new Date(year, month, 1);
  const startOffset = (first.getDay() + 6) % 7; // Monday-first
  const gridStart = new Date(year, month, 1 - startOffset);
  const days = [...Array(42)].map((_, i) => { const d = new Date(gridStart); d.setDate(gridStart.getDate() + i); return d; });

  const dated = tasks.filter((t) => t.end && taskMatchesFilter(t, fCat, fWho));
  const byDay = {}; dated.forEach((t) => { const k = t.end.slice(0, 10); (byDay[k] = byDay[k] || []).push(t); });
  const msByDay = {}; (milestones || []).filter((m) => m.date).forEach((m) => { const k = m.date.slice(0, 10); (msByDay[k] = msByDay[k] || []).push(m); });
  const commByDay = {}; (commPlan || []).filter((c) => c.date).forEach((c) => { const k = c.date.slice(0, 10); (commByDay[k] = commByDay[k] || []).push(c); });
  const todayKey = key(new Date());
  const catColor = (id) => { const c = categories.find((x) => x.id === id); return c ? "var(--t-" + c.color + ")" : "var(--accent)"; };
  const step = (n) => setCursor(new Date(year, month + n, 1));
  const today = () => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); setCursor(d); };
  const WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  return (
    <div className="view-pad view-wide">
      <div className="cal-bar no-print">
        <div className="cal-nav">
          <button className="btn btn-icon btn-ghost" onClick={() => step(-1)} title="Previous month"><Icon name="chevR" size={16} style={{ transform: "rotate(180deg)" }} /></button>
          <span className="cal-month serif">{monthLabel}</span>
          <button className="btn btn-icon btn-ghost" onClick={() => step(1)} title="Next month"><Icon name="chevR" size={16} /></button>
          <button className="btn btn-sm btn-ghost" onClick={today}>Today</button>
        </div>
        <div className="cal-legend">
          <span><span className="cal-key-dot" style={{ background: "var(--accent)" }} /> Deadline</span>
          <span><span className="cal-key-ms">◆</span> Milestone</span>
          <span><span className="cal-key-gate">┃</span> Gate</span>
          <span><Icon name="send" size={11} /> Comms</span>
        </div>
      </div>
      <div className="cal-grid panel">
        {WD.map((d) => <div key={d} className="cal-wd">{d}</div>)}
        {days.map((d, i) => {
          const k = key(d);
          const inMonth = d.getMonth() === month;
          const dayTasks = byDay[k] || [];
          const dayMs = msByDay[k] || [];
          const dayComms = commByDay[k] || [];
          const shown = dayTasks.slice(0, 4);
          return (
            <div key={i} className={"cal-cell" + (inMonth ? "" : " out") + (k === todayKey ? " today" : "")}>
              <div className="cal-daynum">{d.getDate()}</div>
              <div className="cal-items">
                {dayMs.map((m) => (
                  <button key={m.id} className={"cal-ms" + (m.type === "gate" ? " gate" : "")} onClick={() => setMsEdit(m.id)} title={m.title}>
                    <span className="cal-ms-mark">{m.type === "gate" ? "┃" : "◆"}</span>{m.title}
                  </button>
                ))}
                {shown.map((t) => (
                  <button key={t.id} className={"cal-task" + (t.status === "done" ? " done" : "")} style={{ "--c": catColor(t.category) }} onClick={() => setOpen(t)} title={t.title + (t.status === "done" ? " (done)" : "")}>
                    {t.title}
                  </button>
                ))}
                {dayTasks.length > shown.length && <span className="cal-more">+{dayTasks.length - shown.length} more</span>}
                {dayComms.length > 0 && <span className="cal-comm" title={dayComms.length + " communication(s)"}><Icon name="send" size={10} /> {dayComms.length}</span>}
              </div>
            </div>
          );
        })}
      </div>
      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
      {msEdit && <MilestoneModal id={msEdit} onClose={() => setMsEdit(null)} />}
    </div>
  );
}

Object.assign(window, { Actions, CalendarView });


// ======== stakeholders.jsx ========
/* ============================================================
   PROJECT MEMBERS — canonical people list
   Feeds the org chart, task assignees and the personal view.
   Exposes window.Members (+ legacy Stakeholders alias, Seg)
   ============================================================ */
const { useState: useS } = React;

const MEMBER_COLORS = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];

// where a member's name is referenced across the project
function memberUsage(s, name) {
  const taskCount = (s.tasks || []).filter((t) => assigneesOf(t).includes(name)).length;
  const inOrg = (s.org || []).some((o) => o.name === name);
  return { taskCount, inOrg };
}

function Members() {
  const s = Store.useStore();
  const members = s.members || [];
  const [del, setDel] = useS(null);

  const add = () => {
    const id = Store.uid("mem");
    Store.add("members", { id, name: "New member", role: "", email: "", color: MEMBER_COLORS[members.length % MEMBER_COLORS.length] });
  };
  const patch = (id, c) => Store.patch("members", id, c);
  const removeMember = (m) => {
    Store.removeMember(m.id);
    setDel(null);
  };

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 580, fontSize: 14, lineHeight: 1.55 }}>
            Everyone working on the project. This is the <b>master list</b> — names, roles and colour tags flow from here into task assignees, the capacity view and the roles &amp; org chart. Rename someone and it updates everywhere; recolour them and their tag changes across the tool.
          </p>
          <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add member</button>
        </div>

        <div className="mem-grid">
          {members.map((m) => {
            const use = memberUsage(s, m.name);
            return (
              <div key={m.id} className="mem-card panel">
                <div className="mem-card-top">
                  <span className="avatar mem-avatar" style={{ background: "var(--t-" + (m.color || "indigo") + ")" }}>{initials(m.name)}</span>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <UI.Editable className="mem-name" value={m.name} onChange={(v) => Store.renameMember(m.id, v)} placeholder="Full name" />
                    <UI.Editable className="mem-role" value={m.role} onChange={(v) => patch(m.id, { role: v })} placeholder="Role on the project" />
                  </div>
                  <button className="btn btn-icon btn-ghost btn-danger no-print mem-del" title="Remove member" onClick={() => setDel(m)}><Icon name="trash" size={14} /></button>
                </div>
                <div className="mem-colorpick no-print">
                  {MEMBER_COLORS.map((c) => (
                    <button key={c} className={"mem-swatch" + (m.color === c ? " on" : "")} style={{ background: "var(--t-" + c + ")" }} onClick={() => patch(m.id, { color: c })} />
                  ))}
                </div>
                <div className="mem-email">
                  <Icon name="users" size={13} />
                  <UI.Editable className="mono" value={m.email} onChange={(v) => patch(m.id, { email: v })} placeholder="email@company.example" />
                </div>
                <div className="mem-foot">
                  <span className="mem-stat"><b>{use.taskCount}</b> task{use.taskCount === 1 ? "" : "s"}</span>
                  <span className={"mem-stat" + (use.inOrg ? " on" : "")}>{use.inOrg ? "In org chart" : "Not in org chart"}</span>
                </div>
              </div>
            );
          })}
          {members.length === 0 && (
            <div className="empty" style={{ gridColumn: "1/-1" }}>
              <div className="serif">No members yet</div>Add the people working on this project.
            </div>
          )}
        </div>
      </div>
      {del && (
        <UI.Confirm
          title="Remove member?"
          body={`Remove ${del.name} from the project's member list? This won't unassign them from tasks they're already on.`}
          confirmLabel="Remove"
          onConfirm={() => removeMember(del)}
          onClose={() => setDel(null)}
        />
      )}
    </div>
  );
}

// keep Seg available (used by risks modal)
function Seg({ value, options, onChange }) {
  return (
    <div className="statusseg">
      {Object.entries(options).map(([k, v]) => (
        <button key={k} className={value === k ? "on" : ""} onClick={() => onChange(k)}>{v}</button>
      ))}
    </div>
  );
}

Object.assign(window, { Members, Stakeholders: Members, Seg });


// ======== risks.jsx ========
/* ============================================================
   RISKS & MITIGATION — register + heatmap + task remediation
   Exposes window.Risks + remediation helpers
   ============================================================ */
const { useState: useR } = React;

const LVL = { low: 1, med: 2, high: 3 };
const LVL_LABEL = { low: "Low", med: "Medium", high: "High" };
const RISK_STATUS = { open: { label: "Open", c: "var(--t-red)" }, monitoring: { label: "Monitoring", c: "var(--t-amber)" }, closed: { label: "Closed", c: "var(--t-green)" } };
const scoreColor = (l, i) => { const s = LVL[l] * LVL[i]; if (s >= 6) return "var(--t-red)"; if (s >= 3) return "var(--t-amber)"; return "var(--t-green)"; };

// remediation state from linked tasks
function remediation(risk, tasks) {
  const ids = risk.taskIds || [];
  const linked = tasks.filter((t) => ids.includes(t.id));
  if (!linked.length) return { state: "none", done: 0, total: 0, linked };
  const done = linked.filter((t) => t.status === "done").length;
  const active = linked.some((t) => t.status === "inprogress");
  let state = "planned";
  if (done === linked.length) state = "remediated";
  else if (done > 0 || active) state = "progress";
  return { state, done, total: linked.length, linked };
}
const REMED = {
  none: { label: "No actions", c: "var(--ink-faint)" },
  planned: { label: "Remediation planned", c: "var(--t-indigo)" },
  progress: { label: "Remediating", c: "var(--t-amber)" },
  remediated: { label: "Remediated", c: "var(--t-green)" },
};

function Risks() {
  const { risks, tasks } = Store.useStore();
  const [open, setOpen] = useR(null);
  const [del, setDel] = useR(null);
  const add = () => { const id = Store.uid("r"); Store.add("risks", { id, title: "New risk", likelihood: "med", impact: "med", mitigation: "", owner: "", status: "open", taskIds: [] }); setOpen(id); };
  const sorted = [...risks].sort((a, b) => LVL[b.likelihood] * LVL[b.impact] - LVL[a.likelihood] * LVL[a.impact]);

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 520, fontSize: 14, lineHeight: 1.55 }}>
            Active risk register, ordered by exposure. Link <b>remediation actions</b> to a risk and it's marked remediated once those tasks are done.
          </p>
          <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add risk</button>
        </div>

        <div className="risk-layout">
          <div className="risk-list">
            {sorted.map((r) => {
              const rem = remediation(r, tasks);
              return (
                <div key={r.id} className="risk-card panel" onClick={() => setOpen(r.id)}>
                  <div className="risk-score" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</div>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="risk-title">{r.title}</div>
                    <p className="risk-mit">{r.mitigation || "No mitigation yet."}</p>
                    <div className="risk-meta">
                      <span className="chip" style={{ "--chip-c": RISK_STATUS[r.status]?.c }}><span className="chip-dot" />{RISK_STATUS[r.status]?.label}</span>
                      <span className="mono muted" style={{ fontSize: 11.5 }}>L:{LVL_LABEL[r.likelihood]} · I:{LVL_LABEL[r.impact]}</span>
                      {r.owner && <span className="muted" style={{ fontSize: 12.5 }}><Icon name="users" size={12} style={{ verticalAlign: -2 }} /> {r.owner}</span>}
                    </div>
                    {rem.state !== "none" && (
                      <div className="remed-row">
                        <span className="remed-chip" style={{ "--rc": REMED[rem.state].c }}>
                          {rem.state === "remediated" ? <Icon name="check" size={12} /> : <Icon name="shield" size={12} />}
                          {REMED[rem.state].label}
                        </span>
                        <div className="remed-bar"><div className="remed-fill" style={{ width: (rem.done / rem.total * 100) + "%", background: REMED[rem.state].c }} /></div>
                        <span className="mono muted" style={{ fontSize: 11 }}>{rem.done}/{rem.total} done</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="risk-side">
            <div className="eyebrow" style={{ marginBottom: 12 }}>Likelihood × Impact</div>
            <Heatmap risks={risks} onOpen={setOpen} />
            <div className="heat-legend">
              <span><i style={{ background: "var(--t-green)" }} /> Low</span>
              <span><i style={{ background: "var(--t-amber)" }} /> Medium</span>
              <span><i style={{ background: "var(--t-red)" }} /> High</span>
            </div>
          </div>
        </div>
      </div>
      {open && <RiskModal id={open} onClose={() => setOpen(null)} onDelete={() => { setDel(open); setOpen(null); }} />}
      {del && <UI.Confirm title="Delete risk?" body="This removes the risk from the register." onConfirm={() => Store.remove("risks", del)} onClose={() => setDel(null)} />}
    </div>
  );
}

function Heatmap({ risks, onOpen }) {
  const cells = [];
  for (let imp = 3; imp >= 1; imp--) {
    for (let lik = 1; lik <= 3; lik++) {
      const here = risks.filter((r) => LVL[r.likelihood] === lik && LVL[r.impact] === imp);
      const lk = Object.keys(LVL).find((k) => LVL[k] === lik), ik = Object.keys(LVL).find((k) => LVL[k] === imp);
      cells.push(
        <div key={lik + "-" + imp} className="heat-cell" style={{ background: "color-mix(in oklch, " + scoreColor(lk, ik) + " 16%, var(--panel))" }}>
          {here.map((r) => (<span key={r.id} className="heat-dot" style={{ background: scoreColor(r.likelihood, r.impact) }} title={r.title} onClick={() => onOpen(r.id)} />))}
        </div>
      );
    }
  }
  return (<div className="heat"><div className="heat-ylabel">Impact →</div><div className="heat-grid">{cells}</div><div className="heat-xlabel">Likelihood →</div></div>);
}

function RiskModal({ id, onClose, onDelete }) {
  const { tasks } = Store.useStore();
  const r = Store.getState().risks.find((x) => x.id === id);
  if (!r) return null;
  const set = (c) => Store.patch("risks", id, c);
  const rem = remediation(r, tasks);
  const toggleTask = (tid) => { const cur = r.taskIds || []; set({ taskIds: cur.includes(tid) ? cur.filter((x) => x !== tid) : [...cur, tid] }); };
  const linkedIds = r.taskIds || [];

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <UI.Editable className="cm-title" style={{ fontSize: 20 }} multiline value={r.title} onChange={(v) => set({ title: v || "Untitled risk" })} placeholder="Risk title" />
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="cm-grid">
          <div>
            <div className="cm-section">
              <div className="field-label">Mitigation plan</div>
              <UI.Editable className="input" tag="div" multiline value={r.mitigation} style={{ minHeight: 80, lineHeight: 1.55 }} onChange={(v) => set({ mitigation: v })} placeholder="How will this be prevented or contained?" />
            </div>
            <div className="cm-section">
              <div className="between" style={{ marginBottom: 8 }}>
                <div className="field-label" style={{ margin: 0 }}>Remediation actions</div>
                {rem.state !== "none" && <span className="remed-chip" style={{ "--rc": REMED[rem.state].c }}>{rem.state === "remediated" ? <Icon name="check" size={12} /> : <Icon name="shield" size={12} />}{REMED[rem.state].label}</span>}
              </div>
              <p className="muted" style={{ fontSize: 12.5, margin: "0 0 8px", lineHeight: 1.5 }}>Tie this risk to the tasks that actively reduce it. It becomes <b>Remediated</b> when all linked tasks are Done.</p>
              <div className="prod-tasklist">
                {tasks.length === 0 && <div className="act-empty">No tasks in this project yet.</div>}
                {tasks.map((t) => (
                  <button key={t.id} className={"prod-taskopt" + (linkedIds.includes(t.id) ? " on" : "")} onClick={() => toggleTask(t.id)}>
                    <span className={"checkbox" + (linkedIds.includes(t.id) ? " on" : "")}>{linkedIds.includes(t.id) && <Icon name="check" size={11} />}</span>
                    <span className="grow" style={{ textAlign: "left" }}>{t.title}</span>
                    <span className={"status-dot s-" + t.status} title={t.status} />
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="cm-side">
            <div><div className="field-label">Likelihood</div><Seg value={r.likelihood} options={LVL_LABEL} onChange={(v) => set({ likelihood: v })} /></div>
            <div><div className="field-label">Impact</div><Seg value={r.impact} options={LVL_LABEL} onChange={(v) => set({ impact: v })} /></div>
            <div><div className="field-label">Exposure</div>
              <div className="risk-expo" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}<span>/ 9</span></div>
            </div>
            <div><div className="field-label">Status</div>
              <div className="statusseg" style={{ flexWrap: "wrap" }}>{Object.entries(RISK_STATUS).map(([k, v]) => (<button key={k} className={r.status === k ? "on" : ""} style={{ "--prio-c": v.c, flex: "1 0 30%" }} onClick={() => set({ status: k })}>{v.label}</button>))}</div>
            </div>
            <div><div className="field-label">Owner</div><UI.Editable className="input" value={r.owner} onChange={(v) => set({ owner: v })} placeholder="Who owns this?" /></div>
          </div>
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost btn-danger" onClick={onDelete}><Icon name="trash" size={15} /> Delete</button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { Risks, LVL, LVL_LABEL, RISK_STATUS, scoreColor, remediation, REMED });


// ======== preanalysis.jsx ========
/* ============================================================
   PRE-ANALYSIS — early research findings
   Exposes window.PreAnalysis
   ============================================================ */
const { useState: useP } = React;

function PreAnalysis() {
  const { findings, categories } = Store.useStore();
  const [filter, setFilter] = useP(null);
  const [del, setDel] = useP(null);

  const add = () => {
    Store.add("findings", { id: Store.uid("f"), title: "New finding", summary: "", category: null, source: "" });
  };
  const shown = filter ? findings.filter((f) => f.category === filter) : findings;

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <section className="prean-asis">
          <div className="between" style={{ marginBottom: 14, flexWrap: "wrap", gap: 10 }}>
            <div>
              <h2 className="scope-h serif" style={{ margin: "0 0 3px" }}>As-is assessment</h2>
              <p className="muted" style={{ margin: 0, fontSize: 13.5, lineHeight: 1.5, maxWidth: 560 }}>
                Capture the current state for each area you're studying. The <b>to-be</b> target is added later on the Scope page and in the Business case — they share this same table.
              </p>
            </div>
          </div>
          <AssessmentTable mode="asis" />
        </section>

        <div className="prean-divider" />

        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <div>
            <h2 className="scope-h serif" style={{ margin: "0 0 3px" }}>Findings</h2>
            <p className="muted" style={{ margin: 0, maxWidth: 520, fontSize: 13.5, lineHeight: 1.5 }}>
              Evidence gathered during discovery. These findings shaped the scope, the architecture and the business case.
            </p>
          </div>
          <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add finding</button>
        </div>

        <div className="filter-pills no-print" style={{ marginBottom: 20 }}>
          <button className={"fpill" + (!filter ? " on" : "")} style={{ "--t-var": "var(--accent)" }} onClick={() => setFilter(null)}>All</button>
          {categories.map((c) => (
            <button key={c.id} className={"fpill" + (filter === c.id ? " on" : "")} style={{ "--t-var": "var(--t-" + c.color + ")" }} onClick={() => setFilter(filter === c.id ? null : c.id)}>
              <span className="chip-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}
            </button>
          ))}
        </div>

        <div className="find-grid">
          {shown.map((f, i) => {
            const cat = categories.find((c) => c.id === f.category);
            return (
              <article key={f.id} className="find-card panel">
                <div className="find-num mono">{String(i + 1).padStart(2, "0")}</div>
                <div className="find-body">
                  <div className="find-cat-row">
                    <PickInline options={categories} value={f.category} onChange={(v) => Store.patch("findings", f.id, { category: v })} />
                    <button className="btn btn-icon btn-ghost btn-danger no-print" style={{ marginLeft: "auto" }} onClick={() => setDel(f.id)}><Icon name="trash" size={14} /></button>
                  </div>
                  <UI.Editable className="find-title serif" multiline value={f.title} onChange={(v) => Store.patch("findings", f.id, { title: v || "Untitled finding" })} placeholder="Finding headline" />
                  <UI.Editable className="find-summary" tag="div" multiline value={f.summary} onChange={(v) => Store.patch("findings", f.id, { summary: v })} placeholder="What did the research show, and why does it matter?" />
                  <div className="find-source">
                    <Icon name="search" size={13} />
                    <UI.Editable tag="span" className="mono" value={f.source} onChange={(v) => Store.patch("findings", f.id, { source: v })} placeholder="source" />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        {shown.length === 0 && <div className="empty"><div className="serif">No findings here</div>Try a different category or add one.</div>}
      </div>
      {del && <UI.Confirm title="Delete finding?" body="This removes the research finding." onConfirm={() => Store.remove("findings", del)} onClose={() => setDel(null)} />}
    </div>
  );
}

Object.assign(window, { PreAnalysis });


// ======== orgchart.jsx ========
/* ============================================================
   ORG CHART — free-positioned roles, drag-to-connect lines,
   floating (unattached) roles. Exposes window.OrgChart
   ============================================================ */
const { useState: useO, useRef: useOR, useMemo: useOM, useEffect: useOE } = React;

const NODEW = 192, NODEH = 96, HGAP = 48, VGAP = 96, GRID = 96;
const ORG_ACCENTS = ["purple", "indigo", "blue", "teal", "green", "amber", "pink", "red"];

/* tidy-tree fallback positions for nodes that have never been placed */
function autoLayout(nodes) {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, { ...n, children: [] }]));
  const roots = [];
  nodes.forEach((n) => { if (n.parent && byId[n.parent]) byId[n.parent].children.push(byId[n.id]); else roots.push(byId[n.id]); });
  let leaf = 0;
  const place = (node, depth) => {
    node.depth = depth;
    if (!node.children.length) { node.ax = leaf * (NODEW + HGAP); leaf++; }
    else { node.children.forEach((c) => place(c, depth + 1)); node.ax = (node.children[0].ax + node.children[node.children.length - 1].ax) / 2; }
    node.ay = depth * (NODEH + VGAP);
  };
  roots.forEach((r) => { place(r, 0); leaf += 1; });
  return byId;
}

function descendantsOf(nodes, id) {
  const out = new Set([id]); let added = true;
  while (added) { added = false; nodes.forEach((n) => { if (n.parent && out.has(n.parent) && !out.has(n.id)) { out.add(n.id); added = true; } }); }
  return out;
}

function OrgChart() {
  const { org, members } = Store.useStore();
  const wrapRef = useOR(null);
  const [del, setDel] = useO(null);
  const [showMemberMenu, setShowMemberMenu] = useO(false);
  const [live, setLive] = useO(null);       // {id,x,y} while moving
  const [link, setLink] = useO(null);        // {id, x, y, target} while connecting
  const PAD = 40;

  // The member list is the source of truth: a card linked to a member (by
  // memberId) inherits its name, role and colour live. Unlinked cards keep
  // their own values. The note (responsibility) is always card-specific.
  const memById = useOM(() => Object.fromEntries((members || []).map((m) => [m.id, m])), [members]);
  const linkedMember = (n) => (n.memberId ? memById[n.memberId] : (members || []).find((m) => m.name === n.name)) || null;
  const dispName = (n) => { const m = linkedMember(n); return m ? m.name : n.name; };
  const dispRole = (n) => { const m = linkedMember(n); return m ? (m.role || "") : (n.role || ""); };
  const dispAccent = (n) => { const m = linkedMember(n); return m ? (m.color || "indigo") : (n.accent || "indigo"); };

  // Auto-layout: every role's position is DERIVED from the reporting structure
  // (a tidy tree) and recomputed whenever that structure changes. A node only
  // keeps a hand-placed position once the user has explicitly dragged it
  // (its `manual` flag). Re-linking or Auto-arrange clears the flag so the
  // role snaps back to its computed slot.
  const autoPos = useOM(() => {
    const byId = autoLayout(org);
    const out = {};
    org.forEach((n) => {
      const b = byId[n.id] || {};
      out[n.id] = {
        x: Math.max(0, Math.round((b.ax || 0) / GRID) * GRID),
        y: Math.max(0, Math.round((b.ay || 0) / GRID) * GRID),
      };
    });
    return out;
  }, [org]);

  const posOf = (n) => {
    if (live && live.id === n.id) return { x: live.x, y: live.y };
    if (n.manual && n.x != null && n.y != null) return { x: n.x, y: n.y };
    return autoPos[n.id] || { x: n.x || 0, y: n.y || 0 };
  };
  const bounds = useOM(() => {
    let w = 600, h = 360;
    org.forEach((n) => { const p = posOf(n); w = Math.max(w, p.x + NODEW); h = Math.max(h, p.y + NODEH); });
    return { w: w + PAD * 2, h: h + PAD * 2 };
  }, [org, live]);

  const canvasXY = (e) => {
    const r = wrapRef.current.getBoundingClientRect();
    return { x: e.clientX - r.left + wrapRef.current.scrollLeft - PAD, y: e.clientY - r.top + wrapRef.current.scrollTop - PAD };
  };

  /* ---- move a card freely ---- */
  const moveRef = useOR(null);
  const startMove = (e, n) => {
    e.preventDefault(); e.stopPropagation();
    const c = canvasXY(e); const p = posOf(n);
    moveRef.current = { id: n.id, ox: c.x - p.x, oy: c.y - p.y, moved: false };
    setLive({ id: n.id, x: p.x, y: p.y });
    window.addEventListener("pointermove", onMoveMove);
    window.addEventListener("pointerup", onMoveUp);
  };
  const onMoveMove = (e) => {
    const m = moveRef.current; if (!m) return;
    const c = canvasXY(e);
    m.moved = true;
    // snap live preview to the grid so it feels firm while dragging
    m.lastX = Math.max(0, Math.round((c.x - m.ox) / GRID) * GRID);
    m.lastY = Math.max(0, Math.round((c.y - m.oy) / GRID) * GRID);
    setLive({ id: m.id, x: m.lastX, y: m.lastY });
  };
  const onMoveUp = () => {
    window.removeEventListener("pointermove", onMoveMove);
    window.removeEventListener("pointerup", onMoveUp);
    const m = moveRef.current; moveRef.current = null;
    if (m && m.moved && m.lastX != null) {
      const gx = Math.max(0, Math.round(m.lastX / GRID) * GRID);
      const gy = Math.max(0, Math.round(m.lastY / GRID) * GRID);
      Store.patch("org", m.id, { x: gx, y: gy, manual: true });
    }
    setLive(null);
  };

  /* ---- drag-to-connect a reporting line ---- */
  const linkRef = useOR(null);
  const startLink = (e, n) => {
    e.preventDefault(); e.stopPropagation();
    const c = canvasXY(e);
    linkRef.current = { id: n.id, blocked: descendantsOf(org, n.id) };
    setLink({ id: n.id, x: c.x, y: c.y, target: null });
    window.addEventListener("pointermove", onLinkMove);
    window.addEventListener("pointerup", onLinkUp);
  };
  const onLinkMove = (e) => {
    const l = linkRef.current; if (!l) return;
    const c = canvasXY(e);
    let target = null;
    for (const n of org) {
      if (l.blocked.has(n.id)) continue;
      const p = posOf(n);
      if (c.x >= p.x && c.x <= p.x + NODEW && c.y >= p.y && c.y <= p.y + NODEH) { target = n.id; break; }
    }
    l.target = target;
    setLink({ id: l.id, x: c.x, y: c.y, target });
  };
  const onLinkUp = () => {
    window.removeEventListener("pointermove", onLinkMove);
    window.removeEventListener("pointerup", onLinkUp);
    const l = linkRef.current; linkRef.current = null;
    // Re-link: drop any manual placement so the role snaps into its correct
    // auto position under the new manager (or its floating slot).
    if (l) Store.patch("org", l.id, { parent: l.target || null, manual: false, x: null, y: null });
    setLink(null);
  };

  const addRole = (parentId) => {
    const id = Store.uid("o");
    // No fixed coordinates — the auto-layout drops the new role into the right
    // slot (below its parent, or in the floating row) on the next render.
    Store.add("org", { id, name: "New role", role: "", parent: parentId || null, note: "", accent: ORG_ACCENTS[org.length % ORG_ACCENTS.length], manual: false, x: null, y: null });
  };
  const removeNode = (id) => {
    const node = org.find((n) => n.id === id);
    Store.setState((s) => ({ ...s, org: s.org.filter((n) => n.id !== id).map((n) => n.parent === id ? { ...n, parent: node.parent } : n) }));
  };
  // AUTO-SYNC: the member list is the source of truth. Any member without a card
  // is added automatically (deletions are handled in Store.removeMember, which
  // drops the card and the person's task assignments). Manually-added floating
  // roles (no member link) are left alone.
  const memberCardless = (members || []).filter((m) => m.name && !org.some((o) => o.memberId === m.id || o.name === m.name));
  useOE(() => {
    if (!memberCardless.length) return;
    Store.setState((s) => {
      const present = new Set();
      let next = [...s.org];
      const topId = (next.find((n) => !n.parent) || {}).id || null;
      (s.members || []).forEach((m) => {
        if (!m.name) return;
        if (next.some((o) => o.memberId === m.id || o.name === m.name)) return;
        if (present.has(m.id)) return; present.add(m.id);
        next.push({ id: Store.uid("o"), memberId: m.id, name: m.name, role: m.role || "", parent: topId, note: "", accent: m.color || "indigo", manual: false, x: null, y: null });
      });
      return { ...s, org: next };
    });
  }, [memberCardless.length]);
  const addMemberNode = (m) => {
    const id = Store.uid("o");
    Store.add("org", { id, memberId: m.id, name: m.name, role: m.role || "", parent: null, note: "", accent: m.color || ORG_ACCENTS[org.length % ORG_ACCENTS.length], manual: false, x: null, y: null });
    setShowMemberMenu(false);
  };

  // snap everything back to the computed layout (drop all manual placements)
  const tidyUp = () => Store.setState((s) => ({ ...s, org: s.org.map((n) => ({ ...n, manual: false, x: null, y: null })) }));
  const anyManual = org.some((n) => n.manual);

  // shared horizontal trunk per parent: each parent's children share one horizontal line
  // drawn at a fixed offset below the parent's bottom edge.
  const TRUNK_OFFSET = 36;
  const connPoint = (n, which) => { const p = posOf(n); return which === "bottom" ? { x: p.x + NODEW / 2, y: p.y + NODEH } : { x: p.x + NODEW / 2, y: p.y }; };
  // build per-parent trunk paths (one combined SVG path each)
  const trunkPaths = useOM(() => {
    const byParent = new Map();
    org.forEach((n) => {
      if (!n.parent) return;
      const p = org.find((x) => x.id === n.parent); if (!p) return;
      if (!byParent.has(p.id)) byParent.set(p.id, { parent: p, children: [] });
      byParent.get(p.id).children.push(n);
    });
    const paths = [];
    byParent.forEach(({ parent, children }) => {
      const a = connPoint(parent, "bottom");
      const trunkY = a.y + TRUNK_OFFSET;
      const stemX = a.x;
      const childPoints = children.map((c) => connPoint(c, "top"));
      const leftX = Math.min(stemX, ...childPoints.map((p) => p.x));
      const rightX = Math.max(stemX, ...childPoints.map((p) => p.x));
      let d = `M${stemX + PAD},${a.y + PAD} V${trunkY + PAD}`;
      if (leftX !== rightX) d += ` M${leftX + PAD},${trunkY + PAD} H${rightX + PAD}`;
      childPoints.forEach((cp) => { d += ` M${cp.x + PAD},${trunkY + PAD} V${cp.y + PAD}`; });
      paths.push({ key: parent.id, d, color: "var(--t-" + dispAccent(parent) + ")" });
    });
    return paths;
  }, [org, live, PAD, members]);

  return (
    <div className="view-scroll">
      <div className="view-pad">
        <div className="between" style={{ marginBottom: 16, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 600, fontSize: 14, lineHeight: 1.55 }}>
            Roles arrange themselves automatically by who reports to whom. Cards marked <b>member</b> inherit their name, role &amp; colour from the <b>Members</b> page. Drag the <b>link handle</b> onto another role to set its manager — or onto empty space to leave it <b>floating</b>. Drag the <b>move grip</b> to fine-tune; <b>Auto-arrange</b> snaps everything back.
          </p>
          <div className="row no-print" style={{ gap: 8 }}>
            <button className="btn" onClick={tidyUp} disabled={!anyManual} title={anyManual ? "Snap every role back to its automatic position" : "Everything is already auto-arranged"}><Icon name="org" size={15} /> Auto-arrange</button>
            <button className="btn" onClick={() => addRole(null)}><Icon name="plus" size={15} /> Add floating role</button>
          </div>
        </div>

        <div className="org-wrap panel" ref={wrapRef}>
          <div className="org-canvas org-grid" style={{ width: bounds.w, height: bounds.h }}>
            <svg className="org-lines" width={bounds.w} height={bounds.h}>
              {trunkPaths.map((p) => <path key={p.key} d={p.d} className="org-line" stroke={p.color} />)}
              {link && (() => {
                const src = org.find((x) => x.id === link.id); if (!src) return null;
                const a = connPoint(src, "bottom");
                const b = { x: link.x - NODEW / 2, y: link.y };
                const trunkY = a.y + TRUNK_OFFSET;
                return <path d={`M${a.x + PAD},${a.y + PAD} V${trunkY + PAD} H${b.x + PAD} V${b.y + PAD}`} className="org-line live" />;
              })()}
            </svg>
            {org.map((n) => {
              const p = posOf(n);
              const floating = !n.parent && !org.some((c) => c.parent === n.id);
              const mem = linkedMember(n);
              return (
                <div key={n.id}
                  className={"org-node" + (link?.target === n.id ? " target" : "") + (live?.id === n.id ? " moving" : "") + (floating ? " floating" : "")}
                  style={{ left: p.x + PAD, top: p.y + PAD, width: NODEW, "--node-c": "var(--t-" + dispAccent(n) + ")" }}>
                  <div className="org-node-bar" />
                  <div className="org-node-hd">
                    <span className="org-grip" onPointerDown={(e) => startMove(e, n)} title="Drag to move"><Icon name="drag" size={15} /></span>
                    {mem && <span className="org-member-tag" title="Linked to a project member — edit name, role & colour on the Members page"><Icon name="users" size={11} /> member</span>}
                    {floating && <span className="org-float-tag mono">floating</span>}
                    <div className="org-actions no-print">
                      <button className="org-act" title="Add report under this role" onClick={() => addRole(n.id)}><Icon name="plus" size={13} /></button>
                      <button className="org-act" title="Remove" onClick={() => setDel(n.id)}><Icon name="x" size={13} /></button>
                    </div>
                  </div>
                  {mem ? (
                    <React.Fragment>
                      <div className="org-name org-name-ro" title="Edit on the Members page">{dispName(n)}</div>
                      <div className="org-role org-role-ro">{dispRole(n) || <span className="org-role-empty">No role set</span>}</div>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      <UI.Editable className="org-name" value={n.name} onChange={(v) => Store.patch("org", n.id, { name: v || "Unnamed" })} placeholder="Name" />
                      <UI.Editable className="org-role" value={n.role} onChange={(v) => Store.patch("org", n.id, { role: v })} placeholder="Role" />
                    </React.Fragment>
                  )}
                  <UI.Editable className="org-note" value={n.note} onChange={(v) => Store.patch("org", n.id, { note: v })} placeholder="responsibility…" />
                  <span className="org-link no-print" onPointerDown={(e) => startLink(e, n)} title="Drag onto a role to set who this reports to (or drop on empty to float)">
                    <Icon name="link" size={13} />
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {del && <UI.Confirm title="Remove this role?" body="Any direct reports move up to this role's manager (or become floating)." confirmLabel="Remove" onConfirm={() => removeNode(del)} onClose={() => setDel(null)} />}
    </div>
  );
}

Object.assign(window, { OrgChart });


// ======== catalogue.jsx ========
/* ============================================================
   PRODUCT CATALOGUE — local uploads + external shared-drive links
   Exposes window.Catalogue
   ============================================================ */
const { useState: useC, useEffect: useCE, useRef: useCR } = React;

const TYPE_FROM = (file) => {
  const n = (file.name || "").toLowerCase(), t = file.type || "";
  if (t.startsWith("image/")) return "image";
  if (t === "application/pdf" || n.endsWith(".pdf")) return "pdf";
  if (/\.(xlsx|xls|csv)$/.test(n) || t.includes("spreadsheet")) return "excel";
  if (/\.(pptx|ppt|key)$/.test(n) || t.includes("presentation")) return "slides";
  if (/\.(docx|doc|txt|md|rtf)$/.test(n) || t.includes("word")) return "doc";
  return "doc";
};
const TYPE_ICON = { image: "image", pdf: "doc", excel: "sheet", slides: "slides", doc: "file" };
const TYPE_LABEL = { image: "Image", pdf: "PDF", excel: "Spreadsheet", slides: "Presentation", doc: "Document" };
const fmtBytes = (b) => !b ? "" : b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(0) + " KB" : (b / 1048576).toFixed(1) + " MB";

function FileThumb({ product }) {
  const [url, setUrl] = useC(null);
  useCE(() => {
    let u;
    if (product.fileId && product.type === "image") {
      Store.files.get(product.fileId).then((blob) => { if (blob) { u = URL.createObjectURL(blob); setUrl(u); } });
    }
    return () => u && URL.revokeObjectURL(u);
  }, [product.fileId, product.type]);
  if (url) return <div className="cat-thumb img" style={{ backgroundImage: `url(${url})` }} />;
  const isExt = !!product.externalUrl;
  return (
    <div className={"cat-thumb t-" + product.type}>
      <Icon name={TYPE_ICON[product.type] || "file"} size={30} />
      {product.placeholder && <span className="cat-thumb-ph mono">placeholder</span>}
      {isExt && <span className="cat-thumb-ext mono"><Icon name="link" size={10} /> shared drive</span>}
    </div>
  );
}

function Catalogue() {
  const { products } = Store.useStore();
  const [open, setOpen] = useC(null);
  const [over, setOver] = useC(false);
  const [busy, setBusy] = useC(false);
  const [showAddLink, setShowAddLink] = useC(false);
  const inputRef = useCR(null);

  const ingest = async (files) => {
    setBusy(true);
    for (const file of files) {
      if (file.size > 30 * 1048576) { alert(`"${file.name}" is larger than 30 MB and was skipped.`); continue; }
      const fileId = Store.uid("file");
      try {
        await Store.files.put(fileId, file);
        Store.add("products", {
          id: Store.uid("p"), name: file.name, type: TYPE_FROM(file), fileId,
          size: file.size, taskIds: [], phase: null, date: new Date().toISOString().slice(0, 10), note: "", externalUrl: "",
        });
      } catch (e) { alert("Could not store file (browser storage may be full)."); }
    }
    setBusy(false);
  };
  const onDrop = (e) => { e.preventDefault(); setOver(false); if (e.dataTransfer.files.length) ingest([...e.dataTransfer.files]); };

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 560, fontSize: 14, lineHeight: 1.55 }}>
            Every deliverable produced by the project. Upload files locally, or <b>link to your shared drive</b> (SharePoint, OneDrive, Google Drive) so the whole team can access them.
          </p>
          <div className="row no-print" style={{ gap: 8 }}>
            <button className="btn" onClick={() => setShowAddLink(true)}><Icon name="link" size={15} /> Link from drive</button>
            <button className="btn btn-primary" onClick={() => inputRef.current.click()}><Icon name="upload" size={15} /> Upload file</button>
          </div>
          <input ref={inputRef} type="file" multiple hidden onChange={(e) => { ingest([...e.target.files]); e.target.value = ""; }} />
        </div>

        <div className={"cat-drop no-print" + (over ? " over" : "")}
          onDragOver={(e) => { e.preventDefault(); setOver(true); }}
          onDragLeave={(e) => { if (e.currentTarget === e.target) setOver(false); }}
          onDrop={onDrop} onClick={() => inputRef.current.click()}>
          <Icon name={busy ? "reset" : "upload"} size={22} className={busy ? "spin" : ""} />
          <div><b>{busy ? "Storing…" : "Drop files here"}</b> <span className="muted">or click to browse — PDF, Excel, slides, images (≤30 MB, stored locally)</span></div>
        </div>

        <div className="cat-grid">
          {products.map((p) => (
            <div key={p.id} className="cat-card panel" onClick={() => setOpen(p.id)}>
              <FileThumb product={p} />
              <div className="cat-body">
                <div className="cat-name">{p.name}</div>
                <div className="cat-meta">
                  <span className="chip" style={{ "--chip-c": "var(--t-" + ({ image: "pink", pdf: "red", excel: "green", slides: "amber", doc: "blue" }[p.type] || "blue") + ")" }}>{TYPE_LABEL[p.type]}</span>
                  {p.externalUrl && <span className="chip" style={{ "--chip-c": "var(--t-teal)" }}><Icon name="link" size={10} /> Drive</span>}
                  {p.size && !p.externalUrl ? <span className="muted mono" style={{ fontSize: 11 }}>{fmtBytes(p.size)}</span> : null}
                </div>
                <div className="cat-links">
                  <Icon name="link" size={12} />
                  <span className="muted" style={{ fontSize: 12 }}>{(p.taskIds || []).length} linked action{(p.taskIds || []).length === 1 ? "" : "s"}</span>
                </div>
              </div>
            </div>
          ))}
          {products.length === 0 && <div className="empty" style={{ gridColumn: "1/-1" }}><div className="serif">No deliverables yet</div>Upload a file or link one from your shared drive.</div>}
        </div>
      </div>
      {open && <ProductModal id={open} onClose={() => setOpen(null)} />}
      {showAddLink && <AddLinkModal onClose={() => setShowAddLink(false)} />}
    </div>
  );
}

/* ---------- Add external link modal ---------- */
function AddLinkModal({ onClose }) {
  const [name, setName] = useC("");
  const [url, setUrl] = useC("");
  const [type, setType] = useC("doc");
  const submit = () => {
    Store.add("products", {
      id: Store.uid("p"), name: name.trim() || "Untitled", type,
      fileId: null, size: 0, taskIds: [], phase: null,
      date: new Date().toISOString().slice(0, 10), note: "",
      externalUrl: url.trim(),
    });
    onClose();
  };
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 20 }}>Link from shared drive</div>
          <div className="muted" style={{ fontSize: 13 }}>Paste a URL from SharePoint, OneDrive, Google Drive, or any web link. The file stays on the drive — Atlas just links to it.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="field-label">File name</div>
        <input className="input" autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Migration Plan v2.xlsx" style={{ marginBottom: 14 }} />
        <div className="field-label">Shared drive URL</div>
        <input className="input mono" style={{ fontSize: 13, marginBottom: 14 }} value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://company.sharepoint.com/…" />
        <div className="field-label">Type</div>
        <div className="wrap">
          {Object.entries(TYPE_LABEL).map(([k, v]) => (
            <button key={k} className={"fpill" + (type === k ? " on" : "")} style={{ "--t-var": "var(--t-" + ({ image: "pink", pdf: "red", excel: "green", slides: "amber", doc: "blue" }[k] || "blue") + ")" }} onClick={() => setType(k)}>
              <Icon name={TYPE_ICON[k]} size={13} /> {v}
            </button>
          ))}
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <div className="grow" />
        <button className="btn btn-primary" disabled={!url.trim()} onClick={submit}><Icon name="link" size={15} /> Add link</button>
      </div>
    </UI.Modal>
  );
}

/* ---------- Product modal (updated for external links) ---------- */
function ProductModal({ id, onClose }) {
  const { tasks, phases } = Store.useStore();
  const p = Store.getState().products.find((x) => x.id === id);
  const [dlUrl, setDlUrl] = useC(null);
  useCE(() => {
    let u;
    if (p && p.fileId) Store.files.get(p.fileId).then((b) => { if (b) { u = URL.createObjectURL(b); setDlUrl(u); } });
    return () => u && URL.revokeObjectURL(u);
  }, [p?.fileId]);
  if (!p) return null;
  const set = (c) => Store.patch("products", id, c);
  const toggleTask = (tid) => { const cur = p.taskIds || []; set({ taskIds: cur.includes(tid) ? cur.filter((x) => x !== tid) : [...cur, tid] }); };
  const isExt = !!p.externalUrl;

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className={"cat-thumb t-" + p.type} style={{ width: 52, height: 52, flex: "0 0 52px", borderRadius: 10 }}>
          <Icon name={TYPE_ICON[p.type] || "file"} size={24} />
        </div>
        <div className="grow" style={{ minWidth: 0 }}>
          <UI.Editable className="cm-title" style={{ fontSize: 20 }} multiline value={p.name} onChange={(v) => set({ name: v || "Untitled" })} placeholder="File name" />
          <div className="muted mono" style={{ fontSize: 12 }}>
            {TYPE_LABEL[p.type]}
            {p.size && !isExt ? " · " + fmtBytes(p.size) : ""}
            {isExt ? " · shared drive link" : ""}
            {p.placeholder ? " · sample placeholder" : ""}
          </div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        {p.type === "image" && dlUrl && <img src={dlUrl} className="cat-preview" alt={p.name} />}

        {isExt && (
          <div style={{ marginBottom: 18 }}>
            <div className="field-label">Shared drive URL</div>
            <div className="cat-exturl">
              <Icon name="link" size={14} />
              <input className="input mono" style={{ fontSize: 12, flex: 1 }} value={p.externalUrl} onChange={(e) => set({ externalUrl: e.target.value })} placeholder="https://…" />
              <a className="btn btn-sm" href={p.externalUrl} target="_blank" rel="noopener noreferrer"><Icon name="arrowR" size={13} /> Open</a>
            </div>
          </div>
        )}

        <div className="field-label">Notes</div>
        <UI.Editable className="input" tag="div" multiline value={p.note} style={{ minHeight: 60, lineHeight: 1.5, marginBottom: 18 }} onChange={(v) => set({ note: v })} placeholder="What is this deliverable?" />
        <div className="row" style={{ gap: 16, marginBottom: 18 }}>
          <div className="grow"><div className="field-label">Phase</div><PickInline options={phases} value={p.phase} onChange={(v) => set({ phase: v })} /></div>
          <div><div className="field-label">Date</div><input className="datemini" type="date" value={p.date || ""} onChange={(e) => set({ date: e.target.value })} /></div>
        </div>
        <div className="field-label">Linked actions</div>
        <div className="prod-tasklist">
          {tasks.map((t) => (
            <button key={t.id} className={"prod-taskopt" + ((p.taskIds || []).includes(t.id) ? " on" : "")} onClick={() => toggleTask(t.id)}>
              <span className={"checkbox" + ((p.taskIds || []).includes(t.id) ? " on" : "")}>{(p.taskIds || []).includes(t.id) && <Icon name="check" size={11} />}</span>
              <span className="grow" style={{ textAlign: "left" }}>{t.title}</span>
              <span className={"status-dot s-" + t.status} />
            </button>
          ))}
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost btn-danger" onClick={() => { if (p.fileId) Store.files.del(p.fileId); Store.remove("products", id); onClose(); }}><Icon name="trash" size={15} /> Delete</button>
        <div className="grow" />
        {isExt && <a className="btn" href={p.externalUrl} target="_blank" rel="noopener noreferrer"><Icon name="arrowR" size={13} /> Open in drive</a>}
        {dlUrl && !isExt && <a className="btn" href={dlUrl} download={p.name}><Icon name="upload" size={15} style={{ transform: "rotate(180deg)" }} /> Download</a>}
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { Catalogue });


// ======== businesscase.jsx ========
/* ============================================================
   BUSINESS CASE — structured, printable, OPTIONAL sections
   User chooses which sections appear; numbering is dynamic.
   Exposes window.BusinessCase
   ============================================================ */
const { useState: useBC, useMemo: useBCM } = React;

const BC_SECTIONS = [
  { id: "situation", label: "Situation, challenges & opportunities" },
  { id: "risks", label: "Key risks" },
  { id: "outcomes", label: "Desired outcome & effects" },
  { id: "scope", label: "Scope" },
  { id: "asis", label: "As-is / To-be" },
  { id: "financial", label: "Financial justification" },
];
const ALL_IDS = BC_SECTIONS.map((s) => s.id);

function BusinessCase({ go }) {
  const s = Store.useStore();
  const bc = s.businessCase;
  const set = (c) => Store.setState((st) => ({ ...st, businessCase: { ...st.businessCase, ...c } }));
  const setList = (key, i, v) => set({ [key]: bc[key].map((x, idx) => (idx === i ? v : x)) });
  const addOutcome = () => set({ outcomes: [...(bc.outcomes || []), "New intended outcome"] });
  const removeOutcome = (i) => set({ outcomes: bc.outcomes.filter((_, idx) => idx !== i) });

  // which sections are active — stored alongside the BC
  const active = Array.isArray(bc._sections) ? bc._sections : ALL_IDS;
  const setActive = (ids) => set({ _sections: ids });
  const isOn = (id) => active.includes(id);
  const toggle = (id) => {
    if (isOn(id)) setActive(active.filter((x) => x !== id));
    else {
      // insert in canonical order
      const next = ALL_IDS.filter((x) => active.includes(x) || x === id);
      setActive(next);
    }
  };

  // dynamic numbering for active sections
  const num = useBCM(() => {
    const m = {}; let n = 1;
    ALL_IDS.forEach((id) => { if (active.includes(id)) { m[id] = n++; } });
    return m;
  }, [active]);

  const inactive = BC_SECTIONS.filter((s) => !isOn(s.id));

  const Persp = ({ k, label }) => (
    <div className="bc-persp">
      <div className="bc-persp-label">{label}</div>
      <UI.Editable className="bc-persp-text" tag="div" multiline value={bc[k]} onChange={(v) => set({ [k]: v })} placeholder="…" />
    </div>
  );
  const Effect = ({ k, label, hint }) => (
    <div className="bc-effect">
      <div className="bc-effect-hd">{label}</div>
      <div className="bc-effect-hint">{hint}</div>
      <UI.Editable className="bc-effect-text" tag="div" multiline value={bc[k]} onChange={(v) => set({ [k]: v })} placeholder="…" />
    </div>
  );
  const SectionRemove = ({ id }) => (
    <button className="btn btn-icon btn-ghost btn-danger no-print bc-remove" title="Remove this section" onClick={() => toggle(id)}><Icon name="x" size={15} /></button>
  );

  return (
    <div className="view-scroll">
      <div className="bc-doc">
        <header className="bc-head">
          <div className="bc-eyebrow eyebrow">Business Case</div>
          <UI.Editable className="bc-title serif" multiline value={s.meta?.project} onChange={(v) => Store.setState((st) => ({ ...st, meta: { ...st.meta, project: v } }))} />
          <div className="bc-byline mono">Prepared for the steering committee · Confidential</div>
        </header>

        {isOn("situation") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.situation} · Situation, challenges & opportunities</h2>
              <SectionRemove id="situation" />
            </div>
            <div className="bc-why">Why are we doing this? Why does it matter?</div>
            <UI.Editable className="bc-lead" tag="p" multiline value={bc.purpose} onChange={(v) => set({ purpose: v })} placeholder="Summarise the core reason this project exists." />
            <div className="bc-sub">Seen from each perspective</div>
            <div className="bc-persp-grid">
              <Persp k="perspOurs" label="Ours" />
              <Persp k="perspUsers" label="Users" />
              <Persp k="perspStakeholders" label="Other stakeholders" />
            </div>
            <div className="bc-twocol">
              <div>
                <div className="bc-sub"><Icon name="warn" size={14} /> Situations that create or worsen it</div>
                <UI.Editable className="bc-body" tag="p" multiline value={bc.worsening} onChange={(v) => set({ worsening: v })} placeholder="What makes the challenge harder or more urgent?" />
              </div>
              <div>
                <div className="bc-sub"><Icon name="bulb" size={14} /> Opportunities we can leverage</div>
                <UI.Editable className="bc-body" tag="p" multiline value={bc.opportunities} onChange={(v) => set({ opportunities: v })} placeholder="What can we take advantage of?" />
              </div>
            </div>
          </section>
        )}

        {isOn("risks") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.risks} · Project key risks</h2>
              <SectionRemove id="risks" />
            </div>
            <p className="bc-why" style={{ marginBottom: 14 }}>Pulled live from the Risks & mitigation register.</p>
            <RisksEmbed go={go} />
          </section>
        )}

        {isOn("outcomes") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.outcomes} · Desired outcome & effects</h2>
              <SectionRemove id="outcomes" />
            </div>
            <div className="bc-why">What does good look like? What tangible changes should we observe if this succeeds?</div>
            <ul className="bc-outcomes">
              {(bc.outcomes || []).map((o, i) => (
                <li key={i}>
                  <span className="bc-bullet"><Icon name="target" size={15} /></span>
                  <UI.Editable tag="span" className="grow" multiline value={o} onChange={(v) => setList("outcomes", i, v)} />
                  <button className="btn btn-icon btn-ghost btn-danger no-print" onClick={() => removeOutcome(i)}><Icon name="x" size={13} /></button>
                </li>
              ))}
            </ul>
            <button className="btn btn-sm btn-ghost no-print" onClick={addOutcome}><Icon name="plus" size={13} /> Add outcome / KPI</button>
            <div className="bc-effects">
              <Effect k="effProcess" label="Process" hint="What process changes are needed? New process, QMS / Cortex document?" />
              <Effect k="effSystem" label="System" hint="What system changes or functionalities? Which tools & templates?" />
              <Effect k="effBehaviour" label="Behaviour" hint="What should target users & key roles do, or be able to do?" />
              <Effect k="effLeadership" label="Leadership & Organisation" hint="Changes to leadership, structure, roles & training to succeed." />
            </div>
          </section>
        )}

        {isOn("scope") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.scope} · Scope</h2>
              <SectionRemove id="scope" />
            </div>
            <div className="bc-why">What's within the boundary, and what's explicitly outside?</div>
            <ScopeBoundaries compact />
            <button className="btn btn-sm no-print" style={{ marginTop: 12 }} onClick={() => go && go("scope")}><Icon name="scope" size={14} /> Open the Scope page</button>
          </section>
        )}

        {isOn("asis") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.asis} · As-is / To-be</h2>
              <SectionRemove id="asis" />
            </div>
            <div className="bc-why">Where we are today, and the target state once delivered. Tied to the scope above.</div>
            <AssessmentTable mode="full" />
          </section>
        )}

        {isOn("financial") && (
          <section className="bc-section">
            <div className="bc-section-hd">
              <h2 className="bc-h2 serif">{num.financial} · Financial justification</h2>
              <SectionRemove id="financial" />
            </div>
            <div className="bc-fin">
              {bc.financial.map((f, i) => (
                <div key={i} className="bc-fin-cell">
                  <div className="bc-fin-label">{f.label}</div>
                  <UI.Editable className="bc-fin-value serif" value={f.value} onChange={(v) => setList("financial", i, { ...f, value: v })} placeholder="—" />
                  <div className="bc-fin-note muted">{f.note}</div>
                </div>
              ))}
            </div>
            <UI.Editable className="bc-body" tag="p" multiline value={bc.justification} style={{ marginTop: 18 }} onChange={(v) => set({ justification: v })} placeholder="Why is this the right investment?" />
          </section>
        )}

        {/* add-section bar for inactive ones */}
        {inactive.length > 0 && (
          <div className="bc-add-bar no-print">
            <div className="bc-add-label">Add a section</div>
            <div className="bc-add-pills">
              {inactive.map((sec) => (
                <button key={sec.id} className="bc-add-pill" onClick={() => toggle(sec.id)}>
                  <Icon name="plus" size={13} /> {sec.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <footer className="bc-foot no-print">
          <button className="btn btn-dark" onClick={() => window.print()}><Icon name="print" size={15} /> Print / Save as PDF</button>
        </footer>
      </div>
    </div>
  );
}

Object.assign(window, { BusinessCase });


// ======== scope.jsx ========
/* ============================================================
   SCOPE — boundaries + shared As-is/To-be assessment
   Exposes window.ScopePage, window.ScopeBoundaries,
           window.AssessmentTable, window.RisksEmbed
   ============================================================ */
const { useState: useSc } = React;

/* ---------- scope boundaries (in / out) ---------- */
function ScopeBoundaries({ compact }) {
  const s = Store.useStore();
  const scope = s.scope || { inScope: [], outScope: [] };
  const setScope = (c) => Store.setState((st) => ({ ...st, scope: { ...(st.scope || { inScope: [], outScope: [] }), ...c } }));
  const addItem = (key) => setScope({ [key]: [...(scope[key] || []), "New item"] });
  const setItem = (key, i, v) => setScope({ [key]: scope[key].map((x, idx) => (idx === i ? v : x)) });
  const rmItem = (key, i) => setScope({ [key]: scope[key].filter((_, idx) => idx !== i) });

  const Col = ({ side, label, icon, items }) => (
    <div className={"scope-col " + side}>
      <div className="scope-col-hd">
        <span className="scope-col-ico"><Icon name={icon} size={15} /></span>
        <span className="scope-col-label">{label}</span>
        <span className="scope-col-n mono">{items.length}</span>
      </div>
      <div className="scope-items">
        {items.length === 0 && <div className="scope-empty">Nothing listed yet.</div>}
        {items.map((it, i) => (
          <div className="scope-item" key={i}>
            <span className="scope-bullet" />
            <UI.Editable className="scope-item-text" tag="div" multiline value={it} onChange={(v) => setItem(side === "in" ? "inScope" : "outScope", i, v)} placeholder="Describe a boundary item…" />
            <button className="chip-x no-print" onClick={() => rmItem(side === "in" ? "inScope" : "outScope", i)}><Icon name="x" size={12} /></button>
          </div>
        ))}
        <button className="scope-add no-print" onClick={() => addItem(side === "in" ? "inScope" : "outScope")}><Icon name="plus" size={13} /> Add</button>
      </div>
    </div>
  );

  return (
    <div className={"scope-grid" + (compact ? " compact" : "")}>
      <Col side="in" label="In scope" icon="check" items={scope.inScope || []} />
      <Col side="out" label="Out of scope" icon="x" items={scope.outScope || []} />
    </div>
  );
}

/* ---------- shared As-is / To-be assessment ---------- */
function AssessmentTable({ mode = "full", title }) {
  const s = Store.useStore();
  const rows = s.assessment || [];
  const setRows = (fn) => Store.setState((st) => ({ ...st, assessment: fn(st.assessment || []) }));
  const add = () => setRows((r) => [...r, { id: Store.uid("as"), area: "New area", asIs: "", toBe: "" }]);
  const patch = (id, c) => setRows((r) => r.map((x) => (x.id === id ? { ...x, ...c } : x)));
  const rm = (id) => setRows((r) => r.filter((x) => x.id !== id));
  const full = mode === "full";

  return (
    <div className="asis">
      <div className={"asis-head" + (full ? " full" : "")}>
        <div className="asis-h">Area</div>
        <div className="asis-h">As-is <span className="asis-h-sub">today</span></div>
        {full && <div className="asis-h tobe">To-be <span className="asis-h-sub">target</span></div>}
        <div />
      </div>
      {rows.length === 0 && <div className="asis-empty">No assessment areas yet. Add the dimensions you want to compare current vs. target state.</div>}
      {rows.map((row) => (
        <div className={"asis-row" + (full ? " full" : "")} key={row.id}>
          <div className="asis-area">
            <span className="asis-area-bar" />
            <UI.Editable className="asis-area-text" tag="div" multiline value={row.area} onChange={(v) => patch(row.id, { area: v || "Area" })} placeholder="Area" />
          </div>
          <UI.Editable className="asis-cell asis-cell-now" tag="div" multiline value={row.asIs} onChange={(v) => patch(row.id, { asIs: v })} placeholder="How is it today?" />
          {full && (
            <div className="asis-cell-wrap">
              <span className="asis-arrow no-print"><Icon name="arrowR" size={14} /></span>
              <UI.Editable className="asis-cell asis-cell-tobe" tag="div" multiline value={row.toBe} onChange={(v) => patch(row.id, { toBe: v })} placeholder="What should it become?" />
            </div>
          )}
          <button className="chip-x asis-del no-print" onClick={() => rm(row.id)}><Icon name="trash" size={13} /></button>
        </div>
      ))}
      <button className="btn btn-sm btn-ghost no-print" style={{ marginTop: 10 }} onClick={add}><Icon name="plus" size={13} /> Add area</button>
    </div>
  );
}

/* ---------- risks embedded read-only (for business case) ---------- */
function RisksEmbed({ go }) {
  const { risks, tasks } = Store.useStore();
  const sorted = [...risks].sort((a, b) => LVL[b.likelihood] * LVL[b.impact] - LVL[a.likelihood] * LVL[a.impact]);
  if (!risks.length) return <p className="bc-body muted">No risks captured yet. Add them on the Risks & mitigation page and they'll appear here.</p>;
  return (
    <div className="bc-risks">
      {sorted.map((r) => {
        const rem = remediation(r, tasks);
        return (
          <div key={r.id} className="bc-risk">
            <span className="risk-score sm" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="bc-risk-title">{r.title}</div>
              <div className="bc-risk-mit">{r.mitigation || "No mitigation recorded."}</div>
            </div>
            <div className="bc-risk-meta">
              <span className="chip" style={{ "--chip-c": RISK_STATUS[r.status]?.c }}><span className="chip-dot" />{RISK_STATUS[r.status]?.label}</span>
              {rem.state !== "none" && <span className="mono" style={{ fontSize: 10.5, color: REMED[rem.state].c }}>{REMED[rem.state].label}</span>}
            </div>
          </div>
        );
      })}
      {go && <button className="btn btn-sm no-print" style={{ marginTop: 12 }} onClick={() => go("risks")}><Icon name="shield" size={14} /> Manage risks</button>}
    </div>
  );
}

/* ---------- Scope page ---------- */
function ScopePage({ go }) {
  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <p className="muted" style={{ margin: "0 0 22px", maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
          Define the boundary of the work, then map where things are today (<b>as-is</b>) against where they need to be (<b>to-be</b>). This drives the business case and keeps the team aligned on what's in and out.
        </p>

        <section className="scope-section">
          <div className="scope-section-hd">
            <h2 className="scope-h serif">Boundaries</h2>
            <span className="muted" style={{ fontSize: 13 }}>What's inside the project, and what's explicitly not.</span>
          </div>
          <ScopeBoundaries />
        </section>

        <section className="scope-section">
          <div className="scope-section-hd">
            <h2 className="scope-h serif">As-is / To-be assessment</h2>
            <span className="muted" style={{ fontSize: 13 }}>Shared with Pre-analysis (as-is) and the Business case.</span>
          </div>
          <AssessmentTable mode="full" />
        </section>
      </div>
    </div>
  );
}

Object.assign(window, { ScopePage, ScopeBoundaries, AssessmentTable, RisksEmbed });


// ======== plans.jsx ========
/* ============================================================
   PLANS — Communication plan + Change management plan
   Exposes window.CommPlan, window.ChangePlan
   ============================================================ */
const { useState: usePl } = React;

/* shared: editable bulleted cell (array of strings) */
function BulletCell({ items, onChange, placeholder = "Add…", accent }) {
  const list = items || [];
  const set = (i, v) => onChange(list.map((x, idx) => (idx === i ? v : x)));
  const add = () => onChange([...list, ""]);
  const rm = (i) => onChange(list.filter((_, idx) => idx !== i));
  return (
    <div className="bullets">
      {list.map((it, i) => (
        <div className="bullet-row" key={i}>
          <span className="bullet-dot" style={accent ? { background: accent } : null} />
          <UI.Editable className="bullet-text" tag="div" multiline value={it} onChange={(v) => set(i, v)} placeholder={placeholder} />
          <button className="chip-x no-print" onClick={() => rm(i)}><Icon name="x" size={11} /></button>
        </div>
      ))}
      <button className="bullet-add no-print" onClick={add}><Icon name="plus" size={12} /> Add</button>
    </div>
  );
}

/* ============================================================
   COMMUNICATION PLAN
   ============================================================ */
const COMM_COLS = [
  { key: "audience", label: "Audience", w: "120px", kind: "text" },
  { key: "purpose", label: "Purpose of communication", w: "1.3fr", kind: "text" },
  { key: "messages", label: "Key messages", w: "2fr", kind: "bullets" },
  { key: "channels", label: "Channel(s)", w: "120px", kind: "bullets" },
  { key: "timing", label: "Timing", w: "190px", kind: "text" },
  { key: "owner", label: "Owner", w: "100px", kind: "text" },
  { key: "deliverables", label: "Deliverables", w: "1.5fr", kind: "bullets" },
];

function CommPlan() {
  const { commPlan, tasks } = Store.useStore();
  const [del, setDel] = usePl(null);
  const rows = commPlan || [];
  const cols = COMM_COLS.map((c) => c.w).join(" ") + " 78px";

  const addRow = () => Store.setState((st) => ({ ...st, commPlan: [...(st.commPlan || []), { id: Store.uid("cm"), audience: "New audience", purpose: "", messages: [], channels: [], timing: "", owner: "", deliverables: [] }] }));
  const patch = (id, c) => Store.setState((st) => ({ ...st, commPlan: st.commPlan.map((r) => (r.id === id ? { ...r, ...c } : r)) }));
  const remove = (id) => Store.setState((st) => ({ ...st, commPlan: st.commPlan.filter((r) => r.id !== id) }));
  const linkedTask = (rid) => (tasks || []).find((t) => t.sourceId === rid && t.origin === "comms");
  const toAction = (r) => {
    if (linkedTask(r.id)) return;
    Store.add("tasks", { id: Store.uid("t"), title: "Comms: " + (r.audience || "audience"), status: "backlog", tags: [], priority: "med", assignees: r.owner ? [r.owner] : [], desc: r.purpose || "", phase: null, category: null, origin: "comms", sourceId: r.id, start: r.date || "", end: r.date || "", deps: [] });
  };

  return (
    <div className="view-scroll">
      <div className="view-pad">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
            Who needs to hear what, through which channel and when — and who owns each message. One row per audience.
          </p>
          <button className="btn btn-primary no-print" onClick={addRow}><Icon name="plus" size={15} /> Add audience</button>
        </div>

        <div className="plan-table">
          <div className="plan-head" style={{ gridTemplateColumns: cols }}>
            {COMM_COLS.map((c) => <div key={c.key}>{c.label}</div>)}
            <div />
          </div>
          {rows.length === 0 && <div className="plan-empty">No audiences yet. Add the first one to start the plan.</div>}
          {rows.map((r) => (
            <div className="plan-row" style={{ gridTemplateColumns: cols }} key={r.id}>
              {COMM_COLS.map((c) => (
                <div className={"plan-cell" + (c.key === "audience" ? " plan-cell-key" : "")} key={c.key}>
                  {c.kind === "bullets"
                    ? <BulletCell items={r[c.key]} onChange={(v) => patch(r.id, { [c.key]: v })} />
                    : c.key === "timing"
                      ? (<div className="comm-timing">
                          <UI.Editable className="plan-text" tag="div" multiline value={r.timing} onChange={(v) => patch(r.id, { timing: v })} placeholder="e.g. 2 weeks before go-live" />
                          <label className="comm-date no-print">
                            <Icon name="calendar" size={12} />
                            <input type="date" value={r.date || ""} onChange={(e) => patch(r.id, { date: e.target.value })} />
                          </label>
                          {r.date && <div className="comm-date-badge print-only">📅 {r.date}</div>}
                        </div>)
                      : <UI.Editable className="plan-text" tag="div" multiline value={r[c.key]} onChange={(v) => patch(r.id, { [c.key]: v })} placeholder="…" />}
                </div>
              ))}
              <div className="plan-row-actions no-print">
                {linkedTask(r.id)
                  ? <span className="plan-linked" title="Already in the action list"><Icon name="check" size={12} /> In actions</span>
                  : <button className="plan-toaction" title="Add this communication to the action list" onClick={() => toAction(r)}><Icon name="plus" size={12} /> Action</button>}
                <button className="chip-x plan-del" onClick={() => setDel(r.id)}><Icon name="trash" size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {del && <UI.Confirm title="Remove audience row?" body="This deletes the communication-plan row." onConfirm={() => remove(del)} onClose={() => setDel(null)} />}
    </div>
  );
}

/* ============================================================
   CHANGE MANAGEMENT PLAN — grouped tables
   ============================================================ */
const CHG_COLS = "150px 1.6fr 1.5fr 110px 78px";
const CHG_ACCENTS = ["indigo", "teal", "purple", "amber", "green", "blue", "pink", "red"];

function ChangePlan() {
  const { changePlan, tasks } = Store.useStore();
  const groups = (changePlan && changePlan.groups) || [];
  const [del, setDel] = usePl(null);
  const linkedTask = (rid) => (tasks || []).find((t) => t.sourceId === rid && t.origin === "change");
  const toAction = (r, groupLabel) => {
    if (linkedTask(r.id)) return;
    Store.add("tasks", { id: Store.uid("t"), title: r.component || "Change activity", status: "backlog", tags: [], priority: "med", assignees: r.owner ? [r.owner] : [], desc: r.description || "", phase: null, category: null, origin: "change", sourceId: r.id, start: "", end: "", deps: [] });
  };

  const setGroups = (fn) => Store.setState((st) => ({ ...st, changePlan: { ...(st.changePlan || {}), groups: fn((st.changePlan && st.changePlan.groups) || []) } }));
  const addGroup = () => setGroups((g) => [...g, { id: Store.uid("cg"), label: "New group", accent: CHG_ACCENTS[g.length % CHG_ACCENTS.length], rows: [{ id: Store.uid("cr"), component: "New component", description: "", deliverables: [], owner: "" }] }]);
  const patchGroup = (gid, c) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, ...c } : x)));
  const rmGroup = (gid) => setGroups((g) => g.filter((x) => x.id !== gid));
  const addRow = (gid) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, rows: [...x.rows, { id: Store.uid("cr"), component: "New component", description: "", deliverables: [], owner: "" }] } : x)));
  const patchRow = (gid, rid, c) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, rows: x.rows.map((r) => (r.id === rid ? { ...r, ...c } : r)) } : x)));
  const rmRow = (gid, rid) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, rows: x.rows.filter((r) => r.id !== rid) } : x)));

  return (
    <div className="view-scroll">
      <div className="view-pad">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
            The activities that move people to the new way of working — grouped by audience. Each component has a description, deliverables and an owner.
          </p>
          <button className="btn btn-primary no-print" onClick={addGroup}><Icon name="plus" size={15} /> Add group</button>
        </div>

        {groups.length === 0 && <div className="empty"><div className="serif">No change groups yet</div>Add a group (e.g. a team or audience) to start the plan.</div>}

        {groups.map((g) => (
          <div className="chg-group" key={g.id} style={{ "--chg-c": "var(--t-" + (g.accent || "indigo") + ")" }}>
            <div className="chg-rail">
              <UI.Editable className="chg-rail-label" tag="div" multiline value={g.label} onChange={(v) => patchGroup(g.id, { label: v || "Group" })} placeholder="Group" />
              <div className="chg-rail-actions no-print">
                <button className="chg-rail-btn" title="Change colour" onClick={() => patchGroup(g.id, { accent: CHG_ACCENTS[(CHG_ACCENTS.indexOf(g.accent) + 1) % CHG_ACCENTS.length] })}><Icon name="tag" size={13} /></button>
                <button className="chg-rail-btn" title="Remove group" onClick={() => setDel({ type: "group", gid: g.id })}><Icon name="trash" size={13} /></button>
              </div>
            </div>
            <div className="chg-table">
              <div className="chg-head" style={{ gridTemplateColumns: CHG_COLS }}>
                <div>Component</div><div>Description</div><div>Deliverables</div><div>Owner</div><div />
              </div>
              {g.rows.map((r) => (
                <div className="chg-row" style={{ gridTemplateColumns: CHG_COLS }} key={r.id}>
                  <div className="plan-cell plan-cell-key"><UI.Editable className="plan-text" tag="div" multiline value={r.component} onChange={(v) => patchRow(g.id, r.id, { component: v })} placeholder="Component" /></div>
                  <div className="plan-cell"><UI.Editable className="plan-text" tag="div" multiline value={r.description} onChange={(v) => patchRow(g.id, r.id, { description: v })} placeholder="What is it?" /></div>
                  <div className="plan-cell"><BulletCell items={r.deliverables} onChange={(v) => patchRow(g.id, r.id, { deliverables: v })} accent={"var(--chg-c)"} /></div>
                  <div className="plan-cell"><UI.Editable className="plan-text" tag="div" multiline value={r.owner} onChange={(v) => patchRow(g.id, r.id, { owner: v })} placeholder="—" /></div>
                  <div className="plan-row-actions no-print">
                    {linkedTask(r.id)
                      ? <span className="plan-linked" title="Already in the action list"><Icon name="check" size={12} /> In actions</span>
                      : <button className="plan-toaction" title="Add this change activity to the action list" onClick={() => toAction(r, g.label)}><Icon name="plus" size={12} /> Action</button>}
                    <button className="chip-x plan-del" onClick={() => setDel({ type: "row", gid: g.id, rid: r.id })}><Icon name="trash" size={13} /></button>
                  </div>
                </div>
              ))}
              <button className="chg-addrow no-print" onClick={() => addRow(g.id)}><Icon name="plus" size={13} /> Add component</button>
            </div>
          </div>
        ))}
      </div>
      {del && <UI.Confirm title={del.type === "group" ? "Remove group?" : "Remove component?"} body={del.type === "group" ? "This deletes the group and all its components." : "This deletes the component row."} onConfirm={() => del.type === "group" ? rmGroup(del.gid) : rmRow(del.gid, del.rid)} onClose={() => setDel(null)} />}
    </div>
  );
}

Object.assign(window, { CommPlan, ChangePlan });


// ======== taxonomy.jsx ========
/* ============================================================
   TAXONOMY EDITOR — edit categories, tags, phases
   Exposes window.TaxonomyEditor
   ============================================================ */
const { useState: useTx } = React;

const TAX_COLORS = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];

function TaxonomyEditor({ onClose }) {
  const s = Store.useStore();
  const [tab, setTab] = useTx("categories");

  const TABS = [
    { id: "categories", label: "Categories", key: "categories", hint: "Group actions by theme (Platform, Migration, etc.)" },
    { id: "tags", label: "Tags", key: "tags", hint: "Label tasks with skills or topics (Frontend, Security, etc.)" },
    { id: "phases", label: "Phases", key: "phases", hint: "Timeline phases (Discovery, Design, Build, Launch)" },
    { id: "custom", label: "Custom fields", key: "customFields", hint: "Extra fields shown on every task (text, number, date, dropdown, checkbox)." },
  ];
  const cur = TABS.find((t) => t.id === tab);

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="tag" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Edit taxonomy</div>
          <div className="muted" style={{ fontSize: 13 }}>Add, rename, recolour or remove categories, tags and phases.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="sync-tabs">
        {TABS.map((t) => (
          <button key={t.id} className={tab === t.id ? "on" : ""} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="modal-bd">
        <p className="muted" style={{ fontSize: 13, lineHeight: 1.5, margin: "0 0 16px" }}>{cur.hint}</p>
        {tab === "custom" ? <CustomFieldsEditor fields={s.customFields || []} /> : <TaxList storeKey={cur.key} items={s[cur.key] || []} />}
      </div>
      <div className="modal-ft">
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

/* custom-field definitions editor (label + type + select options) */
function CustomFieldsEditor({ fields }) {
  const TYPES = [{ id: "text", label: "Text" }, { id: "number", label: "Number" }, { id: "date", label: "Date" }, { id: "select", label: "Dropdown" }, { id: "checkbox", label: "Checkbox" }];
  const add = () => Store.update("customFields", (arr) => [...arr, { id: Store.uid("cf"), label: "New field", type: "text", options: [] }]);
  const patch = (id, c) => Store.update("customFields", (arr) => arr.map((x) => (x.id === id ? { ...x, ...c } : x)));
  const remove = (id) => {
    Store.update("customFields", (arr) => arr.filter((x) => x.id !== id));
    Store.update("tasks", (arr) => arr.map((t) => { if (!t.custom || !(id in t.custom)) return t; const c = { ...t.custom }; delete c[id]; return { ...t, custom: c }; }));
  };
  return (
    <div className="cf-defs">
      {fields.length === 0 && <div className="tax-empty">No custom fields yet. Add one below — it appears on every task.</div>}
      {fields.map((f) => (
        <div key={f.id} className="cf-def panel">
          <div className="cf-def-top">
            <UI.Editable className="cf-def-name" noPencil value={f.label} onChange={(v) => patch(f.id, { label: v || "Field" })} placeholder="Field name" />
            <select className="cf-input" style={{ maxWidth: 130 }} value={f.type} onChange={(e) => patch(f.id, { type: e.target.value })}>
              {TYPES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
            </select>
            <button className="tax-act tax-del" onClick={() => remove(f.id)} title="Delete field"><Icon name="trash" size={13} /></button>
          </div>
          {f.type === "select" && (
            <input className="cf-input" style={{ width: "100%", marginTop: 8 }} value={(f.options || []).join(", ")}
              onChange={(e) => patch(f.id, { options: e.target.value.split(",").map((x) => x.trim()).filter(Boolean) })}
              placeholder="Dropdown options, comma-separated" />
          )}
        </div>
      ))}
      <button className="btn btn-sm btn-ghost" style={{ marginTop: 8 }} onClick={add}><Icon name="plus" size={13} /> Add field</button>
    </div>
  );
}

function TaxList({ storeKey, items }) {
  const [confirm, setConfirm] = useTx(null);

  const add = () => {
    const id = Store.uid(storeKey.slice(0, 2));
    Store.update(storeKey, (arr) => [...arr, { id, label: "New " + storeKey.slice(0, -1), color: TAX_COLORS[arr.length % TAX_COLORS.length] }]);
  };
  const patch = (id, changes) => {
    Store.update(storeKey, (arr) => arr.map((x) => (x.id === id ? { ...x, ...changes } : x)));
  };
  const remove = (id) => {
    Store.update(storeKey, (arr) => arr.filter((x) => x.id !== id));
    // clean up references in tasks
    if (storeKey === "categories") {
      Store.update("tasks", (arr) => arr.map((t) => t.category === id ? { ...t, category: null } : t));
      Store.update("milestones", (arr) => arr.map((m) => m.category === id ? { ...m, category: null } : m));
      Store.update("findings", (arr) => (arr || []).map((f) => f.category === id ? { ...f, category: null } : f));
    } else if (storeKey === "tags") {
      Store.update("tasks", (arr) => arr.map((t) => ({ ...t, tags: (t.tags || []).filter((x) => x !== id) })));
    } else if (storeKey === "phases") {
      Store.update("tasks", (arr) => arr.map((t) => t.phase === id ? { ...t, phase: null } : t));
      Store.update("products", (arr) => (arr || []).map((p) => p.phase === id ? { ...p, phase: null } : p));
    }
    setConfirm(null);
  };
  const moveUp = (i) => {
    if (i === 0) return;
    Store.update(storeKey, (arr) => { const n = [...arr]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; return n; });
  };
  const moveDown = (i) => {
    Store.update(storeKey, (arr) => { if (i >= arr.length - 1) return arr; const n = [...arr]; [n[i], n[i + 1]] = [n[i + 1], n[i]]; return n; });
  };

  return (
    <div className="tax-list">
      {items.length === 0 && <div className="tax-empty">No {storeKey} yet. Add one below.</div>}
      {items.map((item, i) => (
        <div key={item.id} className="tax-row">
          <div className="tax-color-pick">
            {TAX_COLORS.map((c) => (
              <button key={c} className={"tax-swatch" + (item.color === c ? " on" : "")} style={{ background: "var(--t-" + c + ")" }} onClick={() => patch(item.id, { color: c })} />
            ))}
          </div>
          <UI.Editable className="tax-name" noPencil value={item.label} onChange={(v) => patch(item.id, { label: v || "Unnamed" })} placeholder="Name" />
          <div className="tax-actions">
            <button className="tax-act" onClick={() => moveUp(i)} disabled={i === 0} title="Move up"><Icon name="chevD" size={13} style={{ transform: "rotate(180deg)" }} /></button>
            <button className="tax-act" onClick={() => moveDown(i)} disabled={i === items.length - 1} title="Move down"><Icon name="chevD" size={13} /></button>
            <button className="tax-act tax-del" onClick={() => setConfirm(item.id)} title="Delete"><Icon name="trash" size={13} /></button>
          </div>
        </div>
      ))}
      <button className="btn btn-sm btn-ghost" style={{ marginTop: 8 }} onClick={add}>
        <Icon name="plus" size={13} /> Add {storeKey.slice(0, -1)}
      </button>
      {confirm && (
        <UI.Confirm
          title={"Delete " + storeKey.slice(0, -1) + "?"}
          body={"Tasks using this " + storeKey.slice(0, -1) + " will become uncategorised. This cannot be undone."}
          confirmLabel="Delete"
          onConfirm={() => remove(confirm)}
          onClose={() => setConfirm(null)}
        />
      )}
    </div>
  );
}

Object.assign(window, { TaxonomyEditor });


// ======== glossary.jsx ========
/* ============================================================
   GLOSSARY — terms + definitions, with global text highlighting
   Exposes window.Glossary, window.setupGlossaryHighlighter
   ============================================================ */
const { useState: useG } = React;

function Glossary() {
  const s = Store.useStore();
  const terms = s.glossary || [];
  const [q, setQ] = useG("");
  const [del, setDel] = useG(null);
  const [bulk, setBulk] = useG(false);

  const add = () => {
    const id = Store.uid("gl");
    Store.add("glossary", { id, term: "New term", definition: "" });
  };
  const patch = (id, c) => Store.patch("glossary", id, c);

  const sorted = [...terms].sort((a, b) => (a.term || "").localeCompare(b.term || ""));
  const filtered = q
    ? sorted.filter((t) => (t.term + " " + (t.definition || "")).toLowerCase().includes(q.toLowerCase()))
    : sorted;

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 600, fontSize: 14, lineHeight: 1.55 }}>
            Project-specific words and their meaning. Every term added here is automatically highlighted everywhere it appears in this project — hover any underlined word to read the definition.
          </p>
          <div className="row no-print" style={{ gap: 8 }}>
            <button className="btn" onClick={() => setBulk(true)}><Icon name="list" size={15} /> Paste list</button>
            <button className="btn btn-primary" onClick={add}><Icon name="plus" size={15} /> Add term</button>
          </div>
        </div>

        <div className="filterbar no-print" style={{ padding: 0, border: "none", background: "transparent", marginBottom: 16 }}>
          <div className="search-box" style={{ minWidth: 260 }}>
            <Icon name="search" size={15} />
            <input placeholder="Search terms…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
        </div>

        <div className="gloss-list">
          {filtered.length === 0 && (
            <div className="empty">
              <div className="serif">{q ? "No matches" : "No terms yet"}</div>
              {q ? "Try a different search." : (
                <div>
                  <p style={{ margin: "4px 0 14px" }}>Add the first term to get started — hover-tooltips appear everywhere you use it.</p>
                  <div className="row" style={{ gap: 8, justifyContent: "center" }}>
                    <button className="btn" onClick={() => setBulk(true)}><Icon name="list" size={14} /> Paste a list</button>
                    <button className="btn btn-primary" onClick={add}><Icon name="plus" size={14} /> Add one</button>
                  </div>
                </div>
              )}
            </div>
          )}
          {filtered.map((t) => (
            <div key={t.id} className="gloss-row panel no-gloss">
              <div className="gloss-row-main">
                <UI.Editable className="gloss-term-text serif" value={t.term} onChange={(v) => patch(t.id, { term: v || "(unnamed)" })} placeholder="Term" />
                <UI.Editable className="gloss-def" tag="div" multiline value={t.definition} onChange={(v) => patch(t.id, { definition: v })} placeholder="What does this term mean in this project?" />
              </div>
              <button className="btn btn-icon btn-ghost btn-danger no-print gloss-del" title="Remove" onClick={() => setDel(t)}><Icon name="trash" size={14} /></button>
            </div>
          ))}
        </div>
      </div>
      {del && (
        <UI.Confirm
          title="Remove term?"
          body={`Remove "${del.term}" from the glossary?`}
          confirmLabel="Remove"
          onConfirm={() => { Store.remove("glossary", del.id); setDel(null); }}
          onClose={() => setDel(null)}
        />
      )}
      {bulk && <BulkImport onClose={() => setBulk(false)} existing={terms} />}
    </div>
  );
}

/* ============================================================
   BULK IMPORT — paste a comma-separated list of terms
   Accepts:
     term1, term2, term3                   (just terms)
     term: definition, term: definition    (with definitions)
     One per line is fine too — separator can be comma or newline.
   ============================================================ */
function parseBulk(text) {
  if (!text) return [];
  // split on newlines first, then on commas — but only on commas NOT inside a definition.
  // simple heuristic: a "term: definition" entry ends at the next ", " followed by capital letter
  // safer approach: split on newlines OR semicolons OR commas-followed-by-space-and-letter
  const entries = text
    .split(/[\n;]+|,(?=\s*[A-Za-z])/)
    .map((s) => s.trim())
    .filter(Boolean);
  return entries.map((raw) => {
    // first colon, dash or en-dash separates term from definition
    const m = raw.match(/^([^:\u2013\u2014\-]+?)\s*[:\u2013\u2014\-]\s*(.+)$/);
    if (m) return { term: m[1].trim(), definition: m[2].trim() };
    return { term: raw.trim(), definition: "" };
  }).filter((e) => e.term);
}

function BulkImport({ onClose, existing }) {
  const [text, setText] = useG("");
  const [skipDupes, setSkipDupes] = useG(true);
  const parsed = parseBulk(text);
  const knownLower = new Set((existing || []).map((t) => (t.term || "").toLowerCase()));
  const newOnes = parsed.filter((p) => !skipDupes || !knownLower.has(p.term.toLowerCase()));
  const dupeCount = parsed.length - newOnes.length;

  const submit = () => {
    newOnes.forEach((p) => {
      Store.add("glossary", { id: Store.uid("gl"), term: p.term, definition: p.definition });
    });
    onClose();
  };

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="list" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Add many terms at once</div>
          <div className="muted" style={{ fontSize: 13 }}>Paste a comma-separated list. Add definitions with <span className="mono">term: definition</span>.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="field-label">Terms</div>
        <textarea
          className="textarea"
          rows={6}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={"SSO, ETL, UAT, CI/CD\n\nor with definitions, one per line:\nSSO: Single sign-on across all tools\nETL: Extract, Transform, Load pipeline\nhypercare: Intensive support window after go-live"}
          style={{ fontFamily: "var(--font-mono)", fontSize: 13, lineHeight: 1.55 }}
          autoFocus
        />
        <label className="sync-check" style={{ marginTop: 10 }}>
          <input type="checkbox" checked={skipDupes} onChange={(e) => setSkipDupes(e.target.checked)} />
          Skip terms that already exist
        </label>
        {parsed.length > 0 && (
          <div className="bulk-preview">
            <div className="bulk-preview-hd">
              Will add <b>{newOnes.length}</b> term{newOnes.length === 1 ? "" : "s"}
              {dupeCount > 0 && <span className="muted"> · {dupeCount} duplicate{dupeCount === 1 ? "" : "s"} skipped</span>}
            </div>
            <div className="bulk-preview-list">
              {newOnes.slice(0, 8).map((p, i) => (
                <div key={i} className="bulk-preview-item">
                  <span className="bulk-preview-term">{p.term}</span>
                  {p.definition && <span className="bulk-preview-def">— {p.definition}</span>}
                </div>
              ))}
              {newOnes.length > 8 && <div className="muted" style={{ fontSize: 12 }}>…and {newOnes.length - 8} more</div>}
            </div>
          </div>
        )}
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <div className="grow" />
        <button className="btn btn-primary" disabled={newOnes.length === 0} onClick={submit}>
          <Icon name="plus" size={15} /> Add {newOnes.length || ""} term{newOnes.length === 1 ? "" : "s"}
        </button>
      </div>
    </UI.Modal>
  );
}

/* ============================================================
   GLOBAL HIGHLIGHTER — walks the DOM and wraps glossary terms
   ============================================================ */
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

let glossPending = false;
let glossObserver = null;
let glossTooltipEl = null;
let lastGlossSig = "";

function ensureGlossTooltip() {
  if (glossTooltipEl) return glossTooltipEl;
  const el = document.createElement("div");
  el.className = "gloss-tip";
  el.style.display = "none";
  document.body.appendChild(el);
  glossTooltipEl = el;

  document.addEventListener("pointerover", (e) => {
    const mark = e.target.closest && e.target.closest(".gloss-mark");
    if (!mark) return;
    const def = mark.dataset.glossDef;
    const term = mark.dataset.glossTerm;
    if (!def) return;
    el.innerHTML = '<div class="gloss-tip-term">' + term + '</div><div class="gloss-tip-def">' + def.replace(/&/g, "&amp;").replace(/</g, "&lt;") + "</div>";
    el.style.display = "block";
    const r = mark.getBoundingClientRect();
    const w = el.offsetWidth, h = el.offsetHeight;
    let left = r.left + r.width / 2 - w / 2;
    let top = r.top - h - 8;
    if (top < 8) top = r.bottom + 8;
    left = Math.max(8, Math.min(window.innerWidth - w - 8, left));
    el.style.left = left + "px";
    el.style.top = top + "px";
  });
  document.addEventListener("pointerout", (e) => {
    const mark = e.target.closest && e.target.closest(".gloss-mark");
    if (mark && (!e.relatedTarget || !mark.contains(e.relatedTarget))) {
      el.style.display = "none";
    }
  });
  document.addEventListener("scroll", () => { el.style.display = "none"; }, true);
  return el;
}

function scanAndMark() {
  const state = (Store.getState && Store.getState()) || null;
  if (!state) return;
  const raw = (state.glossary || []).filter((g) => g.term && g.term.trim());
  // sort longest first so multi-word terms win over single-word substrings
  const terms = raw.slice().sort((a, b) => b.term.length - a.term.length);

  // remove existing marks if no terms
  const sig = terms.map((t) => t.term + "::" + (t.definition || "")).join("|");
  if (sig === lastGlossSig && document.querySelector(".gloss-mark")) {
    return; // nothing changed and marks already in place
  }
  lastGlossSig = sig;

  // unwrap any existing marks first (definitions might have changed)
  document.querySelectorAll(".gloss-mark").forEach((m) => {
    const parent = m.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(m.textContent), m);
    parent.normalize();
  });

  if (!terms.length) return;

  const defMap = new Map();
  terms.forEach((t) => defMap.set(t.term.toLowerCase(), t.definition || ""));
  const pattern = new RegExp("\\b(" + terms.map((t) => escapeRegex(t.term)).join("|") + ")\\b", "gi");

  const root = document.getElementById("root");
  if (!root) return;
  const SKIP_TAGS = new Set(["INPUT", "TEXTAREA", "SELECT", "SCRIPT", "STYLE", "OPTION", "BUTTON", "H1", "H2", "H3", "H4", "H5", "H6"]);
  // titles/headings are excluded from highlighting (glossary marks belong in body copy)
  const TITLE_SEL = 'h1,h2,h3,h4,h5,h6,[class*="title"],[class*="-name"],[class*="eyebrow"],[class*="-label"]';

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      let el = node.parentElement;
      while (el && el !== root) {
        if (el.isContentEditable) return NodeFilter.FILTER_REJECT;
        if (el.classList) {
          if (el.classList.contains("gloss-mark")) return NodeFilter.FILTER_REJECT;
          if (el.classList.contains("no-gloss")) return NodeFilter.FILTER_REJECT;
          if (el.classList.contains("gloss-tip")) return NodeFilter.FILTER_REJECT;
        }
        if (SKIP_TAGS.has(el.tagName)) return NodeFilter.FILTER_REJECT;
        if (el.matches && el.matches(TITLE_SEL)) return NodeFilter.FILTER_REJECT;
        el = el.parentElement;
      }
      pattern.lastIndex = 0;
      return pattern.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    },
  });

  const targets = [];
  let n;
  while ((n = walker.nextNode())) targets.push(n);

  targets.forEach((node) => {
    const text = node.nodeValue;
    pattern.lastIndex = 0;
    const parts = [];
    let last = 0;
    let m;
    while ((m = pattern.exec(text)) !== null) {
      if (m.index > last) parts.push({ t: text.slice(last, m.index), match: false });
      parts.push({ t: m[0], match: true });
      last = m.index + m[0].length;
    }
    if (last < text.length) parts.push({ t: text.slice(last), match: false });
    if (parts.length <= 1) return;

    const frag = document.createDocumentFragment();
    parts.forEach((part) => {
      if (part.match) {
        const span = document.createElement("span");
        span.className = "gloss-mark";
        span.dataset.glossTerm = part.t;
        span.dataset.glossDef = defMap.get(part.t.toLowerCase()) || "";
        span.textContent = part.t;
        frag.appendChild(span);
      } else {
        frag.appendChild(document.createTextNode(part.t));
      }
    });
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
  });
}

function scheduleScan() {
  if (glossPending) return;
  glossPending = true;
  setTimeout(() => {
    glossPending = false;
    try { scanAndMark(); } catch (e) { /* swallow */ }
  }, 250);
}

function setupGlossaryHighlighter() {
  ensureGlossTooltip();
  // initial scan after first paint
  scheduleScan();
  // observe DOM changes (React rerenders, navigation)
  if (glossObserver) glossObserver.disconnect();
  const root = document.getElementById("root");
  if (!root) return;
  glossObserver = new MutationObserver((mutations) => {
    // ignore mutations that ONLY touched gloss spans
    let real = false;
    for (const m of mutations) {
      if (m.target && m.target.classList && m.target.classList.contains("gloss-mark")) continue;
      real = true;
      break;
    }
    if (real) {
      // force re-evaluation against signature each call
      lastGlossSig = "";
      scheduleScan();
    }
  });
  glossObserver.observe(root, { childList: true, subtree: true, characterData: true });
}

Object.assign(window, { Glossary, setupGlossaryHighlighter });


// ======== intake.jsx ========
/* ============================================================
   INTAKE WIZARD — guided setup for a NEW project.
   Sizes the project, then asks scope + business-case questions
   (many yes/no) and auto-populates the relevant sections.
   Exposes window.IntakeWizard
   ============================================================ */
const { useState: useIn } = React;

const SIZES = [
  { id: "small", label: "Small", blurb: "A few weeks · one team · low risk & budget.", detail: "Light-touch: a clear purpose, a scope and a handful of actions. Most heavy sections stay optional." },
  { id: "medium", label: "Medium", blurb: "1–3 months · a couple of teams · several stakeholders.", detail: "A full business case, scope and as-is/to-be, plus communication and a light change plan." },
  { id: "large", label: "Large", blurb: "3+ months · multiple departments · high risk & budget.", detail: "Formal governance: business case, financials, risks, stakeholder map, change management and steering." },
];

const SIZE_DEFAULTS = {
  small:  { hasProblem: true, fromUsers: false, fromStakeholders: false, hasOpportunities: false, needProcess: false, needSystem: true, needBehaviour: false, needLeadership: false, hasFinancials: false, hasRisks: false },
  medium: { hasProblem: true, fromUsers: true, fromStakeholders: true, hasOpportunities: true, needProcess: true, needSystem: true, needBehaviour: true, needLeadership: false, hasFinancials: true, hasRisks: true },
  large:  { hasProblem: true, fromUsers: true, fromStakeholders: true, hasOpportunities: true, needProcess: true, needSystem: true, needBehaviour: true, needLeadership: true, hasFinancials: true, hasRisks: true },
};

function YN({ value, onChange, label, hint }) {
  return (
    <div className={"yn" + (value ? " on" : "")}>
      <div className="yn-main">
        <div className="yn-label">{label}</div>
        {hint && <div className="yn-hint">{hint}</div>}
      </div>
      <div className="yn-seg">
        <button className={value ? "on" : ""} onClick={() => onChange(true)}>Yes</button>
        <button className={!value ? "on" : ""} onClick={() => onChange(false)}>No</button>
      </div>
    </div>
  );
}

function Reveal({ show, children }) {
  if (!show) return null;
  return <div className="intake-reveal">{children}</div>;
}

function IntakeWizard({ onClose, onDone }) {
  const s = Store.getState();
  const [step, setStep] = useIn(0);
  const [a, setA] = useIn({
    size: "", purpose: "", problem: "",
    usersText: "", stakeText: "", oppText: "",
    outcomes: "", processText: "", systemText: "", behaviourText: "", leadershipText: "",
    costOneOff: "", costRun: "", saving: "", payback: "",
    inScope: "", outScope: "", risksText: "",
    ...SIZE_DEFAULTS.medium,
  });
  const set = (c) => setA((p) => ({ ...p, ...c }));
  const pickSize = (id) => set({ size: id, ...SIZE_DEFAULTS[id] });

  const STEPS = ["Size", "Situation", "Outcome & effects", "Financials", "Scope & risks"];
  const lines = (t) => (t || "").split("\n").map((x) => x.trim()).filter(Boolean);

  const finish = () => {
    Store.setState((st) => ({
      ...st,
      meta: { ...st.meta, size: a.size || "medium" },
      businessCase: {
        ...st.businessCase,
        purpose: a.purpose || st.businessCase.purpose,
        problem: a.hasProblem ? a.problem : "",
        perspUsers: a.fromUsers ? a.usersText : "",
        perspStakeholders: a.fromStakeholders ? a.stakeText : "",
        opportunities: a.hasOpportunities ? a.oppText : "",
        outcomes: lines(a.outcomes).length ? lines(a.outcomes) : st.businessCase.outcomes,
        effProcess: a.needProcess ? a.processText : "",
        effSystem: a.needSystem ? a.systemText : "",
        effBehaviour: a.needBehaviour ? a.behaviourText : "",
        effLeadership: a.needLeadership ? a.leadershipText : "",
        financial: a.hasFinancials
          ? [
              { label: "Programme cost (one-off)", value: a.costOneOff, note: "" },
              { label: "Annual run cost", value: a.costRun, note: "" },
              { label: "Annual saving", value: a.saving, note: "" },
              { label: "Payback period", value: a.payback, note: "" },
            ]
          : st.businessCase.financial,
      },
      scope: { inScope: lines(a.inScope), outScope: lines(a.outScope) },
      risks: a.hasRisks
        ? lines(a.risksText).map((t) => ({ id: Store.uid("r"), title: t, likelihood: "med", impact: "med", mitigation: "", owner: "", status: "open", taskIds: [] }))
        : st.risks,
    }));
    onDone && onDone();
  };

  const canNext = step !== 0 || !!a.size;

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--accent)" }}><Icon name="scope" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Set up “{s?.meta?.project || "project"}”</div>
          <div className="muted" style={{ fontSize: 13 }}>Answer what's relevant — skip the rest. We'll fill the sections for you.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>

      <div className="intake-steps">
        {STEPS.map((st, i) => (
          <button key={i} className={"intake-step" + (i === step ? " on" : "") + (i < step ? " done" : "")} onClick={() => (i === 0 || a.size) && setStep(i)}>
            <span className="intake-step-n">{i < step ? <Icon name="check" size={12} /> : i + 1}</span>
            <span className="intake-step-l">{st}</span>
          </button>
        ))}
      </div>

      <div className="modal-bd intake-bd">
        {step === 0 && (
          <div>
            <div className="intake-q">How big is this project?</div>
            <p className="muted" style={{ fontSize: 13, lineHeight: 1.5, margin: "0 0 16px" }}>This tailors which sections we ask about — you can change everything later.</p>
            <div className="size-grid">
              {SIZES.map((sz) => (
                <button key={sz.id} className={"size-card" + (a.size === sz.id ? " on" : "")} onClick={() => pickSize(sz.id)}>
                  <div className="size-card-hd"><span className="size-name serif">{sz.label}</span>{a.size === sz.id && <span className="size-check"><Icon name="check" size={13} /></span>}</div>
                  <div className="size-blurb">{sz.blurb}</div>
                  <div className="size-detail">{sz.detail}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="intake-form">
            <div>
              <div className="field-label">Why are we doing this? Why does it matter?</div>
              <textarea className="textarea" rows={2} value={a.purpose} onChange={(e) => set({ purpose: e.target.value })} placeholder="The core reason this project exists." />
            </div>
            <YN value={a.hasProblem} onChange={(v) => set({ hasProblem: v })} label="Is there a clear problem or pain today?" hint="A situation that creates or worsens the challenge." />
            <Reveal show={a.hasProblem}><textarea className="textarea" rows={2} value={a.problem} onChange={(e) => set({ problem: e.target.value })} placeholder="What is wrong today, and what makes it worse?" /></Reveal>
            <YN value={a.fromUsers} onChange={(v) => set({ fromUsers: v })} label="Does this matter from the users' perspective?" />
            <Reveal show={a.fromUsers}><textarea className="textarea" rows={2} value={a.usersText} onChange={(e) => set({ usersText: e.target.value })} placeholder="How do users experience the challenge?" /></Reveal>
            <YN value={a.fromStakeholders} onChange={(v) => set({ fromStakeholders: v })} label="Are other stakeholders affected?" />
            <Reveal show={a.fromStakeholders}><textarea className="textarea" rows={2} value={a.stakeText} onChange={(e) => set({ stakeText: e.target.value })} placeholder="Compliance, leadership, partners…" /></Reveal>
            <YN value={a.hasOpportunities} onChange={(v) => set({ hasOpportunities: v })} label="Are there opportunities we can leverage?" />
            <Reveal show={a.hasOpportunities}><textarea className="textarea" rows={2} value={a.oppText} onChange={(e) => set({ oppText: e.target.value })} placeholder="What can we take advantage of?" /></Reveal>
          </div>
        )}

        {step === 2 && (
          <div className="intake-form">
            <div>
              <div className="field-label">What does good look like? Outcomes / KPIs <span className="ai-opt">one per line</span></div>
              <textarea className="textarea" rows={3} value={a.outcomes} onChange={(e) => set({ outcomes: e.target.value })} placeholder={"Reduce support tickets by 50%\nSingle sign-on across all tools"} />
            </div>
            <div className="intake-sub">Which kinds of change are needed?</div>
            <YN value={a.needProcess} onChange={(v) => set({ needProcess: v })} label="Process change" hint="New or changed process, QMS / Cortex document." />
            <Reveal show={a.needProcess}><textarea className="textarea" rows={2} value={a.processText} onChange={(e) => set({ processText: e.target.value })} placeholder="What process needs to change?" /></Reveal>
            <YN value={a.needSystem} onChange={(v) => set({ needSystem: v })} label="System change" hint="New tools, functionality or templates." />
            <Reveal show={a.needSystem}><textarea className="textarea" rows={2} value={a.systemText} onChange={(e) => set({ systemText: e.target.value })} placeholder="What system changes are needed?" /></Reveal>
            <YN value={a.needBehaviour} onChange={(v) => set({ needBehaviour: v })} label="Behaviour change" hint="What target users & key roles should do." />
            <Reveal show={a.needBehaviour}><textarea className="textarea" rows={2} value={a.behaviourText} onChange={(e) => set({ behaviourText: e.target.value })} placeholder="What should people do differently?" /></Reveal>
            <YN value={a.needLeadership} onChange={(v) => set({ needLeadership: v })} label="Leadership / organisation change" hint="Structure, roles, responsibilities, training." />
            <Reveal show={a.needLeadership}><textarea className="textarea" rows={2} value={a.leadershipText} onChange={(e) => set({ leadershipText: e.target.value })} placeholder="What needs to change in leadership or org?" /></Reveal>
          </div>
        )}

        {step === 3 && (
          <div className="intake-form">
            <YN value={a.hasFinancials} onChange={(v) => set({ hasFinancials: v })} label="Is there a financial case?" hint="Costs, savings and payback. Not every project needs one." />
            <Reveal show={a.hasFinancials}>
              <div className="intake-fin">
                <div><div className="field-label">Programme cost (one-off)</div><input className="input" value={a.costOneOff} onChange={(e) => set({ costOneOff: e.target.value })} placeholder="€480,000" /></div>
                <div><div className="field-label">Annual run cost</div><input className="input" value={a.costRun} onChange={(e) => set({ costRun: e.target.value })} placeholder="€120,000" /></div>
                <div><div className="field-label">Annual saving</div><input className="input" value={a.saving} onChange={(e) => set({ saving: e.target.value })} placeholder="€210,000" /></div>
                <div><div className="field-label">Payback period</div><input className="input" value={a.payback} onChange={(e) => set({ payback: e.target.value })} placeholder="~2.4 years" /></div>
              </div>
            </Reveal>
            {!a.hasFinancials && <p className="muted" style={{ fontSize: 13, lineHeight: 1.5 }}>No problem — we'll leave the financial section empty. You can add figures any time on the Business case page.</p>}
          </div>
        )}

        {step === 4 && (
          <div className="intake-form">
            <div className="intake-cols">
              <div>
                <div className="field-label">In scope <span className="ai-opt">one per line</span></div>
                <textarea className="textarea" rows={4} value={a.inScope} onChange={(e) => set({ inScope: e.target.value })} placeholder={"Customer records migration\nSingle sign-on\nNew portal core flows"} />
              </div>
              <div>
                <div className="field-label">Out of scope <span className="ai-opt">one per line</span></div>
                <textarea className="textarea" rows={4} value={a.outScope} onChange={(e) => set({ outScope: e.target.value })} placeholder={"Finance / ERP integration\nNative mobile apps\nPartner portals"} />
              </div>
            </div>
            <YN value={a.hasRisks} onChange={(v) => set({ hasRisks: v })} label="Do you already know of any risks?" hint="We'll add them to the risk register to score later." />
            <Reveal show={a.hasRisks}><textarea className="textarea" rows={3} value={a.risksText} onChange={(e) => set({ risksText: e.target.value })} placeholder={"One risk per line, e.g.\nLegacy data quality worse than expected\nKey user availability during UAT"} /></Reveal>
          </div>
        )}
      </div>

      <div className="modal-ft">
        {step > 0 ? <button className="btn btn-ghost" onClick={() => setStep(step - 1)}><Icon name="chevR" size={14} style={{ transform: "rotate(180deg)" }} /> Back</button>
                  : <button className="btn btn-ghost" onClick={onClose}>Cancel</button>}
        <div className="grow" />
        {step < STEPS.length - 1
          ? <button className="btn btn-primary" disabled={!canNext} onClick={() => setStep(step + 1)}>Continue <Icon name="chevR" size={14} /></button>
          : <button className="btn btn-primary" onClick={finish}><Icon name="check" size={15} /> Create project</button>}
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { IntakeWizard });


// ======== sync.jsx ========
/* ============================================================
   SYNC — npoint.io live sync + backup/transfer
   Data-only sync (no files); catalogue uses shared-drive links.
   Exposes window.SyncPanel, window.SyncBadge, window.SyncToast, window.initSync
   ============================================================ */
const { useState: useSy, useEffect: useSyE, useRef: useSyR } = React;

const SYNC_KEY = "atlas.sync.config";
const blob2dataURL = (blob) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob); });
async function dataURL2blob(u) { const r = await fetch(u); return await r.blob(); }

function loadSyncCfg() { try { return JSON.parse(localStorage.getItem(SYNC_KEY)) || {}; } catch (e) { return {}; } }
function saveSyncCfg(c) { localStorage.setItem(SYNC_KEY, JSON.stringify(c)); }

/* ---------- workspace build / restore ---------- */
async function buildWorkspace(includeFiles) {
  const root = Store.getRoot();
  const pkg = { atlas: true, version: 2, exportedAt: new Date().toISOString(), root: { version: 2, projects: root.projects, rev: root.rev || 0, savedAt: root.savedAt || Date.now() }, files: {} };
  if (includeFiles) {
    const all = await Store.files.all();
    for (const [id, blob] of Object.entries(all)) {
      try { pkg.files[id] = await blob2dataURL(blob); } catch (e) {}
    }
  }
  return pkg;
}

// Single-project export. Only files referenced by this project's products are included.
async function buildProjectExport(projectId, includeFiles) {
  const root = Store.getRoot();
  const proj = root.projects.find((p) => p.id === projectId);
  if (!proj) throw new Error("Project not found");
  const pkg = { atlas: true, version: 2, singleProject: true, exportedAt: new Date().toISOString(), root: { version: 2, projects: [proj], rev: 0, savedAt: Date.now() }, files: {} };
  if (includeFiles) {
    const all = await Store.files.all();
    const referenced = new Set();
    (proj.products || []).forEach((p) => { if (p.fileId) referenced.add(p.fileId); });
    referenced.add("atlas.hero." + projectId); // cover image
    for (const id of referenced) {
      const blob = all[id];
      if (blob) { try { pkg.files[id] = await blob2dataURL(blob); } catch (e) {} }
    }
  }
  return pkg;
}

async function restoreWorkspace(pkg, opts) {
  const rootData = pkg.root || pkg;
  if (pkg.singleProject && rootData.projects && rootData.projects.length === 1) {
    // merge single project: add or replace by id, keep other projects intact
    const incoming = rootData.projects[0];
    const root = Store.getRoot();
    const existing = root.projects.findIndex((p) => p.id === incoming.id);
    const newProjects = [...root.projects];
    if (existing >= 0) newProjects[existing] = incoming;
    else newProjects.push(incoming);
    Store.importRoot({ version: 2, projects: newProjects, rev: (root.rev || 0) + 1, savedAt: Date.now() }, opts);
  } else {
    Store.importRoot(rootData, opts);
  }
  if (pkg.files) {
    for (const [id, durl] of Object.entries(pkg.files)) {
      try { Store.files.put(id, await dataURL2blob(durl)); } catch (e) {}
    }
  }
}

/* ---------- remote helpers ---------- */
async function remotePull(cfg) {
  const res = await fetch(cfg.url, { headers: { "Accept": "application/json" } });
  if (!res.ok) throw new Error("GET " + res.status);
  const txt = await res.text();
  if (!txt || !txt.trim()) return null;
  const data = JSON.parse(txt);
  return data.root ? data : { root: data };
}
async function remotePush(cfg, pkg) {
  const res = await fetch(cfg.url, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(pkg) });
  if (!res.ok) throw new Error("PUT " + res.status);
}

/* ---------- npoint.io one-click create ---------- */
async function createNpointBin() {
  const res = await fetch("https://api.npoint.io/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: {} }),
  });
  if (!res.ok) throw new Error("Could not create bin (HTTP " + res.status + ")");
  const json = await res.json();
  // npoint returns something like https://api.npoint.io/abc123
  return "https://api.npoint.io/" + (json.id || json);
}

/* ---------- live sync engine ---------- */
let syncTimer = null, pushDebounce = null, lastPushedRev = -1, lastRemoteSavedAt = 0, unsub = null;
const syncState = { status: "off", msg: "", at: 0, conflict: false, listeners: new Set() };
const toastState = { visible: false, msg: "", listeners: new Set() };

function setSync(status, msg) { syncState.status = status; syncState.msg = msg || ""; syncState.at = Date.now(); syncState.listeners.forEach((l) => l()); }
function showToast(msg) { toastState.visible = true; toastState.msg = msg; toastState.listeners.forEach((l) => l()); setTimeout(() => { toastState.visible = false; toastState.listeners.forEach((l) => l()); }, 4000); }

async function doPull(cfg, { apply } = { apply: true }) {
  const remote = await remotePull(cfg);
  if (!remote || !remote.root) return { changed: false };
  const localAt = Store.getRoot().savedAt || 0;
  const rAt = remote.root.savedAt || 0;
  const rRev = remote.root.rev || 0;
  const localRev = Store.getRoot().rev || 0;

  if (rAt > localAt && rRev !== localRev) {
    // Do we have local edits that haven't been pushed yet?
    const hasLocalPending = localAt > lastRemoteSavedAt && lastPushedRev !== -1 && localRev !== lastPushedRev;
    if (hasLocalPending) {
      // Don't overwrite unsaved local work (which could eject us from a just-created
      // project). Flag the conflict and let our pending push reconcile instead.
      syncState.conflict = true;
      setSync("ok", "Local changes pending — will push");
      lastRemoteSavedAt = rAt;
      return { changed: false };
    }
    if (apply) {
      await restoreWorkspace(remote, { keepActive: true });
      lastPushedRev = Store.getRoot().rev || 0;
      lastRemoteSavedAt = rAt;
      showToast("Workspace updated from the shared endpoint.");
      return { changed: true };
    }
  }
  lastRemoteSavedAt = rAt;
  return { changed: false };
}
async function doPush(cfg) {
  const pkg = await buildWorkspace(false); // never include files in live sync
  await remotePush(cfg, pkg);
  lastPushedRev = Store.getRoot().rev || 0;
  lastRemoteSavedAt = pkg.root.savedAt;
  syncState.conflict = false;
}

function startSync(cfg) {
  stopSync();
  if (!cfg || !cfg.url || !cfg.auto) return;
  setSync("syncing", "Connecting…");
  doPull(cfg).then((r) => { setSync("ok", r.changed ? "Pulled latest" : "Up to date"); })
    .catch((e) => setSync("error", String(e.message || e)));
  syncTimer = setInterval(() => {
    doPull(cfg).then((r) => { if (r.changed) setSync("ok", "Pulled update"); else if (syncState.status !== "error") setSync("ok", "Up to date"); })
      .catch((e) => setSync("error", String(e.message || e)));
  }, Math.max(5, cfg.interval || 10) * 1000);
  unsub = subscribeStore(() => {
    const rev = Store.getRoot().rev || 0;
    if (rev === lastPushedRev) return;
    clearTimeout(pushDebounce);
    pushDebounce = setTimeout(() => {
      setSync("syncing", "Saving…");
      doPush(cfg).then(() => { setSync("ok", "Saved"); showToast("Changes pushed to team."); }).catch((e) => setSync("error", String(e.message || e)));
    }, 1200);
  });
}
function stopSync() {
  clearInterval(syncTimer); syncTimer = null;
  clearTimeout(pushDebounce);
  if (unsub) { unsub(); unsub = null; }
  if (syncState.status !== "off") setSync("off", "");
}

function subscribeStore(fn) {
  let lastRev = Store.getRoot().rev || 0;
  const id = setInterval(() => { const r = Store.getRoot().rev || 0; if (r !== lastRev) { lastRev = r; fn(); } }, 800);
  return () => clearInterval(id);
}

function initSync() {
  const cfg = loadSyncCfg();
  if (cfg.url && cfg.auto) startSync(cfg);
}

/* ---------- Toast ---------- */
function SyncToast() {
  const [, force] = useSy(0);
  useSyE(() => { const l = () => force((x) => x + 1); toastState.listeners.add(l); return () => toastState.listeners.delete(l); }, []);
  if (!toastState.visible) return null;
  return (
    <div className="sync-toast">
      <Icon name="reset" size={14} />
      <span>{toastState.msg}</span>
    </div>
  );
}

/* ---------- Badge ---------- */
function SyncBadge({ onClick }) {
  const [, force] = useSy(0);
  useSyE(() => { const l = () => force((x) => x + 1); syncState.listeners.add(l); return () => syncState.listeners.delete(l); }, []);
  const cfg = loadSyncCfg();
  const live = cfg.url && cfg.auto;
  const map = { off: ["var(--ink-ghost)", "Local only"], ok: ["var(--hue-done)", "Synced"], syncing: ["var(--t-amber)", "Syncing…"], error: ["var(--t-red)", "Sync error"] };
  const [c, label] = live ? map[syncState.status] || map.ok : map.off;
  return (
    <button className="sync-badge" onClick={onClick} title={syncState.msg || label}>
      <span className="sync-dot" style={{ background: c }} />
      <span className="grow" style={{ textAlign: "left" }}>{live ? label : "Backup & sync"}</span>
      <Icon name="reset" size={13} />
    </button>
  );
}

/* ---------- Panel ---------- */
function SyncPanel({ onClose }) {
  const [tab, setTab] = useSy("live");
  const [cfg, setCfg] = useSy(loadSyncCfg());
  const [busy, setBusy] = useSy("");
  const [note, setNote] = useSy(null);
  const [, force] = useSy(0);
  const fileRef = useSyR(null);
  useSyE(() => { const l = () => force((x) => x + 1); syncState.listeners.add(l); return () => syncState.listeners.delete(l); }, []);
  const upd = (c) => { const n = { ...cfg, ...c }; setCfg(n); saveSyncCfg(n); };

  const doExport = async (withFiles) => {
    setBusy("export");
    try {
      const active = Store.getState();
      const pkg = active ? await buildProjectExport(Store.getRoot().activeId, withFiles) : await buildWorkspace(withFiles);
      const filename = active
        ? "atlas-" + (active.meta?.project || "project").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + new Date().toISOString().slice(0, 10) + ".json"
        : "atlas-workspace-" + new Date().toISOString().slice(0, 10) + ".json";
      const blob = new Blob([JSON.stringify(pkg)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNote({ ok: true, msg: active ? `Exported “${active.meta?.project}”.` : "Workspace downloaded." });
    } catch (e) { setNote({ ok: false, msg: "Export failed: " + e.message }); }
    setBusy("");
  };
  const doExportWorkspace = async (withFiles) => {
    setBusy("export-all");
    try {
      const pkg = await buildWorkspace(withFiles);
      const blob = new Blob([JSON.stringify(pkg)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = "atlas-workspace-" + new Date().toISOString().slice(0, 10) + ".json";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNote({ ok: true, msg: "Whole workspace downloaded." });
    } catch (e) { setNote({ ok: false, msg: "Export failed: " + e.message }); }
    setBusy("");
  };
  const doImport = async (file) => {
    setBusy("import");
    try {
      const txt = await file.text(); const pkg = JSON.parse(txt);
      await restoreWorkspace(pkg);
      setNote({ ok: true, msg: "Workspace imported. Everything replaced." });
    } catch (e) { setNote({ ok: false, msg: "Import failed: " + (e.message || "unreadable file") }); }
    setBusy("");
  };

  const doCreateBin = async () => {
    setBusy("create");
    try {
      const url = await createNpointBin();
      upd({ url });
      // immediately push current state so bin isn't empty
      Store.touch();
      await doPush({ ...cfg, url });
      setNote({ ok: true, msg: "Workspace created at npoint.io. Share this URL with your team — anyone with it can sync." });
    } catch (e) { setNote({ ok: false, msg: "Could not create bin: " + e.message }); }
    setBusy("");
  };

  const testConn = async () => {
    setBusy("test");
    try { await remotePull(cfg); setNote({ ok: true, msg: "Connected — endpoint is reachable." }); }
    catch (e) { setNote({ ok: false, msg: "Could not reach endpoint: " + e.message }); }
    setBusy("");
  };
  const toggleLive = (on) => { upd({ auto: on }); if (on) { Store.touch(); startSync({ ...cfg, auto: true }); } else stopSync(); };
  const pushNow = async () => { setBusy("push"); try { Store.touch(); await doPush(cfg); setNote({ ok: true, msg: "Pushed." }); } catch (e) { setNote({ ok: false, msg: "Push failed: " + e.message }); } setBusy(""); };
  const pullNow = async () => { setBusy("pull"); try { const r = await doPull(cfg); setNote({ ok: true, msg: r.changed ? "Pulled latest." : "Already up to date." }); } catch (e) { setNote({ ok: false, msg: "Pull failed: " + e.message }); } setBusy(""); };

  const copyUrl = () => { navigator.clipboard.writeText(cfg.url || ""); setNote({ ok: true, msg: "URL copied to clipboard. Share it with your team." }); };

  // one-click: use the Vercel KV backend served from this same deployment
  const useThisServer = async () => {
    setBusy("server");
    try {
      const url = new URL("/api/workspace", location.origin).href;
      // verify the endpoint is reachable before committing
      const r = await fetch(url, { headers: { Accept: "application/json" } });
      if (!r.ok) throw new Error("Server responded " + r.status + " — is the API deployed and the database connected?");
      upd({ url });
      Store.touch();
      await doPush({ ...cfg, url });
      setNote({ ok: true, msg: "Connected to this site's built-in server. Share this site's URL with your team — they click the same button." });
    } catch (e) {
      setNote({ ok: false, msg: "Couldn't reach the built-in server: " + e.message });
    }
    setBusy("");
  };

  // auto-fix common npoint URL mistakes
  const fixUrl = (raw) => {
    let u = (raw || "").trim();
    u = u.replace(/^https?:\/\/(?:www\.)?npoint\.io\/docs\//, "https://api.npoint.io/");
    u = u.replace(/^https?:\/\/npoint\.io\/(?!api)/, "https://api.npoint.io/");
    return u;
  };
  const onUrlChange = (raw) => { const fixed = fixUrl(raw); if (fixed !== raw) setNote({ ok: true, msg: "Auto-corrected to the API URL." }); return fixed; };

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="reset" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Backup & sync</div>
          <div className="muted" style={{ fontSize: 13 }}>Keep your team in sync via npoint.io, or export/import workspace files.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="sync-tabs">
        <button className={tab === "live" ? "on" : ""} onClick={() => { setTab("live"); setNote(null); }}><Icon name="link" size={15} /> Team sync</button>
        <button className={tab === "backup" ? "on" : ""} onClick={() => { setTab("backup"); setNote(null); }}><Icon name="box" size={15} /> Backup & transfer</button>
      </div>
      <div className="modal-bd">
        {tab === "live" && (
          <div className="col" style={{ gap: 16 }}>
            {!cfg.url && (
              <div className="sync-block" style={{ borderColor: "var(--accent-line)", background: "var(--accent-soft)" }}>
                <div className="sync-block-hd"><Icon name="link" size={16} /><b>Use this site's built-in server</b></div>
                <p className="sync-p">If this Atlas is hosted on Vercel with the sync database connected, one click sets up real two-way sync for your whole team — no third-party service.</p>
                <button className="btn btn-primary" disabled={busy === "server"} onClick={useThisServer}>
                  {busy === "server" ? <Icon name="reset" size={15} className="spin" /> : <Icon name="link" size={15} />} Use this site's server
                </button>
                <p className="sync-p" style={{ fontSize: 12, color: "var(--ink-faint)", margin: "12px 0 0" }}>Teammates open the same site URL and click this same button. Project data syncs live; files go on a shared drive, linked in the Product catalogue.</p>
                <div className="sync-or" style={{ margin: "14px 0 4px" }}>or use a manual JSON endpoint</div>
                <ol className="sync-steps-list">
                  <li><b>Open <a href="https://www.npoint.io" target="_blank" rel="noopener noreferrer">npoint.io</a></b> in a new tab</li>
                  <li>Paste <code>{"{}"}</code> into the editor and click <b>Save</b> — you'll get a URL like <code>api.npoint.io/abc123…</code></li>
                  <li>Copy that URL and paste it below</li>
                </ol>
                <p className="sync-p" style={{ fontSize: 12, color: "var(--ink-faint)", margin: "10px 0 0" }}>Project data syncs live. Files (PDFs, images) should be stored on a <b>shared drive</b> (SharePoint, OneDrive, Google Drive) and linked in the Product catalogue.</p>
              </div>
            )}
            {!cfg.url && (
              <div>
                <div className="field-label">Paste your npoint.io URL here</div>
                <input className="input mono" style={{ fontSize: 13 }} value={cfg.url || ""} placeholder="https://api.npoint.io/abc123…" onChange={(e) => upd({ url: onUrlChange(e.target.value) })} />
              </div>
            )}
            {cfg.url && (
              <>
                <div className="sync-block">
                  <div className="between" style={{ marginBottom: 6 }}>
                    <div className="sync-block-hd" style={{ margin: 0 }}><Icon name="link" size={16} /><b>Shared workspace URL</b></div>
                    <button className="btn btn-sm btn-ghost btn-danger" onClick={() => { stopSync(); upd({ url: "", auto: false }); setNote({ ok: true, msg: "Disconnected. You can paste a new URL." }); }}><Icon name="x" size={13} /> Disconnect</button>
                  </div>
                  <div className="sync-url-row">
                    <input className="input mono" style={{ fontSize: 12, flex: 1 }} value={cfg.url} placeholder="https://api.npoint.io/abc123…" onChange={(e) => { stopSync(); upd({ url: onUrlChange(e.target.value), auto: false }); }} />
                    <button className="btn btn-sm" onClick={copyUrl}><Icon name="link" size={13} /> Copy</button>
                  </div>
                  <p className="sync-p" style={{ margin: "8px 0 0" }}>Share this URL with your team. Edit it to switch endpoints, or Disconnect to start fresh.</p>
                </div>
                <div className="row" style={{ gap: 14, flexWrap: "wrap" }}>
                  <div className="row" style={{ gap: 6 }}>
                    <span className="muted" style={{ fontSize: 12.5 }}>Poll every</span>
                    <input className="datemini" style={{ width: 56 }} type="number" min="3" max="120" value={cfg.interval || 10} onChange={(e) => upd({ interval: Number(e.target.value) })} /><span className="muted" style={{ fontSize: 12.5 }}>s</span>
                  </div>
                </div>
                <div className="row" style={{ gap: 9, flexWrap: "wrap" }}>
                  <button className="btn btn-sm" disabled={!cfg.url || busy} onClick={testConn}>{busy === "test" ? <Icon name="reset" size={14} className="spin" /> : <Icon name="check" size={14} />} Test</button>
                  <button className="btn btn-sm" disabled={!cfg.url || busy} onClick={pushNow}>Push now</button>
                  <button className="btn btn-sm" disabled={!cfg.url || busy} onClick={pullNow}>Pull now</button>
                </div>
                <label className={"sync-live-toggle" + (cfg.auto ? " on" : "")}>
                  <input type="checkbox" checked={!!cfg.auto} disabled={!cfg.url} onChange={(e) => toggleLive(e.target.checked)} />
                  <span className="sync-live-text">
                    <b>Keep this computer in sync</b>
                    <span className="muted">{cfg.auto ? (syncState.msg || "Live") : "Off — changes stay local"}</span>
                  </span>
                  <span className="sync-dot" style={{ background: cfg.auto ? (syncState.status === "error" ? "var(--t-red)" : "var(--hue-done)") : "var(--ink-ghost)" }} />
                </label>
              </>
            )}
          </div>
        )}
        {tab === "backup" && (
          <div className="col" style={{ gap: 18 }}>
            <div className="sync-block">
              <div className="sync-block-hd"><Icon name="upload" size={16} style={{ transform: "rotate(180deg)" }} /><b>{Store.getState() ? `Export “${Store.getState().meta?.project}”` : "Export this workspace"}</b></div>
              <p className="sync-p">{Store.getState() ? "Download this project as a single file. Re-import it anywhere to restore it as it is now." : "Download every project as a single file. Carry it to another computer and import it there."}</p>
              <div className="row" style={{ gap: 9, flexWrap: "wrap" }}>
                <button className="btn btn-primary" disabled={busy === "export"} onClick={() => doExport(true)}>
                  {busy === "export" ? <Icon name="reset" size={15} className="spin" /> : <Icon name="upload" size={15} style={{ transform: "rotate(180deg)" }} />} Export with local files
                </button>
                <button className="btn" disabled={busy === "export"} onClick={() => doExport(false)}>Export data only</button>
              </div>
              {Store.getState() && (
                <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
                  <p className="sync-p" style={{ marginBottom: 8, fontSize: 12 }}>Need everything?</p>
                  <button className="btn btn-sm" disabled={busy === "export-all"} onClick={() => doExportWorkspace(true)}>
                    {busy === "export-all" ? <Icon name="reset" size={14} className="spin" /> : <Icon name="layers" size={14} />} Export whole workspace
                  </button>
                </div>
              )}
            </div>
            <div className="sync-block">
              <div className="sync-block-hd"><Icon name="upload" size={16} /><b>Import a workspace</b></div>
              <p className="sync-p">Load a workspace file. <b>This replaces everything</b> on this computer.</p>
              <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => { if (e.target.files[0]) doImport(e.target.files[0]); e.target.value = ""; }} />
              <button className="btn" disabled={busy === "import"} onClick={() => fileRef.current.click()}>
                {busy === "import" ? <Icon name="reset" size={15} className="spin" /> : <Icon name="upload" size={15} />} Choose file…
              </button>
            </div>
          </div>
        )}
        {note && <div className={"sync-note " + (note.ok ? "ok" : "bad")}><Icon name={note.ok ? "check" : "warn"} size={14} /> {note.msg}</div>}
      </div>
      <div className="modal-ft">
        <span className="muted" style={{ fontSize: 12 }}>Data syncs live. Files should live on your shared drive.</span>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { SyncPanel, SyncBadge, SyncToast, initSync, restoreWorkspace, buildWorkspace, buildProjectExport });


// ======== projects.jsx ========
/* ============================================================
   PROJECTS LANDING — programs, subprojects, create, sync
   Exposes window.ProjectsHome
   ============================================================ */
const { useState: usePj, useRef: usePjR, useEffect: usePjE } = React;

const PRJ_COLORS = ["purple", "indigo", "blue", "teal", "green", "amber", "pink", "red"];

function projStats(p) {
  const tasks = p.tasks || [];
  const done = tasks.filter((t) => t.status === "done").length;
  const active = tasks.filter((t) => t.status === "inprogress").length;
  const openRisks = (p.risks || []).filter((r) => r.status !== "closed").length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  return { total: tasks.length, done, active, openRisks, pct };
}
function relTime(ts) {
  if (!ts) return "—";
  const d = Math.floor((Date.now() - ts) / 86400000);
  if (d <= 0) return "today";
  if (d === 1) return "yesterday";
  if (d < 30) return d + " days ago";
  return Math.floor(d / 30) + " mo ago";
}

function ProjectCard({ p, projects, onOpen, onDelete, sub }) {
  const s = projStats(p);
  const [menu, setMenu] = usePj(false);
  const ref = usePjR(null);
  usePjE(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setMenu(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  // candidate parents: any top-level project that isn't this one and isn't this one's child
  const childIds = new Set(projects.filter((x) => x.parentId === p.id).map((x) => x.id));
  const parents = projects.filter((x) => x.id !== p.id && !childIds.has(x.id) && !x.parentId);

  return (
    <article className={"pj-card" + (sub ? " sub" : "")} onClick={() => onOpen(p.id)}>
      <div className="pj-card-bar" style={{ background: "var(--t-" + (p.color || "indigo") + ")" }} />
      <div className="pj-card-top">
        <span className="pj-code mono">{relTime(p.createdAt) === "today" ? "New" : ""}</span>
        <div className="pj-card-actions no-print" ref={ref}>
          <button className="pj-menu-btn" title="Group / move" onClick={(e) => { e.stopPropagation(); setMenu((m) => !m); }}><Icon name="layers" size={14} /></button>
          <button className="pj-del" title="Delete project" onClick={(e) => { e.stopPropagation(); onDelete(p); }}><Icon name="trash" size={14} /></button>
          {menu && (
            <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 210 }} onClick={(e) => e.stopPropagation()}>
              <div className="dep-menu-label">Group under a major project</div>
              {p.parentId && <button className="tagpicker-opt" onClick={() => { Store.projects.setParent(p.id, null); setMenu(false); }}><Icon name="x" size={13} /><span className="grow">Make top-level</span></button>}
              {parents.length === 0 && !p.parentId && <div className="dep-menu-empty">No other top-level projects to nest under yet.</div>}
              {parents.map((par) => (
                <button key={par.id} className={"tagpicker-opt" + (p.parentId === par.id ? " on" : "")} onClick={() => { Store.projects.setParent(p.id, par.id); setMenu(false); }}>
                  <span className="chip-dot" style={{ background: "var(--t-" + (par.color || "indigo") + ")" }} />
                  <span className="grow">{par.meta?.project}</span>
                  {p.parentId === par.id && <Icon name="check" size={14} />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      <h2 className="pj-name serif">{p.meta?.project}</h2>
      <div className="pj-progress">
        <div className="pj-progress-track"><div className="pj-progress-fill" style={{ width: s.pct + "%", background: "var(--t-" + (p.color || "indigo") + ")" }} /></div>
        <span className="pj-progress-pct mono">{s.pct}%</span>
      </div>
      <div className="pj-statline">
        <span><b>{s.active}</b> active</span><span className="pj-dot-sep" />
        <span><b>{s.total}</b> tasks</span><span className="pj-dot-sep" />
        <span className={s.openRisks ? "pj-risk" : ""}><b>{s.openRisks}</b> risks</span>
      </div>
      <div className="pj-card-foot">
        <div className="pj-faces">
          {[...new Set((p.tasks || []).filter((t) => t.status === "inprogress").flatMap((t) => assigneesOf(t)))].slice(0, 4).map((n, i) => (
            <span key={i} className="avatar pj-face" style={{ background: "var(--t-" + PRJ_COLORS[i % PRJ_COLORS.length] + ")" }} title={n}>{initials(n)}</span>
          ))}
          {s.active === 0 && <span className="muted" style={{ fontSize: 12 }}>No one assigned yet</span>}
        </div>
        <span className="pj-updated muted">Updated {relTime(p.updatedAt)}</span>
      </div>
      <span className="pj-open">Open <Icon name="arrowR" size={14} /></span>
    </article>
  );
}

function ProjectsHome() {
  const root = Store.useRoot();
  const [create, setCreate] = usePj(false);
  const [intake, setIntake] = usePj(false);
  const [del, setDel] = usePj(null);
  const [sync, setSync] = usePj(false);
  const [importing, setImporting] = usePj(false);
  const [importNote, setImportNote] = usePj(null);
  const importInputRef = usePjR(null);

  const handleImport = async (file) => {
    if (!file) return;
    setImporting(true);
    setImportNote(null);
    try {
      const txt = await file.text();
      const pkg = JSON.parse(txt);
      await window.restoreWorkspace(pkg);
      setImportNote({ ok: true, msg: `Imported — ${pkg.root?.projects?.length || "?"} project(s) restored.` });
    } catch (e) {
      setImportNote({ ok: false, msg: "Import failed: " + (e.message || "unreadable file") });
    }
    setImporting(false);
  };
  const projects = root.projects;

  const open = (id) => { Store.projects.open(id); location.hash = "home"; };
  const byId = Object.fromEntries(projects.map((p) => [p.id, p]));
  const childrenOf = (id) => projects.filter((p) => p.parentId === id);
  // top-level = no parent, OR parent missing
  const tops = projects.filter((p) => !p.parentId || !byId[p.parentId]);
  const programs = tops.filter((p) => childrenOf(p.id).length > 0);
  const standalone = tops.filter((p) => childrenOf(p.id).length === 0);

  const allTasks = projects.flatMap((p) => p.tasks || []);
  const totalActive = allTasks.filter((t) => t.status === "inprogress").length;
  const totalRisks = projects.flatMap((p) => p.risks || []).filter((r) => r.status !== "closed").length;

  const cardProps = { projects, onOpen: open, onDelete: setDel };

  return (
    <div className="pj-root">
      <div className="pj-wrap">
        <header className="pj-head">
          <div className="between" style={{ marginBottom: 28 }}>
            <div className="brand" style={{ padding: 0 }}>
              <div className="brand-mark" style={{ width: 40, height: 40 }}><Icon name="layers" size={22} /></div>
              <div>
                <div className="brand-name" style={{ fontSize: 24 }}>Atlas</div>
                <div className="brand-sub">Project portfolio</div>
              </div>
            </div>
            <div className="row no-print" style={{ gap: 8 }}>
              <button className="btn" onClick={() => setSync(true)}><Icon name="reset" size={15} /> Backup & sync</button>
            </div>
          </div>
          <div className="pj-hero">
            <div>
              <h1 className="pj-title serif">Your projects</h1>
              <p className="pj-lead">Every initiative in one place — group related work under a major project, then open any one to manage its board, plan, people, risks and deliverables.</p>
            </div>
            <div className="pj-rollup">
              <div className="pj-roll"><span className="pj-roll-n serif">{projects.length}</span><span className="pj-roll-l">projects</span></div>
              <div className="pj-roll"><span className="pj-roll-n serif">{totalActive}</span><span className="pj-roll-l">active tasks</span></div>
              <div className="pj-roll"><span className="pj-roll-n serif" style={{ color: totalRisks ? "var(--t-red)" : "inherit" }}>{totalRisks}</span><span className="pj-roll-l">open risks</span></div>
            </div>
          </div>
        </header>

        {programs.map((prog) => {
          const kids = childrenOf(prog.id);
          const rolled = [prog, ...kids];
          const tot = rolled.reduce((a, p) => a + (p.tasks || []).length, 0);
          const dn = rolled.reduce((a, p) => a + (p.tasks || []).filter((t) => t.status === "done").length, 0);
          return (
            <section key={prog.id} className="pj-program" style={{ "--prog-c": "var(--t-" + (prog.color || "indigo") + ")" }}>
              <div className="pj-program-hd">
                <span className="pj-program-mark"><Icon name="layers" size={15} /></span>
                <div>
                  <div className="pj-program-name serif">{prog.meta?.project}</div>
                  <div className="pj-program-sub">Program · {kids.length} subproject{kids.length === 1 ? "" : "s"} · {tot ? Math.round(dn / tot * 100) : 0}% complete overall</div>
                </div>
              </div>
              <div className="pj-grid">
                <ProjectCard p={prog} {...cardProps} />
                {kids.map((k) => <ProjectCard key={k.id} p={k} {...cardProps} sub />)}
              </div>
            </section>
          );
        })}

        {standalone.length > 0 && (
          <section className="pj-program plain">
            {programs.length > 0 && <div className="pj-section-label eyebrow">Other projects</div>}
            <div className="pj-grid">
              {standalone.map((p) => <ProjectCard key={p.id} p={p} {...cardProps} />)}
            </div>
          </section>
        )}

        <div className="pj-grid" style={{ marginTop: standalone.length > 0 || programs.length > 0 ? 0 : 20 }}>
          <button className="pj-new" onClick={() => setCreate(true)}>
            <span className="pj-new-icon"><Icon name="plus" size={26} /></span>
            <span className="pj-new-label serif">New project</span>
            <span className="pj-new-sub">Blank, guided setup, or AI</span>
          </button>
          <button className="pj-new pj-import" onClick={() => importInputRef.current.click()} disabled={importing}>
            <span className="pj-new-icon">{importing ? <Icon name="reset" size={26} className="spin" /> : <Icon name="upload" size={26} />}</span>
            <span className="pj-new-label serif">{importing ? "Importing…" : "Import workspace"}</span>
            <span className="pj-new-sub">Load a previously exported file</span>
          </button>
          <input ref={importInputRef} type="file" accept="application/json,.json" hidden onChange={(e) => { if (e.target.files[0]) handleImport(e.target.files[0]); e.target.value = ""; }} />
        </div>
        {importNote && (
          <div className={"sync-note " + (importNote.ok ? "ok" : "bad")} style={{ marginTop: 14, maxWidth: 600 }}>
            <Icon name={importNote.ok ? "check" : "warn"} size={14} /> {importNote.msg}
          </div>
        )}

        {projects.length === 0 && (
          <div className="empty" style={{ marginTop: 20 }}>
            <div className="serif">No projects yet</div>
            Create your first project to get started.
          </div>
        )}
      </div>

      {create && <CreateProject projects={projects} onClose={() => setCreate(false)} onGuided={() => { setCreate(false); setIntake(true); }} />}
      {intake && <IntakeWizard onClose={() => { setIntake(false); location.hash = "home"; }} onDone={() => { setIntake(false); location.hash = "home"; }} />}
      {sync && <SyncPanel onClose={() => setSync(false)} />}
      {del && <UI.Confirm title="Delete project?" body={childrenOf(del.id).length ? `"${del.meta?.project}" will be deleted. Its ${childrenOf(del.id).length} subproject(s) become top-level projects.` : `"${del.meta?.project}" and all its tasks, risks and deliverables will be permanently removed.`} confirmLabel="Delete project" onConfirm={() => Store.projects.remove(del.id)} onClose={() => setDel(null)} />}
    </div>
  );
}

function CreateProject({ onClose, onGuided, projects }) {
  const [name, setName] = usePj("");
  const [color, setColor] = usePj("indigo");
  const [parent, setParent] = usePj("");
  const [method, setMethod] = usePj("guided");
  const [templateSrc, setTemplateSrc] = usePj("");
  const [inclTasks, setInclTasks] = usePj(false);
  const [inclContent, setInclContent] = usePj(false);
  const tops = (projects || []).filter((p) => !p.parentId);
  const create = () => Store.projects.create(name.trim() || "Untitled project", "", color, parent || null);
  const go = () => {
    if (method === "clone") {
      if (!templateSrc) return;
      Store.projects.createFromTemplate(templateSrc, { name: name.trim() || "Untitled project", color, parentId: parent || null, includeTasks: inclTasks, includeContent: inclContent });
      location.hash = "home"; onClose(); return;
    }
    create();
    if (method === "guided") onGuided();
    else { location.hash = "home"; onClose(); }
  };
  const METHODS = [
    { id: "guided", icon: "scope", label: "Guided setup", sub: "Answer a few questions — we fill the sections", tag: "Recommended" },
    { id: "clone", icon: "copy", label: "Copy an existing project", sub: "Duplicate structure from another project" },
    { id: "blank", icon: "plus", label: "Blank project", sub: "Start from an empty board" },
  ];
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>New project</div>
          <div className="muted" style={{ fontSize: 13 }}>Name it, then choose how to set it up.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="field-label">Project name</div>
        <input className="input" autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Data Warehouse Consolidation"
          onKeyDown={(e) => e.key === "Enter" && go()} style={{ marginBottom: 16 }} />
        <div className="row" style={{ gap: 12, marginBottom: 16, alignItems: "flex-start" }}>
          <div className="grow">
            <div className="field-label">Part of <span className="ai-opt">optional</span></div>
            <select className="select" value={parent} onChange={(e) => setParent(e.target.value)}>
              <option value="">— Top-level project —</option>
              {tops.map((p) => <option key={p.id} value={p.id}>{p.meta?.project}</option>)}
            </select>
          </div>
          <div>
            <div className="field-label">Colour</div>
            <div className="wrap" style={{ maxWidth: 150 }}>
              {PRJ_COLORS.map((c) => (
                <button key={c} className={"pj-swatch sm" + (color === c ? " on" : "")} style={{ background: "var(--t-" + c + ")" }} onClick={() => setColor(c)}>
                  {color === c && <Icon name="check" size={12} />}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="field-label">How do you want to set it up?</div>
        <div className="method-list">
          {METHODS.map((m) => (
            <button key={m.id} className={"method-card" + (method === m.id ? " on" : "")} onClick={() => setMethod(m.id)}>
              <span className="method-ico"><Icon name={m.icon} size={17} /></span>
              <span className="method-text">
                <span className="method-label">{m.label}{m.tag && <span className="method-tag">{m.tag}</span>}</span>
                <span className="method-sub">{m.sub}</span>
              </span>
              <span className={"method-radio" + (method === m.id ? " on" : "")}>{method === m.id && <Icon name="check" size={12} />}</span>
            </button>
          ))}
        </div>
        {method === "clone" && (
          <div className="tmpl-cfg">
            <div className="field-label" style={{ marginTop: 16 }}>Copy structure from</div>
            <select className="select" value={templateSrc} onChange={(e) => setTemplateSrc(e.target.value)}>
              <option value="">— Choose a project —</option>
              {(projects || []).map((p) => <option key={p.id} value={p.id}>{p.meta?.project}</option>)}
            </select>
            <label className="tmpl-opt"><input type="checkbox" checked={inclContent} onChange={(e) => setInclContent(e.target.checked)} /> <span>Include planning content <span className="muted">(business case, scope, comms, glossary)</span></span></label>
            <label className="tmpl-opt"><input type="checkbox" checked={inclTasks} onChange={(e) => setInclTasks(e.target.checked)} /> <span>Include tasks &amp; milestones <span className="muted">(reset to To-do, dates cleared)</span></span></label>
            <div className="muted" style={{ fontSize: 12.5, marginTop: 8, lineHeight: 1.5 }}>Categories, tags, phases, custom fields, automations, sections and the org skeleton are always copied.</div>
          </div>
        )}
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={go} disabled={method === "clone" && !templateSrc}>{method === "blank" ? "Create project" : method === "clone" ? "Create project" : "Continue"} <Icon name="chevR" size={14} /></button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { ProjectsHome });


// ======== dashboard.jsx ========
/* ============================================================
   DASHBOARD — project front page
   View switcher (project / per-person) · tasks · risks · deps
   Exposes window.Dashboard
   ============================================================ */
const { useState: useD, useMemo: useDM } = React;

const STATUS_ORDER = [
{ id: "inprogress", label: "In progress" },
{ id: "backlog", label: "To do" },
{ id: "done", label: "Done" }];


function DashCommand({ go }) {
  const [text, setText] = React.useState("");
  const submit = () => {
    const v = text.trim();
    if (!v) { go("aiimport"); return; }
    try { sessionStorage.setItem("atlas.cmd.pending", v); } catch (e) {}
    go("aiimport");
  };
  return (
    <section className="dash-cmd-big no-print">
      <div className="dash-cmd-big-hd">
        <div className="dash-cmd-big-ico"><Icon name="spark" size={20} /></div>
        <div>
          <div className="dash-cmd-big-title">Update the plan</div>
          <div className="dash-cmd-big-sub">Tell it what happened — status changes, delays, new risks, decisions, dates — and review the changes before anything is applied.</div>
        </div>
      </div>
      <div className="dash-cmd-big-box">
        <textarea
          className="dash-cmd-big-input"
          rows={4}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit(); }}
          placeholder={"e.g. “Mark the API integration done, push everything else to next week, and log a risk about the vendor being slow to respond.”"}
        />
        <div className="dash-cmd-big-foot">
          <span className="muted">⌘/Ctrl + Enter to run · nothing changes until you approve it</span>
          <button className="btn btn-primary" onClick={submit}><Icon name="spark" size={15} /> Update plan</button>
        </div>
      </div>
    </section>
  );
}

function Dashboard({ go }) {
  const s = Store.useStore();
  const { tasks, risks, products, phases, stakeholders, members, milestones, commPlan, categories, externals } = s;
  const [openTask, setOpenTask] = useD(null);

  const VKEY = "atlas.view." + s.id;
  const [who, setWho] = useD(() => {
    const saved = localStorage.getItem(VKEY) || "";
    return saved;
  });
  const phaseOf = (id) => phases.find((p) => p.id === id);

  const people = useDM(() => {
    // members are the single source of truth for who can be viewed
    return [...new Set((members || []).map((m) => m.name).filter((n) => n && n !== "You"))].sort((a, b) => a.localeCompare(b));
  }, [members]);

  // if saved person no longer exists, fall back to project view
  const personal = who && people.includes(who);
  const changeWho = (v) => {
    setWho(v);
    if (v) localStorage.setItem(VKEY, v);else localStorage.removeItem(VKEY);
  };

  const viewTasks = personal ? tasks.filter((t) => assigneesOf(t).includes(who)) : tasks;
  const myIds = useDM(() => new Set(viewTasks.map((t) => t.id)), [viewTasks]);
  const viewRisks = personal ? risks.filter((r) => (r.taskIds || []).some((id) => myIds.has(id))) : risks;
  const viewProducts = personal ? products.filter((p) => (p.taskIds || []).some((id) => myIds.has(id))) : products;

  const done = viewTasks.filter((t) => t.status === "done").length;
  const active = viewTasks.filter((t) => t.status === "inprogress");
  const openRisks = viewRisks.filter((r) => r.status !== "closed").length;

  // project view: group active by person
  const byPerson = useDM(() => {
    const out = [];const idx = {};
    active.forEach((t) => {
      const keys = assigneesOf(t).length ? assigneesOf(t) : ["\u2014 Unassigned"];
      keys.forEach((n) => {if (idx[n] == null) {idx[n] = out.length;out.push({ name: n, tasks: [] });}out[idx[n]].tasks.push(t);});
    });
    out.sort((a, b) => (a.name.startsWith("\u2014") ? 1 : 0) - (b.name.startsWith("\u2014") ? 1 : 0) || b.tasks.length - a.tasks.length);
    return out;
  }, [active]);

  // personal view: group all my tasks by status
  const byStatus = useDM(() => STATUS_ORDER.map((st) => ({ ...st, tasks: viewTasks.filter((t) => t.status === st.id) })).filter((g) => g.tasks.length), [viewTasks]);

  const depTasks = viewTasks.filter((t) => (t.deps || []).length && t.status !== "done");
  let blockedCount = 0,extCount = 0;
  depTasks.forEach((t) => (t.deps || []).forEach((d) => {const r = resolveDep(d, tasks, products, t, externals);if (r.external) extCount++;else if (r.blocked) blockedCount++;}));

  const topRisks = [...viewRisks].sort((a, b) => LVL[b.likelihood] * LVL[b.impact] - LVL[a.likelihood] * LVL[a.impact]).slice(0, 5);
  const firstName = personal ? who.split(/\s+/)[0] : "";

  return (
    <div className="view-scroll">
      <div className="dash">
        <section className="dash-hero">
          <div className="dash-hero-main">
            <div className="eyebrow" style={{ marginBottom: 14 }}>{personal ? "Personal view" : "Project overview"}</div>
            <UI.Editable className="dash-title serif" tag="h1" value={s.meta?.project} onChange={(v) => Store.setState((st) => ({ ...st, meta: { ...st.meta, project: v || "Untitled" } }))} placeholder="Project name" />
            <UI.Editable className="dash-lead" tag="p" multiline value={s.businessCase?.purpose || ""} onChange={(v) => Store.setState((st) => ({ ...st, businessCase: { ...st.businessCase, purpose: v } }))} placeholder="Add a business purpose to summarise this project here." />
            {personal && <p className="dash-lead-personal">Showing only {who}'s tasks and the risks on work they're assigned to.</p>}
            <div className="row" style={{ gap: 10, marginTop: 18, flexWrap: "wrap" }}>
              <button className="btn btn-primary" onClick={() => go("business")}><Icon name="doc" size={15} /> Read the business case</button>
              <button className="btn" onClick={() => go("actions")}><Icon name="board" size={15} /> Open the board</button>
            </div>
          </div>
          <div className="dash-right">
            <HeroImage projectId={s.id} />
            <div className="dash-viewbox no-print">
            <div className="dash-viewbox-label">View</div>
            <div className="dash-viewselect" style={{ fontFamily: "system-ui" }}>
              {personal && <span className="avatar" style={{ width: 26, height: 26, fontSize: 10 }}>{initials(who)}</span>}
              {!personal && <span className="dash-viewglobe"><Icon name="users" size={16} /></span>}
              <select value={personal ? who : ""} onChange={(e) => changeWho(e.target.value)}>
                <option value="">Project view — everything</option>
                {people.length > 0 && <option disabled>──────────</option>}
                {people.map((p) => <option key={p} value={p}>{p} — personal</option>)}
              </select>
              <Icon name="chevD" size={15} />
            </div>
            <div className="dash-viewhint">{personal ? "Only this person's work" : "Everyone's work"}</div>
            </div>
          </div>
        </section>

        <DashCommand go={go} />

        <UpcomingTimeline viewTasks={viewTasks} tasks={tasks} products={products} milestones={milestones} commPlan={commPlan} categories={categories} externals={externals} phaseOf={phaseOf} onOpen={setOpenTask} go={go} />

        <div className="dash-cols">
          <section className="dash-panel">
            <div className="dash-panel-hd">
              <span className="card-hd">{personal ? `${firstName}'s tasks` : "In progress now"}</span>
              <button className="btn btn-sm btn-ghost" onClick={() => go("actions")}>{personal ? "Actions" : "Board"} <Icon name="arrowR" size={13} /></button>
            </div>

            {!personal &&
            <div className="active-people">
                {active.length === 0 && <div className="dash-empty">Nothing in progress. Move a card into <b>In&nbsp;Progress</b> to see who's working on what.</div>}
                {byPerson.map((grp) =>
              <div key={grp.name} className="person-group">
                    <div className="person-hd">
                      <span className="avatar" style={{ background: grp.name.startsWith("\u2014") ? "var(--ink-ghost)" : "var(--ink)" }}>{grp.name.startsWith("\u2014") ? "?" : initials(grp.name)}</span>
                      <span className="person-name">{grp.name.startsWith("\u2014") ? "Unassigned" : grp.name}</span>
                      <span className="person-count">{grp.tasks.length}</span>
                    </div>
                    <div className="person-tasks">
                      {grp.tasks.map((t) => <TaskLine key={t.id} t={t} ph={phaseOf(t.phase)} onOpen={setOpenTask} />)}
                    </div>
                  </div>
              )}
              </div>
            }

            {personal &&
            <div className="active-people">
                {viewTasks.length === 0 && <div className="dash-empty">{who} isn't assigned to any tasks yet. Assign them on a task card.</div>}
                {byStatus.map((g) =>
              <div key={g.id} className="person-group">
                    <div className="person-hd">
                      <span className={"status-dot s-" + g.id} style={{ width: 10, height: 10, margin: 0 }} />
                      <span className="person-name">{g.label}</span>
                      <span className="person-count">{g.tasks.length}</span>
                    </div>
                    <div className="person-tasks">
                      {g.tasks.map((t) => <TaskLine key={t.id} t={t} ph={phaseOf(t.phase)} onOpen={setOpenTask} />)}
                    </div>
                  </div>
              )}
              </div>
            }
          </section>

          <section className="dash-panel">
            <div className="dash-panel-hd">
              <span className="card-hd">{personal ? `${firstName}'s risks` : "Top risks"}</span>
              <button className="btn btn-sm btn-ghost" onClick={() => go("risks")}>All risks <Icon name="arrowR" size={13} /></button>
            </div>
            <div className="dash-risks">
              {topRisks.length === 0 && <div className="dash-empty">{personal ? "No risks linked to their tasks." : "No risks captured yet."}</div>}
              {topRisks.map((r) => {
                const rem = remediation(r, tasks);
                return (
                  <div key={r.id} className="dash-risk" onClick={() => go("risks")}>
                    <span className="risk-score sm" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="dash-risk-title">{r.title}</span>
                      {rem.state !== "none" && <span className="dash-risk-rem" style={{ color: REMED[rem.state].c }}>{REMED[rem.state].label} · {rem.done}/{rem.total}</span>}
                    </span>
                  </div>);

              })}
            </div>
          </section>
        </div>

        <section className="dash-panel" style={{ marginBottom: 30 }}>
          <div className="dash-panel-hd">
            <span className="card-hd">Dependencies & blockers</span>
            <span className="dep-summary">
              {blockedCount > 0 && <span className="dep-pill blocked"><span className="dep-flag">●</span> {blockedCount} blocking</span>}
              {extCount > 0 && <span className="dep-pill ext"><Icon name="link" size={12} /> {extCount} external</span>}
              {blockedCount + extCount === 0 && <span className="muted" style={{ fontSize: 12.5 }}>No open dependencies</span>}
            </span>
          </div>
          {depTasks.length === 0 && <div className="dash-empty">{personal ? "None of their tasks have open dependencies." : "No open dependencies. Add them on any task card."}</div>}
          <div className="dep-grid">
            {depTasks.map((t) =>
            <div key={t.id} className="dep-card" onClick={() => setOpenTask(t)}>
                <div className="dep-card-task"><span className={"status-dot s-" + t.status} />{t.title}</div>
                <div className="dep-card-needs">
                  {(t.deps || []).map((d) => {
                  const r = resolveDep(d, tasks, products, t, externals);
                  return <span key={d.id} className={"dep-need" + (r.external ? " ext" : r.blocked ? " blocked" : " ok")} title={r.scope}><Icon name={r.icon} size={11} />{r.name}{r.external && r.scope ? ` (${r.scope})` : ""}</span>;
                })}
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
      {openTask && <CardModal task={openTask} onClose={() => setOpenTask(null)} />}
    </div>);

}

function TaskLine({ t, ph, onOpen }) {
  return (
    <div className="person-task" onClick={() => onOpen(t)}>
      <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
      <span className="person-task-title">{t.title}</span>
      {ph && <span className="person-task-phase">{ph.label}</span>}
    </div>);
}

function UpcomingTimeline({ viewTasks, tasks, products, milestones, commPlan, categories, externals, phaseOf, onOpen, go }) {
  const DAYMS = 86400000;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  // upcoming = not done, dated, ending today or later — soonest first
  const upcoming = (viewTasks || [])
    .filter((t) => t.status !== "done" && t.start && t.end && new Date(t.end) >= today)
    .sort((a, b) => new Date(a.start) - new Date(b.start))
    .slice(0, 8);

  // future markers: milestones, gates, comms ending today or later
  const futureMs = (milestones || []).filter((m) => m.date && new Date(m.date) >= today);
  const futureComms = (commPlan || []).filter((c) => c.date && new Date(c.date) >= today);

  if (!upcoming.length && !futureMs.length && !futureComms.length) {
    return (
      <section className="dash-panel" style={{ marginBottom: 18 }}>
        <div className="dash-panel-hd"><span className="card-hd">Upcoming — the road ahead</span></div>
        <div className="dash-empty">Nothing scheduled ahead. Add dates to actions, gates/milestones or communications to see the road ahead.</div>
      </section>
    );
  }

  let min = Infinity, max = -Infinity;
  upcoming.forEach((t) => { min = Math.min(min, +new Date(t.start)); max = Math.max(max, +new Date(t.end)); });
  futureMs.forEach((m) => { min = Math.min(min, +new Date(m.date)); max = Math.max(max, +new Date(m.date)); });
  futureComms.forEach((c) => { min = Math.min(min, +new Date(c.date)); max = Math.max(max, +new Date(c.date)); });
  min = Math.min(min, +today);
  max = Math.max(max, +today + 7 * DAYMS);
  const span = Math.max(1, (max - min) / DAYMS);
  const pct = (d) => ((+new Date(d) - min) / DAYMS / span) * 100;
  const todayPct = ((+today - min) / DAYMS / span) * 100;
  const catColor = (id) => { const c = (categories || []).find((x) => x.id === id); return c ? "var(--t-" + c.color + ")" : "var(--accent)"; };

  // month ticks
  const ticks = [];
  const d = new Date(min); d.setDate(1);
  while (+d <= max) {
    ticks.push({ label: d.toLocaleDateString("en-GB", { month: "short" }), left: ((+d - min) / DAYMS / span) * 100 });
    d.setMonth(d.getMonth() + 1);
  }

  const gates = futureMs.filter((m) => m.type === "gate");
  const miles = futureMs.filter((m) => m.type !== "gate");
  // tie each gate/milestone to the action it gates: same category, nearest deadline
  const ownerOf = {};
  futureMs.forEach((m) => {
    const sameCat = upcoming.filter((t) => t.category && t.category === m.category);
    if (!sameCat.length) return;
    let best = null, bd = Infinity;
    sameCat.forEach((t) => { const d = Math.abs(+new Date(t.end) - +new Date(m.date)); if (d < bd) { bd = d; best = t; } });
    ownerOf[m.id] = best.id;
  });
  const ownerName = (id) => { const t = upcoming.find((x) => x.id === id); return t ? t.title : ""; };

  return (
    <section className="dash-panel up-panel" style={{ marginBottom: 18 }}>
      <div className="dash-panel-hd">
        <span className="card-hd">Upcoming — the road ahead</span>
        <button className="btn btn-sm btn-ghost" onClick={() => go("actions")}>Full timeline <Icon name="arrowR" size={13} /></button>
      </div>
      <div className="up-track-head">
        {ticks.map((tk, i) => (tk.left >= 0 && tk.left <= 100) && <span key={i} className="up-tick" style={{ left: tk.left + "%" }}>{tk.label}</span>)}
        {/* date ruler: every gate, milestone & comms marker */}
        {gates.map((m) => <span key={m.id} className="up-mk-gate" style={{ left: pct(m.date) + "%" }} title={m.title + " (gate) — " + fmtD(m.date) + (ownerOf[m.id] ? " · gates: " + ownerName(ownerOf[m.id]) : "")}>▐</span>)}
        {miles.map((m) => <span key={m.id} className="up-mk-mile" style={{ left: pct(m.date) + "%", color: catColor(m.category) }} title={m.title + (ownerOf[m.id] ? " · tied to: " + ownerName(ownerOf[m.id]) : "") + " — " + fmtD(m.date)}>◆</span>)}
        {futureComms.map((c) => <span key={c.id} className="up-mk-comm" style={{ left: pct(c.date) + "%" }} title={"Comms: " + (c.audience || "") + " — " + fmtD(c.date)}><Icon name="send" size={10} /></span>)}
        {todayPct >= 0 && todayPct <= 100 && <span className="up-today" style={{ left: todayPct + "%" }}><span className="up-today-pill">Today</span></span>}
      </div>
      <div className="up-rows">
        {todayPct >= 0 && todayPct <= 100 && <div className="up-today-layer"><span className="up-todayline-full" style={{ left: todayPct + "%" }} /></div>}
        {gates.length > 0 && <div className="up-today-layer">{gates.map((m) => { const gl = pct(m.date); return (gl >= 0 && gl <= 100) ? <span key={m.id} className="up-gateline-full" style={{ left: gl + "%" }} title={m.title + " (gate)" + (ownerOf[m.id] ? " — gates: " + ownerName(ownerOf[m.id]) : "")} /> : null; })}</div>}
        {upcoming.map((t) => {
          const left = Math.max(0, pct(t.start));
          const width = Math.max(2.5, pct(t.end) - pct(t.start));
          const deps = (t.deps || []).map((dep) => resolveDep(dep, tasks, products, t, externals));
          const blockers = deps.filter((r) => r.blocked && !r.external);
          const extDeps = deps.filter((r) => r.external);
          const risky = blockers.length > 0;
          const rowGates = gates.filter((m) => ownerOf[m.id] === t.id);
          const rowMiles = miles.filter((m) => ownerOf[m.id] === t.id);
          return (
            <div key={t.id} className={"up-row" + (risky ? " risky" : "")} onClick={() => onOpen(t)}>
              <div className="up-label">
                <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                <span className="up-title">{t.title}</span>
                {rowGates.map((m) => <span key={m.id} className="up-tie up-tie-gate" title={"Gate: " + m.title}>▐ gate</span>)}
                {rowMiles.map((m) => <span key={m.id} className="up-tie up-tie-ms" style={{ color: catColor(m.category) }} title={"Milestone: " + m.title}>◆</span>)}
                {risky && <span className="up-warn" title={"Waiting on: " + blockers.map((b) => b.name).join(", ")}><Icon name="warn" size={12} /> {blockers.length}</span>}
                {extDeps.length > 0 && <span className="up-ext" title={"External: " + extDeps.map((b) => b.name).join(", ")}><Icon name="inbound" size={11} /> {extDeps.length}</span>}
              </div>
              <div className="up-track">
                <span className={"up-bar" + (t.status === "inprogress" ? " active" : "")} style={{ left: left + "%", width: width + "%" }}>
                  <span className="up-bar-dates">{fmtD(t.start)} → {fmtD(t.end)}</span>
                </span>
                {rowGates.map((m) => <span key={m.id} className="up-rowgate" style={{ left: pct(m.date) + "%" }} title={m.title + " (gate) — gates this action"}><span className="up-rowgate-dia">◆</span></span>)}
                {rowMiles.map((m) => <span key={m.id} className="up-rowms" style={{ left: pct(m.date) + "%", color: catColor(m.category) }} title={m.title + " — tied to this action"}>◆</span>)}
              </div>
            </div>
          );
        })}
        {/* gates/milestones with no task rows still need a band to sit on */}
        {!upcoming.length && (gates.length || miles.length || futureComms.length) > 0 && (
          <div className="up-row">
            <div className="up-label"><span className="up-title muted">Key dates</span></div>
            <div className="up-track"></div>
          </div>
        )}
      </div>
      <div className="up-legend">
        <span><span className="up-leg-bar active" /> In progress</span>
        <span><span className="up-leg-bar" /> Upcoming</span>
        <span style={{ color: "var(--accent-deep)" }}>◆ Milestone</span>
        <span style={{ color: "var(--t-red)" }}>▐ Gate</span>
        <span style={{ color: "var(--t-teal)" }}><Icon name="send" size={11} /> Comms</span>
        <span className="up-leg-warn"><Icon name="warn" size={12} /> Waiting on an unfinished task</span>
      </div>
    </section>
  );
}

function Stat({ n, label, icon, accent }) {
  return (
    <div className={"stat" + (accent ? " accent" : "")}>
      <span className="stat-icon"><Icon name={icon} size={17} /></span>
      <span className="stat-n serif">{n}</span>
      <span className="stat-label">{label}</span>
    </div>);

}

function HeroImage({ projectId }) {
  const KEY = "atlas.hero." + projectId;
  const [url, setUrl] = React.useState(null);
  const inputRef = React.useRef(null);
  React.useEffect(() => {
    let u;
    Store.files.get(KEY).then((blob) => {
      if (blob) { u = URL.createObjectURL(blob); setUrl(u); }
    });
    return () => { if (u) URL.revokeObjectURL(u); };
  }, [projectId]);
  const onFile = async (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    await Store.files.put(KEY, file);
    if (url) URL.revokeObjectURL(url);
    setUrl(URL.createObjectURL(file));
  };
  const onDrop = (e) => { e.preventDefault(); if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]); };
  const remove = async () => { await Store.files.del(KEY); if (url) URL.revokeObjectURL(url); setUrl(null); };

  if (url) {
    return (
      <div className="hero-img-wrap">
        <img src={url} className="hero-img" alt="Project cover" />
        <div className="hero-img-actions no-print">
          <button className="btn btn-sm btn-ghost" onClick={() => inputRef.current.click()}><Icon name="edit" size={13} /> Change</button>
          <button className="btn btn-sm btn-ghost btn-danger" onClick={remove}><Icon name="trash" size={13} /></button>
        </div>
        <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => { if (e.target.files[0]) onFile(e.target.files[0]); e.target.value = ""; }} />
      </div>
    );
  }
  return (
    <div className="hero-img-drop no-print" onDragOver={(e) => e.preventDefault()} onDrop={onDrop} onClick={() => inputRef.current.click()}>
      <Icon name="image" size={22} />
      <span>Add a cover image</span>
      <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e) => { if (e.target.files[0]) onFile(e.target.files[0]); e.target.value = ""; }} />
    </div>
  );
}

Object.assign(window, { Dashboard });

/* ============================================================
   WORKSPACE — a person's tasks + everything tied to each one
   (deps, deliverables, links, risks, insights, comments) in one place
   ============================================================ */
function Workspace({ go }) {
  const s = Store.useStore();
  const { tasks, risks, products, findings, phases, categories, members, milestones, externals } = s;
  const [openTask, setOpenTask] = useD(null);
  const [mode, setMode] = useD(() => localStorage.getItem("atlas.ws.mode") || "focus");
  const setWsMode = (m) => { setMode(m); localStorage.setItem("atlas.ws.mode", m); };

  const WKEY = "atlas.view." + s.id;
  const [who, setWho] = useD(() => {
    const saved = localStorage.getItem(WKEY);
    const has = (n) => tasks.some((t) => assigneesOf(t).includes(n));
    if (saved != null && (saved === "" || has(saved))) return saved;
    if (has("You")) return "You";
    return ""; // Everyone — never land on an empty view
  });
  const people = useDM(() => {
    // members are the single source of truth for who can be viewed
    return [...new Set((members || []).map((m) => m.name).filter(Boolean))].sort((a, b) => (a === "You" ? -1 : b === "You" ? 1 : a.localeCompare(b)));
  }, [members]);
  const everyone = who === "";
  const changeWho = (v) => { setWho(v); if (v) localStorage.setItem(WKEY, v); else localStorage.removeItem(WKEY); };

  const myTasks = useDM(() => (everyone ? tasks : tasks.filter((t) => assigneesOf(t).includes(who))), [tasks, who, everyone]);
  const groups = useDM(() => STATUS_ORDER.map((st) => ({ ...st, items: myTasks.filter((t) => t.status === st.id) })).filter((g) => g.items.length), [myTasks]);

  const [sel, setSel] = useD(null);
  const selTask = myTasks.find((t) => t.id === sel) || myTasks[0] || null;

  const phaseOf = (id) => phases.find((p) => p.id === id);
  const catOf = (id) => categories.find((c) => c.id === id);
  const today = new Date(); today.setHours(0, 0, 0, 0);

  // everything tied to the selected task
  const ctx = useDM(() => {
    if (!selTask) return null;
    const tid = selTask.id;
    const deps = (selTask.deps || []).map((d) => resolveDep(d, tasks, products, selTask, externals));
    const deliverables = products.filter((p) => (p.taskIds || []).includes(tid));
    const linkedRisks = risks.filter((r) => (r.taskIds || []).includes(tid));
    const insights = findings.filter((f) => f.category && f.category === selTask.category);
    const cf = (s.customFields || []).map((f) => ({ f, v: (selTask.custom || {})[f.id] })).filter((x) => x.v !== undefined && x.v !== "" && x.v !== null);
    const gates = (milestones || []).filter((m) => m.type === "gate" && m.category === selTask.category && m.date && selTask.end && new Date(m.date) >= new Date(selTask.end));
    return { deps, deliverables, linkedRisks, insights, cf, gates };
  }, [selTask, tasks, products, risks, findings, milestones, s.customFields]);

  const openLink = async (p) => {
    if (p.externalUrl) { window.open(p.externalUrl, "_blank", "noopener"); return; }
    if (p.fileId) { try { const b = await Store.files.get(p.fileId); if (b) { const u = URL.createObjectURL(b); window.open(u, "_blank"); setTimeout(() => URL.revokeObjectURL(u), 60000); } } catch (e) {} }
  };

  return (
    <div className="view-scroll"><div className="ws">
      <div className="ws-bar no-print">
        <div className="dash-viewselect ws-who">
          {!everyone && <span className="avatar" style={{ width: 24, height: 24, fontSize: 10, background: "var(--t-" + ((members.find((m) => m.name === who) || {}).color || "indigo") + ")" }}>{initials(who)}</span>}
          {everyone && <span className="dash-viewglobe"><Icon name="users" size={15} /></span>}
          <select value={who} onChange={(e) => changeWho(e.target.value)}>
            <option value="">Everyone — all tasks</option>
            {people.map((p) => <option key={p} value={p}>{p === "You" ? "You" : p}</option>)}
          </select>
          <Icon name="chevD" size={14} />
        </div>
        <p className="muted ws-intro">{everyone ? "Every task and everything tied to it, in one place." : `${who === "You" ? "Your" : who + "'s"} tasks and everything needed to do them — in one place.`}</p>
        <div className="grow" />
        <div className="seg-toggle ws-modetoggle">
          <button className={mode === "focus" ? "on" : ""} onClick={() => setWsMode("focus")}><Icon name="layers" size={14} /> Focus</button>
          <button className={mode === "timeline" ? "on" : ""} onClick={() => setWsMode("timeline")}><Icon name="timeline" size={14} /> Timeline</button>
        </div>
      </div>

      {myTasks.length === 0 && <div className="empty"><div className="serif">Nothing here yet</div>{everyone ? "No tasks in this project yet." : `${who} isn't assigned to any tasks. Assign them on a task card.`}</div>}

      {myTasks.length > 0 && mode === "focus" && (
        <div className="ws-split">
          <div className="ws-list">
            {groups.map((g) => (
              <div key={g.id} className="ws-group">
                <div className="ws-group-hd"><span className={"status-dot s-" + g.id} /> {g.label} <span className="ws-group-n">{g.items.length}</span></div>
                {g.items.map((t) => {
                  const overdue = t.status !== "done" && t.end && new Date(t.end) < today;
                  const nLinks = products.filter((p) => (p.taskIds || []).includes(t.id)).length;
                  const nRisks = risks.filter((r) => (r.taskIds || []).includes(t.id)).length;
                  const nDeps = (t.deps || []).length;
                  const nCmt = (t.comments || []).length;
                  return (
                    <button key={t.id} className={"ws-item" + (selTask && selTask.id === t.id ? " on" : "")} onClick={() => setSel(t.id)}>
                      <span className="prio-pip" style={{ background: PRIO[t.priority]?.c }} />
                      <span className="ws-item-main">
                        <span className="ws-item-title">{t.title}</span>
                        <span className="ws-item-meta">
                          {everyone && assigneesOf(t).length > 0 && <span className="ws-im-who">{assigneesOf(t)[0]}{assigneesOf(t).length > 1 ? " +" + (assigneesOf(t).length - 1) : ""}</span>}
                          {t.end && <span className={"ws-im-date" + (overdue ? " over" : "")}>{fmtD(t.end)}</span>}
                          {nDeps > 0 && <span className="ws-im-tag"><Icon name="link" size={10} />{nDeps}</span>}
                          {nLinks > 0 && <span className="ws-im-tag"><Icon name="box" size={10} />{nLinks}</span>}
                          {nRisks > 0 && <span className="ws-im-tag risk"><Icon name="shield" size={10} />{nRisks}</span>}
                          {nCmt > 0 && <span className="ws-im-tag"><Icon name="chat" size={10} />{nCmt}</span>}
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>

          {selTask && ctx && (
            <div className="ws-detail">
              <WSHub task={selTask} ctx={ctx} phaseOf={phaseOf} catOf={catOf} members={members} onOpen={() => setOpenTask(selTask)} openLink={openLink} go={go} />
            </div>
          )}
        </div>
      )}

      {myTasks.length > 0 && mode === "timeline" && (
        <div className="ws-tl-wrap">
          <WSTimeline tasks={myTasks} selId={selTask && selTask.id} onSelect={setSel} catOf={catOf} />
          {selTask && ctx && (
            <div className="ws-detail ws-detail-wide">
              <WSHub task={selTask} ctx={ctx} phaseOf={phaseOf} catOf={catOf} members={members} onOpen={() => setOpenTask(selTask)} openLink={openLink} go={go} />
            </div>
          )}
        </div>
      )}
      {openTask && <CardModal task={openTask} onClose={() => setOpenTask(null)} />}
    </div></div>
  );
}

/* personal timeline — the selected person's dated tasks on a month axis */
function WSTimeline({ tasks, selId, onSelect, catOf }) {
  const dated = tasks.filter((t) => t.start && t.end).sort((a, b) => new Date(a.start) - new Date(b.start));
  const undated = tasks.filter((t) => !(t.start && t.end));
  const today = new Date(); today.setHours(0, 0, 0, 0);
  if (!dated.length) return (
    <div className="ws-tl panel"><div className="empty" style={{ padding: 28 }}>No scheduled tasks. Add start and end dates to see them on the timeline.{undated.length ? ` (${undated.length} undated.)` : ""}</div></div>
  );
  const min = new Date(Math.min(...dated.map((t) => +new Date(t.start))));
  const max = new Date(Math.max(...dated.map((t) => +new Date(t.end))));
  min.setDate(min.getDate() - 3); max.setDate(max.getDate() + 3);
  const DAYW = 13;
  const days = Math.max(1, Math.round((max - min) / 86400000));
  const totalW = days * DAYW;
  const dleft = (d) => Math.round((new Date(d) - min) / 86400000) * DAYW;
  const months = [];
  let cur = new Date(min.getFullYear(), min.getMonth(), 1);
  while (cur <= max) { const next = new Date(cur.getFullYear(), cur.getMonth() + 1, 1); const l = Math.max(0, dleft(cur)); const r = Math.min(totalW, dleft(next)); months.push({ label: cur.toLocaleDateString("en-GB", { month: "short", year: "2-digit" }), left: l, width: r - l }); cur = next; }
  const todayLeft = today >= min && today <= max ? dleft(today) : null;
  return (
    <div className="ws-tl panel">
      <div className="ws-tl-scroll">
        <div className="ws-tl-inner" style={{ width: totalW + 200 }}>
          <div className="ws-tl-head">
            <div className="ws-tl-corner">Task</div>
            <div className="ws-tl-axis" style={{ width: totalW }}>
              {months.map((m, i) => <div key={i} className="ws-tl-month" style={{ left: m.left, width: m.width }}>{m.label}</div>)}
            </div>
          </div>
          {dated.map((t) => {
            const cat = catOf(t.category);
            const color = cat ? "var(--t-" + cat.color + ")" : "var(--accent)";
            const left = dleft(t.start);
            const w = Math.max(DAYW, dleft(t.end) - left);
            const overdue = t.status !== "done" && new Date(t.end) < today;
            return (
              <div key={t.id} className={"ws-tl-row" + (selId === t.id ? " on" : "")} onClick={() => onSelect(t.id)}>
                <div className="ws-tl-label" title={t.title}>{t.title}</div>
                <div className="ws-tl-track" style={{ width: totalW }}>
                  {todayLeft != null && <div className="ws-tl-today" style={{ left: todayLeft }} />}
                  <div className={"ws-tl-bar" + (t.status === "done" ? " done" : "") + (overdue ? " over" : "")} style={{ left, width: w, "--c": color }}>
                    <span className="ws-tl-bar-label">{t.title}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {undated.length > 0 && (
        <div className="ws-tl-undated">
          <span className="ws-tl-undated-h">Undated</span>
          {undated.map((t) => <button key={t.id} className={"ws-tl-chip" + (selId === t.id ? " on" : "")} onClick={() => onSelect(t.id)}>{t.title}</button>)}
        </div>
      )}
    </div>
  );
}

function WSHub({ task, ctx, phaseOf, catOf, members, onOpen, openLink, go }) {
  const ph = phaseOf(task.phase), cat = catOf(task.category);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const subs = Store.getState().tasks.filter((x) => x.parentId === task.id);
  const overdue = task.status !== "done" && task.end && new Date(task.end) < today;
  const STL = { backlog: "To do", inprogress: "In progress", done: "Done" };
  const { deps, deliverables, linkedRisks, insights, cf, gates } = ctx;
  const typeColor = (t) => "var(--t-" + ({ image: "pink", pdf: "red", excel: "green", slides: "amber", doc: "blue" }[t] || "blue") + ")";
  return (
    <div className="ws-hub">
      <div className="ws-hub-head">
        <div className="grow" style={{ minWidth: 0 }}>
          <div className="ws-hub-status"><span className={"status-dot s-" + task.status} /> {STL[task.status]}</div>
          <h2 className="ws-hub-title serif" onClick={onOpen} title="Open full task">{task.title}</h2>
          <div className="ws-hub-chips">
            {cat && <span className="chip" style={{ "--chip-c": "var(--t-" + cat.color + ")" }}><span className="chip-dot" style={{ background: "var(--t-" + cat.color + ")" }} />{cat.label}</span>}
            {ph && <span className="chip" style={{ "--chip-c": "var(--t-" + ph.color + ")" }}>{ph.label}</span>}
            <span className="chip" style={{ "--chip-c": PRIO[task.priority]?.c }}>{PRIO[task.priority]?.label} priority</span>
            {task.end && <span className={"ws-hub-date" + (overdue ? " over" : "")}><Icon name="calendar" size={12} /> {task.start ? fmtD(task.start) + " → " : "due "}{fmtD(task.end)}{overdue ? " · overdue" : ""}</span>}
          </div>
        </div>
        <div className="ws-hub-statuspick">
          <select className="ws-status-sel" value={task.status} onChange={(e) => Store.patch("tasks", task.id, { status: e.target.value })} title="Change status">
            {COLUMNS.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
          <button className="btn btn-sm" onClick={onOpen}><Icon name="board" size={14} /> Open task</button>
        </div>
      </div>

      {task.assignees && task.assignees.length > 0 && (
        <div className="ws-hub-people">
          {assigneesOf(task).map((n) => <span key={n} className="assignee-chip"><span className="avatar" style={{ width: 18, height: 18, fontSize: 8 }}>{initials(n)}</span>{n}</span>)}
        </div>
      )}

      {task.desc && <p className="ws-hub-desc">{task.desc}</p>}
      {!task.desc && <p className="ws-hub-desc ws-hub-nodesc">No description yet — open the task to add one.</p>}

      {subs.length > 0 && (
        <div className="ws-card ws-card-cmt" style={{ marginBottom: 14 }}>
          <div className="ws-card-hd"><Icon name="layers" size={14} /> Subtasks <span className="ws-card-n">{subs.filter((x) => x.status === "done").length}/{subs.length}</span></div>
          {subs.map((st) => (
            <div key={st.id} className="ws-sub-row">
              <button className={"sub-check s-" + st.status} title={st.status === "done" ? "Mark not done" : "Mark done"} onClick={() => Store.patch("tasks", st.id, { status: st.status === "done" ? "backlog" : "done" })}>{st.status === "done" ? <Icon name="check" size={11} /> : null}</button>
              <span className={"ws-sub-name" + (st.status === "done" ? " done" : "")}>{st.title}</span>
              {st.end && <span className="ws-sub-date mono">{fmtD(st.end)}</span>}
            </div>
          ))}
        </div>
      )}

      <div className="ws-hub-grid">
        {deps.length > 0 && (
          <div className="ws-card">
            <div className="ws-card-hd"><Icon name="link" size={14} /> Depends on <span className="ws-card-n">{deps.length}</span></div>
            {deps.map((d, i) => (
              <div key={i} className={"ws-line" + (d.violated ? " bad" : "")}>
                <Icon name={d.icon} size={13} />
                <span className="grow">{d.name}{d.external && d.scope ? <span className="muted"> · {d.scope}</span> : ""}</span>
                <span className={"ws-line-tag " + (d.violated ? "bad" : d.blocked ? "warn" : "ok")}>{d.violated ? "blocked" : d.blocked ? "waiting" : d.status === "done" ? "ready" : "ok"}</span>
              </div>
            ))}
          </div>
        )}

        {deliverables.length > 0 && (
          <div className="ws-card">
            <div className="ws-card-hd"><Icon name="box" size={14} /> Deliverables &amp; links <span className="ws-card-n">{deliverables.length}</span></div>
            {deliverables.map((p) => (
              <button key={p.id} className="ws-line ws-line-btn" onClick={() => openLink(p)} title={p.externalUrl || (p.fileId ? "Open file" : "No file attached")}>
                <span className="ws-file-ico" style={{ color: typeColor(p.type) }}><Icon name={p.externalUrl ? "link" : (TYPE_ICON[p.type] || "file")} size={13} /></span>
                <span className="grow ws-file-name">{p.name}</span>
                {p.externalUrl ? <span className="ws-line-tag ok">Drive</span> : p.fileId ? <span className="ws-line-tag">file</span> : <span className="ws-line-tag muted">none</span>}
              </button>
            ))}
          </div>
        )}

        {linkedRisks.length > 0 && (
          <div className="ws-card">
            <div className="ws-card-hd"><Icon name="shield" size={14} /> Risks this mitigates <span className="ws-card-n">{linkedRisks.length}</span></div>
            {linkedRisks.map((r) => (
              <div key={r.id} className="ws-line ws-line-btn" onClick={() => go && go("risks")}>
                <span className="risk-score sm" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
                <span className="grow">{r.title}</span>
              </div>
            ))}
          </div>
        )}

        {insights.length > 0 && (
          <div className="ws-card">
            <div className="ws-card-hd"><Icon name="bulb" size={14} /> Insights from pre-analysis <span className="ws-card-n">{insights.length}</span></div>
            {insights.map((f) => (
              <div key={f.id} className="ws-line ws-line-btn ws-insight" onClick={() => go && go("preanalysis")}>
                <Icon name="bulb" size={13} />
                <span className="grow">{f.title}</span>
              </div>
            ))}
          </div>
        )}

        {gates.length > 0 && (
          <div className="ws-card">
            <div className="ws-card-hd"><Icon name="gate" size={14} /> Gate ahead <span className="ws-card-n">{gates.length}</span></div>
            {gates.map((g) => (
              <div key={g.id} className="ws-line">
                <span className="ws-gate-ico"><Icon name="gate" size={12} /></span>
                <span className="grow">{g.title}</span>
                <span className="ws-line-tag mono">{fmtD(g.date)}</span>
              </div>
            ))}
          </div>
        )}

        {cf.length > 0 && (
          <div className="ws-card">
            <div className="ws-card-hd"><Icon name="tag" size={14} /> Details</div>
            {cf.map(({ f, v }) => (
              <div key={f.id} className="ws-line">
                <span className="ws-cf-label">{f.label}</span>
                <span className="grow ws-cf-val">{f.type === "checkbox" ? (v ? "Yes" : "No") : f.type === "date" ? fmtD(v) : String(v)}</span>
              </div>
            ))}
          </div>
        )}

        <div className="ws-card ws-card-cmt">
          <TaskComments task={task} members={members || []} projectId={Store.getState().id} />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Workspace, WSHub });

/* ============================================================
   STRATEGY — start-up founding sections (all stored under s.startup)
   Mission/Vision · Value Proposition · BMC · Lean Canvas ·
   Market & Competition · Personas · Go-to-Market
   ============================================================ */
function useStartup() {
  const s = Store.useStore();
  const st = s.startup || {};
  const set = (key, val) => Store.setState((p) => { const cur = p.startup || {}; return { ...p, startup: { ...cur, [key]: typeof val === "function" ? val(cur[key]) : val } }; });
  return [st, set];
}
function AutoGrow({ value, onChange, placeholder, className }) {
  const ref = React.useRef(null);
  const fit = () => { const el = ref.current; if (el) { el.style.height = "auto"; el.style.height = el.scrollHeight + "px"; } };
  React.useEffect(() => { fit(); }, [value]);
  return <textarea ref={ref} rows={1} className={className} value={value} placeholder={placeholder} onInput={fit} onChange={(e) => onChange(e.target.value)} />;
}
function StrList({ items, onChange, placeholder, accent }) {
  const arr = Array.isArray(items) ? items : [];
  return (
    <div className="stg-list">
      {arr.map((it, i) => (
        <div className="stg-list-row" key={i}>
          <span className="stg-bullet" style={accent ? { background: accent } : undefined} />
          <AutoGrow className="stg-inp" value={it} onChange={(v) => onChange(arr.map((x, j) => (j === i ? v : x)))} placeholder={placeholder || "…"} />
          <button className="stg-x no-print" onClick={() => onChange(arr.filter((_, j) => j !== i))} title="Remove"><Icon name="x" size={12} /></button>
        </div>
      ))}
      <button className="stg-add no-print" onClick={() => onChange([...arr, ""])}><Icon name="plus" size={12} /> Add</button>
    </div>
  );
}
function StgIntro({ children }) { return <p className="muted stg-intro">{children}</p>; }

function MissionVision() {
  const [st, set] = useStartup();
  const m = st.mission || {};
  const setM = (k, v) => set("mission", (c) => ({ ...(c || {}), [k]: v }));
  const values = m.values || [];
  const setValues = (vs) => setM("values", vs);
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>The founding statements that anchor every decision. Keep them short and memorable.</StgIntro>
      <div className="stg-statements">
        <div className="stg-stmt">
          <div className="stg-stmt-label">Vision <span>— the world we're working toward</span></div>
          <UI.Editable className="stg-stmt-text serif" tag="div" multiline value={m.vision || ""} onChange={(v) => setM("vision", v)} placeholder="In a world where…" />
        </div>
        <div className="stg-stmt">
          <div className="stg-stmt-label">Mission <span>— what we do, for whom, and why</span></div>
          <UI.Editable className="stg-stmt-text serif" tag="div" multiline value={m.mission || ""} onChange={(v) => setM("mission", v)} placeholder="We help…" />
        </div>
      </div>
      <div className="stg-box" style={{ marginTop: 16 }}>
        <div className="stg-box-hd"><Icon name="flag" size={14} /><span>Core values</span></div>
        <div className="stg-box-hint">The principles that guide how the team behaves.</div>
        <div className="stg-values">
          {values.map((v) => (
            <div className="stg-value" key={v.id}>
              <button className="stg-x no-print" onClick={() => setValues(values.filter((x) => x.id !== v.id))} title="Remove"><Icon name="x" size={12} /></button>
              <UI.Editable className="stg-value-name" value={v.label} onChange={(val) => setValues(values.map((x) => (x.id === v.id ? { ...x, label: val } : x)))} placeholder="Value" />
              <UI.Editable className="stg-value-desc" multiline value={v.desc} onChange={(val) => setValues(values.map((x) => (x.id === v.id ? { ...x, desc: val } : x)))} placeholder="What it means in practice…" />
            </div>
          ))}
          <button className="stg-add-card no-print" onClick={() => setValues([...values, { id: Store.uid("val"), label: "", desc: "" }])}><Icon name="plus" size={14} /> Add value</button>
        </div>
      </div>
    </div></div>
  );
}

const PAIN_SEV = [["high", "Severe", "var(--t-red)"], ["med", "Moderate", "var(--t-amber)"], ["low", "Minor", "var(--ink-faint)"]];
// pains can be legacy strings or {t, sev}; normalize on read
function normPain(p) { return typeof p === "string" ? { t: p, sev: "med" } : { t: (p && p.t) || "", sev: (p && p.sev) || "med" }; }
function PainList({ items, onChange }) {
  const arr = (Array.isArray(items) ? items : []).map(normPain);
  const order = { high: 0, med: 1, low: 2 };
  const idx = arr.map((_, i) => i).sort((a, b) => order[arr[a].sev] - order[arr[b].sev]);
  const cycleSev = (i) => { const cur = arr[i].sev; const next = cur === "high" ? "med" : cur === "med" ? "low" : "high"; onChange(arr.map((x, j) => j === i ? { ...x, sev: next } : x)); };
  const sevMeta = (s) => PAIN_SEV.find((m) => m[0] === s) || PAIN_SEV[1];
  return (
    <div className="vp-pain-list">
      {idx.map((i) => { const p = arr[i]; const m = sevMeta(p.sev); return (
        <div className="vp-pain-row" key={i} style={{ "--sev": m[2] }}>
          <button className="vp-pain-sev no-print" title={"Severity: " + m[1] + " — click to change"} onClick={() => cycleSev(i)}><span className="vp-pain-dot" /></button>
          <AutoGrow className="stg-inp vp-pain-inp" value={p.t} onChange={(v) => onChange(arr.map((x, j) => j === i ? { ...x, t: v } : x))} placeholder="What frustrates or blocks them?" />
          <span className="vp-pain-tag" style={{ color: m[2] }}>{m[1]}</span>
          <button className="stg-x no-print" onClick={() => onChange(arr.filter((_, j) => j !== i))} title="Remove"><Icon name="x" size={12} /></button>
        </div>
      ); })}
      <button className="stg-add no-print" onClick={() => onChange([...arr, { t: "", sev: "med" }])}><Icon name="plus" size={12} /> Add pain</button>
    </div>
  );
}
function ValueProp() {
  const [st, set] = useStartup();
  const vp = st.valueProp || {};
  const setVP = (k, v) => set("valueProp", (c) => ({ ...(c || {}), [k]: v }));
  const segs = vp.segments || [];
  const setSegs = (s) => setVP("segments", s);
  const patchSeg = (id, k, v) => setSegs(segs.map((x) => (x.id === id ? { ...x, [k]: v } : x)));
  const painCount = (sg) => (sg.pains || []).map(normPain).filter((p) => p.sev === "high").length;
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>Understand each client type before pitching to them: start with their world (jobs, pains, gains), rank how much each pain hurts, then map what you offer to relieve it. Pains are sorted most-severe first.</StgIntro>
      <div className="stg-headline">
        <div className="stg-stmt-label">Headline value proposition</div>
        <UI.Editable className="stg-stmt-text serif" tag="div" multiline value={vp.headline || ""} onChange={(v) => setVP("headline", v)} placeholder="We help [customer] achieve [outcome] by [how], unlike [alternative]." />
      </div>
      {segs.map((sg) => (
        <div className="stg-vp-seg" key={sg.id}>
          <div className="stg-vp-seg-hd">
            <span className="vp-seg-ico"><Icon name="persona" size={16} /></span>
            <UI.Editable className="stg-vp-seg-name" value={sg.segment} onChange={(v) => patchSeg(sg.id, "segment", v)} placeholder="Client type (e.g. Startups)" />
            {painCount(sg) > 0 && <span className="vp-seg-painflag" title={painCount(sg) + " severe pain(s)"}>{painCount(sg)} severe pain{painCount(sg) === 1 ? "" : "s"}</span>}
            <button className="stg-x no-print" onClick={() => setSegs(segs.filter((x) => x.id !== sg.id))} title="Remove segment"><Icon name="x" size={13} /></button>
          </div>
          <div className="vp-seg-context">
            <UI.Editable value={sg.context} onChange={(v) => patchSeg(sg.id, "context", v)} placeholder="Who they are in one line — size, stage, situation…" />
          </div>
          <div className="stg-vp-grid">
            <div className="stg-vp-col stg-vp-cust">
              <div className="stg-vp-col-hd"><Icon name="persona" size={13} /> Their world</div>
              <div className="stg-sub">Jobs — what they're trying to get done</div><StrList items={sg.jobs} onChange={(v) => patchSeg(sg.id, "jobs", v)} accent="var(--t-indigo)" />
              <div className="stg-sub vp-sub-pain">Pains — what frustrates or blocks them <span className="vp-sub-hint">click a dot to rank severity</span></div>
              <PainList items={sg.pains} onChange={(v) => patchSeg(sg.id, "pains", v)} />
              <div className="stg-sub">Gains — what a good outcome looks like</div><StrList items={sg.gains} onChange={(v) => patchSeg(sg.id, "gains", v)} accent="var(--t-teal)" />
            </div>
            <div className="stg-vp-col stg-vp-value">
              <div className="stg-vp-col-hd"><Icon name="gift" size={13} /> How we answer it</div>
              <div className="stg-sub">Products & services</div><StrList items={sg.products} onChange={(v) => patchSeg(sg.id, "products", v)} accent="var(--t-blue)" />
              <div className="stg-sub">Pain relievers — how we ease each pain</div><StrList items={sg.relievers} onChange={(v) => patchSeg(sg.id, "relievers", v)} accent="var(--t-green)" />
              <div className="stg-sub">Gain creators — how we deliver the upside</div><StrList items={sg.creators} onChange={(v) => patchSeg(sg.id, "creators", v)} accent="var(--t-amber)" />
            </div>
          </div>
        </div>
      ))}
      <button className="stg-add-card no-print" onClick={() => setSegs([...segs, { id: Store.uid("seg"), segment: "", context: "", jobs: [], pains: [], gains: [], products: [], relievers: [], creators: [] }])}><Icon name="plus" size={14} /> Add client type</button>
    </div></div>
  );
}

const BMC_BLOCKS = [
  ["partners", "Key Partners", "Who helps us deliver?"],
  ["activities", "Key Activities", "What must we do well?"],
  ["resources", "Key Resources", "What assets do we need?"],
  ["value", "Value Propositions", "What value do we deliver?"],
  ["relationships", "Customer Relationships", "How do we engage them?"],
  ["channels", "Channels", "How do we reach them?"],
  ["segments", "Customer Segments", "Who are we serving?"],
  ["costs", "Cost Structure", "What drives our costs?"],
  ["revenue", "Revenue Streams", "How do we earn?"],
];
function BmcBlock({ blockKey, title, hint, bmc, setBlock, setMode }) {
  const mode = (bmc._mode && bmc._mode[blockKey]) || "list";
  return (
    <div className={"stg-box bmc-" + blockKey}>
      <div className="stg-box-hd">
        <span>{title}</span>
        <div className="bmc-mode no-print">
          <button className={"bmc-mode-btn" + (mode === "list" ? " on" : "")} title="Bullet list" onClick={() => setMode(blockKey, "list")}><Icon name="list" size={12} /></button>
          <button className={"bmc-mode-btn" + (mode === "notes" ? " on" : "")} title="Free text" onClick={() => setMode(blockKey, "notes")}><Icon name="doc" size={12} /></button>
        </div>
      </div>
      <div className="stg-box-hint">{hint}</div>
      {mode === "notes"
        ? <UI.Editable className="bmc-notes" tag="div" multiline value={bmc[blockKey + "_note"] || ""} onChange={(v) => setBlock(blockKey + "_note", v)} placeholder="Write as much as you need…" />
        : <StrList items={bmc[blockKey]} onChange={(v) => setBlock(blockKey, v)} />}
    </div>
  );
}
function BMC() {
  const [st, set] = useStartup();
  const bmc = st.bmc || {};
  const setBlock = (k, v) => set("bmc", (c) => ({ ...(c || {}), [k]: v }));
  const setMode = (k, m) => set("bmc", (c) => ({ ...(c || {}), _mode: { ...((c || {})._mode || {}), [k]: m } }));
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>The nine building blocks of how the business creates, delivers and captures value. Use the toggle on any block to switch between a bullet list and free-form notes.</StgIntro>
      <div className="bmc-grid">
        {BMC_BLOCKS.map(([k, title, hint]) => (
          <BmcBlock key={k} blockKey={k} title={title} hint={hint} bmc={bmc} setBlock={setBlock} setMode={setMode} />
        ))}
      </div>
    </div></div>
  );
}

const LEAN_BLOCKS = [
  ["problem", "Problem", "Top 1–3 problems", true],
  ["solution", "Solution", "Top features", true],
  ["uvp", "Unique Value Proposition", "Single, clear, compelling message", true],
  ["advantage", "Unfair Advantage", "Can't be easily copied or bought", true],
  ["segments", "Customer Segments", "Target customers & users", true],
  ["metrics", "Key Metrics", "Numbers that tell you how you're doing", true],
  ["channels", "Channels", "Path to customers", true],
  ["costs", "Cost Structure", "Customer acquisition, hosting, people…", true],
  ["revenue", "Revenue Streams", "Revenue model, pricing, LTV", true],
];
function LeanCanvas() {
  const [st, set] = useStartup();
  const lean = st.lean || {};
  const setBlock = (k, v) => set("lean", (c) => ({ ...(c || {}), [k]: v }));
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>A one-page startup model — the leaner, more problem/risk-focused cousin of the Business Model Canvas.</StgIntro>
      <div className="lean-grid">
        {LEAN_BLOCKS.map(([k, title, hint]) => (
          <div className={"stg-box lean-" + k} key={k}>
            <div className="stg-box-hd"><span>{title}</span></div>
            <div className="stg-box-hint">{hint}</div>
            <StrList items={lean[k]} onChange={(v) => setBlock(k, v)} />
          </div>
        ))}
      </div>
    </div></div>
  );
}

function MarketCompetition() {
  const [st, set] = useStartup();
  const mk = st.market || {};
  const setMk = (k, v) => set("market", (c) => ({ ...(c || {}), [k]: v }));
  const comp = mk.competitors || [];
  const setComp = (c) => setMk("competitors", c);
  const patchC = (id, k, v) => setComp(comp.map((x) => (x.id === id ? { ...x, [k]: v } : x)));
  const STATS = [["tam", "TAM", "Total addressable market"], ["sam", "SAM", "Serviceable available market"], ["som", "SOM", "Serviceable obtainable market"]];
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>How big is the opportunity, who else is in it, and how you win.</StgIntro>
      <div className="mkt-sizing">
        {STATS.map(([k, label, hint]) => (
          <div className="mkt-stat" key={k}>
            <div className="mkt-stat-label">{label}</div>
            <UI.Editable className="mkt-stat-val serif" value={mk[k]} onChange={(v) => setMk(k, v)} placeholder="€ —" />
            <div className="mkt-stat-hint">{hint}</div>
          </div>
        ))}
      </div>
      <div className="stg-box">
        <div className="stg-box-hd"><Icon name="scope" size={14} /><span>Positioning statement</span></div>
        <UI.Editable className="stg-stmt-text" tag="div" multiline value={mk.positioning || ""} onChange={(v) => setMk("positioning", v)} placeholder="For [target] who [need], [product] is the [category] that [benefit] — unlike [competitors]." />
      </div>
      <div className="stg-box" style={{ marginTop: 16 }}>
        <div className="stg-box-hd"><Icon name="chart" size={14} /><span>Competitors</span></div>
        <div className="cmp-table">
          <div className="cmp-row cmp-head"><span>Competitor</span><span>Their strength</span><span>Their weakness</span><span>Our edge</span><span className="no-print" /></div>
          {comp.map((c) => (
            <div className="cmp-row" key={c.id}>
              <input value={c.name || ""} onChange={(e) => patchC(c.id, "name", e.target.value)} placeholder="Name" />
              <input value={c.strength || ""} onChange={(e) => patchC(c.id, "strength", e.target.value)} placeholder="…" />
              <input value={c.weakness || ""} onChange={(e) => patchC(c.id, "weakness", e.target.value)} placeholder="…" />
              <input value={c.edge || ""} onChange={(e) => patchC(c.id, "edge", e.target.value)} placeholder="…" />
              <button className="stg-x no-print" onClick={() => setComp(comp.filter((x) => x.id !== c.id))} title="Remove"><Icon name="x" size={12} /></button>
            </div>
          ))}
          {comp.length === 0 && <div className="cmp-empty">No competitors added yet.</div>}
        </div>
        <button className="stg-add no-print" onClick={() => setComp([...comp, { id: Store.uid("cmp"), name: "", strength: "", weakness: "", edge: "" }])}><Icon name="plus" size={12} /> Add competitor</button>
      </div>
    </div></div>
  );
}

function Personas() {
  const [st, set] = useStartup();
  const list = st.personas || [];
  const setList = (l) => set("personas", l);
  const patchP = (id, k, v) => setList(list.map((x) => (x.id === id ? { ...x, [k]: v } : x)));
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>The people you build for. Capture who they are, what they're trying to do, and what gets in their way.</StgIntro>
      <div className="persona-grid">
        {list.map((p) => (
          <div className="persona-card" key={p.id}>
            <div className="persona-hd">
              <span className="persona-av"><Icon name="persona" size={20} /></span>
              <div className="grow" style={{ minWidth: 0 }}>
                <UI.Editable className="persona-name" value={p.name} onChange={(v) => patchP(p.id, "name", v)} placeholder="Persona name" />
                <UI.Editable className="persona-role" value={p.role} onChange={(v) => patchP(p.id, "role", v)} placeholder="Role / title" />
              </div>
              <button className="stg-x no-print" onClick={() => setList(list.filter((x) => x.id !== p.id))} title="Remove"><Icon name="x" size={13} /></button>
            </div>
            <div className="persona-seg"><UI.Editable value={p.segment} onChange={(v) => patchP(p.id, "segment", v)} placeholder="Segment / company type" /></div>
            <div className="stg-sub">Goals / jobs</div><StrList items={p.goals} onChange={(v) => patchP(p.id, "goals", v)} accent="var(--t-teal)" />
            <div className="stg-sub">Pains</div><StrList items={p.pains} onChange={(v) => patchP(p.id, "pains", v)} accent="var(--t-red)" />
            <div className="stg-sub">Notes</div>
            <UI.Editable className="persona-note" multiline value={p.note} onChange={(v) => patchP(p.id, "note", v)} placeholder="Context, quote, behaviour…" />
          </div>
        ))}
        <button className="persona-add no-print" onClick={() => setList([...list, { id: Store.uid("per"), name: "", role: "", segment: "", goals: [], pains: [], note: "" }])}><Icon name="plus" size={16} /> Add persona</button>
      </div>
    </div></div>
  );
}

function GoToMarket() {
  const [st, set] = useStartup();
  const g = st.gtm || {};
  const setG = (k, v) => set("gtm", (c) => ({ ...(c || {}), [k]: v }));
  const pricing = g.pricing || [];
  const setPricing = (p) => setG("pricing", p);
  const patchT = (id, k, v) => setPricing(pricing.map((x) => (x.id === id ? { ...x, [k]: v } : x)));
  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <StgIntro>How you'll reach customers, what you charge, and how you'll land the first ones.</StgIntro>
      <div className="gtm-two">
        <div className="stg-box">
          <div className="stg-box-hd"><Icon name="megaphone" size={14} /><span>Sales motion</span></div>
          <div className="stg-box-hint">How deals actually get done (self-serve, inside sales, partner-led…).</div>
          <UI.Editable className="stg-stmt-text" tag="div" multiline value={g.motion || ""} onChange={(v) => setG("motion", v)} placeholder="Describe how a prospect becomes a paying customer…" />
        </div>
        <div className="stg-box">
          <div className="stg-box-hd"><Icon name="comms" size={14} /><span>Channels</span></div>
          <div className="stg-box-hint">Where you find and reach your customers.</div>
          <StrList items={g.channels} onChange={(v) => setG("channels", v)} accent="var(--t-blue)" />
        </div>
      </div>
      <div className="stg-box" style={{ marginTop: 16 }}>
        <div className="stg-box-hd"><Icon name="coin" size={14} /><span>Pricing tiers</span></div>
        <div className="price-grid">
          {pricing.map((t) => (
            <div className="price-card" key={t.id}>
              <button className="stg-x no-print" onClick={() => setPricing(pricing.filter((x) => x.id !== t.id))} title="Remove"><Icon name="x" size={12} /></button>
              <UI.Editable className="price-tier" value={t.tier} onChange={(v) => patchT(t.id, "tier", v)} placeholder="Tier" />
              <UI.Editable className="price-amt serif" value={t.price} onChange={(v) => patchT(t.id, "price", v)} placeholder="€ —" />
              <div className="stg-sub">Includes</div>
              <StrList items={t.includes} onChange={(v) => patchT(t.id, "includes", v)} />
            </div>
          ))}
          <button className="price-add no-print" onClick={() => setPricing([...pricing, { id: Store.uid("tier"), tier: "", price: "", includes: [] }])}><Icon name="plus" size={15} /> Add tier</button>
        </div>
      </div>
      <div className="stg-box" style={{ marginTop: 16 }}>
        <div className="stg-box-hd"><Icon name="flag" size={14} /><span>Launch plan</span></div>
        <div className="stg-box-hint">The sequence of moves to get to first customers.</div>
        <StrList items={g.launch} onChange={(v) => setG("launch", v)} accent="var(--t-amber)" />
      </div>
    </div></div>
  );
}

Object.assign(window, { MissionVision, ValueProp, BMC, LeanCanvas, MarketCompetition, Personas, GoToMarket });

const FEATURE_OUTCOMES = [
  ["cost", "Reduce cost", "green"],
  ["time", "Save time", "blue"],
  ["flow", "Optimize flow", "indigo"],
  ["quality", "Increase quality", "amber"],
  ["replace", "Replace output", "purple"],
];
function FeatureSuite() {
  const [st, set] = useStartup();
  const fs = st.features || {};
  const groups = fs.groups || [];
  const packages = fs.packages || [];
  const [tab, setTab] = React.useState(packages.length ? "packages" : "library");
  const [pickFor, setPickFor] = React.useState(null); // package id we're adding a feature to
  const setGroups = (g) => set("features", { ...(fs || {}), groups: g });
  const setPackages = (p) => set("features", { ...(fs || {}), packages: p });
  const patchG = (gid, fn) => setGroups(groups.map((g) => (g.id === gid ? fn(g) : g)));
  const addGroup = () => setGroups([...groups, { id: Store.uid("fg"), label: "New category", items: [] }]);
  const addItem = (gid) => patchG(gid, (g) => ({ ...g, items: [...(g.items || []), { id: Store.uid("ft"), name: "", desc: "", audience: "", outcomes: [] }] }));
  const patchItem = (gid, iid, k, v) => patchG(gid, (g) => ({ ...g, items: g.items.map((it) => (it.id === iid ? { ...it, [k]: v } : it)) }));
  const delItem = (gid, iid) => patchG(gid, (g) => ({ ...g, items: g.items.filter((it) => it.id !== iid) }));
  const toggleOutcome = (gid, iid, key) => patchG(gid, (g) => ({ ...g, items: g.items.map((it) => (it.id === iid ? { ...it, outcomes: (it.outcomes || []).includes(key) ? it.outcomes.filter((o) => o !== key) : [...(it.outcomes || []), key] } : it)) }));

  // flatten the library so packages can reference any feature by id
  const featureIndex = useStartupIndex(groups);
  const patchPkg = (pid, fn) => setPackages(packages.map((p) => (p.id === pid ? fn(p) : p)));
  const addPackage = () => { const id = Store.uid("pkg"); setPackages([...packages, { id, name: "New package", tagline: "", featureIds: [] }]); setTab("packages"); };
  const moveStep = (pid, idx, dir) => patchPkg(pid, (p) => { const a = [...p.featureIds]; const j = idx + dir; if (j < 0 || j >= a.length) return p; const t = a[idx]; a[idx] = a[j]; a[j] = t; return { ...p, featureIds: a }; });
  const removeStep = (pid, fid) => patchPkg(pid, (p) => ({ ...p, featureIds: p.featureIds.filter((x) => x !== fid) }));
  const addStep = (pid, fid) => { patchPkg(pid, (p) => ({ ...p, featureIds: [...(p.featureIds || []), fid] })); setPickFor(null); };

  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <div className="fs-tabs no-print">
        <button className={"fs-tab" + (tab === "packages" ? " on" : "")} onClick={() => setTab("packages")}><Icon name="bundle" size={14} /> Packages{packages.length ? " · " + packages.length : ""}</button>
        <button className={"fs-tab" + (tab === "library" ? " on" : "")} onClick={() => setTab("library")}><Icon name="box" size={14} /> Feature library</button>
      </div>

      {tab === "library" && (<React.Fragment>
        <StgIntro>The concrete services and tools we offer clients. Group them however you sell them, and tag each with the business outcome it drives.</StgIntro>
        <div className="fs-legend no-print">
          <span className="fs-legend-lbl">Outcomes:</span>
          {FEATURE_OUTCOMES.map(([k, label, c]) => <span key={k} className="fs-out" style={{ "--oc": "var(--t-" + c + ")" }}><span className="fs-out-dot" />{label}</span>)}
        </div>
        {groups.map((g) => (
          <div className="fs-group" key={g.id}>
            <div className="fs-group-hd">
              <UI.Editable className="fs-group-label" value={g.label} onChange={(v) => patchG(g.id, (x) => ({ ...x, label: v || "Untitled" }))} placeholder="Category" />
              <span className="fs-group-n">{(g.items || []).length}</span>
              <div className="grow" />
              <button className="btn btn-sm no-print" onClick={() => addItem(g.id)}><Icon name="plus" size={13} /> Feature</button>
              <button className="stg-x no-print" title="Remove category" onClick={() => setGroups(groups.filter((x) => x.id !== g.id))}><Icon name="x" size={13} /></button>
            </div>
            <div className="fs-grid">
              {(g.items || []).map((it) => (
                <div className="fs-card" key={it.id}>
                  <button className="stg-x fs-card-x no-print" title="Remove" onClick={() => delItem(g.id, it.id)}><Icon name="x" size={12} /></button>
                  <UI.Editable className="fs-card-name" value={it.name} onChange={(v) => patchItem(g.id, it.id, "name", v)} placeholder="Feature / service name" />
                  <UI.Editable className="fs-card-desc" multiline value={it.desc} onChange={(v) => patchItem(g.id, it.id, "desc", v)} placeholder="What it is and what the client gets…" />
                  <div className="fs-hw">
                    <div className="fs-hw-row">
                      <span className="fs-hw-lbl">How</span>
                      <UI.Editable className="fs-hw-val" multiline value={it.how} onChange={(v) => patchItem(g.id, it.id, "how", v)} placeholder="How we deliver it…" />
                    </div>
                    <div className="fs-hw-row">
                      <span className="fs-hw-lbl what">What</span>
                      <UI.Editable className="fs-hw-val" multiline value={it.what} onChange={(v) => patchItem(g.id, it.id, "what", v)} placeholder="What the client receives (the output)…" />
                    </div>
                  </div>
                  <div className="fs-audience"><span className="fs-audience-lbl">Best for</span><UI.Editable value={it.audience} onChange={(v) => patchItem(g.id, it.id, "audience", v)} placeholder="Startups · SMBs · Enterprise" /></div>
                  <div className="fs-outcomes">
                    {FEATURE_OUTCOMES.map(([k, label, c]) => {
                      const on = (it.outcomes || []).includes(k);
                      return <button key={k} className={"fs-out fs-out-btn" + (on ? " on" : "")} style={{ "--oc": "var(--t-" + c + ")" }} onClick={() => toggleOutcome(g.id, it.id, k)}><span className="fs-out-dot" />{label}</button>;
                    })}
                  </div>
                </div>
              ))}
              <button className="fs-add-card no-print" onClick={() => addItem(g.id)}><Icon name="plus" size={15} /> Add feature</button>
            </div>
          </div>
        ))}
        <button className="stg-add-card no-print" onClick={addGroup}><Icon name="plus" size={14} /> Add category</button>
      </React.Fragment>)}

      {tab === "packages" && (<React.Fragment>
        <StgIntro>Curated bundles you sell as a journey — pull features from the library into an ordered sequence (e.g. preparedness → assessment → governance). The same feature can appear in more than one package.</StgIntro>
        {packages.length === 0 && <div className="empty"><div className="serif">No packages yet</div>Build a sales packet by bundling features in the order you'd deliver them.</div>}
        <div className="pkg-list">
          {packages.map((pk) => {
            const steps = (pk.featureIds || []).map((fid) => featureIndex[fid]).filter(Boolean);
            const available = Object.values(featureIndex).filter((f) => f.name && !(pk.featureIds || []).includes(f.id));
            return (
              <div className="pkg-card" key={pk.id}>
                <div className="pkg-hd">
                  <span className="pkg-ico"><Icon name="bundle" size={16} /></span>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <UI.Editable className="pkg-name serif" value={pk.name} onChange={(v) => patchPkg(pk.id, (p) => ({ ...p, name: v || "Untitled package" }))} placeholder="Package name" />
                    <UI.Editable className="pkg-tagline" value={pk.tagline} onChange={(v) => patchPkg(pk.id, (p) => ({ ...p, tagline: v }))} placeholder="One-line pitch for this bundle…" />
                  </div>
                  <span className="pkg-count">{steps.length} step{steps.length === 1 ? "" : "s"}</span>
                  <button className="stg-x no-print" title="Remove package" onClick={() => setPackages(packages.filter((x) => x.id !== pk.id))}><Icon name="x" size={14} /></button>
                </div>
                <div className="pkg-steps">
                  {steps.map((f, i) => (
                    <div className="pkg-step" key={f.id}>
                      <span className="pkg-step-n">{i + 1}</span>
                      <div className="pkg-step-main">
                        <div className="pkg-step-name">{f.name || "Untitled feature"}</div>
                        <div className="pkg-step-meta">
                          <span className="pkg-step-cat">{f.groupLabel}</span>
                          {(f.outcomes || []).map((k) => { const m = FEATURE_OUTCOMES.find((o) => o[0] === k); return m ? <span key={k} className="pkg-out-dot" style={{ background: "var(--t-" + m[2] + ")" }} title={m[1]} /> : null; })}
                        </div>
                      </div>
                      <div className="pkg-step-tools no-print">
                        <button className="org-act" title="Move up" disabled={i === 0} onClick={() => moveStep(pk.id, i, -1)}><Icon name="chevD" size={13} style={{ transform: "rotate(180deg)" }} /></button>
                        <button className="org-act" title="Move down" disabled={i === steps.length - 1} onClick={() => moveStep(pk.id, i, 1)}><Icon name="chevD" size={13} /></button>
                        <button className="org-act" title="Remove from package" onClick={() => removeStep(pk.id, f.id)}><Icon name="x" size={13} /></button>
                      </div>
                    </div>
                  ))}
                  <div className="pkg-add-wrap no-print">
                    <button className={"pkg-add" + (pickFor === pk.id ? " on" : "")} onClick={() => setPickFor(pickFor === pk.id ? null : pk.id)}><Icon name={pickFor === pk.id ? "x" : "plus"} size={14} /> {pickFor === pk.id ? "Close" : "Add feature"}</button>
                    {pickFor === pk.id && (
                      <div className="pkg-pick">
                        {available.length === 0 && <div className="dep-menu-empty">Every feature is already in this package.</div>}
                        {groups.map((g) => {
                          const opts = (g.items || []).filter((it) => it.name && !(pk.featureIds || []).includes(it.id));
                          if (!opts.length) return null;
                          return (
                            <div key={g.id} className="pkg-pick-group">
                              <div className="pkg-pick-cat">{g.label}</div>
                              <div className="pkg-pick-opts">
                                {opts.map((it) => <button key={it.id} className="pkg-pick-opt" onClick={() => addStep(pk.id, it.id)}><Icon name="plus" size={12} /><span className="grow">{it.name}</span></button>)}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <button className="stg-add-card no-print" onClick={addPackage}><Icon name="plus" size={14} /> Add package</button>
      </React.Fragment>)}
    </div></div>
  );
}
function useStartupIndex(groups) {
  return React.useMemo(() => {
    const idx = {};
    (groups || []).forEach((g) => (g.items || []).forEach((it) => { idx[it.id] = { ...it, groupLabel: g.label }; }));
    return idx;
  }, [groups]);
}

Object.assign(window, { FeatureSuite });

/* ============================================================
   COMPANY OVERVIEW — a company one-pager that pulls live from the
   Strategy sections (mission, value prop, features, market, personas).
   Deliberately omits project artefacts (risks, outcomes, financials).
   ============================================================ */
function CoEmpty({ label, go, to }) {
  return <button className="co-empty no-print" onClick={() => go && go(to)}>{label} <Icon name="arrowR" size={12} /></button>;
}
function CompanyOverview({ go }) {
  const s = Store.useStore();
  const st = s.startup || {};
  const bc = s.businessCase || {};
  const setBC = (c) => Store.setState((p) => ({ ...p, businessCase: { ...p.businessCase, ...c } }));
  const m = st.mission || {};
  const vp = st.valueProp || {};
  const mk = st.market || {};
  const fs = st.features || {};
  const groups = fs.groups || [];
  const packages = fs.packages || [];
  const personas = st.personas || [];
  const values = m.values || [];
  const segments = vp.segments || [];
  const featureCount = groups.reduce((n, g) => n + (g.items || []).length, 0);
  const sizing = [["tam", "TAM"], ["sam", "SAM"], ["som", "SOM"]].filter(([k]) => mk[k]);

  const Edit = ({ to }) => <button className="co-edit no-print" onClick={() => go && go(to)} title="Edit in this section"><Icon name="edit" size={12} /></button>;

  return (
    <div className="view-scroll"><div className="co-doc">
      <header className="co-head">
        <div className="co-eyebrow eyebrow">Company overview</div>
        <UI.Editable className="co-title serif" multiline value={s.meta?.project} onChange={(v) => Store.setState((p) => ({ ...p, meta: { ...p.meta, project: v } }))} placeholder="Company name" />
        {(m.mission || true) && <UI.Editable className="co-tagline" tag="div" multiline value={m.mission} onChange={(v) => Store.setState((p) => ({ ...p, startup: { ...(p.startup || {}), mission: { ...(p.startup?.mission || {}), mission: v } } }))} placeholder="Our mission — what we do, for whom, and why." />}
      </header>

      {/* What we do */}
      <section className="co-hero">
        <div className="co-label">What we do</div>
        <UI.Editable className="co-hero-text" tag="div" multiline value={bc.purpose} onChange={(v) => setBC({ purpose: v })} placeholder="A short, plain-language description of the company and the value it delivers." />
      </section>

      {/* Problem / Solution */}
      <div className="co-two">
        <section className="co-card">
          <div className="co-label"><Icon name="warn" size={13} /> The problem</div>
          <UI.Editable className="co-body" tag="div" multiline value={bc.problem} onChange={(v) => setBC({ problem: v })} placeholder="What pain or gap exists in the market today?" />
        </section>
        <section className="co-card">
          <div className="co-label"><Icon name="bulb" size={13} /> Our solution</div>
          <UI.Editable className="co-body" tag="div" multiline value={bc.solution} onChange={(v) => setBC({ solution: v })} placeholder="How we solve it — our approach in a few sentences." />
        </section>
      </div>

      {/* Why now */}
      <section className="co-card">
        <div className="co-label"><Icon name="flag" size={13} /> Why now</div>
        <UI.Editable className="co-body" tag="div" multiline value={bc.whyNow} onChange={(v) => setBC({ whyNow: v })} placeholder="What's changed in the market or technology that makes this the right moment?" />
      </section>

      {/* Vision + Values */}
      <section className="co-section">
        <div className="co-section-hd"><h2 className="co-h2 serif">Vision &amp; values</h2><Edit to="mission" /></div>
        <div className="co-two">
          <div className="co-vision">
            <div className="co-mini-label">Vision</div>
            {m.vision ? <div className="co-vision-text serif">{m.vision}</div> : <CoEmpty label="Add a vision statement" go={go} to="mission" />}
          </div>
          <div>
            <div className="co-mini-label">Core values</div>
            {values.length ? (
              <div className="co-values">{values.filter((v) => v.label).map((v) => <span key={v.id} className="co-value-chip" title={v.desc}>{v.label}</span>)}</div>
            ) : <CoEmpty label="Define core values" go={go} to="mission" />}
          </div>
        </div>
      </section>

      {/* Value proposition */}
      <section className="co-section">
        <div className="co-section-hd"><h2 className="co-h2 serif">Value proposition</h2><Edit to="valueprop" /></div>
        {vp.headline ? <div className="co-vp-headline serif">{vp.headline}</div> : <CoEmpty label="Write the headline value proposition" go={go} to="valueprop" />}
        {segments.length > 0 && (
          <div className="co-segs">
            <div className="co-mini-label">Who we serve</div>
            <div className="co-seg-chips">{segments.filter((sg) => sg.segment).map((sg) => <span key={sg.id} className="co-seg-chip"><Icon name="persona" size={12} />{sg.segment}</span>)}</div>
          </div>
        )}
      </section>

      {/* What we offer */}
      <section className="co-section">
        <div className="co-section-hd"><h2 className="co-h2 serif">What we offer</h2><Edit to="features" /></div>
        {featureCount === 0 ? <CoEmpty label="Build out the feature suite" go={go} to="features" /> : (
          <React.Fragment>
            <div className="co-offer-grid">
              {groups.map((g) => (
                <div className="co-offer" key={g.id}>
                  <div className="co-offer-cat">{g.label} <span className="co-offer-n">{(g.items || []).length}</span></div>
                  <ul className="co-offer-list">{(g.items || []).filter((it) => it.name).slice(0, 6).map((it) => <li key={it.id}>{it.name}</li>)}</ul>
                </div>
              ))}
            </div>
            {packages.length > 0 && (
              <div className="co-packages">
                <div className="co-mini-label">Packages</div>
                <div className="co-pkg-chips">{packages.map((pk) => <span key={pk.id} className="co-pkg-chip"><Icon name="bundle" size={12} />{pk.name} <span className="co-pkg-n">{(pk.featureIds || []).length}</span></span>)}</div>
              </div>
            )}
          </React.Fragment>
        )}
      </section>

      {/* Market */}
      {(sizing.length > 0 || mk.positioning) && (
        <section className="co-section">
          <div className="co-section-hd"><h2 className="co-h2 serif">Market</h2><Edit to="market" /></div>
          {sizing.length > 0 && <div className="co-sizing">{sizing.map(([k, label]) => <div className="co-stat" key={k}><div className="co-stat-l">{label}</div><div className="co-stat-v serif">{mk[k]}</div></div>)}</div>}
          {mk.positioning && <div className="co-positioning">{mk.positioning}</div>}
        </section>
      )}
    </div></div>
  );
}

Object.assign(window, { CompanyOverview });

/* ============================================================
   FORECAST — estimated duration, end date & delay impact (CPM over
   the task dependency graph, in working days)
   ============================================================ */
const FC_SIZE = { s: 3, m: 8, l: 15 };          // working-day estimate when a task has no dates
const FC_SIZE_LABEL = { s: "S", m: "M", l: "L" };
const FC_RISK = { low: "Low", med: "Med", high: "High" };
function fcMid(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }
function fcWeekend(d) { const g = d.getDay(); return g === 0 || g === 6; }
function fcAddWD(date, n) {
  let d = fcMid(date); let left = Math.round(Math.abs(n)); const step = n < 0 ? -1 : 1;
  while (left > 0) { d.setDate(d.getDate() + step); if (!fcWeekend(d)) left--; }
  return d;
}
function fcWDBetween(a, b) {
  let d = fcMid(a); const end = fcMid(b); let c = 0;
  if (+end >= +d) { while (+d < +end) { d.setDate(d.getDate() + 1); if (!fcWeekend(d)) c++; } }
  else { while (+d > +end) { d.setDate(d.getDate() - 1); if (!fcWeekend(d)) c--; } }
  return c;
}

function Forecast() {
  const s = Store.useStore();
  const { tasks } = s;
  const bufferPct = (s.forecast && typeof s.forecast.bufferPct === "number") ? s.forecast.bufferPct : 20;
  const setBuffer = (v) => Store.setState((p) => ({ ...p, forecast: { ...(p.forecast || {}), bufferPct: v } }));
  const setTask = (id, patch) => Store.patch("tasks", id, patch);

  const model = React.useMemo(() => {
    const list = (tasks || []).filter((t) => !t.parentId);
    if (!list.length) return null;
    const byId = {}; list.forEach((t) => (byId[t.id] = t));
    const dated = list.filter((t) => t.start);
    let projStart = dated.length ? fcMid(dated.reduce((m, t) => (+new Date(t.start) < +new Date(m.start) ? t : m)).start) : fcMid(new Date());

    const dur = (t) => {
      let d = (t.start && t.end) ? Math.max(1, fcWDBetween(t.start, t.end)) : (FC_SIZE[t.size] || 5);
      return d + (t.delayDays || 0);
    };
    const preds = (t) => (t.deps || []).filter((d) => d.type === "task" && byId[d.refId]).map((d) => d.refId);

    const esMemo = {}, efMemo = {}, stack = {};
    const ES = (id) => {
      if (esMemo[id] != null) return esMemo[id];
      if (stack[id]) return 0; stack[id] = true;
      const t = byId[id];
      const rootOff = t.start ? Math.max(0, fcWDBetween(projStart, t.start)) : 0;
      let depMax = 0;
      preds(t).forEach((p) => { depMax = Math.max(depMax, EF(p)); });
      stack[id] = false;
      return (esMemo[id] = Math.max(rootOff, depMax));
    };
    const EF = (id) => (efMemo[id] != null ? efMemo[id] : (efMemo[id] = ES(id) + dur(byId[id])));

    list.forEach((t) => EF(t.id));
    const projDur = list.reduce((m, t) => Math.max(m, efMemo[t.id]), 0);

    // backward pass for slack / critical path
    const succs = {}; list.forEach((t) => (succs[t.id] = []));
    list.forEach((t) => preds(t).forEach((p) => succs[p] && succs[p].push(t.id)));
    const lfMemo = {}, lstack = {};
    const LF = (id) => {
      if (lfMemo[id] != null) return lfMemo[id];
      if (lstack[id]) return projDur; lstack[id] = true;
      const ss = succs[id] || [];
      let v = ss.length ? Math.min(...ss.map((x) => LF(x) - dur(byId[x]))) : projDur;
      lstack[id] = false;
      return (lfMemo[id] = v);
    };
    const rows = list.map((t) => {
      const es = esMemo[t.id], ef = efMemo[t.id];
      const lf = LF(t.id); const slack = (lf - dur(t)) - es;
      return {
        t, dur: dur(t), es, ef, slack: Math.round(slack),
        critical: slack <= 0.001,
        startDate: fcAddWD(projStart, es), endDate: fcAddWD(projStart, ef),
        done: t.status === "done",
      };
    }).sort((a, b) => a.es - b.es || a.ef - b.ef);

    const expectedEnd = fcAddWD(projStart, projDur);
    const withDelayDur = Math.ceil(projDur * (1 + bufferPct / 100));
    const withDelayEnd = fcAddWD(projStart, withDelayDur);
    const plannedEnd = dated.filter((t) => t.end).length ? fcMid(list.filter((t) => t.end).reduce((m, t) => (+new Date(t.end) > +new Date(m.end) ? t : m)).end) : null;
    const criticalCount = rows.filter((r) => r.critical).length;
    return { rows, projStart, projDur, expectedEnd, withDelayDur, withDelayEnd, plannedEnd, criticalCount };
  }, [tasks, bufferPct]);

  if (!model) {
    return <div className="view-scroll"><div className="view-pad"><div className="empty"><div className="serif">Nothing to forecast yet</div>Add actions with dates (or a size estimate) to see a projected duration and end date.</div></div></div>;
  }
  const { rows, projStart, projDur, expectedEnd, withDelayDur, withDelayEnd, plannedEnd, criticalCount } = model;
  const weeks = (n) => (n / 5).toFixed(n / 5 >= 10 ? 0 : 1);
  const slipDays = plannedEnd ? fcWDBetween(plannedEnd, withDelayEnd) : 0;

  return (
    <div className="view-scroll"><div className="view-pad view-wide fc-wrap">
      <p className="muted fc-intro">Projected from your actions and their dependencies (the critical path), counted in working days. Add a delay to any action below and the whole schedule — and the end date — recalculates.</p>

      <div className="fc-cards">
        <div className="fc-card">
          <div className="fc-card-l">Estimated duration</div>
          <div className="fc-card-v serif">{weeks(projDur)} <span>wks</span></div>
          <div className="fc-card-sub">{projDur} working days · {criticalCount} on critical path</div>
        </div>
        <div className="fc-card">
          <div className="fc-card-l">Expected finish</div>
          <div className="fc-card-v serif">{fmtD(expectedEnd)}</div>
          <div className="fc-card-sub">from {fmtD(projStart)}</div>
        </div>
        <div className="fc-card fc-card-accent">
          <div className="fc-card-l">With delays (+{bufferPct}%)</div>
          <div className="fc-card-v serif">{fmtD(withDelayEnd)}</div>
          <div className="fc-card-sub">{weeks(withDelayDur)} wks · buffered estimate</div>
        </div>
      </div>

      <div className="fc-buffer">
        <div className="fc-buffer-hd"><span>Delay buffer</span><span className="fc-buffer-val">+{bufferPct}%</span></div>
        <input type="range" min="0" max="100" step="5" value={bufferPct} onChange={(e) => setBuffer(+e.target.value)} className="fc-slider" />
        <div className="fc-buffer-note">Global contingency added on top of the critical-path estimate to produce the pessimistic finish{plannedEnd ? " — " + (slipDays > 0 ? slipDays + " working days past your current planned end (" + fmtD(plannedEnd) + ")" : "within your planned end (" + fmtD(plannedEnd) + ")") : ""}.</div>
      </div>

      <div className="fc-table">
        <div className="fc-row fc-head">
          <span className="fc-c-name">Action</span>
          <span className="fc-c-size">Size</span>
          <span className="fc-c-dur">Days</span>
          <span className="fc-c-sched">Scheduled</span>
          <span className="fc-c-slack">Slack</span>
          <span className="fc-c-delay">Delay</span>
        </div>
        {rows.map((r) => (
          <div key={r.t.id} className={"fc-row" + (r.critical ? " critical" : "") + (r.done ? " done" : "")}>
            <span className="fc-c-name">
              {r.critical && <span className="fc-cp-dot" title="On the critical path — a delay here pushes the whole project" />}
              <span className="fc-name-txt">{r.t.title}</span>
              {!r.t.start && <span className="fc-est-tag" title="No dates set — estimated from size">est</span>}
            </span>
            <span className="fc-c-size">
              <select value={r.t.size || ""} onChange={(e) => setTask(r.t.id, { size: e.target.value || undefined })} className="fc-size-sel" title="Size estimate (used when no dates)">
                <option value="">–</option>
                <option value="s">S</option><option value="m">M</option><option value="l">L</option>
              </select>
            </span>
            <span className="fc-c-dur">{r.dur}</span>
            <span className="fc-c-sched">{fmtD(r.startDate)} → {fmtD(r.endDate)}</span>
            <span className="fc-c-slack">{r.critical ? <span className="fc-crit-lbl">critical</span> : r.slack + "d"}</span>
            <span className="fc-c-delay">
              <button className="fc-delay-btn" disabled={!(r.t.delayDays > 0)} onClick={() => setTask(r.t.id, { delayDays: Math.max(0, (r.t.delayDays || 0) - 1) })} title="Remove a day of delay">−</button>
              <span className={"fc-delay-n" + (r.t.delayDays > 0 ? " on" : "")}>{r.t.delayDays > 0 ? "+" + r.t.delayDays + "d" : "—"}</span>
              <button className="fc-delay-btn" onClick={() => setTask(r.t.id, { delayDays: (r.t.delayDays || 0) + 1 })} title="Add a day of delay (shifts everything downstream)">+</button>
            </span>
          </div>
        ))}
      </div>
      <div className="fc-legend"><span className="fc-cp-dot" /> Critical path — delaying these pushes the project end date. Slack is how many working days an action can slip before it does.</div>
    </div></div>
  );
}

Object.assign(window, { Forecast });

// ======== app.jsx ========
/* ============================================================
   APP SHELL — projects landing + per-project sidebar & routing
   ============================================================ */
const { useState: useApp } = React;

// sections that can be toggled on/off per project
const TOGGLEABLE = {
  mission: "Mission, vision & values",
  valueprop: "Value proposition",
  features: "Feature suite",
  bmc: "Business Model Canvas",
  lean: "Lean Canvas",
  market: "Market & competition",
  personas: "Customer personas",
  gtm: "Go-to-market",
  comms: "Communication plan",
  change: "Change management",
  scope: "Scope",
  business: "Business case",
  financials: "Financials",
  preanalysis: "Pre-analysis",
  catalogue: "Product catalogue",
  org: "Roles & org chart",
  capacity: "Capacity"
};
const STARTUP_SECTIONS = ["mission", "valueprop", "features", "bmc", "lean", "market", "personas", "gtm"];
const DEFAULT_ON = ["comms", "change", "scope", "business", "financials", "preanalysis", "catalogue", "org", "capacity"];

const NAV = [
{ group: "Overview", items: [
  { id: "home", label: "Front page", icon: "home" },
  { id: "workspace", label: "Workspace", icon: "layers", count: (s) => s.tasks.length },
  { id: "scope", label: "Scope", icon: "scope" },
  { id: "business", label: "Company overview", icon: "doc" },
  { id: "financials", label: "Financials", icon: "coin" }]
},
{ group: "Strategy", items: [
  { id: "mission", label: "Mission & values", icon: "flag" },
  { id: "valueprop", label: "Value proposition", icon: "gift" },
  { id: "features", label: "Feature suite", icon: "box" },
  { id: "bmc", label: "Business Model Canvas", icon: "grid" },
  { id: "lean", label: "Lean Model Canvas", icon: "list" },
  { id: "market", label: "Market & competition", icon: "chart" },
  { id: "personas", label: "Customer personas", icon: "persona" },
  { id: "gtm", label: "Go-to-market", icon: "megaphone" }]
},
{ group: "Delivery", items: [
  { id: "actions", label: "Action list & timeline", icon: "timeline", count: (s) => s.tasks.length },
  { id: "forecast", label: "Forecast", icon: "gauge" },
  { id: "aiimport", label: "Update plan from chat", icon: "spark" },
  { id: "audit", label: "Audit trail", icon: "list" },
  { id: "catalogue", label: "Product catalogue", icon: "box", count: (s) => s.products.length }]
},
{ group: "People", items: [
  { id: "members", label: "Project members", icon: "users", count: (s) => (s.members || []).length },
  { id: "org", label: "Roles & org chart", icon: "org" },
  { id: "capacity", label: "Capacity", icon: "gauge" }]
},
{ group: "Change & comms", items: [
  { id: "comms", label: "Communication plan", icon: "comms", count: (s) => (s.commPlan || []).length },
  { id: "change", label: "Change management", icon: "swap", count: (s) => (s.changePlan && s.changePlan.groups || []).reduce((a, g) => a + g.rows.length, 0) }]
},
{ group: "Insight", items: [
  { id: "preanalysis", label: "Market & customer research", icon: "bulb", count: (s) => s.findings.length },
  { id: "risks", label: "Risks & mitigation", icon: "shield", count: (s) => s.risks.length },
  { id: "kpis", label: "Goals & metrics (OKRs)", icon: "target", count: null },
  { id: "glossary", label: "Glossary", icon: "tag", count: (s) => (s.glossary || []).length }]
}];


const TITLES = {
  home: ["Front page", "Project overview & quick links"],
  workspace: ["Workspace", "Your tasks and everything tied to them"],
  mission: ["Mission, vision & values", "What we do, where we're going, and what we stand for"],
  valueprop: ["Value proposition", "The promise to each customer segment"],
  features: ["Feature suite", "The services & tools we offer clients"],
  bmc: ["Business Model Canvas", "How the business creates, delivers & captures value"],
  lean: ["Lean Canvas", "The one-page start-up model"],
  market: ["Market & competition", "Sizing, positioning & competitors"],
  personas: ["Customer personas", "Who we build for"],
  gtm: ["Go-to-market", "Channels, pricing & launch"],
  financials: ["Financials", "Contract, budget & budget-vs-progress"],
  aiimport: ["Update plan from chat", "Turn a discussion into plan changes you approve"],
  audit: ["Audit trail", "Every change in the last 5 weeks"],
  scope: ["Scope", "Boundaries and as-is / to-be"],
  business: ["Company overview", "Problem, solution, why now & purpose"],
  actions: ["Actions & timeline", "Plan of work by phase"],
  forecast: ["Forecast", "Estimated duration, end date & delay impact"],
  catalogue: ["Product catalogue", "Deliverables produced by the project"],
  members: ["Project members", "Everyone working on the project"],
  org: ["Roles & responsibilities", "Reporting structure"],
  capacity: ["Capacity", "Who's busy, who has room"],
  comms: ["Communication plan", "Who hears what, when and how"],
  change: ["Change management plan", "Activities that embed the change"],
  preanalysis: ["Market & customer research", "Research findings about the market and customers"],
  risks: ["Risks & mitigation", "What could go wrong, and the plan"],
  kpis: ["Goals & metrics (OKRs)", "Objectives, key results and project-health metrics"],
  glossary: ["Glossary", "Terms used in this project — highlighted everywhere they appear"]
};

/* ============================================================
   STATUS REPORT — auto-composed exec summary (printable)
   ============================================================ */
function StatusReport({ onClose }) {
  const s = Store.useStore();
  const { tasks, risks, milestones, categories } = s;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const addDays = (d, n) => new Date(+d + n * 86400000);
  const done = tasks.filter((t) => t.status === "done");
  const inprog = tasks.filter((t) => t.status === "inprogress");
  const overdue = tasks.filter((t) => t.status !== "done" && t.end && new Date(t.end) < today).sort((a, b) => new Date(a.end) - new Date(b.end));
  const slipping = tasks.filter((t) => t.status === "backlog" && t.end && new Date(t.end) >= today && new Date(t.end) <= addDays(today, 7));
  const openRisks = risks.filter((r) => r.status !== "closed");
  const openHigh = openRisks.filter((r) => r.impact === "high");
  const pct = tasks.length ? Math.round(done.length / tasks.length * 100) : 0;
  const rag = overdue.length > 0 ? "red" : (openHigh.length > 0 || slipping.length > 0) ? "amber" : "green";
  const RAG = { red: { label: "At risk", c: "var(--t-red)" }, amber: { label: "Needs attention", c: "var(--t-amber)" }, green: { label: "On track", c: "var(--t-green)" } };
  const upcoming = [
    ...tasks.filter((t) => t.status !== "done" && t.end && new Date(t.end) >= today && new Date(t.end) <= addDays(today, 14)).map((t) => ({ kind: "task", date: t.end, title: t.title, obj: t })),
    ...(milestones || []).filter((m) => m.date && new Date(m.date) >= today && new Date(m.date) <= addDays(today, 14)).map((m) => ({ kind: m.type === "gate" ? "gate" : "ms", date: m.date, title: m.title })),
  ].sort((a, b) => new Date(a.date) - new Date(b.date));
  const catProg = categories.map((c) => { const ct = tasks.filter((t) => t.category === c.id); return { ...c, total: ct.length, done: ct.filter((t) => t.status === "done").length }; }).filter((c) => c.total);
  const topRisks = [...openRisks].sort((a, b) => ({ high: 3, med: 2, low: 1 }[b.impact] || 0) - ({ high: 3, med: 2, low: 1 }[a.impact] || 0)).slice(0, 5);
  const fd = (d) => new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  const summary = `${s.meta?.project} is ${RAG[rag].label.toLowerCase()} at ${pct}% complete — ${done.length} of ${tasks.length} actions done, ${inprog.length} in progress` +
    (overdue.length ? `, ${overdue.length} overdue` : "") + (openRisks.length ? `, ${openRisks.length} open risk${openRisks.length === 1 ? "" : "s"}` : "") + ".";

  const print = () => {
    document.body.classList.add("report-print");
    const after = () => { document.body.classList.remove("report-print"); window.removeEventListener("afterprint", after); };
    window.addEventListener("afterprint", after);
    window.print();
  };

  return (
    <UI.Modal onClose={onClose}>
      <div className="modal-hd no-print">
        <div className="ai-spark" style={{ background: "var(--ink)" }}><Icon name="doc" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Status report</div>
          <div className="muted" style={{ fontSize: 13 }}>Auto-composed from the live plan. Print or save as PDF to share.</div>
        </div>
        <button className="btn btn-sm" onClick={print}><Icon name="print" size={14} /> Print / PDF</button>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd status-report">
        <div className="sr-head">
          <div>
            <div className="sr-proj serif">{s.meta?.project}</div>
            <div className="sr-meta mono">{s.meta?.code ? s.meta.code + " · " : ""}{new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</div>
          </div>
          <div className="sr-rag" style={{ "--rag": RAG[rag].c }}><span className="sr-rag-dot" /> {RAG[rag].label}</div>
        </div>
        <p className="sr-summary">{summary}</p>
        <div className="sr-stats">
          <div className="sr-stat"><span className="sr-stat-n serif">{pct}%</span><span className="sr-stat-l">complete</span></div>
          <div className="sr-stat"><span className="sr-stat-n serif">{inprog.length}</span><span className="sr-stat-l">in progress</span></div>
          <div className="sr-stat"><span className="sr-stat-n serif" style={{ color: overdue.length ? "var(--t-red)" : "inherit" }}>{overdue.length}</span><span className="sr-stat-l">overdue</span></div>
          <div className="sr-stat"><span className="sr-stat-n serif">{done.length}/{tasks.length}</span><span className="sr-stat-l">actions done</span></div>
          <div className="sr-stat"><span className="sr-stat-n serif" style={{ color: openRisks.length ? "var(--t-amber)" : "inherit" }}>{openRisks.length}</span><span className="sr-stat-l">open risks</span></div>
        </div>

        {catProg.length > 0 && (
          <div className="sr-block">
            <div className="sr-h">Progress by category</div>
            {catProg.map((c) => (
              <div className="sr-prog" key={c.id}>
                <span className="sr-prog-l">{c.label}</span>
                <div className="sr-prog-track"><div className="sr-prog-fill" style={{ width: Math.round(c.done / c.total * 100) + "%", background: "var(--t-" + c.color + ")" }} /></div>
                <span className="sr-prog-n mono">{c.done}/{c.total}</span>
              </div>
            ))}
          </div>
        )}

        <div className="sr-cols">
          <div className="sr-block">
            <div className="sr-h">Needs attention</div>
            {overdue.length === 0 && slipping.length === 0 && <div className="sr-empty">Nothing overdue or slipping. 👍</div>}
            {overdue.map((t) => <div className="sr-li" key={t.id}><span className="sr-li-dot" style={{ background: "var(--t-red)" }} /><span className="grow">{t.title}</span><span className="sr-li-d mono">overdue · {fd(t.end)}</span></div>)}
            {slipping.map((t) => <div className="sr-li" key={t.id}><span className="sr-li-dot" style={{ background: "var(--t-amber)" }} /><span className="grow">{t.title}</span><span className="sr-li-d mono">due {fd(t.end)}</span></div>)}
          </div>
          <div className="sr-block">
            <div className="sr-h">Upcoming · next 14 days</div>
            {upcoming.length === 0 && <div className="sr-empty">Nothing dated in the next two weeks.</div>}
            {upcoming.map((u, i) => <div className="sr-li" key={i}><span className="sr-li-mark">{u.kind === "task" ? "•" : u.kind === "gate" ? "┃" : "◆"}</span><span className="grow">{u.title}</span><span className="sr-li-d mono">{fd(u.date)}</span></div>)}
          </div>
        </div>

        {inprog.length > 0 && (
          <div className="sr-block">
            <div className="sr-h">In progress now</div>
            {inprog.map((t) => <div className="sr-li" key={t.id}><span className="sr-li-dot" style={{ background: "var(--t-blue)" }} /><span className="grow">{t.title}</span><span className="sr-li-d mono">{assigneesOf(t).join(", ") || "unassigned"}</span></div>)}
          </div>
        )}

        {topRisks.length > 0 && (
          <div className="sr-block">
            <div className="sr-h">Top open risks</div>
            {topRisks.map((r) => <div className="sr-li" key={r.id}><span className="sr-li-dot" style={{ background: r.impact === "high" ? "var(--t-red)" : r.impact === "med" ? "var(--t-amber)" : "var(--t-green)" }} /><span className="grow">{r.title}</span><span className="sr-li-d mono">{r.owner || "unowned"}</span></div>)}
          </div>
        )}
      </div>
      <div className="modal-ft no-print">
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>
  );
}

/* ============================================================
   EXTERNAL INPUTS — commitments owned by parties outside the project
   that internal tasks depend on (each has a party, owner, due date, status)
   ============================================================ */
const EXT_STATUS = [
  { id: "pending", label: "Pending", c: "var(--t-amber)" },
  { id: "committed", label: "Committed", c: "var(--t-blue)" },
  { id: "received", label: "Received", c: "var(--t-green)" },
];
function ExternalInputs() {
  const s = Store.useStore();
  const exts = s.externals || [];
  const tasks = s.tasks || [];
  const [del, setDel] = React.useState(null);
  const today = new Date(); today.setHours(0, 0, 0, 0);

  const add = () => Store.add("externals", { id: Store.uid("ext"), title: "New external input", party: "", owner: "", due: "", status: "pending", note: "" });
  const patch = (id, c) => Store.patch("externals", id, c);
  const dependents = (eid) => tasks.filter((t) => (t.deps || []).some((d) => d.type === "ext" && d.refId === eid));
  const statusOf = (e) => EXT_STATUS.find((x) => x.id === e.status) || EXT_STATUS[0];
  const isOverdue = (e) => e.status !== "received" && e.due && new Date(e.due) < today;

  const pending = exts.filter((e) => e.status !== "received").length;
  const overdue = exts.filter(isOverdue).length;
  const received = exts.filter((e) => e.status === "received").length;

  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <div className="between" style={{ marginBottom: 16, flexWrap: "wrap", gap: 12 }}>
        <p className="muted" style={{ margin: 0, maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
          Things this project depends on from <b>outside</b> — work owned by another team, a vendor, a regulator or a client. Give each a party, an owner, an expected date and a status. Any internal task can then <b>depend on it</b> (add it under “Depends on” on the task), and a late or missing input shows up as a <b>dependency block</b>.
        </p>
        <button className="btn btn-primary no-print" onClick={add}><Icon name="plus" size={15} /> Add external input</button>
      </div>

      <div className="ext-summary">
        <div className="ext-sum"><span className="ext-sum-n serif">{exts.length}</span><span className="ext-sum-l">total</span></div>
        <div className="ext-sum"><span className="ext-sum-n serif" style={{ color: pending ? "var(--t-amber)" : "inherit" }}>{pending}</span><span className="ext-sum-l">outstanding</span></div>
        <div className="ext-sum"><span className="ext-sum-n serif" style={{ color: overdue ? "var(--t-red)" : "inherit" }}>{overdue}</span><span className="ext-sum-l">overdue</span></div>
        <div className="ext-sum"><span className="ext-sum-n serif" style={{ color: received ? "var(--t-green)" : "inherit" }}>{received}</span><span className="ext-sum-l">received</span></div>
      </div>

      {exts.length === 0 && <div className="empty"><div className="serif">No external inputs yet</div>Add the first thing this project is waiting on from outside the team.</div>}

      <div className="ext-list">
        {exts.map((e) => {
          const st = statusOf(e); const od = isOverdue(e); const deps = dependents(e.id);
          return (
            <div key={e.id} className={"ext-card" + (od ? " overdue" : "")} style={{ "--ext-c": od ? "var(--t-red)" : st.c }}>
              <span className="ext-card-bar" />
              <div className="ext-card-main">
                <div className="ext-card-top">
                  <span className="ext-ico"><Icon name="inbound" size={15} /></span>
                  <UI.Editable className="ext-title" value={e.title} onChange={(v) => patch(e.id, { title: v || "External input" })} placeholder="What is needed?" />
                  <button className="chip-x no-print" onClick={() => setDel(e)} title="Remove"><Icon name="x" size={13} /></button>
                </div>
                <div className="ext-fields">
                  <label className="ext-field"><span className="ext-flabel">From (party)</span><UI.Editable className="ext-fval" value={e.party} onChange={(v) => patch(e.id, { party: v })} placeholder="e.g. Regulator — FCA" /></label>
                  <label className="ext-field"><span className="ext-flabel">Contact / owner</span><UI.Editable className="ext-fval" value={e.owner} onChange={(v) => patch(e.id, { owner: v })} placeholder="Person outside the project" /></label>
                  <label className="ext-field"><span className="ext-flabel">Expected by</span><input className="ext-date" type="date" value={e.due || ""} onChange={(ev) => patch(e.id, { due: ev.target.value })} /></label>
                  <label className="ext-field"><span className="ext-flabel">Status</span>
                    <div className="ext-status-seg">
                      {EXT_STATUS.map((x) => <button key={x.id} className={"ext-seg-btn" + (e.status === x.id ? " on" : "")} style={e.status === x.id ? { "--seg-c": x.c } : undefined} onClick={() => patch(e.id, { status: x.id })}>{x.label}</button>)}
                    </div>
                  </label>
                </div>
                <UI.Editable className="ext-note" multiline value={e.note} onChange={(v) => patch(e.id, { note: v })} placeholder="Notes — what exactly is needed, links, conditions…" />
                <div className="ext-deps">
                  {od && <span className="ext-flag overdue"><Icon name="warn" size={12} /> Overdue — blocking dependents</span>}
                  {deps.length > 0 ? (
                    <span className="ext-deps-txt"><Icon name="link" size={12} /> {deps.length} task{deps.length === 1 ? "" : "s"} depend on this: {deps.map((t) => t.title).join(", ")}</span>
                  ) : (
                    <span className="ext-deps-txt muted">No tasks depend on this yet — add it under “Depends on” on a task.</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {del && <UI.Confirm title="Remove this external input?" body="It will also be removed from any task that depends on it." confirmLabel="Remove" onConfirm={() => {
        const eid = del.id;
        Store.setState((stt) => ({ ...stt, externals: (stt.externals || []).filter((x) => x.id !== eid), tasks: (stt.tasks || []).map((t) => (t.deps || []).some((d) => d.type === "ext" && d.refId === eid) ? { ...t, deps: t.deps.filter((d) => !(d.type === "ext" && d.refId === eid)) } : t) }));
        setDel(null);
      }} onClose={() => setDel(null)} />}
    </div></div>
  );
}
Object.assign(window, { ExternalInputs });

/* ============================================================
   CAPACITY — who's busy, who has room: open load + deadline pressure
   ============================================================ */
function Capacity() {
  const s = Store.useStore();
  const { tasks, members } = s;
  const [weeks, setWeeks] = React.useState(6);
  const [open, setOpen] = React.useState(null);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const dow = (today.getDay() + 6) % 7;
  const weekStart = new Date(today); weekStart.setDate(today.getDate() - dow); // Monday of this week
  const wkDate = (i) => { const d = new Date(weekStart); d.setDate(weekStart.getDate() + i * 7); return d; };
  const weekOf = (str) => { const d = new Date(str); d.setHours(0, 0, 0, 0); return Math.floor((d - weekStart) / (7 * 86400000)); };
  const colorOf = (n) => (members.find((m) => m.name === n) || {}).color || "indigo";
  // Capacity follows the member list: only project members are shown (work
  // assigned to anyone no longer a member is reconciled away on load).
  const names = [...new Set((members || []).map((m) => m.name))].filter(Boolean);
  const HEAVY = 4, BUSY = 2;

  const rows = names.map((name) => {
    const mine = tasks.filter((t) => assigneesOf(t).includes(name));
    const openT = mine.filter((t) => t.status !== "done");
    const overdue = openT.filter((t) => t.end && new Date(t.end) < today);
    const perWeek = [...Array(weeks)].map((_, i) => openT.filter((t) => t.end && weekOf(t.end) === i));
    const member = members.find((m) => m.name === name);
    const status = (openT.length >= 6 || perWeek.some((w) => w.length >= HEAVY)) ? "over" : openT.length >= 3 ? "busy" : "room";
    return { name, role: member ? member.role : "", color: colorOf(name), open: openT, overdue, perWeek, status };
  }).sort((a, b) => b.open.length - a.open.length || b.overdue.length - a.overdue.length);

  const unassigned = tasks.filter((t) => t.status !== "done" && assigneesOf(t).length === 0);
  const overloaded = rows.filter((r) => r.status === "over").length;
  const totalOpen = tasks.filter((t) => t.status !== "done").length;
  const STAT = { over: { label: "Overloaded", c: "var(--t-red)" }, busy: { label: "Busy", c: "var(--t-amber)" }, room: { label: "Has room", c: "var(--t-green)" } };
  const wkLabel = (i) => i === 0 ? "This week" : wkDate(i).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  const cellTone = (n) => n === 0 ? "c0" : n >= HEAVY ? "c3" : n >= BUSY ? "c2" : "c1";
  const cols = `minmax(180px,1.4fr) 64px 70px repeat(${weeks}, minmax(46px,1fr))`;

  return (
    <div className="view-scroll"><div className="view-pad view-wide">
      <div className="between" style={{ marginBottom: 16, flexWrap: "wrap", gap: 12 }}>
        <p className="muted" style={{ margin: 0, maxWidth: 600, fontSize: 14, lineHeight: 1.55 }}>
          Who's busy and who has room — each person's open tasks and how their deadlines stack up over the coming weeks. Sorted by load, so anyone stretched sits at the top.
        </p>
        <label className="sortby no-print" title="How many weeks to look ahead">
          <Icon name="calendar" size={14} /><span className="sortby-label">Horizon</span>
          <select value={weeks} onChange={(e) => setWeeks(Number(e.target.value))}>
            {[4, 6, 8, 12].map((w) => <option key={w} value={w}>{w} weeks</option>)}
          </select>
          <Icon name="chevD" size={13} />
        </label>
      </div>

      <div className="cap-summary">
        <div className="cap-sum"><span className="cap-sum-n serif">{totalOpen}</span><span className="cap-sum-l">open tasks</span></div>
        <div className="cap-sum"><span className="cap-sum-n serif" style={{ color: overloaded ? "var(--t-red)" : "inherit" }}>{overloaded}</span><span className="cap-sum-l">overloaded</span></div>
        <div className="cap-sum"><span className="cap-sum-n serif">{rows.length}</span><span className="cap-sum-l">people</span></div>
        <div className="cap-sum"><span className="cap-sum-n serif" style={{ color: unassigned.length ? "var(--t-amber)" : "inherit" }}>{unassigned.length}</span><span className="cap-sum-l">unassigned</span></div>
        <div className="cap-legend">
          <span><span className="cap-key c1" /> light</span>
          <span><span className="cap-key c2" /> busy</span>
          <span><span className="cap-key c3" /> heavy</span>
        </div>
      </div>

      {rows.length === 0 && <div className="empty"><div className="serif">No people yet</div>Assign tasks or add members to see capacity.</div>}

      {rows.length > 0 && (
        <div className="cap-grid panel">
          <div className="cap-row cap-head" style={{ gridTemplateColumns: cols }}>
            <div>Person</div><div className="cap-c">Open</div><div className="cap-c">Late</div>
            {[...Array(weeks)].map((_, i) => <div key={i} className="cap-c cap-wk">{wkLabel(i)}</div>)}
          </div>
          {rows.map((r) => (
            <div className="cap-row" style={{ gridTemplateColumns: cols }} key={r.name}>
              <div className="cap-person">
                <span className="avatar" style={{ background: "var(--t-" + r.color + ")" }}>{initials(r.name)}</span>
                <span className="cap-person-txt">
                  <span className="cap-name">{r.name}</span>
                  <span className="cap-status" style={{ color: STAT[r.status].c }}>{STAT[r.status].label}</span>
                </span>
              </div>
              <div className="cap-c"><span className="cap-open">{r.open.length}</span></div>
              <div className="cap-c">{r.overdue.length > 0 ? <span className="cap-late">{r.overdue.length}</span> : <span className="muted">—</span>}</div>
              {r.perWeek.map((w, i) => (
                <div key={i} className={"cap-c cap-cell " + cellTone(w.length)} title={w.length ? w.map((t) => "• " + t.title).join("\n") : "No deadlines"}
                  onClick={() => w.length === 1 && setOpen(w[0])}>
                  {w.length || ""}
                </div>
              ))}
            </div>
          ))}
          {unassigned.length > 0 && (
            <div className="cap-row cap-unassigned" style={{ gridTemplateColumns: cols }}>
              <div className="cap-person">
                <span className="avatar cap-av-ghost">?</span>
                <span className="cap-person-txt"><span className="cap-name">Unassigned</span><span className="cap-status muted">needs an owner</span></span>
              </div>
              <div className="cap-c"><span className="cap-open">{unassigned.length}</span></div>
              <div className="cap-c">{unassigned.filter((t) => t.end && new Date(t.end) < today).length || <span className="muted">—</span>}</div>
              {[...Array(weeks)].map((_, i) => {
                const w = unassigned.filter((t) => t.end && weekOf(t.end) === i);
                return <div key={i} className={"cap-c cap-cell " + cellTone(w.length)} title={w.length ? w.map((t) => "• " + t.title).join("\n") : "No deadlines"}>{w.length || ""}</div>;
              })}
            </div>
          )}
        </div>
      )}
      {open && <CardModal task={open} onClose={() => setOpen(null)} />}
    </div></div>
  );
}

Object.assign(window, { StatusReport, Capacity });

/* ============================================================
   AUDIT TRAIL — every change in the tool over the last 5 weeks,
   fed by the Store's change differ + the AI engine + automations
   ============================================================ */
function AuditTrail() {
  const s = Store.useStore();
  const [q, setQ] = React.useState("");
  const cut = Date.now() - 35 * 86400000;
  const items = (s.activity || []).filter((a) => a.ts >= cut && (!q || (a.text || "").toLowerCase().includes(q.toLowerCase())));
  const days = [];
  items.forEach((a) => {
    const d = new Date(a.ts); const key = d.toDateString();
    let g = days.find((x) => x.key === key);
    if (!g) { g = { key, date: d, items: [] }; days.push(g); }
    g.items.push(a);
  });
  const KIND = { import: ["spark", "Plan update from chat"], edit: ["doc", "Edit"], status: ["bolt", "Automation"], created: ["bolt", "Automation"], overdue: ["bolt", "Automation"], nudge: ["bolt", "Reminder"] };
  const fmtDay = (d) => { const today = new Date().toDateString(); const yd = new Date(Date.now() - 86400000).toDateString(); if (d.toDateString() === today) return "Today"; if (d.toDateString() === yd) return "Yesterday"; return d.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" }); };
  const fmtT = (ts) => new Date(ts).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  return (
    <div className="view-scroll"><div className="view-pad">
      <div className="audit-bar no-print">
        <p className="muted" style={{ margin: 0, maxWidth: 560, fontSize: 14, lineHeight: 1.55 }}>Every change made in this project — by hand, by the plan engine, or by automations — kept for <b>5 weeks</b>. {items.length} entr{items.length === 1 ? "y" : "ies"}.</p>
        <input className="input audit-search" placeholder="Filter…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {days.length === 0 && <div className="empty"><div className="serif">Nothing yet</div>Changes you make from here on are recorded automatically.</div>}
      {days.map((g) => (
        <div key={g.key} className="audit-day">
          <div className="audit-day-hd">{fmtDay(g.date)} <span className="audit-day-n">{g.items.length}</span></div>
          <div className="audit-list">
            {g.items.map((a) => {
              const [ico, lbl] = KIND[a.kind] || ["bolt", "Automation"];
              return (
                <div key={a.id} className={"audit-row k-" + (a.kind || "edit")}>
                  <span className="audit-ico"><Icon name={ico} size={13} /></span>
                  <span className="audit-text">{a.text}</span>
                  <span className="audit-kind">{lbl}</span>
                  <span className="audit-time">{fmtT(a.ts)}</span>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div></div>
  );
}
Object.assign(window, { AuditTrail });

/* ============================================================
   SUGGESTIONS PANEL — review all smart prompts in one place
   ============================================================ */
function SuggestionsPanel({ onClose }) {
  const s = Store.useStore();
  const list = Store.smartSuggestions(s);
  const catOf = (id) => s.categories.find((c) => c.id === id);
  const fd = (d) => d ? new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "—";
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="ai-spark" style={{ background: "var(--accent)" }}><Icon name="idea" size={17} /></div>
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 20 }}>Suggestions</div>
          <div className="muted" style={{ fontSize: 13 }}>Prompts from your dates — confirm or dismiss, and we won't ask again.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        {list.length === 0 && (
          <div className="sg-empty"><Icon name="check" size={22} /><div>Nothing to review right now. As you set task dates, we'll flag actions that look like they hand off to one another.</div></div>
        )}
        <div className="sg-list">
          {list.map((sg) => {
            const cat = catOf(sg.category);
            return (
              <div className="sg-card" key={sg.id}>
                <div className="sg-card-head">
                  {cat && <span className="chip-dot" style={{ background: "var(--t-" + cat.color + ")" }} />}
                  {cat && <span className="sg-card-cat">{cat.label}</span>}
                  <div className="grow" />
                  <span className="sg-card-gap mono">{sg.gap <= 0 ? "overlaps" : sg.gap + "d gap"}</span>
                </div>
                <div className="sg-card-text"><b>{sg.a}</b> <span className="muted">ends {fd(sg.aEnd)}</span> → <b>{sg.b}</b> <span className="muted">starts {fd(sg.bStart)}</span></div>
                <div className="sg-card-q">Does “{sg.b}” wait on “{sg.a}”, or do they run in parallel?</div>
                <div className="sg-card-actions">
                  <button className="btn btn-sm btn-primary" onClick={() => Store.linkTasks(sg.bId, sg.aId)}><Icon name="link" size={12} /> Sequential</button>
                  <button className="btn btn-sm" onClick={() => Store.dismissSuggestion(sg.id, "parallel")}>Parallel</button>
                  <div className="grow" />
                  <button className="btn btn-sm btn-ghost" onClick={() => Store.dismissSuggestion(sg.id, "dismissed")}>Dismiss</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { SuggestionsPanel });

/* ============================================================
   AI IMPORT — paste an AI/Copilot chat; the system reads it
   against your real tasks and proposes updates you approve.
   ============================================================ */
const AI_STATUS = { backlog: "To do", inprogress: "In progress", done: "Done" };
function aiShiftISO(iso, days) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || "")) return iso;
  const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + days);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function aiParseJSON(raw) {
  if (!raw) return null;
  let s = String(raw).trim();
  // strip ``` fences and any prose around the JSON object
  s = s.replace(/```(?:json)?/gi, "");
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a === -1 || b === -1) return null;
  try { return JSON.parse(s.slice(a, b + 1)); } catch (e) { return null; }
}

const AI_LVL = { low: "Low", med: "Medium", high: "High" };
function AIImport() {
  const s = Store.useStore();
  const { tasks, categories, members } = s;
  const [text, setText] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState("");
  const [groups, setGroups] = React.useState(null);   // null = not analysed yet
  const [done, setDone] = React.useState(0);
  const [clarify, setClarify] = React.useState(null);  // {questions:[{q,options}], answers:{}} when AI needs input
  const [pending, setPending] = React.useState(false);  // auto-analyze a command handed off from the front page

  const flat = tasks; // includes subtasks
  const catName = (id) => (categories.find((c) => c.id === id) || {}).label || "";
  const catByName = (n) => categories.find((c) => c.label.toLowerCase() === String(n || "").toLowerCase());

  const analyze = async (clarifyAnswers) => {
    setErr(""); setDone(0);
    if (!text.trim()) { setErr("Paste a chat transcript or a summary of what was done first."); return; }
    if (!window.claude || !window.claude.complete) { setErr("The AI assistant isn't available in this view."); return; }
    setBusy(true);
    try {
      const lc = text.toLowerCase();
      const has = (re) => re.test(lc);
      const isQuestion = /\?/.test(text) || /^(what|who|when|which|where|how|why|is|are|do|does|can|should)\b/.test(lc.trim());
      const wantsDates = isQuestion || has(/\b(date|day|week|month|deadline|due|start|finish|schedule|push|delay|postpone|move|by |before |after |sept|oct|nov|dec|jan|feb|mar|apr|may|jun|jul|aug|monday|tuesday|wednesday|thursday|friday)\b/);
      // Task list: titles always; dates only when the message is about scheduling. Trimmed to what's needed.
      const list = flat.slice(0, 400).map((t, i) => `T${i + 1}: ${t.title} [${AI_STATUS[t.status]}${t.category ? ", " + catName(t.category) : ""}${t.parentId ? ", sub" : ""}${wantsDates && t.start ? ", " + t.start + "→" + (t.end || "?") : ""}]`).join("\n");
      const cats = categories.map((c) => c.label).join(", ") || "(none)";
      const nowISO = (() => { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); })();
      // Only attach the context a message actually needs — saves tokens on every call.
      const ctxLines = [];
      if (isQuestion || has(/\bscope\b|out of scope|in scope|deferred|won'?t do|not doing|exclude|include/)) {
        const sc = s.scope || { inScope: [], outScope: [] };
        ctxLines.push("IN SCOPE: " + ((sc.inScope || []).join(" | ") || "(empty)"), "OUT OF SCOPE: " + ((sc.outScope || []).join(" | ") || "(empty)"));
      }
      if (isQuestion || has(/\brisk|threat|danger|could fail|might fail|mitigat|blocker|jeopard|close\b/)) ctxLines.push("EXISTING RISKS: " + ((s.risks || []).map((r, i) => "R" + (i + 1) + ": " + r.title + " (" + r.likelihood + "/" + r.impact + ", " + (r.status || "open") + ")").join(" | ") || "(none)"));
      if (has(/\bfinding|insight|research|learned|discover|data show|survey|interview/)) ctxLines.push("EXISTING INSIGHTS: " + ((s.findings || []).map((f) => f.title).join(" | ") || "(none)"));
      if (has(/\bglossary|term|acronym|abbreviation|stands for|means\b|definition/)) ctxLines.push("EXISTING GLOSSARY: " + ((s.glossary || []).map((g) => g.term).join(", ") || "(none)"));
      if (isQuestion || has(/\bmilestone|gate|sign-?off|go\/no-?go|launch|deadline/)) ctxLines.push("EXISTING MILESTONES/GATES: " + ((s.milestones || []).map((m) => m.title + (m.type === "gate" ? " (gate)" : "") + (m.date ? " " + m.date : "")).join(" | ") || "(none)"));
      if (isQuestion || has(/member|team\b|role|assign|owner|report|manager|capacity|who\b|rename/)) ctxLines.push("MEMBERS: " + ((s.members || []).map((m) => m.name + (m.role ? " (" + m.role + ")" : "")).join(" | ") || "(none)"));
      if (isQuestion) {
        // question mode: give the model the whole project so it can answer like an assistant
        ctxLines.push("DELIVERABLES: " + ((s.products || []).map((p) => p.name).join(" | ") || "(none)"));
        ctxLines.push("INSIGHTS: " + ((s.findings || []).map((f) => f.title).join(" | ") || "(none)"));
        const su = s.startup || {};
        const bits = [];
        if ((su.mission || {}).mission) bits.push("Mission: " + su.mission.mission);
        if ((su.valueProp || {}).headline) bits.push("Value prop: " + su.valueProp.headline);
        if (((su.features || {}).groups || []).length) bits.push("Features: " + su.features.groups.flatMap((g) => (g.items || []).map((i) => i.name)).join(", "));
        if (((su.features || {}).packages || []).length) bits.push("Packages: " + su.features.packages.map((p) => p.name).join(", "));
        if (bits.length) ctxLines.push("STRATEGY: " + bits.join(" \u00b7 "));
        const fin = s.financials || {};
        if ((fin.budget || []).length) ctxLines.push("BUDGET: " + fin.budget.map((b) => b.label + " " + (b.amount || 0)).join(" | "));
        ctxLines.push("Answer questions fully and concretely from this context (counts, names, dates); if something isn't in the context, say so.");
      }
      // Only advertise the scheduling ops when the message is about dates — shortens the schema.
      const schedOps = !wantsDates ? [] : [
        '{"type":"dates","task":"T3","start":"YYYY-MM-DD","end":"YYYY-MM-DD"}',
        '{"type":"shift_all","toStart":"YYYY-MM-DD"}  // push whole project so earliest task starts here; all move equally',
        '{"type":"shift_all","byDays":N}  // shift every dated task by N days',
        "Scheduling: 'start next week'/'nothing before X' → shift_all toStart. 'move N days' → shift_all byDays. One task → dates. Preserve durations.",
      ];
      const riskOps = !(isQuestion || has(/\brisk|threat|mitigat|close\b/)) ? [] : [
        '{"type":"edit_risk","risk":"R2","title":"<|>","likelihood":"<|>","impact":"<|>","mitigation":"<|>","owner":"<|>","status":"open|monitoring|closed|"}  // edit or close an existing risk',
      ];
      const peopleOps = !has(/member|team\b|role|report|manager|org|capacity|rename/) ? [] : [
        '{"type":"edit_member","name":"<existing member>","rename":"<new name|>","role":"<new role|>"}',
        '{"type":"org_report","who":"<member>","to":"<their manager>"}  // reporting line on the org chart',
      ];
      const structOps = !has(/subtask|promote|reorder|top of|bottom of|package|bundle|track|move /) ? [] : [
        '{"type":"move_track","task":"T3","track":"<name>"}  // move a task to another track',
        '{"type":"make_subtask","task":"T3","parent":"T5"} / {"type":"promote","task":"T3"}',
        '{"type":"reorder","task":"T3","to":"top|bottom"}',
        '{"type":"package","name":"...","tagline":"<|>","features":["<feature names>"]}  // bundle features into a sales package',
      ];
      const strategyOps = !has(/mission|vision|value prop|core value|persona|market|competitor|\btam\b|\bsam\b|\bsom\b|positioning|go.?to.?market|\bgtm\b|channel|launch plan|canvas|\bbmc\b|business model/) ? [] : [
        '{"type":"value","label":"...","desc":"<|>"}  // add a core company value',
        '{"type":"vp_segment","segment":"<client type>","jobs":[],"pains":[],"gains":[]}  // add to the value-prop canvas for a segment',
        '{"type":"persona","name":"...","role":"<|>","segment":"<|>","goals":[],"pains":[],"note":"<|>"}',
        '{"type":"market","field":"tam|sam|som|positioning","text":"..."} / {"type":"competitor","name":"...","note":"<|>"}',
        '{"type":"gtm","field":"motion","text":"..."} / {"type":"gtm","field":"channels|launch","items":["..."]}',
      ];
      const prompt = [
        "You are a delivery assistant for a project-management tool. Translate the discussion below into concrete plan updates.",
        "GROUP updates from the SAME point in the text; include the short verbatim 'quote' (<=14 words) that triggered each group. One point may need several ops.",
        "Match existing items to avoid duplicates.",
        "TODAY IS " + nowISO + ". Resolve relative dates yourself.",
        "",
        "TASKS:",
        list || "(none)",
        "CATEGORIES: " + cats,
        ...(ctxLines.length ? ["", ...ctxLines] : []),
        "",
        "Return ONLY JSON {\"groups\":[{\"quote\":\"...\",\"ops\":[...]}]}. Ops:",
        '{"type":"status","task":"T3","to":"done|inprogress|backlog"}',
        '{"type":"comment","task":"T3","text":"..."}',
        '{"type":"create","title":"...","category":"<name|>","priority":"low|med|high"}',
        '{"type":"subtask","task":"T3","title":"..."}',
        '{"type":"risk","title":"...","likelihood":"low|med|high","impact":"low|med|high","mitigation":"...","task":"T3|"}',
        '{"type":"dependency","task":"T3","on":"T5","external":""}',
        '{"type":"scope_in","text":"..."} / {"type":"scope_out","text":"..."}',
        '{"type":"finding","title":"...","summary":"...","category":"<name|>"}',
        '{"type":"glossary","term":"...","definition":"..."}',
        '{"type":"milestone","title":"...","kind":"milestone|gate","category":"<name|>","date":"YYYY-MM-DD|","note":"..."}  // creates, or updates when the title matches an existing one',
        '{"type":"assign","task":"T3","who":"<person name>","clear":false}  // set/add an assignee (clear:true removes)',
        '{"type":"priority","task":"T3","to":"low|med|high"}',
        '{"type":"member","name":"<person>","role":"<role|>"}  // add a project member/person',
        '{"type":"delete","task":"T3"}  // remove a task (only on explicit request to delete/remove)',
        '{"type":"deliverable","name":"...","link":"<url|>","task":"T3|"}  // add a product/deliverable to the catalogue, optionally tied to a task',
        '{"type":"track","label":"..."}  // create a new track/category',
        '{"type":"tag","task":"T3","label":"..."}  // tag a task (creates the tag if new)',
        '{"type":"strategy","section":"mission|vision|valueprop|bmc_partners|bmc_activities|bmc_resources|bmc_value|bmc_relationships|bmc_channels|bmc_segments|bmc_costs|bmc_revenue","text":"..."}  // write/replace strategy-page content',
        '{"type":"feature","name":"...","group":"<feature category|>","how":"<how we deliver|>","what":"<client output|>"}  // add to the feature suite',
        '{"type":"favorite","page":"<page name>","on":true}  // pin/unpin a page in the sidebar favourites',
        '{"type":"section","page":"<page name>","on":true}  // show/hide a page for this project',
        '{"type":"setting","key":"autoStart|leadStart|leadDue|buffer","value":0}  // reminder & forecast settings (autoStart: true/false; leadStart/leadDue: days; buffer: %)',
        '{"type":"budget","label":"...","amount":0}  // add a budget line to Financials',
        '{"type":"edit_task","task":"T3","title":"<new|>","desc":"<new|>","track":"<name|>"}  // edit an existing task',
        '{"type":"remove","kind":"risk|scope|finding|glossary|milestone|deliverable|budget|track|tag|member|feature|package|persona|value","name":"..."}  // delete any existing item by name (only on explicit request)',
        '{"type":"remove_dep","task":"T3","on":"T5"}  // remove a dependency',
        '{"type":"untag","task":"T3","label":"..."}',
        '{"type":"bulk","filter":{"track":"<name|>","status":"backlog|inprogress|done|","assignee":"<name|>","priority":"low|med|high|","unassigned":false},"set":{"status":"|","priority":"|","assign":"<name|>","track":"<name|>"},"shiftDays":0}  // one change applied to every matching task',
        '{"type":"answer","text":"..."}  // ONLY when the user asks a question about the plan: answer it concisely from the context instead of proposing changes',
        ...riskOps, ...peopleOps, ...structOps, ...strategyOps,
        ...schedOps,
        "Guidance: blocker→dependency; threat→risk+mitigation (also comment); scope decision→scope_in/out; fact learned→finding; term defined→glossary; deadline/go-no-go→milestone; owner/assignee change→assign; importance→priority; new person→member; explicit delete/remove→delete; a document/output/artefact→deliverable; new work area→track; strategy/positioning text→strategy; new service→feature; pin/hide pages→favorite/section; reminder or forecast-buffer changes→setting; a change to something that already exists→edit_task/edit_risk/edit_member; the same change across many tasks→ONE bulk op, never many singles; a question→answer only. Up to 16 groups. JSON only.",
        "If — and ONLY if — the request is too ambiguous to act on (unclear which task, missing a needed date, unclear who), return {\"clarify\":[{\"q\":\"short question\",\"options\":[\"choice A\",\"choice B\"]}]} INSTEAD of groups. Prefer acting over asking; ask at most 3 questions." + (clarifyAnswers ? " The user has ALREADY answered your clarifications below — do NOT ask again; act on their answers now." : ""),
        "",
        "DISCUSSION:",
        text.slice(0, 40000),
        clarifyAnswers ? "\nCLARIFICATIONS:\n" + clarifyAnswers : "",
      ].join("\n");
      const out = await window.claude.complete(prompt);
      const parsed = aiParseJSON(out);
      // AI may ask for clarification instead of proposing changes
      if (parsed && Array.isArray(parsed.clarify) && parsed.clarify.length && !parsed.groups && !parsed.ops) {
        setClarify({ questions: parsed.clarify.slice(0, 3).map((q, i) => ({ id: "cq" + i, q: String(q.q || "").trim(), options: Array.isArray(q.options) ? q.options.slice(0, 5) : [] })), answers: {} });
        setBusy(false); return;
      }
      const rawGroups = parsed && (Array.isArray(parsed.groups) ? parsed.groups : (Array.isArray(parsed.ops) ? [{ quote: "", ops: parsed.ops }] : null));
      if (!rawGroups) { setErr("Couldn't read a clear set of changes from that. Try pasting a bit more detail."); setBusy(false); return; }
      const resolve = (ref) => { const m = /^T(\d+)$/.exec(String(ref || "").trim()); return m ? flat[+m[1] - 1] : null; };
      const resolvePage = (name) => { const q = String(name || "").trim().toLowerCase(); if (!q) return null; const all = NAV.flatMap((g) => g.items); return all.find((it) => it.label.toLowerCase() === q) || all.find((it) => it.label.toLowerCase().includes(q) || q.includes(it.label.toLowerCase())) || all.find((it) => it.id === q) || null; };
      const resolveRisk = (ref) => { const m = /^R(\d+)$/.exec(String(ref || "").trim()); if (m) return (s.risks || [])[+m[1] - 1] || null; const q = String(ref || "").trim().toLowerCase(); return q ? ((s.risks || []).find((r) => r.title.toLowerCase() === q) || (s.risks || []).find((r) => r.title.toLowerCase().includes(q) || q.includes(r.title.toLowerCase()))) : null; };
      const memByName = (n) => { const q = String(n || "").trim().toLowerCase(); return q ? ((s.members || []).find((m) => m.name.toLowerCase() === q) || (s.members || []).find((m) => m.name.toLowerCase().includes(q))) : null; };
      const lvl = (v) => (["low", "med", "high"].includes(v) ? v : "med");
      let n = 0;
      const norm = rawGroups.map((grp, gi) => {
        const ops = (grp.ops || []).map((o) => {
          const base = { _id: "op" + (n++), _sel: true, type: o.type };
          if (o.type === "status") { const t = resolve(o.task); if (!t || !AI_STATUS[o.to]) return null; return { ...base, taskId: t.id, taskTitle: t.title, from: t.status, to: o.to }; }
          if (o.type === "comment") { const t = resolve(o.task); if (!t || !o.text) return null; return { ...base, taskId: t.id, taskTitle: t.title, text: o.text }; }
          if (o.type === "subtask") { const t = resolve(o.task); if (!t || !o.title) return null; return { ...base, parentId: t.id, taskTitle: t.title, title: o.title }; }
          if (o.type === "create") { if (!o.title) return null; const c = catByName(o.category); return { ...base, title: o.title, category: c ? c.id : null, categoryName: c ? c.label : "", priority: lvl(o.priority) }; }
          if (o.type === "risk") { if (!o.title) return null; const t = resolve(o.task); return { ...base, title: o.title, likelihood: lvl(o.likelihood), impact: lvl(o.impact), mitigation: o.mitigation || "", taskId: t ? t.id : null, taskTitle: t ? t.title : "" }; }
          if (o.type === "dependency") { const t = resolve(o.task); if (!t) return null; const on = resolve(o.on); const ext = String(o.external || "").trim(); if (!on && !ext) return null; return { ...base, taskId: t.id, taskTitle: t.title, onId: on ? on.id : null, onTitle: on ? on.title : "", external: on ? "" : ext }; }
          if (o.type === "scope_in" || o.type === "scope_out") { const txt = String(o.text || "").trim(); if (!txt) return null; return { ...base, side: o.type === "scope_in" ? "inScope" : "outScope", text: txt }; }
          if (o.type === "finding") { if (!o.title) return null; const c = catByName(o.category); return { ...base, title: o.title, summary: o.summary || "", category: c ? c.id : null, categoryName: c ? c.label : "" }; }
          if (o.type === "glossary") { if (!o.term) return null; return { ...base, term: o.term, definition: o.definition || "" }; }
          if (o.type === "milestone") { if (!o.title) return null; const c = catByName(o.category); const date = /^\d{4}-\d{2}-\d{2}$/.test(o.date || "") ? o.date : ""; const ex = (s.milestones || []).find((m) => m.title.toLowerCase() === String(o.title).toLowerCase()); return { ...base, title: o.title, kind: o.kind === "gate" ? "gate" : "milestone", category: c ? c.id : null, categoryName: c ? c.label : "", note: o.note || "", date, existingId: ex ? ex.id : null }; }
          if (o.type === "dates") { const t = resolve(o.task); if (!t) return null; const st = /^\d{4}-\d{2}-\d{2}$/.test(o.start || "") ? o.start : (t.start || ""); const en = /^\d{4}-\d{2}-\d{2}$/.test(o.end || "") ? o.end : (t.end || ""); if (!st && !en) return null; return { ...base, taskId: t.id, taskTitle: t.title, start: st, end: en, fromStart: t.start || "", fromEnd: t.end || "" }; }
          if (o.type === "shift_all") {
            const dated = flat.filter((t) => t.start);
            if (!dated.length) return null;
            const earliest = dated.reduce((m, t) => (t.start < m ? t.start : m), dated[0].start);
            let days;
            if (/^\d{4}-\d{2}-\d{2}$/.test(o.toStart || "")) { days = Math.round((+new Date(o.toStart) - +new Date(earliest)) / 86400000); }
            else if (typeof o.byDays === "number") { days = Math.round(o.byDays); }
            else return null;
            if (!days) return null;
            return { ...base, days, count: dated.length, earliest, newEarliest: aiShiftISO(earliest, days) };
          }
          if (o.type === "assign") { const t = resolve(o.task); if (!t || !o.who) return null; return { ...base, taskId: t.id, taskTitle: t.title, who: String(o.who).trim(), clear: !!o.clear }; }
          if (o.type === "priority") { const t = resolve(o.task); if (!t || !["low", "med", "high"].includes(o.to)) return null; return { ...base, taskId: t.id, taskTitle: t.title, to: o.to }; }
          if (o.type === "member") { const nm = String(o.name || "").trim(); if (!nm) return null; if ((s.members || []).some((m) => m.name.toLowerCase() === nm.toLowerCase())) return null; return { ...base, name: nm, role: String(o.role || "").trim() }; }
          if (o.type === "delete") { const t = resolve(o.task); if (!t) return null; return { ...base, taskId: t.id, taskTitle: t.title }; }
          if (o.type === "deliverable") { const nm = String(o.name || "").trim(); if (!nm) return null; const t = resolve(o.task); return { ...base, name: nm, link: String(o.link || "").trim(), taskId: t ? t.id : null, taskTitle: t ? t.title : "" }; }
          if (o.type === "track") { const lb = String(o.label || "").trim(); if (!lb || categories.some((c) => c.label.toLowerCase() === lb.toLowerCase())) return null; return { ...base, label: lb }; }
          if (o.type === "tag") { const t = resolve(o.task); const lb = String(o.label || "").trim(); if (!t || !lb) return null; return { ...base, taskId: t.id, taskTitle: t.title, label: lb }; }
          if (o.type === "strategy") { const sec = String(o.section || "").trim(); const txt = String(o.text || "").trim(); const ok = ["mission", "vision", "valueprop"].includes(sec) || /^bmc_(partners|activities|resources|value|relationships|channels|segments|costs|revenue)$/.test(sec); if (!ok || !txt) return null; return { ...base, section: sec, text: txt }; }
          if (o.type === "feature") { const nm = String(o.name || "").trim(); if (!nm) return null; return { ...base, name: nm, group: String(o.group || "").trim(), how: String(o.how || "").trim(), what: String(o.what || "").trim() }; }
          if (o.type === "favorite" || o.type === "section") { const pg = resolvePage(o.page); if (!pg) return null; return { ...base, pageId: pg.id, pageLabel: pg.label, on: o.on !== false }; }
          if (o.type === "setting") { const k = String(o.key || "").trim(); if (!["autoStart", "leadStart", "leadDue", "buffer"].includes(k)) return null; return { ...base, key: k, value: k === "autoStart" ? !!o.value : Math.max(0, Math.min(100, +o.value || 0)) }; }
          if (o.type === "budget") { const lb = String(o.label || "").trim(); if (!lb) return null; return { ...base, label: lb, amount: +o.amount || 0 }; }
          if (o.type === "answer") { const txt = String(o.text || "").trim(); if (!txt) return null; return { ...base, _sel: false, _info: true, text: txt }; }
          if (o.type === "edit_task") { const t = resolve(o.task); if (!t) return null; const c = catByName(o.track); const title = String(o.title || "").trim(), desc = String(o.desc || "").trim(); if (!title && !desc && !c) return null; return { ...base, taskId: t.id, taskTitle: t.title, title, desc, trackId: c ? c.id : null, trackName: c ? c.label : "" }; }
          if (o.type === "edit_risk") { const r = resolveRisk(o.risk || o.name || o.title); if (!r) return null; const c = {}; const nt = String(o.title || "").trim(); if (nt && nt.toLowerCase() !== r.title.toLowerCase()) c.title = nt; if (["low", "med", "high"].includes(o.likelihood)) c.likelihood = o.likelihood; if (["low", "med", "high"].includes(o.impact)) c.impact = o.impact; if (o.mitigation) c.mitigation = String(o.mitigation); if (o.owner) c.owner = String(o.owner); if (["open", "monitoring", "closed"].includes(o.status)) c.status = o.status; if (!Object.keys(c).length) return null; return { ...base, riskId: r.id, riskTitle: r.title, changes: c }; }
          if (o.type === "remove") {
            const kind = String(o.kind || "").trim(); const q = String(o.name || o.title || "").trim(); const ql = q.toLowerCase(); if (!kind || !q) return null;
            const find = (arr, get) => (arr || []).find((x) => String(get(x) || "").toLowerCase() === ql) || (arr || []).find((x) => String(get(x) || "").toLowerCase().includes(ql));
            let display = q, refId = null, extra = null;
            if (kind === "risk") { const r = resolveRisk(q); if (!r) return null; refId = r.id; display = r.title; }
            else if (kind === "scope") { const sc = s.scope || {}; let side = null, line = null; ["inScope", "outScope"].forEach((k) => { if (!line) { line = (sc[k] || []).find((x) => x.toLowerCase() === ql) || (sc[k] || []).find((x) => x.toLowerCase().includes(ql)); if (line) side = k; } }); if (!line) return null; extra = { side, line }; display = line; }
            else if (kind === "finding") { const x = find(s.findings, (f) => f.title); if (!x) return null; refId = x.id; display = x.title; }
            else if (kind === "glossary") { const x = find(s.glossary, (g) => g.term); if (!x) return null; refId = x.id; display = x.term; }
            else if (kind === "milestone") { const x = find(s.milestones, (m) => m.title); if (!x) return null; refId = x.id; display = x.title; }
            else if (kind === "deliverable") { const x = find(s.products, (p) => p.name); if (!x) return null; refId = x.id; display = x.name; }
            else if (kind === "budget") { const x = find((s.financials || {}).budget, (b) => b.label); if (!x) return null; refId = x.id; display = x.label; }
            else if (kind === "track") { const x = find(categories, (c) => c.label); if (!x) return null; refId = x.id; display = x.label; }
            else if (kind === "tag") { const x = find(s.tags, (t) => t.label); if (!x) return null; refId = x.id; display = x.label; }
            else if (kind === "member") { const x = memByName(q); if (!x) return null; refId = x.id; display = x.name; }
            else if (kind === "feature") { const gs = ((s.startup || {}).features || {}).groups || []; let hit = null; gs.forEach((g) => (g.items || []).forEach((it) => { if (!hit && (it.name.toLowerCase() === ql || it.name.toLowerCase().includes(ql))) hit = it; })); if (!hit) return null; refId = hit.id; display = hit.name; }
            else if (kind === "package") { const x = find(((s.startup || {}).features || {}).packages, (p) => p.name); if (!x) return null; refId = x.id; display = x.name; }
            else if (kind === "persona") { const x = find((s.startup || {}).personas, (p) => p.name); if (!x) return null; refId = x.id; display = x.name; }
            else if (kind === "value") { const x = find(((s.startup || {}).mission || {}).values, (v) => v.label); if (!x) return null; refId = x.id; display = x.label; }
            else return null;
            return { ...base, kind, refId, display, extra };
          }
          if (o.type === "remove_dep") { const t = resolve(o.task); if (!t) return null; const on = resolve(o.on); const q = String(o.external || o.on || "").trim().toLowerCase(); const d = (t.deps || []).find((dd) => (on && dd.type === "task" && dd.refId === on.id) || (dd.type === "external" && q && (dd.label || "").toLowerCase().includes(q)) || (dd.type === "task" && q && !on && (((tasks.find((x) => x.id === dd.refId) || {}).title) || "").toLowerCase().includes(q))); if (!d) return null; const predT = d.type === "task" ? ((tasks.find((x) => x.id === d.refId) || {}).title) : d.label; return { ...base, taskId: t.id, taskTitle: t.title, depId: d.id, predTitle: predT || "a dependency" }; }
          if (o.type === "untag") { const t = resolve(o.task); const q = String(o.label || "").trim().toLowerCase(); if (!t || !q) return null; const tg = (s.tags || []).find((x) => x.label.toLowerCase() === q) || (s.tags || []).find((x) => x.label.toLowerCase().includes(q)); if (!tg || !(t.tags || []).includes(tg.id)) return null; return { ...base, taskId: t.id, taskTitle: t.title, tagId: tg.id, label: tg.label }; }
          if (o.type === "move_track") { const t = resolve(o.task); const c = catByName(o.track); if (!t || !c || t.category === c.id) return null; return { ...base, taskId: t.id, taskTitle: t.title, trackId: c.id, trackName: c.label }; }
          if (o.type === "make_subtask") { const t = resolve(o.task), p = resolve(o.parent); if (!t || !p || t.id === p.id || p.parentId) return null; return { ...base, taskId: t.id, taskTitle: t.title, parentId: p.id, parentTitle: p.title }; }
          if (o.type === "promote") { const t = resolve(o.task); if (!t || !t.parentId) return null; return { ...base, taskId: t.id, taskTitle: t.title }; }
          if (o.type === "reorder") { const t = resolve(o.task); const to = o.to === "top" ? "top" : o.to === "bottom" ? "bottom" : null; if (!t || !to) return null; return { ...base, taskId: t.id, taskTitle: t.title, to }; }
          if (o.type === "edit_member") { const m = memByName(o.name); if (!m) return null; const rn = String(o.rename || "").trim(), rl = String(o.role || "").trim(); if (!rn && !rl) return null; return { ...base, memberId: m.id, name: m.name, rename: rn, role: rl }; }
          if (o.type === "org_report") { const a = memByName(o.who), b = memByName(o.to); if (!a || !b || a.id === b.id) return null; return { ...base, whoId: a.id, who: a.name, toId: b.id, to: b.name }; }
          if (o.type === "package") { const nm = String(o.name || "").trim(); if (!nm) return null; const names = Array.isArray(o.features) ? o.features.map((x) => String(x).trim()).filter(Boolean) : []; return { ...base, name: nm, tagline: String(o.tagline || "").trim(), features: names }; }
          if (o.type === "value") { const lb = String(o.label || "").trim(); if (!lb) return null; return { ...base, label: lb, desc: String(o.desc || "").trim() }; }
          if (o.type === "vp_segment") { const sg = String(o.segment || "").trim(); if (!sg) return null; const arr = (k) => (Array.isArray(o[k]) ? o[k].map((x) => String(x).trim()).filter(Boolean) : []); const jobs = arr("jobs"), pains = arr("pains"), gains = arr("gains"); if (!jobs.length && !pains.length && !gains.length) return null; return { ...base, segment: sg, jobs, pains, gains }; }
          if (o.type === "persona") { const nm = String(o.name || "").trim(); if (!nm) return null; const arr = (k) => (Array.isArray(o[k]) ? o[k].map((x) => String(x).trim()).filter(Boolean) : []); return { ...base, name: nm, role: String(o.role || "").trim(), segment: String(o.segment || "").trim(), goals: arr("goals"), pains: arr("pains"), note: String(o.note || "").trim() }; }
          if (o.type === "market") { const f = String(o.field || "").trim(); const txt = String(o.text || "").trim(); if (!["tam", "sam", "som", "positioning"].includes(f) || !txt) return null; return { ...base, field: f, text: txt }; }
          if (o.type === "competitor") { const nm = String(o.name || "").trim(); if (!nm) return null; return { ...base, name: nm, note: String(o.note || "").trim() }; }
          if (o.type === "gtm") { const f = String(o.field || "").trim(); if (f === "motion") { const txt = String(o.text || "").trim(); if (!txt) return null; return { ...base, field: f, text: txt, items: [] }; } if (["channels", "launch"].includes(f)) { const items = Array.isArray(o.items) ? o.items.map((x) => String(x).trim()).filter(Boolean) : (o.text ? [String(o.text).trim()] : []); if (!items.length) return null; return { ...base, field: f, text: "", items }; } return null; }
          if (o.type === "bulk") {
            const f = o.filter || {}; const setv = o.set || {}; const fc = f.track ? catByName(f.track) : null; const toC = setv.track ? catByName(setv.track) : null; const days = typeof o.shiftDays === "number" ? Math.round(o.shiftDays) : 0;
            const matched = flat.filter((t) => { if (f.track && !fc) return false; if (fc && t.category !== fc.id) return false; if (f.status && t.status !== f.status) return false; if (f.priority && t.priority !== f.priority) return false; if (f.assignee && !assigneesOf(t).some((n) => n.toLowerCase() === String(f.assignee).toLowerCase())) return false; if (f.unassigned && assigneesOf(t).length) return false; return true; });
            const set2 = {}; if (AI_STATUS[setv.status]) set2.status = setv.status; if (["low", "med", "high"].includes(setv.priority)) set2.priority = setv.priority; if (setv.assign) set2.assign = String(setv.assign).trim(); if (toC) { set2.track = toC.id; set2.trackName = toC.label; }
            if (!matched.length || (!Object.keys(set2).length && !days)) return null;
            const fdesc = [fc && ("in " + fc.label), f.status && AI_STATUS[f.status], f.priority && (f.priority + " priority"), f.assignee && ("assigned to " + f.assignee), f.unassigned && "unassigned"].filter(Boolean).join(", ") || "all tasks";
            const sdesc = [set2.status && ("status \u2192 " + AI_STATUS[set2.status]), set2.priority && ("priority \u2192 " + set2.priority), set2.assign && ("assign " + set2.assign), set2.trackName && ("track \u2192 " + set2.trackName), days ? ("shift " + (days > 0 ? "+" : "") + days + "d") : ""].filter(Boolean).join(", ");
            return { ...base, matchedIds: matched.map((t) => t.id), count: matched.length, fdesc, sdesc, set: set2, days };
          }
          return null;
        }).filter(Boolean);
        return ops.length ? { _id: "g" + gi, quote: String(grp.quote || "").trim(), ops } : null;
      }).filter(Boolean);
      // CASCADE DETECTION: annotate ops whose change ripples into other tasks
      const allTasks = s.tasks || [];
      const downstreamOf = (id) => { const aff = new Set([id]); let grew = true; while (grew) { grew = false; allTasks.forEach((x) => { if (!aff.has(x.id) && (x.deps || []).some((d) => d.type === "task" && aff.has(d.refId))) { aff.add(x.id); grew = true; } }); } aff.delete(id); return allTasks.filter((x) => aff.has(x.id)); };
      norm.forEach((g) => g.ops.forEach((o) => {
        if (o.type === "status" && o.to === "done") { const w = allTasks.filter((x) => x.status !== "done" && (x.deps || []).some((d) => d.type === "task" && d.refId === o.taskId)); if (w.length) o._cascade = "Unblocks " + w.length + " waiting task" + (w.length === 1 ? "" : "s"); }
        if (o.type === "status" && o.to !== "done") { const t = allTasks.find((x) => x.id === o.taskId); if (t && t.status === "done") { const w = allTasks.filter((x) => x.status !== "done" && (x.deps || []).some((d) => d.type === "task" && d.refId === o.taskId)); if (w.length) o._cascade = "Re-blocks " + w.length + " dependent task" + (w.length === 1 ? "" : "s"); } }
        if (o.type === "dates" && o.taskId) { const ds = downstreamOf(o.taskId); if (ds.length) o._cascade = ds.length + " downstream task" + (ds.length === 1 ? "" : "s") + " may need to move too"; }
        if (o.type === "delete" && o.taskId) { const dep = allTasks.filter((x) => (x.deps || []).some((d) => d.type === "task" && d.refId === o.taskId)); if (dep.length) o._cascade = dep.length + " task" + (dep.length === 1 ? "" : "s") + " depend on this — their dependency will be removed"; }
        if (o.type === "dependency" && o.taskId && o.onId) { const t = allTasks.find((x) => x.id === o.taskId), p = allTasks.find((x) => x.id === o.onId); if (t && p && t.start && p.end && p.status !== "done" && new Date(t.start) < new Date(p.end)) o._cascade = "Creates a dependency block — it starts before “" + p.title + "” finishes"; }
        if (o.type === "shift_all") o._cascade = "Moves every dated task — milestones & gates keep their own dates";
        if (o.type === "bulk" && o.days) o._cascade = "Moves " + o.count + " tasks — dependents outside the selection may need review";
        if (o.type === "remove" && o.kind === "member") o._cascade = "Their task assignments are cleared and their org-chart card is removed";
        if (o.type === "remove" && o.kind === "track") { const nt = allTasks.filter((t) => t.category === o.refId).length; if (nt) o._cascade = nt + " task" + (nt === 1 ? "" : "s") + " lose this track label"; }
        if (o.type === "remove" && o.kind === "tag") o._cascade = "The tag is stripped from every task that carries it";
        if (o.type === "make_subtask") { const kids = allTasks.filter((t) => t.parentId === o.taskId).length; if (kids) o._cascade = "It has " + kids + " subtask" + (kids === 1 ? "" : "s") + " of its own — they stay attached"; }
        if (o.type === "edit_member" && o.rename) o._cascade = "The rename flows into every assignment, the capacity view and the org chart";
        if (o.type === "assign" && !o.clear && !(s.members || []).some((m) => m.name.toLowerCase() === o.who.toLowerCase())) o._cascade = "“" + o.who + "” isn't a project member yet — they'll appear once added on Members";
      }));
      if (!norm.length) { setErr("No changes matched your tasks. You can paste more context, or add them manually."); setBusy(false); return; }
      setGroups(norm);
    } catch (e) {
      setErr("Something went wrong reaching the assistant. Please try again.");
    }
    setBusy(false);
  };

  const allOps = groups ? groups.flatMap((g) => g.ops) : [];
  // pick up a command handed off from the front-page command bar, and auto-run it
  React.useEffect(() => {
    let v = null;
    try { v = sessionStorage.getItem("atlas.cmd.pending"); if (v) sessionStorage.removeItem("atlas.cmd.pending"); } catch (e) {}
    if (v) { setText(v); setPending(true); }
  }, []);
  React.useEffect(() => {
    if (pending && text) { setPending(false); analyze(); }
  }, [pending, text]);
  const selCount = allOps.filter((o) => o._sel).length;
  const mapOps = (fn) => setGroups((gs) => gs.map((g) => ({ ...g, ops: g.ops.map(fn) })));
  const toggle = (id) => mapOps((x) => (x._id === id ? { ...x, _sel: !x._sel } : x));
  const editOp = (id, c) => mapOps((x) => (x._id === id ? { ...x, ...c } : x));
  const toggleGroup = (gid, val) => setGroups((gs) => gs.map((g) => (g._id === gid ? { ...g, ops: g.ops.map((o) => ({ ...o, _sel: val })) } : g)));

  const apply = () => {
    const sel = allOps.filter((o) => o._sel && o.type !== "answer");
    const author = "AI import";
    const logs = [];
    Store.muteAudit(true); // the engine writes its own labelled entries; skip the generic differ
    try {
    sel.forEach((o) => {
      if (o.type === "status") { Store.patch("tasks", o.taskId, { status: o.to }); logs.push({ text: "Set “" + o.taskTitle + "” to " + AI_STATUS[o.to], task: o.taskTitle }); }
      else if (o.type === "comment") {
        const cur = (Store.getState().tasks.find((t) => t.id === o.taskId) || {}).comments || [];
        Store.patch("tasks", o.taskId, { comments: [...cur, { id: Store.uid("cmt"), author, color: "indigo", text: o.text, ts: Date.now() }] });
        logs.push({ text: "Comment on “" + o.taskTitle + "”", task: o.taskTitle });
      } else if (o.type === "subtask") {
        const p = Store.getState().tasks.find((t) => t.id === o.parentId) || {};
        Store.add("tasks", { id: Store.uid("t"), title: o.title, status: "backlog", parentId: o.parentId, tags: [...(p.tags || [])], priority: p.priority || "med", assignees: [...assigneesOf(p)], desc: "", phase: p.phase || null, category: p.category || null, origin: p.origin || null, start: "", end: "", deps: [], comments: [], custom: {} });
        logs.push({ text: "Added subtask “" + o.title + "” under “" + o.taskTitle + "”", task: o.title });
      } else if (o.type === "create") {
        Store.add("tasks", { id: Store.uid("t"), title: o.title, status: "backlog", tags: [], priority: o.priority, assignees: [], desc: "", phase: null, category: o.category, origin: null, start: "", end: "", deps: [], comments: [], custom: {} });
        logs.push({ text: "Created “" + o.title + "”", task: o.title });
      } else if (o.type === "risk") {
        Store.add("risks", { id: Store.uid("r"), title: o.title, likelihood: o.likelihood, impact: o.impact, mitigation: o.mitigation, owner: "", status: "open", taskIds: o.taskId ? [o.taskId] : [] });
        logs.push({ text: "Logged risk “" + o.title + "”" + (o.taskTitle ? " on “" + o.taskTitle + "”" : ""), task: o.taskTitle || o.title });
      } else if (o.type === "dependency") {
        const dep = Store.getState().tasks.find((t) => t.id === o.taskId);
        if (dep) {
          const has = (dep.deps || []).some((d) => (o.onId ? d.type === "task" && d.refId === o.onId : d.type === "external" && d.label === o.external));
          if (!has) Store.patch("tasks", o.taskId, { deps: [...(dep.deps || []), o.onId ? { id: Store.uid("d"), type: "task", refId: o.onId } : { id: Store.uid("d"), type: "external", label: o.external, scope: "" }] });
        }
        logs.push({ text: "“" + o.taskTitle + "” now depends on " + (o.onTitle || o.external), task: o.taskTitle });
      } else if (o.type === "scope_in" || o.type === "scope_out") {
        const key = o.side;
        const cur = Store.getState().scope || { inScope: [], outScope: [] };
        if (!((cur[key] || []).some((x) => String(x).trim().toLowerCase() === o.text.toLowerCase())))
          Store.setState((st) => ({ ...st, scope: { ...(st.scope || { inScope: [], outScope: [] }), [key]: [...((st.scope || {})[key] || []), o.text] } }));
        logs.push({ text: (key === "inScope" ? "Added to in scope: " : "Added to out of scope: ") + o.text, task: o.text });
      } else if (o.type === "finding") {
        const exF = (Store.getState().findings || []).find((f) => f.title.toLowerCase() === o.title.toLowerCase());
        if (exF) { Store.patch("findings", exF.id, { summary: o.summary || exF.summary, category: o.category || exF.category }); logs.push({ text: "Updated insight “" + o.title + "”", task: o.title }); }
        else { Store.add("findings", { id: Store.uid("f"), title: o.title, summary: o.summary, category: o.category, source: "AI import" }); logs.push({ text: "Added insight “" + o.title + "”", task: o.title }); }
      } else if (o.type === "glossary") {
        const exG = (Store.getState().glossary || []).find((g) => g.term.toLowerCase() === o.term.toLowerCase());
        if (exG) { Store.patch("glossary", exG.id, { definition: o.definition }); logs.push({ text: "Updated definition of “" + o.term + "”", task: o.term }); }
        else { Store.add("glossary", { id: Store.uid("gl"), term: o.term, definition: o.definition }); logs.push({ text: "Defined “" + o.term + "”", task: o.term }); }
      } else if (o.type === "milestone") {
        if (o.existingId) {
          const cM = { type: o.kind }; if (o.date) cM.date = o.date; if (o.note) cM.note = o.note; if (o.category) cM.category = o.category;
          Store.patch("milestones", o.existingId, cM);
          logs.push({ text: "Updated " + (o.kind === "gate" ? "gate" : "milestone") + " “" + o.title + "”", task: o.title });
        } else {
          Store.add("milestones", { id: Store.uid("ms"), title: o.title, type: o.kind, date: o.date || "", category: o.category, note: o.note });
          logs.push({ text: "Added " + (o.kind === "gate" ? "gate" : "milestone") + " “" + o.title + "”", task: o.title });
        }
      } else if (o.type === "dates") {
        Store.patch("tasks", o.taskId, { start: o.start || "", end: o.end || "" });
        logs.push({ text: "Rescheduled “" + o.taskTitle + "” to " + (o.start || "?") + " → " + (o.end || "?"), task: o.taskTitle });
      } else if (o.type === "shift_all") {
        Store.setState((st) => ({ ...st, tasks: (st.tasks || []).map((t) => {
          if (!t.start && !t.end) return t;
          return { ...t, start: t.start ? aiShiftISO(t.start, o.days) : t.start, end: t.end ? aiShiftISO(t.end, o.days) : t.end };
        }) }));
        logs.push({ text: "Shifted the whole plan by " + (o.days > 0 ? "+" : "") + o.days + " days", task: "Whole project" });
      } else if (o.type === "assign") {
        const t = Store.getState().tasks.find((x) => x.id === o.taskId) || {};
        const who = Array.isArray(t.assignees) ? t.assignees : (t.assignee ? [t.assignee] : []);
        const next = o.clear ? who.filter((a) => a !== o.who) : [...new Set([...who, o.who])];
        Store.patch("tasks", o.taskId, { assignees: next, assignee: undefined });
        logs.push({ text: (o.clear ? "Unassigned " : "Assigned ") + o.who + (o.clear ? " from " : " to ") + "“" + o.taskTitle + "”", task: o.taskTitle });
      } else if (o.type === "priority") {
        Store.patch("tasks", o.taskId, { priority: o.to });
        logs.push({ text: "Set “" + o.taskTitle + "” priority to " + o.to, task: o.taskTitle });
      } else if (o.type === "member") {
        const colors = ["blue", "indigo", "teal", "green", "amber", "red", "pink", "purple"];
        Store.add("members", { id: Store.uid("mem"), name: o.name, role: o.role || "", email: "", color: colors[(Store.getState().members || []).length % colors.length] });
        logs.push({ text: "Added member " + o.name + (o.role ? " (" + o.role + ")" : ""), task: o.name });
      } else if (o.type === "delete") {
        Store.removeTask(o.taskId);
        logs.push({ text: "Deleted “" + o.taskTitle + "”", task: o.taskTitle });
      } else if (o.type === "deliverable") {
        Store.add("products", { id: Store.uid("p"), name: o.name, type: "doc", fileId: null, externalUrl: o.link || "", taskIds: o.taskId ? [o.taskId] : [], phase: null, date: "", note: "", placeholder: !o.link });
        logs.push({ text: "Added deliverable “" + o.name + "”" + (o.taskTitle ? " to “" + o.taskTitle + "”" : ""), task: o.taskTitle || o.name });
      } else if (o.type === "track") {
        const COLS = ["teal", "pink", "blue", "indigo", "amber", "green", "red", "purple"];
        Store.add("categories", { id: Store.uid("ct"), label: o.label, color: COLS[(Store.getState().categories || []).length % COLS.length] });
        logs.push({ text: "Created track “" + o.label + "”", task: o.label });
      } else if (o.type === "tag") {
        const st = Store.getState();
        let tg = (st.tags || []).find((x) => x.label.toLowerCase() === o.label.toLowerCase());
        if (!tg) { tg = { id: Store.uid("tg"), label: o.label, color: ["blue", "green", "amber", "pink", "teal", "indigo"][(st.tags || []).length % 6] }; Store.add("tags", tg); }
        const t = st.tasks.find((x) => x.id === o.taskId) || {};
        Store.patch("tasks", o.taskId, { tags: [...new Set([...(t.tags || []), tg.id])] });
        logs.push({ text: "Tagged “" + o.taskTitle + "” with " + o.label, task: o.taskTitle });
      } else if (o.type === "strategy") {
        Store.setState((st) => {
          const su = { ...(st.startup || {}) };
          if (o.section === "mission" || o.section === "vision") su.mission = { ...(su.mission || {}), [o.section]: o.text };
          else if (o.section === "valueprop") su.valueProp = { ...(su.valueProp || {}), headline: o.text };
          else { const k = o.section.replace("bmc_", ""); su.bmc = { ...(su.bmc || {}), [k + "_note"]: o.text, _mode: { ...((su.bmc || {})._mode || {}), [k]: "notes" } }; }
          return { ...st, startup: su };
        });
        logs.push({ text: "Updated strategy: " + o.section.replace("bmc_", "BMC · "), task: o.section });
      } else if (o.type === "feature") {
        Store.setState((st) => {
          const su = { ...(st.startup || {}) };
          const fs = { ...(su.features || {}) };
          let groups2 = [...(fs.groups || [])];
          let gi = o.group ? groups2.findIndex((g) => g.label.toLowerCase() === o.group.toLowerCase()) : -1;
          if (gi < 0 && o.group) { groups2.push({ id: Store.uid("fg"), label: o.group, items: [] }); gi = groups2.length - 1; }
          if (gi < 0) { if (!groups2.length) groups2.push({ id: Store.uid("fg"), label: "General", items: [] }); gi = 0; }
          groups2[gi] = { ...groups2[gi], items: [...(groups2[gi].items || []), { id: Store.uid("ft"), name: o.name, desc: "", audience: "", outcomes: [], how: o.how, what: o.what }] };
          su.features = { ...fs, groups: groups2 };
          return { ...st, startup: su };
        });
        logs.push({ text: "Added feature “" + o.name + "”" + (o.group ? " in " + o.group : ""), task: o.name });
      } else if (o.type === "favorite") {
        try {
          const cur = JSON.parse(localStorage.getItem("atlas.nav.favs") || "[]");
          const next = o.on ? [...new Set([...cur, o.pageId])] : cur.filter((x) => x !== o.pageId);
          localStorage.setItem("atlas.nav.favs", JSON.stringify(next));
          window.dispatchEvent(new CustomEvent("atlas:navfavs", { detail: next }));
        } catch (e) {}
        logs.push({ text: (o.on ? "Pinned " : "Unpinned ") + "“" + o.pageLabel + "”" + (o.on ? " to favourites" : ""), task: o.pageLabel });
      } else if (o.type === "section") {
        Store.setState((st) => {
          const cur = Array.isArray(st._enabledSections) ? st._enabledSections : ["comms", "change", "scope", "business", "financials", "preanalysis", "catalogue", "org", "capacity"];
          return { ...st, _enabledSections: o.on ? [...new Set([...cur, o.pageId])] : cur.filter((x) => x !== o.pageId) };
        });
        logs.push({ text: (o.on ? "Enabled" : "Hid") + " the “" + o.pageLabel + "” page", task: o.pageLabel });
      } else if (o.type === "setting") {
        if (o.key === "buffer") Store.setState((st) => ({ ...st, forecast: { ...(st.forecast || {}), bufferPct: o.value } }));
        else Store.setNudgeConfig({ [o.key]: o.value });
        logs.push({ text: "Changed setting " + o.key + " → " + o.value, task: o.key });
      } else if (o.type === "budget") {
        Store.setState((st) => ({ ...st, financials: { ...(st.financials || {}), budget: [...((st.financials || {}).budget || []), { id: Store.uid("bg"), label: o.label, amount: o.amount, note: "" }] } }));
        logs.push({ text: "Added budget line “" + o.label + "”", task: o.label });
      } else if (o.type === "edit_task") {
        const cT = {}; if (o.title) cT.title = o.title; if (o.desc) cT.desc = o.desc; if (o.trackId) cT.category = o.trackId;
        Store.patch("tasks", o.taskId, cT);
        logs.push({ text: "Edited “" + o.taskTitle + "”" + (o.title ? " → “" + o.title + "”" : "") + (o.trackId ? " (moved to " + o.trackName + ")" : ""), task: o.title || o.taskTitle });
      } else if (o.type === "edit_risk") {
        Store.patch("risks", o.riskId, o.changes);
        logs.push({ text: (o.changes.status === "closed" ? "Closed risk “" : "Updated risk “") + o.riskTitle + "”", task: o.riskTitle });
      } else if (o.type === "remove") {
        if (o.kind === "risk") Store.remove("risks", o.refId);
        else if (o.kind === "scope") Store.setState((st) => ({ ...st, scope: { ...(st.scope || {}), [o.extra.side]: ((st.scope || {})[o.extra.side] || []).filter((x) => x !== o.extra.line) } }));
        else if (o.kind === "finding") Store.remove("findings", o.refId);
        else if (o.kind === "glossary") Store.remove("glossary", o.refId);
        else if (o.kind === "milestone") Store.remove("milestones", o.refId);
        else if (o.kind === "deliverable") Store.remove("products", o.refId);
        else if (o.kind === "budget") Store.setState((st) => ({ ...st, financials: { ...(st.financials || {}), budget: ((st.financials || {}).budget || []).filter((b) => b.id !== o.refId) } }));
        else if (o.kind === "track") Store.setState((st) => ({ ...st, tasks: st.tasks.map((t) => (t.category === o.refId ? { ...t, category: null } : t)), categories: (st.categories || []).filter((c) => c.id !== o.refId) }));
        else if (o.kind === "tag") Store.setState((st) => ({ ...st, tasks: st.tasks.map((t) => ((t.tags || []).includes(o.refId) ? { ...t, tags: t.tags.filter((x) => x !== o.refId) } : t)), tags: (st.tags || []).filter((x) => x.id !== o.refId) }));
        else if (o.kind === "member") { if (Store.removeMember) Store.removeMember(o.refId); else Store.remove("members", o.refId); }
        else if (o.kind === "feature") Store.setState((st) => { const su = { ...(st.startup || {}) }; const fs = { ...(su.features || {}) }; fs.groups = (fs.groups || []).map((g) => ({ ...g, items: (g.items || []).filter((it) => it.id !== o.refId) })); fs.packages = (fs.packages || []).map((p) => ({ ...p, featureIds: (p.featureIds || []).filter((x) => x !== o.refId) })); su.features = fs; return { ...st, startup: su }; });
        else if (o.kind === "package") Store.setState((st) => { const su = { ...(st.startup || {}) }; su.features = { ...(su.features || {}), packages: ((su.features || {}).packages || []).filter((p) => p.id !== o.refId) }; return { ...st, startup: su }; });
        else if (o.kind === "persona") Store.setState((st) => ({ ...st, startup: { ...(st.startup || {}), personas: ((st.startup || {}).personas || []).filter((p) => p.id !== o.refId) } }));
        else if (o.kind === "value") Store.setState((st) => { const su = { ...(st.startup || {}) }; su.mission = { ...(su.mission || {}), values: (((su.mission || {}).values) || []).filter((v) => v.id !== o.refId) }; return { ...st, startup: su }; });
        logs.push({ text: "Removed " + o.kind + " “" + o.display + "”", task: o.display });
      } else if (o.type === "remove_dep") {
        const tD = Store.getState().tasks.find((x) => x.id === o.taskId);
        if (tD) Store.patch("tasks", o.taskId, { deps: (tD.deps || []).filter((d) => d.id !== o.depId) });
        logs.push({ text: "“" + o.taskTitle + "” no longer depends on " + o.predTitle, task: o.taskTitle });
      } else if (o.type === "untag") {
        const tU = Store.getState().tasks.find((x) => x.id === o.taskId);
        if (tU) Store.patch("tasks", o.taskId, { tags: (tU.tags || []).filter((x) => x !== o.tagId) });
        logs.push({ text: "Removed tag " + o.label + " from “" + o.taskTitle + "”", task: o.taskTitle });
      } else if (o.type === "move_track") {
        Store.patch("tasks", o.taskId, { category: o.trackId });
        logs.push({ text: "Moved “" + o.taskTitle + "” to " + o.trackName, task: o.taskTitle });
      } else if (o.type === "make_subtask") {
        Store.patch("tasks", o.taskId, { parentId: o.parentId });
        logs.push({ text: "Made “" + o.taskTitle + "” a subtask of “" + o.parentTitle + "”", task: o.taskTitle });
      } else if (o.type === "promote") {
        Store.patch("tasks", o.taskId, { parentId: null });
        logs.push({ text: "Promoted “" + o.taskTitle + "” to a top-level task", task: o.taskTitle });
      } else if (o.type === "reorder") {
        Store.setState((st) => { const t = st.tasks.find((x) => x.id === o.taskId); if (!t) return st; const rest = st.tasks.filter((x) => x.id !== o.taskId); return { ...st, tasks: o.to === "top" ? [t, ...rest] : [...rest, t] }; });
        logs.push({ text: "Moved “" + o.taskTitle + "” to the " + o.to, task: o.taskTitle });
      } else if (o.type === "edit_member") {
        if (o.rename && Store.renameMember) Store.renameMember(o.memberId, o.rename);
        if (o.role) Store.patch("members", o.memberId, { role: o.role });
        logs.push({ text: o.rename ? "Renamed " + o.name + " → " + o.rename + (o.role ? " (" + o.role + ")" : "") : "Set " + o.name + "'s role to " + o.role, task: o.rename || o.name });
      } else if (o.type === "org_report") {
        Store.setState((st) => {
          let org = [...(st.org || [])];
          const mA = (st.members || []).find((m) => m.id === o.whoId), mB = (st.members || []).find((m) => m.id === o.toId);
          if (!mA || !mB) return st;
          const findCard = (mem) => org.find((c) => c.memberId === mem.id || c.name.toLowerCase() === mem.name.toLowerCase());
          let cb = findCard(mB);
          if (!cb) { cb = { id: Store.uid("o"), name: mB.name, role: mB.role || "", parent: null, note: "", accent: mB.color || "indigo", memberId: mB.id }; org.push(cb); }
          let ca = findCard(mA);
          if (!ca) { ca = { id: Store.uid("o"), name: mA.name, role: mA.role || "", parent: cb.id, note: "", accent: mA.color || "indigo", memberId: mA.id }; org.push(ca); }
          org = org.map((c) => (c.id === ca.id ? { ...c, parent: cb.id } : c));
          return { ...st, org };
        });
        logs.push({ text: o.who + " now reports to " + o.to, task: o.who });
      } else if (o.type === "package") {
        Store.setState((st) => {
          const su = { ...(st.startup || {}) }; const fs = { ...(su.features || {}) };
          const idx = {}; (fs.groups || []).forEach((g) => (g.items || []).forEach((it) => { idx[it.name.toLowerCase()] = it.id; }));
          const fids = o.features.map((n) => idx[n.toLowerCase()]).filter(Boolean);
          let pkgs = [...(fs.packages || [])];
          const i = pkgs.findIndex((p) => p.name.toLowerCase() === o.name.toLowerCase());
          if (i >= 0) pkgs[i] = { ...pkgs[i], tagline: o.tagline || pkgs[i].tagline, featureIds: [...new Set([...(pkgs[i].featureIds || []), ...fids])] };
          else pkgs.push({ id: Store.uid("pkg"), name: o.name, tagline: o.tagline, featureIds: fids });
          fs.packages = pkgs; su.features = fs; return { ...st, startup: su };
        });
        logs.push({ text: "Package “" + o.name + "”" + (o.features.length ? " · " + o.features.length + " features" : ""), task: o.name });
      } else if (o.type === "value") {
        Store.setState((st) => { const su = { ...(st.startup || {}) }; su.mission = { ...(su.mission || {}), values: [...(((su.mission || {}).values) || []), { id: Store.uid("val"), label: o.label, desc: o.desc }] }; return { ...st, startup: su }; });
        logs.push({ text: "Added core value “" + o.label + "”", task: o.label });
      } else if (o.type === "vp_segment") {
        Store.setState((st) => {
          const su = { ...(st.startup || {}) }; const vp = { ...(su.valueProp || {}) };
          let segs = [...(vp.segments || [])];
          const i = segs.findIndex((x) => (x.segment || "").toLowerCase() === o.segment.toLowerCase());
          const merge = (a, b) => [...(a || []), ...b.filter((x) => !(a || []).some((y) => (typeof y === "string" ? y : y.t) === x))];
          if (i >= 0) segs[i] = { ...segs[i], jobs: merge(segs[i].jobs, o.jobs), pains: merge(segs[i].pains, o.pains), gains: merge(segs[i].gains, o.gains) };
          else segs.push({ id: Store.uid("seg"), segment: o.segment, jobs: o.jobs, pains: o.pains, gains: o.gains });
          vp.segments = segs; su.valueProp = vp; return { ...st, startup: su };
        });
        logs.push({ text: "Updated value-prop segment “" + o.segment + "”", task: o.segment });
      } else if (o.type === "persona") {
        Store.setState((st) => {
          const su = { ...(st.startup || {}) }; let ps = [...(su.personas || [])];
          const i = ps.findIndex((x) => (x.name || "").toLowerCase() === o.name.toLowerCase());
          const merge = (a, b) => [...(a || []), ...b.filter((x) => !(a || []).includes(x))];
          if (i >= 0) ps[i] = { ...ps[i], role: o.role || ps[i].role, segment: o.segment || ps[i].segment, goals: merge(ps[i].goals, o.goals), pains: merge(ps[i].pains, o.pains), note: o.note || ps[i].note };
          else ps.push({ id: Store.uid("per"), name: o.name, role: o.role, segment: o.segment, goals: o.goals, pains: o.pains, note: o.note });
          su.personas = ps; return { ...st, startup: su };
        });
        logs.push({ text: "Persona “" + o.name + "” updated", task: o.name });
      } else if (o.type === "market") {
        Store.setState((st) => ({ ...st, startup: { ...(st.startup || {}), market: { ...((st.startup || {}).market || {}), [o.field]: o.text } } }));
        logs.push({ text: "Market · " + (o.field === "positioning" ? "positioning" : o.field.toUpperCase()) + " updated", task: o.field });
      } else if (o.type === "competitor") {
        Store.setState((st) => { const su = { ...(st.startup || {}) }; const mk2 = { ...(su.market || {}) }; mk2.competitors = [...(mk2.competitors || []), { id: Store.uid("cmp"), name: o.name, note: o.note }]; su.market = mk2; return { ...st, startup: su }; });
        logs.push({ text: "Added competitor “" + o.name + "”", task: o.name });
      } else if (o.type === "gtm") {
        Store.setState((st) => { const su = { ...(st.startup || {}) }; const g = { ...(su.gtm || {}) }; if (o.field === "motion") g.motion = o.text; else g[o.field] = [...(g[o.field] || []), ...o.items.filter((x) => !(g[o.field] || []).includes(x))]; su.gtm = g; return { ...st, startup: su }; });
        logs.push({ text: "Go-to-market · " + o.field + " updated", task: o.field });
      } else if (o.type === "bulk") {
        o.matchedIds.forEach((id) => {
          const t = Store.getState().tasks.find((x) => x.id === id); if (!t) return;
          const c = {};
          if (o.set.status) c.status = o.set.status;
          if (o.set.priority) c.priority = o.set.priority;
          if (o.set.track) c.category = o.set.track;
          if (o.set.assign) c.assignees = [...new Set([...assigneesOf(t), o.set.assign])];
          if (o.days) { if (t.start) c.start = aiShiftISO(t.start, o.days); if (t.end) c.end = aiShiftISO(t.end, o.days); }
          Store.patch("tasks", id, c);
        });
        logs.push({ text: "Bulk change on " + o.count + " tasks (" + o.fdesc + "): " + o.sdesc, task: o.count + " tasks" });
      }
    });
    } finally { Store.muteAudit(false); }
    if (logs.length) Store.update("activity", (arr) => [...logs.map((l) => ({ id: Store.uid("act"), ts: Date.now(), kind: "import", text: l.text, task: l.task })), ...(arr || [])].slice(0, 120));
    setDone(sel.length);
    setGroups(null); setText("");
  };

  const ICON = { status: "board", comment: "chat", subtask: "layers", create: "plus", risk: "shield", dependency: "link", scope_in: "check", scope_out: "x", finding: "bulb", glossary: "tag", milestone: "gate", dates: "timeline", shift_all: "timeline", assign: "users", priority: "flag", member: "users", delete: "trash", deliverable: "box", track: "list", tag: "tag", strategy: "grid", feature: "gift", favorite: "home", section: "layers", setting: "gauge", budget: "coin", edit_task: "board", edit_risk: "shield", remove: "trash", remove_dep: "link", untag: "tag", move_track: "list", make_subtask: "layers", promote: "layers", reorder: "list", edit_member: "users", org_report: "org", package: "bundle", value: "flag", vp_segment: "persona", persona: "persona", market: "chart", competitor: "chart", gtm: "megaphone", bulk: "bolt", answer: "chat" };
  const LABEL = { status: "Status", comment: "Comment", subtask: "Subtask", create: "New task", risk: "Risk", dependency: "Dependency", scope_in: "In scope", scope_out: "Out of scope", finding: "Insight", glossary: "Glossary", milestone: "Milestone", dates: "Reschedule", shift_all: "Reschedule", assign: "Assign", priority: "Priority", member: "Member", delete: "Delete", deliverable: "Deliverable", track: "Track", tag: "Tag", strategy: "Strategy", feature: "Feature", favorite: "Favourite", section: "Page", setting: "Setting", budget: "Budget", edit_task: "Edit", edit_risk: "Risk", remove: "Remove", remove_dep: "Dependency", untag: "Tag", move_track: "Track", make_subtask: "Subtask", promote: "Subtask", reorder: "Reorder", edit_member: "Member", org_report: "Org chart", package: "Package", value: "Values", vp_segment: "Value prop", persona: "Persona", market: "Market", competitor: "Market", gtm: "GTM", bulk: "Bulk", answer: "Answer" };

  return (
    <div className="view-scroll"><div className="view-pad view-wide ai-wrap">
      <div className="ai-head">
        <div className="ai-spark-lg"><Icon name="spark" size={20} /></div>
        <div>
          <h2 className="ai-h serif">Update plan from chat</h2>
          <p className="ai-sub">Paste a discussion, meeting notes, or an AI/Copilot chat — or just tell it what to change. It can edit <b>everything</b>: tasks, subtasks, dates, assignees, risks, scope, dependencies, milestones, members &amp; the org chart, strategy pages, packages, settings — and it answers questions about the plan. The same change across many tasks becomes one bulk operation, ripple effects are flagged as <b>cascading events</b>, and nothing changes until you approve it.</p>
        </div>
      </div>

      {done > 0 && <div className="ai-success"><Icon name="check" size={15} /> Applied {done} change{done === 1 ? "" : "s"}. They're now live across the board, scope, risks, insights and activity feed.</div>}

      {!groups && !clarify && (
        <div className="ai-input-card">
          <textarea className="ai-textarea" value={text} onChange={(e) => setText(e.target.value)} placeholder={"Paste your discussion here — it can be long. For example:\n\n“Finished the API integration. Started the iOS onboarding screen. The pen-test found a token-storage issue we need to fix before beta. Android is blocked until the API contract is frozen. We agreed multi-currency is out of scope for v1.”"} rows={12} />
          <div className="ai-input-foot">
            <span className="muted" style={{ fontSize: 12.5 }}>Reads your whole plan · {flat.length} task{flat.length === 1 ? "" : "s"} in context · your text isn't stored</span>
            <button className="btn btn-primary" onClick={() => analyze()} disabled={busy}>{busy ? <React.Fragment><span className="ai-spin" /> Reading…</React.Fragment> : <React.Fragment><Icon name="spark" size={15} /> Analyze</React.Fragment>}</button>
          </div>
          {err && <div className="ai-err">{err}</div>}
        </div>
      )}

      {clarify && (
        <div className="ai-input-card ai-clarify">
          <div className="ai-clarify-hd"><Icon name="idea" size={16} /> A couple of things to confirm first</div>
          {clarify.questions.map((q) => (
            <div key={q.id} className="ai-clarify-q">
              <div className="ai-clarify-qt">{q.q}</div>
              {q.options.length > 0 && (
                <div className="ai-clarify-opts">
                  {q.options.map((o, i) => (
                    <button key={i} className={"ai-clarify-opt" + (clarify.answers[q.id] === o ? " on" : "")} onClick={() => setClarify((c) => ({ ...c, answers: { ...c.answers, [q.id]: o } }))}>{o}</button>
                  ))}
                </div>
              )}
              <input className="ai-op-edit" placeholder={q.options.length ? "…or type your own" : "Your answer"} value={clarify.answers[q.id] && !q.options.includes(clarify.answers[q.id]) ? clarify.answers[q.id] : ""} onChange={(e) => setClarify((c) => ({ ...c, answers: { ...c.answers, [q.id]: e.target.value } }))} />
            </div>
          ))}
          <div className="ai-input-foot">
            <button className="btn btn-sm btn-ghost" onClick={() => setClarify(null)}>Back</button>
            <button className="btn btn-primary" disabled={busy || clarify.questions.some((q) => !clarify.answers[q.id])} onClick={() => { const ans = clarify.questions.map((q) => "- " + q.q + " → " + (clarify.answers[q.id] || "")).join("\n"); setClarify(null); analyze(ans); }}>{busy ? <React.Fragment><span className="ai-spin" /> Reading…</React.Fragment> : <React.Fragment><Icon name="spark" size={15} /> Continue</React.Fragment>}</button>
          </div>
        </div>
      )}

      {groups && (
        <div className="ai-review">
          <div className="ai-review-bar">
            <div><b>{allOps.length}</b> change{allOps.length === 1 ? "" : "s"} across {groups.length} insight{groups.length === 1 ? "" : "s"} · <span className="muted">{selCount} selected</span></div>
            <div className="grow" />
            <button className="btn btn-sm btn-ghost" onClick={() => setGroups(null)}>Discard</button>
            <button className="btn btn-primary" onClick={apply} disabled={!selCount}><Icon name="check" size={14} /> Apply {selCount} change{selCount === 1 ? "" : "s"}</button>
          </div>
          <div className="ai-group-list">
            {groups.map((g) => {
              const gSel = g.ops.filter((o) => o._sel).length;
              return (
                <div key={g._id} className="ai-group">
                  <div className="ai-group-hd">
                    <span className="ai-group-quote"><Icon name="spark" size={13} />{g.quote ? "“" + g.quote + "”" : "From your chat"}</span>
                    <div className="grow" />
                    <button className="ai-group-toggle" onClick={() => toggleGroup(g._id, gSel !== g.ops.length)}>{gSel === g.ops.length ? "Deselect all" : "Select all"}</button>
                  </div>
                  <div className="ai-op-list">
                    {g.ops.map((o) => (
                      <div key={o._id} className={"ai-op" + (o._sel ? " on" : "")}>
                        {o.type === "answer" ? <span className="ai-op-check ai-op-check-info"><Icon name="chat" size={13} /></span> : <label className="ai-op-check"><input type="checkbox" checked={o._sel} onChange={() => toggle(o._id)} /><span className="ai-op-box"><Icon name="check" size={12} /></span></label>}
                        <span className={"ai-op-ico t-" + o.type}><Icon name={ICON[o.type]} size={14} /></span>
                        <div className="ai-op-main">
                          {o.type === "status" && <div className="ai-op-text">Move <b>{o.taskTitle}</b> from <span className="ai-op-pill">{AI_STATUS[o.from]}</span> to <span className="ai-op-pill done">{AI_STATUS[o.to]}</span></div>}
                          {o.type === "comment" && <div className="ai-op-text">Comment on <b>{o.taskTitle}</b><input className="ai-op-edit" value={o.text} onChange={(e) => editOp(o._id, { text: e.target.value })} /></div>}
                          {o.type === "subtask" && <div className="ai-op-text">Add subtask under <b>{o.taskTitle}</b><input className="ai-op-edit" value={o.title} onChange={(e) => editOp(o._id, { title: e.target.value })} /></div>}
                          {o.type === "create" && <div className="ai-op-text">Create action{o.categoryName ? <span className="muted"> in {o.categoryName}</span> : ""}<input className="ai-op-edit" value={o.title} onChange={(e) => editOp(o._id, { title: e.target.value })} /></div>}
                          {o.type === "risk" && <div className="ai-op-text">Log risk{o.taskTitle ? <span className="muted"> on {o.taskTitle}</span> : ""}<input className="ai-op-edit" value={o.title} onChange={(e) => editOp(o._id, { title: e.target.value })} /><span className="ai-op-sub"><span className="ai-op-pill">{AI_LVL[o.likelihood]} likelihood</span><span className="ai-op-pill">{AI_LVL[o.impact]} impact</span></span>{o.mitigation && <span className="ai-op-why">Mitigation: {o.mitigation}</span>}</div>}
                          {o.type === "dependency" && <div className="ai-op-text"><b>{o.taskTitle}</b> depends on <b>{o.onTitle || o.external}</b>{o.external && !o.onTitle ? <span className="muted"> (external)</span> : ""}</div>}
                          {(o.type === "scope_in" || o.type === "scope_out") && <div className="ai-op-text">Add to <b>{o.side === "inScope" ? "in scope" : "out of scope"}</b><input className="ai-op-edit" value={o.text} onChange={(e) => editOp(o._id, { text: e.target.value })} /></div>}
                          {o.type === "finding" && <div className="ai-op-text">Add insight{o.categoryName ? <span className="muted"> in {o.categoryName}</span> : ""}<input className="ai-op-edit" value={o.title} onChange={(e) => editOp(o._id, { title: e.target.value })} />{o.summary && <span className="ai-op-why">{o.summary}</span>}</div>}
                          {o.type === "glossary" && <div className="ai-op-text">Define <b>{o.term}</b><input className="ai-op-edit" value={o.definition} onChange={(e) => editOp(o._id, { definition: e.target.value })} placeholder="definition" /></div>}
                          {o.type === "milestone" && <div className="ai-op-text">Add {o.kind === "gate" ? "gate" : "milestone"}{o.categoryName ? <span className="muted"> in {o.categoryName}</span> : ""}<input className="ai-op-edit" value={o.title} onChange={(e) => editOp(o._id, { title: e.target.value })} /></div>}
                          {o.type === "dates" && <div className="ai-op-text">Reschedule <b>{o.taskTitle}</b> to <span className="ai-op-pill">{o.start || "?"} → {o.end || "?"}</span></div>}
                          {o.type === "shift_all" && <div className="ai-op-text">Shift the <b>whole plan</b> by <span className="ai-op-pill">{o.days > 0 ? "+" : ""}{o.days} days</span> <span className="muted">({o.count} dated actions · earliest start → {o.newEarliest})</span></div>}
                          {o.type === "assign" && <div className="ai-op-text">{o.clear ? "Unassign" : "Assign"} <b>{o.who}</b> {o.clear ? "from" : "to"} <b>{o.taskTitle}</b></div>}
                          {o.type === "priority" && <div className="ai-op-text">Set <b>{o.taskTitle}</b> priority to <span className="ai-op-pill">{o.to}</span></div>}
                          {o.type === "member" && <div className="ai-op-text">Add member <b>{o.name}</b>{o.role ? <span className="muted"> · {o.role}</span> : ""}</div>}
                          {o.type === "delete" && <div className="ai-op-text">Delete <b>{o.taskTitle}</b> <span className="muted">(and its subtasks)</span></div>}
                          {o.type === "deliverable" && <div className="ai-op-text">Add deliverable <b>{o.name}</b>{o.taskTitle ? <span className="muted"> to {o.taskTitle}</span> : ""}{o.link ? <span className="muted"> · linked</span> : ""}</div>}
                          {o.type === "track" && <div className="ai-op-text">Create track <b>{o.label}</b></div>}
                          {o.type === "tag" && <div className="ai-op-text">Tag <b>{o.taskTitle}</b> with <span className="ai-op-pill">{o.label}</span></div>}
                          {o.type === "strategy" && <div className="ai-op-text">Update <b>{o.section === "valueprop" ? "value proposition headline" : o.section.startsWith("bmc_") ? "BMC · " + o.section.replace("bmc_", "") : o.section}</b><input className="ai-op-edit" value={o.text} onChange={(e) => editOp(o._id, { text: e.target.value })} /></div>}
                          {o.type === "feature" && <div className="ai-op-text">Add feature <b>{o.name}</b>{o.group ? <span className="muted"> in {o.group}</span> : ""}</div>}
                          {o.type === "favorite" && <div className="ai-op-text">{o.on ? "Pin" : "Unpin"} <b>{o.pageLabel}</b> {o.on ? "to favourites" : "from favourites"}</div>}
                          {o.type === "section" && <div className="ai-op-text">{o.on ? "Show" : "Hide"} the <b>{o.pageLabel}</b> page</div>}
                          {o.type === "setting" && <div className="ai-op-text">Set <b>{o.key === "buffer" ? "forecast delay buffer" : o.key === "autoStart" ? "auto-start tasks" : o.key === "leadStart" ? "start-reminder lead time" : "deadline-reminder lead time"}</b> to <span className="ai-op-pill">{String(o.value)}{o.key === "buffer" ? "%" : o.key === "autoStart" ? "" : "d"}</span></div>}
                          {o.type === "budget" && <div className="ai-op-text">Add budget line <b>{o.label}</b> <span className="ai-op-pill">{o.amount.toLocaleString()}</span></div>}
                          {o.type === "edit_task" && <div className="ai-op-text">Edit <b>{o.taskTitle}</b>{o.title ? <React.Fragment> — rename to <b>{o.title}</b></React.Fragment> : ""}{o.trackName ? <span className="muted"> · move to {o.trackName}</span> : ""}{o.desc ? <span className="ai-op-why">New description: {o.desc}</span> : ""}</div>}
                          {o.type === "edit_risk" && <div className="ai-op-text">{o.changes.status === "closed" ? "Close" : "Update"} risk <b>{o.riskTitle}</b><span className="ai-op-sub">{Object.keys(o.changes).map((k) => <span key={k} className="ai-op-pill">{k} → {String(o.changes[k])}</span>)}</span></div>}
                          {o.type === "remove" && <div className="ai-op-text">Remove {o.kind} <b>{o.display}</b></div>}
                          {o.type === "remove_dep" && <div className="ai-op-text"><b>{o.taskTitle}</b> no longer depends on <b>{o.predTitle}</b></div>}
                          {o.type === "untag" && <div className="ai-op-text">Remove tag <span className="ai-op-pill">{o.label}</span> from <b>{o.taskTitle}</b></div>}
                          {o.type === "move_track" && <div className="ai-op-text">Move <b>{o.taskTitle}</b> to <span className="ai-op-pill">{o.trackName}</span></div>}
                          {o.type === "make_subtask" && <div className="ai-op-text">Make <b>{o.taskTitle}</b> a subtask of <b>{o.parentTitle}</b></div>}
                          {o.type === "promote" && <div className="ai-op-text">Promote <b>{o.taskTitle}</b> to a top-level task</div>}
                          {o.type === "reorder" && <div className="ai-op-text">Move <b>{o.taskTitle}</b> to the <span className="ai-op-pill">{o.to}</span></div>}
                          {o.type === "edit_member" && <div className="ai-op-text">{o.rename ? <React.Fragment>Rename <b>{o.name}</b> to <b>{o.rename}</b></React.Fragment> : <React.Fragment>Set <b>{o.name}</b>'s role to <b>{o.role}</b></React.Fragment>}{o.rename && o.role ? <span className="muted"> · role: {o.role}</span> : ""}</div>}
                          {o.type === "org_report" && <div className="ai-op-text"><b>{o.who}</b> reports to <b>{o.to}</b></div>}
                          {o.type === "package" && <div className="ai-op-text">Package <b>{o.name}</b>{o.features.length ? <span className="muted"> · {o.features.length} features</span> : ""}{o.tagline ? <span className="ai-op-why">{o.tagline}</span> : ""}</div>}
                          {o.type === "value" && <div className="ai-op-text">Add core value <b>{o.label}</b>{o.desc ? <span className="ai-op-why">{o.desc}</span> : ""}</div>}
                          {o.type === "vp_segment" && <div className="ai-op-text">Value prop · <b>{o.segment}</b><span className="ai-op-sub">{o.jobs.length > 0 && <span className="ai-op-pill">{o.jobs.length} jobs</span>}{o.pains.length > 0 && <span className="ai-op-pill">{o.pains.length} pains</span>}{o.gains.length > 0 && <span className="ai-op-pill">{o.gains.length} gains</span>}</span></div>}
                          {o.type === "persona" && <div className="ai-op-text">Persona <b>{o.name}</b>{o.role ? <span className="muted"> · {o.role}</span> : ""}{o.note ? <span className="ai-op-why">{o.note}</span> : ""}</div>}
                          {o.type === "market" && <div className="ai-op-text">Market · <b>{o.field === "positioning" ? "positioning" : o.field.toUpperCase()}</b><input className="ai-op-edit" value={o.text} onChange={(e) => editOp(o._id, { text: e.target.value })} /></div>}
                          {o.type === "competitor" && <div className="ai-op-text">Add competitor <b>{o.name}</b>{o.note ? <span className="ai-op-why">{o.note}</span> : ""}</div>}
                          {o.type === "gtm" && <div className="ai-op-text">Go-to-market · <b>{o.field}</b>{o.field === "motion" ? <input className="ai-op-edit" value={o.text} onChange={(e) => editOp(o._id, { text: e.target.value })} /> : <span className="ai-op-why">{o.items.join(" · ")}</span>}</div>}
                          {o.type === "bulk" && <div className="ai-op-text">Bulk change on <b>{o.count} tasks</b> <span className="muted">({o.fdesc})</span> → {o.sdesc}</div>}
                          {o.type === "answer" && <div className="ai-op-text ai-op-answer">{o.text}</div>}
                          {o._cascade && <div className="ai-op-cascade"><Icon name="bolt" size={11} /> Cascading event — {o._cascade}</div>}
                        </div>
                        <span className="ai-op-type">{LABEL[o.type]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div></div>
  );
}

Object.assign(window, { AIImport });

/* ============================================================
   FINANCIALS — contract, budget statement, and budget-vs-progress
   (earned-value) tracking: are we on track?
   ============================================================ */
const FIN_DAY = 86400000;
function fmtMoney(n, cur) { const c = cur || "€"; const v = Math.round(Number(n) || 0); return c + v.toLocaleString("en-GB"); }
function fmtMoneyShort(n, cur) {
  const c = cur || "€"; const v = Number(n) || 0;
  if (Math.abs(v) >= 1e6) return c + (v / 1e6).toFixed(v % 1e6 === 0 ? 0 : 1) + "M";
  if (Math.abs(v) >= 1e3) return c + Math.round(v / 1e3) + "k";
  return c + Math.round(v);
}

function Financials() {
  const s = Store.useStore();
  const fin = s.financials || { currency: "€", weighting: "duration", contract: {}, budget: [] };
  const cur = fin.currency || "€";
  const tasks = s.tasks || [];
  const setFin = (patch) => Store.setState((st) => ({ ...st, financials: { ...(st.financials || {}), ...patch } }));
  const setContract = (patch) => Store.setState((st) => ({ ...st, financials: { ...(st.financials || {}), contract: { ...((st.financials || {}).contract || {}), ...patch } } }));
  const setBudget = (fn) => Store.setState((st) => ({ ...st, financials: { ...(st.financials || {}), budget: fn(((st.financials || {}).budget) || []) } }));

  const budget = fin.budget || [];
  const budgetTotal = budget.reduce((a, b) => a + (Number(b.amount) || 0), 0);
  const B = budgetTotal || (Number(fin.contract && fin.contract.value) || 0);

  // ---------- earned value ----------
  const evm = useDM(() => {
    const useDur = (fin.weighting || "duration") === "duration";
    const wOf = (t) => (useDur && t.start && t.end) ? Math.max(1, Math.round((new Date(t.end) - new Date(t.start)) / FIN_DAY)) : 1;
    const totalW = tasks.reduce((a, t) => a + wOf(t), 0) || 1;
    const earnedW = tasks.filter((t) => t.status === "done").reduce((a, t) => a + wOf(t), 0);
    // timeline bounds
    const dated = tasks.filter((t) => t.start && t.end);
    const c = fin.contract || {};
    const starts = dated.map((t) => +new Date(t.start));
    const ends = dated.map((t) => +new Date(t.end));
    let t0 = c.start ? +new Date(c.start) : (starts.length ? Math.min(...starts) : null);
    let t1 = c.end ? +new Date(c.end) : (ends.length ? Math.max(...ends) : null);
    if (!t0 || !t1 || t1 <= t0) return { ok: false, B, earnedPct: tasks.length ? earnedW / totalW : 0 };
    const plannedPctAt = (t) => tasks.reduce((a, x) => a + ((x.end && +new Date(x.end) <= t) ? wOf(x) : 0), 0) / totalW;
    const now = Date.now();
    const tClamp = Math.max(t0, Math.min(now, t1));
    // weekly samples for the planned curve
    const pts = []; const step = 7 * FIN_DAY;
    for (let t = t0; t <= t1 + 1; t += step) { const tt = Math.min(t, t1); pts.push({ t: tt, pct: plannedPctAt(tt) }); }
    if (pts[pts.length - 1].t < t1) pts.push({ t: t1, pct: plannedPctAt(t1) });
    const plannedNow = plannedPctAt(tClamp);
    const earnedPct = earnedW / totalW;
    const spi = plannedNow > 0 ? earnedPct / plannedNow : (earnedPct > 0 ? 1.2 : 1);
    return { ok: true, B, t0, t1, now: tClamp, pts, plannedNow, earnedPct, spi, totalDone: tasks.filter((t) => t.status === "done").length, totalTasks: tasks.length };
  }, [tasks, fin]);

  const verdict = !evm.ok ? null : evm.spi >= 1.03 ? { label: "Ahead of plan", c: "var(--t-green)", tone: "good" }
    : evm.spi >= 0.92 ? { label: "On track", c: "var(--t-green)", tone: "good" }
    : evm.spi >= 0.8 ? { label: "Slightly behind", c: "var(--t-amber)", tone: "warn" }
    : { label: "Behind plan", c: "var(--t-red)", tone: "bad" };

  const addBudget = () => setBudget((arr) => [...arr, { id: Store.uid("bg"), label: "New line", amount: 0, note: "" }]);
  const patchBudget = (id, c) => setBudget((arr) => arr.map((x) => (x.id === id ? { ...x, ...c } : x)));
  const delBudget = (id) => setBudget((arr) => arr.filter((x) => x.id !== id));

  // chart geometry
  const CW = 720, CH = 240, PADL = 48, PADR = 18, PADT = 16, PADB = 34;
  const ix = (t) => PADL + (t - evm.t0) / (evm.t1 - evm.t0) * (CW - PADL - PADR);
  const iy = (pct) => PADT + (1 - pct) * (CH - PADT - PADB);
  const fdate = (t) => new Date(t).toLocaleDateString("en-GB", { day: "numeric", month: "short" });

  return (
    <div className="view-scroll"><div className="view-pad view-wide fin-wrap">
      <p className="muted" style={{ margin: "0 0 22px", maxWidth: 640, fontSize: 14, lineHeight: 1.55 }}>
        The contract and budget for this project, and whether delivery is keeping pace with the financial plan — measured by comparing the value of work completed against what was planned by today (earned value).
      </p>

      {/* are we on track? */}
      <section className="fin-section">
        <div className="kpi-section-hd"><h2 className="kpi-h serif">Are we on track?</h2>
          <label className="sortby no-print" title="How task progress is weighted">
            <span className="sortby-label">Weight by</span>
            <select value={fin.weighting || "duration"} onChange={(e) => setFin({ weighting: e.target.value })}>
              <option value="duration">Task duration</option>
              <option value="equal">Each task equal</option>
            </select>
          </label>
        </div>

        {B <= 0 ? (
          <div className="empty" style={{ padding: 24 }}><div className="serif">Add a budget first</div>Enter budget lines or a contract value below to see budget-vs-progress.</div>
        ) : !evm.ok ? (
          <div className="empty" style={{ padding: 24 }}><div className="serif">Schedule the work</div>Give tasks start &amp; end dates (or set the contract dates) to plot planned vs earned value.</div>
        ) : (
          <React.Fragment>
            <div className="fin-headline">
              <div className="fin-verdict" style={{ "--v": verdict.c }}>
                <div className="fin-verdict-spi">{Math.round(evm.spi * 100)}<span>%</span></div>
                <div className="fin-verdict-txt"><span className="fin-verdict-dot" /> {verdict.label}</div>
                <div className="fin-verdict-sub">schedule performance (SPI)</div>
              </div>
              <div className="fin-metrics">
                <div className="fin-metric"><span className="fin-metric-l">Planned by today</span><span className="fin-metric-v serif">{Math.round(evm.plannedNow * 100)}%</span><span className="fin-metric-s">{fmtMoneyShort(evm.B * evm.plannedNow, cur)} of value</span></div>
                <div className="fin-metric"><span className="fin-metric-l">Earned so far</span><span className="fin-metric-v serif" style={{ color: verdict.c }}>{Math.round(evm.earnedPct * 100)}%</span><span className="fin-metric-s">{fmtMoneyShort(evm.B * evm.earnedPct, cur)} delivered</span></div>
                <div className="fin-metric"><span className="fin-metric-l">Budget</span><span className="fin-metric-v serif">{fmtMoneyShort(evm.B, cur)}</span><span className="fin-metric-s">{evm.totalDone}/{evm.totalTasks} tasks done</span></div>
              </div>
            </div>

            <div className="fin-chart panel">
              <svg viewBox={`0 0 ${CW} ${CH}`} className="fin-svg" preserveAspectRatio="none">
                {[0, 0.25, 0.5, 0.75, 1].map((g) => (
                  <g key={g}>
                    <line x1={PADL} y1={iy(g)} x2={CW - PADR} y2={iy(g)} className="fin-grid" />
                    <text x={PADL - 8} y={iy(g) + 4} className="fin-axis" textAnchor="end">{Math.round(g * 100)}%</text>
                  </g>
                ))}
                {/* planned area + line */}
                <path className="fin-plan-area" d={`M ${ix(evm.pts[0].t)} ${iy(0)} ` + evm.pts.map((p) => `L ${ix(p.t)} ${iy(p.pct)}`).join(" ") + ` L ${ix(evm.pts[evm.pts.length - 1].t)} ${iy(0)} Z`} />
                <polyline className="fin-plan-line" points={evm.pts.map((p) => `${ix(p.t)},${iy(p.pct)}`).join(" ")} />
                {/* today marker */}
                <line x1={ix(evm.now)} y1={PADT} x2={ix(evm.now)} y2={iy(0)} className="fin-today" />
                <text x={ix(evm.now)} y={PADT - 4} className="fin-axis fin-today-lbl" textAnchor="middle">today</text>
                {/* variance bar between planned & earned at today */}
                <line x1={ix(evm.now)} y1={iy(evm.plannedNow)} x2={ix(evm.now)} y2={iy(evm.earnedPct)} className={"fin-var " + verdict.tone} />
                {/* planned point + earned point */}
                <circle cx={ix(evm.now)} cy={iy(evm.plannedNow)} r="4.5" className="fin-dot-plan" />
                <circle cx={ix(evm.now)} cy={iy(evm.earnedPct)} r="5.5" className="fin-dot-earned" style={{ fill: verdict.c }} />
                {/* x labels */}
                <text x={PADL} y={CH - 10} className="fin-axis" textAnchor="start">{fdate(evm.t0)}</text>
                <text x={CW - PADR} y={CH - 10} className="fin-axis" textAnchor="end">{fdate(evm.t1)}</text>
              </svg>
              <div className="fin-legend">
                <span><span className="fin-key fin-key-plan" /> Planned value</span>
                <span><span className="fin-key fin-key-earned" style={{ background: verdict.c }} /> Earned (work done)</span>
                <span className="muted">Gap at “today” = how far ahead/behind delivery is</span>
              </div>
            </div>
          </React.Fragment>
        )}
      </section>

      <div className="fin-cols">
        {/* contract */}
        <section className="fin-section">
          <div className="kpi-section-hd"><h2 className="kpi-h serif">Contract</h2></div>
          <div className="fin-contract panel">
            <input className="fin-c-title" value={(fin.contract || {}).title || ""} onChange={(e) => setContract({ title: e.target.value })} placeholder="Contract / SOW title" />
            <div className="fin-c-grid">
              <label className="fin-f"><span>Counterparty</span><input value={(fin.contract || {}).party || ""} onChange={(e) => setContract({ party: e.target.value })} placeholder="Supplier / client" /></label>
              <label className="fin-f"><span>Value</span><input type="number" value={(fin.contract || {}).value || ""} onChange={(e) => setContract({ value: Number(e.target.value) || 0 })} placeholder="0" /></label>
              <label className="fin-f"><span>Signed</span><input type="date" value={(fin.contract || {}).signed || ""} onChange={(e) => setContract({ signed: e.target.value })} /></label>
              <label className="fin-f"><span>Start</span><input type="date" value={(fin.contract || {}).start || ""} onChange={(e) => setContract({ start: e.target.value })} /></label>
              <label className="fin-f"><span>End</span><input type="date" value={(fin.contract || {}).end || ""} onChange={(e) => setContract({ end: e.target.value })} /></label>
              <label className="fin-f"><span>Document link</span><input value={(fin.contract || {}).url || ""} onChange={(e) => setContract({ url: e.target.value })} placeholder="https://…" /></label>
            </div>
            <textarea className="fin-c-note" value={(fin.contract || {}).note || ""} onChange={(e) => setContract({ note: e.target.value })} placeholder="Notes on scope, terms, what's included/excluded…" rows={2} />
            {(fin.contract || {}).url && <a className="btn btn-sm" href={fin.contract.url} target="_blank" rel="noopener"><Icon name="link" size={13} /> Open contract</a>}
          </div>
        </section>

        {/* budget statement */}
        <section className="fin-section">
          <div className="kpi-section-hd"><h2 className="kpi-h serif">Budget</h2><span className="fin-budget-total mono">{fmtMoney(budgetTotal, cur)}</span></div>
          <div className="fin-budget panel">
            {budget.length === 0 && <div className="fin-budget-empty">No budget lines yet. Add the cost breakdown below.</div>}
            {budget.map((b) => {
              const pct = budgetTotal ? (Number(b.amount) || 0) / budgetTotal * 100 : 0;
              return (
                <div className="fin-bg-row" key={b.id}>
                  <input className="fin-bg-label" value={b.label} onChange={(e) => patchBudget(b.id, { label: e.target.value })} placeholder="Line item" />
                  <div className="fin-bg-bar"><div className="fin-bg-fill" style={{ width: pct + "%" }} /></div>
                  <span className="fin-bg-pct mono">{Math.round(pct)}%</span>
                  <input className="fin-bg-amt" type="number" value={b.amount || ""} onChange={(e) => patchBudget(b.id, { amount: Number(e.target.value) || 0 })} placeholder="0" />
                  <button className="fin-bg-del" title="Remove" onClick={() => delBudget(b.id)}><Icon name="x" size={12} /></button>
                </div>
              );
            })}
            <button className="btn btn-sm btn-ghost" style={{ marginTop: 4 }} onClick={addBudget}><Icon name="plus" size={13} /> Add line</button>
          </div>
        </section>
      </div>
    </div></div>
  );
}

Object.assign(window, { Financials });

/* ============================================================
   KPIs — project health & workload metrics
   ============================================================ */
const KPI_DAY_MS = 86400000;
const kpiStartOfWeek = (d) => { const x = new Date(d); const day = (x.getDay() + 6) % 7; x.setDate(x.getDate() - day); x.setHours(0, 0, 0, 0); return x; };

function KPIs() {
  const s = Store.useStore();
  const { tasks, members, categories, risks, milestones } = s;

  const byCat = React.useMemo(() => {
    const map = new Map();
    categories.forEach((c) => map.set(c.id, { ...c, count: 0, days: 0, done: 0, inprogress: 0 }));
    map.set("__none", { id: "__none", label: "Uncategorised", color: "indigo", count: 0, days: 0, done: 0, inprogress: 0 });
    tasks.forEach((t) => {
      const k = t.category || "__none";
      const row = map.get(k); if (!row) return;
      row.count++;
      if (t.status === "done") row.done++;
      if (t.status === "inprogress") row.inprogress++;
      if (t.start && t.end) row.days += Math.max(1, Math.round((new Date(t.end) - new Date(t.start)) / KPI_DAY_MS));
    });
    return [...map.values()].filter((r) => r.count > 0).sort((a, b) => b.days - a.days);
  }, [tasks, categories]);

  const byPerson = React.useMemo(() => {
    const map = new Map();
    (members || []).forEach((m) => map.set(m.name, { name: m.name, color: m.color || "indigo", role: m.role, count: 0, days: 0, done: 0, inprogress: 0 }));
    tasks.forEach((t) => {
      const who = assigneesOf(t);
      const dur = (t.start && t.end) ? Math.max(1, Math.round((new Date(t.end) - new Date(t.start)) / KPI_DAY_MS)) : 0;
      who.forEach((name) => {
        if (!map.has(name)) map.set(name, { name, color: "indigo", role: "", count: 0, days: 0, done: 0, inprogress: 0 });
        const row = map.get(name);
        row.count++;
        if (t.status === "done") row.done++;
        if (t.status === "inprogress") row.inprogress++;
        row.days += dur;
      });
    });
    if (map.size === 0) return [];
    return [...map.values()].filter((r) => r.count > 0).sort((a, b) => b.days - a.days);
  }, [tasks, members]);

  const byWeek = React.useMemo(() => {
    const dated = tasks.filter((t) => t.start && t.end);
    const now = new Date();
    const currentStart = kpiStartOfWeek(now);
    const offsets = [-1, 0, 1, 2];
    const labels = { [-1]: "Last week", 0: "Current week", 1: "Next week", 2: "In 2 weeks" };
    const tones = { [-1]: "last", 0: "current", 1: "next", 2: "in2" };
    return offsets.map((off) => {
      const wkStart = new Date(+currentStart + off * 7 * KPI_DAY_MS);
      const wkEnd = new Date(+wkStart + 7 * KPI_DAY_MS);
      const active = dated.filter((t) => new Date(t.start) < wkEnd && new Date(t.end) >= wkStart);
      return {
        key: off, label: labels[off], tone: tones[off],
        range: wkStart.toLocaleDateString("en-GB", { day: "numeric", month: "short" }) + " – " + new Date(+wkEnd - KPI_DAY_MS).toLocaleDateString("en-GB", { day: "numeric", month: "short" }),
        load: active.length,
        done: active.filter((t) => t.status === "done").length,
        inprog: active.filter((t) => t.status === "inprogress").length,
        backlog: active.filter((t) => t.status === "backlog").length,
      };
    });
  }, [tasks]);

  const overview = React.useMemo(() => {
    const total = tasks.length;
    const done = tasks.filter((t) => t.status === "done").length;
    const inprog = tasks.filter((t) => t.status === "inprogress").length;
    const backlog = tasks.filter((t) => t.status === "backlog").length;
    const completionPct = total ? Math.round(done / total * 100) : 0;
    const openRisks = risks.filter((r) => r.status !== "closed").length;
    const highRisks = risks.filter((r) => r.status !== "closed" && r.likelihood === "high" && r.impact === "high").length;
    const now = Date.now();
    const upcomingMs = (milestones || []).filter((m) => m.date && +new Date(m.date) >= now).sort((a, b) => +new Date(a.date) - +new Date(b.date)).slice(0, 4);
    return { total, done, inprog, backlog, completionPct, openRisks, highRisks, upcomingMs };
  }, [tasks, risks, milestones]);

  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <p className="muted" style={{ margin: "0 0 22px", maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
          Live indicators on how the project is tracking — workload distribution, completion, and risk exposure. Everything updates as you edit tasks and risks.
        </p>

        <div className="kpi-tiles kpi-tiles-big">
          <KpiTile label="Completion" big={overview.completionPct + "%"} sub={`${overview.done} of ${overview.total} tasks done`} accent="green" />
          <KpiTile label="In progress" big={String(overview.inprog)} sub={`${overview.backlog} still in backlog`} accent="blue" />
          <KpiTile label="Open risks" big={String(overview.openRisks)} sub={overview.highRisks ? `${overview.highRisks} high-impact` : "none high-impact"} accent={overview.highRisks ? "red" : "amber"} />
        </div>

        <section className="kpi-section">
          <div className="kpi-section-hd">
            <h2 className="kpi-h serif">Workload per week</h2>
            <span className="muted" style={{ fontSize: 13 }}>Tasks active in each week.</span>
          </div>
          {(() => {
            const maxLoad = Math.max(1, ...byWeek.map((w) => w.load));
            return (
              <div className="kpi-weekchart panel">
                <div className="kpi-weekchart-bars">
                  {byWeek.map((w) => (
                    <div key={w.key} className="kpi-weekbar-col">
                      <div className="kpi-weekbar-n mono">{w.load}</div>
                      <div className="kpi-weekbar-track">
                        <div className={"kpi-weekbar-fill " + w.tone} style={{ height: (w.load / maxLoad * 100) + "%" }} />
                      </div>
                      <div className="kpi-weekbar-label">{w.label}</div>
                      <div className="kpi-weekbar-range mono">{w.range}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </section>

        <div className="kpi-cols">
          <section className="kpi-section">
            <div className="kpi-section-hd">
              <h2 className="kpi-h serif">Workload per category</h2>
              <span className="muted" style={{ fontSize: 13 }}>Planned effort by theme.</span>
            </div>
            {byCat.length === 0 ? (
              <div className="empty" style={{ padding: 20 }}>No categorised tasks yet.</div>
            ) : (
              <div className="kpi-bars panel">
                {byCat.map((c) => {
                  const maxDays = Math.max(...byCat.map((x) => x.days), 1);
                  const pct = (c.days / maxDays) * 100;
                  const donePct = c.count ? (c.done / c.count) * 100 : 0;
                  return (
                    <div key={c.id} className="kpi-bar-row">
                      <div className="kpi-bar-name"><span className="kcol-dot" style={{ background: "var(--t-" + c.color + ")" }} />{c.label}</div>
                      <div className="kpi-bar-track">
                        <div className="kpi-bar-fill" style={{ width: pct + "%", background: "var(--t-" + c.color + ")" }} />
                        <div className="kpi-bar-done" style={{ width: pct * donePct / 100 + "%" }} />
                      </div>
                      <div className="kpi-bar-stats mono">
                        <b>{c.days}d</b> · {c.count} task{c.count === 1 ? "" : "s"}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          <section className="kpi-section">
            <div className="kpi-section-hd">
              <h2 className="kpi-h serif">Workload per person</h2>
              <span className="muted" style={{ fontSize: 13 }}>Days of work assigned, sorted by load.</span>
            </div>
            {byPerson.length === 0 ? (
              <div className="empty" style={{ padding: 20 }}>No one is assigned to tasks yet.</div>
            ) : (
              <div className="kpi-bars panel">
                {byPerson.map((p) => {
                  const maxDays = Math.max(...byPerson.map((x) => x.days), 1);
                  const pct = (p.days / maxDays) * 100;
                  return (
                    <div key={p.name} className="kpi-bar-row">
                      <div className="kpi-bar-name"><span className="avatar" style={{ width: 22, height: 22, fontSize: 10, background: "var(--t-" + (p.color || "indigo") + ")" }}>{initials(p.name)}</span>{p.name}</div>
                      <div className="kpi-bar-track">
                        <div className="kpi-bar-fill" style={{ width: pct + "%", background: "var(--t-" + (p.color || "indigo") + ")" }} />
                      </div>
                      <div className="kpi-bar-stats mono">
                        <b>{p.days}d</b> · {p.count} task{p.count === 1 ? "" : "s"}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>

        {overview.upcomingMs.length > 0 && (
          <section className="kpi-section">
            <div className="kpi-section-hd">
              <h2 className="kpi-h serif">Upcoming milestones &amp; gates</h2>
              <span className="muted" style={{ fontSize: 13 }}>Next four checkpoints.</span>
            </div>
            <div className="kpi-ms-list panel">
              {overview.upcomingMs.map((m) => {
                const cat = categories.find((c) => c.id === m.category);
                const days = Math.ceil((+new Date(m.date) - Date.now()) / KPI_DAY_MS);
                return (
                  <div key={m.id} className={"kpi-ms " + m.type}>
                    <span className={m.type === "gate" ? "ms-gate-icon" : "ms-mile-icon"}>{m.type === "gate" ? "┃" : "◆"}</span>
                    <div className="grow">
                      <div className="kpi-ms-title">{m.title}</div>
                      {cat && <div className="muted" style={{ fontSize: 12 }}>{cat.label}</div>}
                    </div>
                    <div className="kpi-ms-when mono">
                      <div className="kpi-ms-days">{days === 0 ? "today" : days > 0 ? `in ${days}d` : `${-days}d ago`}</div>
                      <div className="muted" style={{ fontSize: 11 }}>{new Date(m.date).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function KpiTile({ label, big, sub, accent }) {
  return (
    <div className={"kpi-tile accent-" + (accent || "indigo")}>
      <div className="kpi-tile-label">{label}</div>
      <div className="kpi-tile-big serif">{big}</div>
      <div className="kpi-tile-sub">{sub}</div>
    </div>
  );
}

Object.assign(window, { KPIs, KpiTile });

function NudgeCenter({ who, onOpen, onClose }) {
  const s = Store.useStore();
  const cfg = Store.nudgeConfig();
  const nudges = Store.computeNudges(who);
  const [showSettings, setShowSettings] = React.useState(false);
  const [pushing, setPushing] = React.useState(null); // nudge id in "push start" mode
  const dueLabel = (n) => n.days < 0 ? Math.abs(n.days) + "d overdue" : n.days === 0 ? "today" : "in " + n.days + "d";
  return (
    <div className="scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="nudge-panel">
        <div className="nudge-hd">
          <div><div className="nudge-title">Reminders</div><div className="nudge-sub">{who ? "For " + who : "Across the project"}</div></div>
          <button className="btn btn-icon btn-ghost" onClick={() => setShowSettings((v) => !v)} title="Reminder settings"><Icon name="settings" size={16} /></button>
          <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" size={16} /></button>
        </div>
        {showSettings && (
          <div className="nudge-settings">
            <label className="nudge-set-row"><span>Remind me before a task starts</span><select value={cfg.leadStart} onChange={(e) => Store.setNudgeConfig({ leadStart: +e.target.value })}><option value={0}>on the day</option><option value={1}>1 day</option><option value={2}>2 days</option><option value={3}>3 days</option><option value={7}>1 week</option></select></label>
            <label className="nudge-set-row"><span>Remind me before a deadline</span><select value={cfg.leadDue} onChange={(e) => Store.setNudgeConfig({ leadDue: +e.target.value })}><option value={1}>1 day</option><option value={2}>2 days</option><option value={3}>3 days</option><option value={7}>1 week</option></select></label>
            <label className="nudge-set-row nudge-toggle"><span>Auto-move tasks to <b>In progress</b> on their start date</span><input type="checkbox" checked={!!cfg.autoStart} onChange={(e) => { Store.setNudgeConfig({ autoStart: e.target.checked }); if (e.target.checked) Store.sweepNudges(); }} /></label>
          </div>
        )}
        <div className="nudge-list">
          {nudges.length === 0 && <div className="nudge-empty"><Icon name="check" size={22} /><div>You're all caught up.</div><span>No tasks starting or due in the reminder window.</span></div>}
          {nudges.map((n) => (
            <div key={n.id} className={"nudge-item nudge-" + n.kind}>
              <span className={"nudge-ico nudge-ico-" + n.kind}><Icon name={n.kind === "start" ? "board" : "clock"} size={15} /></span>
              <div className="nudge-body">
                <div className="nudge-item-title" onClick={() => onOpen(n.taskId)}>{n.title}</div>
                {n.kind === "start" ? (
                  <div className="nudge-msg">Starts <b>{dueLabel(n)}</b>{n.owner ? " · " + n.owner : ""}. Ready to begin?</div>
                ) : (
                  <div className="nudge-msg">Due <b className={n.days < 0 ? "over" : ""}>{dueLabel(n)}</b>{n.owner ? " · " + n.owner : ""}. Is this complete or nearly there?</div>
                )}
                <div className="nudge-actions">
                  {n.kind === "start" ? (
                    pushing === n.id ? (
                      <div className="nudge-push">
                        <span className="nudge-push-label">Push start by</span>
                        {[2, 3, 5, 7].map((d) => (
                          <button key={d} className="nudge-btn" onClick={() => { Store.pushTaskStart(n.taskId, d); Store.nudgeAct(n.id, "acted"); setPushing(null); }}>{d}d</button>
                        ))}
                        <button className="nudge-btn ghost" onClick={() => setPushing(null)}>Cancel</button>
                      </div>
                    ) : (
                      <React.Fragment>
                        <button className="nudge-btn primary" onClick={() => { Store.patch("tasks", n.taskId, { status: "inprogress" }); Store.nudgeAct(n.id, "acted"); }}>Start now</button>
                        <button className="nudge-btn" onClick={() => setPushing(n.id)} title="Not starting yet — push the start date (dependent tasks move too)">Not yet…</button>
                        <button className="nudge-btn ghost" onClick={() => Store.nudgeAct(n.id, "snooze", 2)} title="Remind me in 2 days">Snooze</button>
                      </React.Fragment>
                    )
                  ) : (
                    <React.Fragment>
                      <button className="nudge-btn primary" onClick={() => { Store.patch("tasks", n.taskId, { status: "done" }); Store.nudgeAct(n.id, "acted"); }}>Mark done</button>
                      <button className="nudge-btn" onClick={() => { const c = (Store.getState().tasks.find((t) => t.id === n.taskId) || {}).comments || []; Store.patch("tasks", n.taskId, { comments: [...c, { id: Store.uid("cmt"), author: "You", color: "amber", text: "Nearly complete — on track for the deadline.", ts: Date.now() }] }); Store.nudgeAct(n.id, "acted"); }}>Near complete</button>
                      <button className="nudge-btn ghost" onClick={() => Store.nudgeAct(n.id, "snooze", 2)} title="Remind me in 2 days">Snooze</button>
                      <button className="nudge-btn ghost" onClick={() => Store.nudgeAct(n.id, "dismissed")}>Dismiss</button>
                    </React.Fragment>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function App() {
  const root = Store.useRoot();
  const [view, setView] = useApp(() => location.hash.slice(1) || "home");
  const [showSync, setShowSync] = useApp(false);
  const [showSections, setShowSections] = useApp(false);
  const [showReport, setShowReport] = useApp(false);
  const [showSuggest, setShowSuggest] = useApp(false);
  const [showNudges, setShowNudges] = useApp(false);
  const [navFavs, setNavFavs] = useApp(() => { try { return JSON.parse(localStorage.getItem("atlas.nav.favs") || "[]"); } catch (e) { return []; } });
  const [navClosed, setNavClosed] = useApp(() => { try { return JSON.parse(localStorage.getItem("atlas.nav.closed") || "[]"); } catch (e) { return []; } });
  const [navOpen, setNavOpen] = useApp(() => { try { return JSON.parse(localStorage.getItem("atlas.nav.open") || "[]"); } catch (e) { return []; } });
  const toggleFav = (id) => setNavFavs((prev) => { const n = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]; try { localStorage.setItem("atlas.nav.favs", JSON.stringify(n)); } catch (e) {} return n; });
  // stay in sync when the AI engine (or another surface) changes favourites
  React.useEffect(() => {
    const h = (e) => setNavFavs(Array.isArray(e.detail) ? e.detail : []);
    window.addEventListener("atlas:navfavs", h);
    return () => window.removeEventListener("atlas:navfavs", h);
  }, []);
  const toggleGroup = (g) => setNavOpen((prev) => { const n = prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]; try { localStorage.setItem("atlas.nav.open", JSON.stringify(n)); } catch (e) {} return n; });
  React.useEffect(() => {
    const h = () => setView(location.hash.slice(1) || "home");
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  React.useEffect(() => {if (window.initSync) window.initSync();}, []);
  React.useEffect(() => {if (window.setupGlossaryHighlighter) window.setupGlossaryHighlighter();}, []);
  React.useEffect(() => { if (root.activeId) Store.sweepAutomations(); }, [root.activeId]);
  React.useEffect(() => { if (root.activeId) Store.sweepNudges(); }, [root.activeId]);
  const go = (v) => {location.hash = v;setView(v);};

  const s = root.activeId ? Store.getState() : null;
  const nudgeWho = s ? (localStorage.getItem("atlas.view." + s.id) || null) : null;
  const nudgeCount = s ? Store.computeNudges(nudgeWho).length : 0;
  const enabledSections = (s && Array.isArray(s._enabledSections)) ? s._enabledSections : DEFAULT_ON;
  const isSectionOn = (id) => !TOGGLEABLE[id] || enabledSections.includes(id);

  // if current view is toggled off, redirect home
  React.useEffect(() => {
    if (s && TOGGLEABLE[view] && !isSectionOn(view)) go("home");
  }, [enabledSections, view, !!s]);

  // top-level: no active project, or explicit projects route → landing
  if (!root.activeId || view === "projects" || !s) {
    return <ProjectsHome />;
  }

  const [title, sub] = TITLES[view] || ["", ""];
  const parent = s.parentId ? root.projects.find((p) => p.id === s.parentId) : null;
  const sgCount = Store.smartSuggestions(s).length;

  const toggleSection = (id) => {
    const next = enabledSections.includes(id) ? enabledSections.filter((x) => x !== id) : [...enabledSections, id];
    Store.setState((st) => ({ ...st, _enabledSections: next }));
  };

  const Views = {
    home: window.Dashboard, business: window.BusinessCase,
    workspace: window.Workspace,
    actions: window.Actions, catalogue: window.Catalogue, members: window.Members, stakeholders: window.Members,
    forecast: window.Forecast,
    org: window.OrgChart, preanalysis: window.PreAnalysis, risks: window.Risks, scope: window.ScopePage,
    comms: window.CommPlan, change: window.ChangePlan, glossary: window.Glossary, kpis: window.KPIs,
    capacity: window.Capacity, aiimport: window.AIImport, audit: window.AuditTrail,
    financials: window.Financials,
    mission: window.MissionVision, valueprop: window.ValueProp, bmc: window.BMC, lean: window.LeanCanvas,
    market: window.MarketCompetition, personas: window.Personas, gtm: window.GoToMarket,
    features: window.FeatureSuite
  };
  const Current = Views[view] || (() => <div className="view-pad">Not found</div>);
  // company-style overview for start-up projects; classic business case otherwise
  const ResolvedCurrent = (view === "business" && s && s.startupKit) ? window.CompanyOverview : Current;

  return (
    <div className="app">
      <aside className="sidebar no-print">
        <button className="proj-switch" onClick={() => { Store.projects.close(); go("projects"); }}>
          <span className="proj-switch-mark" style={{ background: "var(--t-" + (s.color || "indigo") + ")" }}>{(s.meta?.project || "P")[0]}</span>
          <span className="proj-switch-text">
            <span className="proj-switch-name">{s.meta?.project}</span>
            <span className="proj-switch-code mono">{parent ? "↗ " + parent.meta?.project : "View portfolio"}</span>
          </span>
          <span className="proj-switch-ico"><Icon name="chevD" size={15} /></span>
        </button>
        <button className="all-proj no-print" onClick={() => { Store.projects.close(); go("projects"); }}><Icon name="layers" size={14} /> All projects</button>

        {(() => {
          const allItems = NAV.flatMap((grp) => grp.items.filter((it) => isSectionOn(it.id)).map((it) => ({ ...it, group: grp.group })));
          const favItems = navFavs.map((id) => allItems.find((it) => it.id === id)).filter(Boolean);
          const renderItem = (it, showStar) => (
            <button key={it.id} className={"nav-item" + (view === it.id ? " active" : "")} onClick={() => go(it.id)}>
              <Icon name={it.icon} />
              <span className="grow" style={{ textAlign: "left" }}>{it.label}</span>
              {it.count && <span className="nav-count">{it.count(s)}</span>}
              <span className={"nav-star" + (navFavs.includes(it.id) ? " on" : "")} title={navFavs.includes(it.id) ? "Unpin" : "Pin to favourites"} onClick={(e) => { e.stopPropagation(); toggleFav(it.id); }}><Icon name={navFavs.includes(it.id) ? "star-fill" : "star"} size={13} /></span>
            </button>
          );
          return (
            <React.Fragment>
              {favItems.length > 0 && (
                <div className="nav-group">
                  <div className="nav-label">Favourites</div>
                  {favItems.map((it) => renderItem(it, true))}
                </div>
              )}
              {NAV.map((grp) => {
                const visibleItems = grp.items.filter((it) => isSectionOn(it.id) && !navFavs.includes(it.id));
                if (!visibleItems.length) return null;
                const activeInside = visibleItems.some((it) => it.id === view);
                const collapsed = !navOpen.includes(grp.group) && !activeInside;
                return (
                  <div className={"nav-group" + (collapsed ? " nav-collapsed" : "")} key={grp.group}>
                    <button className="nav-label nav-label-btn" onClick={() => toggleGroup(grp.group)}>
                      <Icon name="chevD" size={13} style={{ transform: collapsed ? "rotate(-90deg)" : "none" }} />
                      <span className="grow" style={{ textAlign: "left" }}>{grp.group}</span>
                    </button>
                    {!collapsed && visibleItems.map((it) => renderItem(it, false))}
                  </div>
                );
              })}
            </React.Fragment>
          );
        })()}
        <div className="sidebar-foot">
          <button className="sync-badge" onClick={() => setShowSections(true)}>
            <span className="sync-dot" style={{ background: "var(--accent)" }} />
            <span className="grow" style={{ textAlign: "left" }}>add or remove
sections</span>
            <Icon name="layers" size={13} />
          </button>
          <SyncBadge onClick={() => setShowSync(true)} />
        </div>
      </aside>

      <main className="main">
        <header className="topbar no-print">
          <h1>{title}</h1>
          <span className="topbar-sub">{sub}</span>
          <div className="topbar-actions">
            <button className={"btn btn-icon nudge-bell" + (nudgeCount > 0 ? " has" : "")} onClick={() => setShowNudges(true)} title="Reminders"><Icon name="bell" size={16} />{nudgeCount > 0 && <span className="nudge-bell-badge">{nudgeCount}</span>}</button>
            {sgCount > 0 && <button className="btn btn-suggest" onClick={() => setShowSuggest(true)} title="Smart suggestions based on your dates"><Icon name="idea" size={15} /> Suggestions <span className="suggest-badge">{sgCount}</span></button>}
            <button className="btn" onClick={() => setShowReport(true)} title="Auto-composed status report"><Icon name="doc" size={15} /> Status report</button>
            <button className="btn" onClick={() => window.print()} title="Print this view to PDF"><Icon name="print" size={15} /> Print / PDF</button>
          </div>
        </header>
        <div className="print-head print-only">
          <div className="print-head-l">
            <span className="print-brand">Atlas</span>
            <span className="print-proj">{parent ? parent.meta?.project + " / " : ""}{s.meta?.project}</span>
          </div>
          <div className="print-head-r">
            <span className="print-view">{title}</span>
            <span className="print-date">{new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</span>
          </div>
        </div>
        <ResolvedCurrent go={go} />
      </main>
      <SyncToast />
      {showSync && <SyncPanel onClose={() => setShowSync(false)} />}
      {showSections && <SectionsModal enabled={enabledSections} onToggle={toggleSection} onClose={() => setShowSections(false)} />}
      {showReport && <StatusReport onClose={() => setShowReport(false)} />}
      {showSuggest && <SuggestionsPanel onClose={() => setShowSuggest(false)} />}
      {showNudges && <NudgeCenter who={nudgeWho} onOpen={(tid) => { setShowNudges(false); go("actions"); }} onClose={() => setShowNudges(false)} />}
    </div>);
}

function SectionsModal({ enabled, onToggle, onClose }) {
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>Customise sections</div>
          <div className="muted" style={{ fontSize: 13 }}>Turn off sections that aren't relevant to this project. They stay hidden from the sidebar — turn them back on any time.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="sections-list">
          {Object.entries(TOGGLEABLE).map(([id, label]) => {
            const on = enabled.includes(id);
            return (
              <label key={id} className={"section-toggle" + (on ? " on" : "")}>
                <input type="checkbox" checked={on} onChange={() => onToggle(id)} />
                <Icon name={NAV.flatMap((g) => g.items).find((i) => i.id === id)?.icon || "doc"} size={16} />
                <span className="grow">{label}</span>
                {!on && <span className="section-off-label">Hidden</span>}
              </label>);

          })}
        </div>
      </div>
      <div className="modal-ft">
        <span className="muted" style={{ fontSize: 12 }}>Changes apply immediately to this project only.</span>
        <div className="grow" />
        <button className="btn btn-primary" onClick={onClose}>Done</button>
      </div>
    </UI.Modal>);

}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
