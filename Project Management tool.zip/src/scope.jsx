/* ============================================================
   SCOPE — boundaries + shared As-is/To-be assessment
   Exposes window.ScopePage, window.ScopeBoundaries,
           window.AssessmentTable, window.RisksEmbed
   ============================================================ */
const { useState: useSc } = React;

/* ---------- scope boundaries (in / out) ---------- */
function ScopeBoundaries({ compact }) {
  const s = Store.useStore();
  const scope = s.scope || { inScope: [], outScope: [] };
  const setScope = (c) => Store.setState((st) => ({ ...st, scope: { ...(st.scope || { inScope: [], outScope: [] }), ...c } }));
  const addItem = (key) => setScope({ [key]: [...(scope[key] || []), "New item"] });
  const setItem = (key, i, v) => setScope({ [key]: scope[key].map((x, idx) => (idx === i ? v : x)) });
  const rmItem = (key, i) => setScope({ [key]: scope[key].filter((_, idx) => idx !== i) });

  const Col = ({ side, label, icon, items }) => (
    <div className={"scope-col " + side}>
      <div className="scope-col-hd">
        <span className="scope-col-ico"><Icon name={icon} size={15} /></span>
        <span className="scope-col-label">{label}</span>
        <span className="scope-col-n mono">{items.length}</span>
      </div>
      <div className="scope-items">
        {items.length === 0 && <div className="scope-empty">Nothing listed yet.</div>}
        {items.map((it, i) => (
          <div className="scope-item" key={i}>
            <span className="scope-bullet" />
            <UI.Editable className="scope-item-text" tag="div" multiline value={it} onChange={(v) => setItem(side === "in" ? "inScope" : "outScope", i, v)} placeholder="Describe a boundary item…" />
            <button className="chip-x no-print" onClick={() => rmItem(side === "in" ? "inScope" : "outScope", i)}><Icon name="x" size={12} /></button>
          </div>
        ))}
        <button className="scope-add no-print" onClick={() => addItem(side === "in" ? "inScope" : "outScope")}><Icon name="plus" size={13} /> Add</button>
      </div>
    </div>
  );

  return (
    <div className={"scope-grid" + (compact ? " compact" : "")}>
      <Col side="in" label="In scope" icon="check" items={scope.inScope || []} />
      <Col side="out" label="Out of scope" icon="x" items={scope.outScope || []} />
    </div>
  );
}

/* ---------- shared As-is / To-be assessment ---------- */
function AssessmentTable({ mode = "full", title }) {
  const s = Store.useStore();
  const rows = s.assessment || [];
  const setRows = (fn) => Store.setState((st) => ({ ...st, assessment: fn(st.assessment || []) }));
  const add = () => setRows((r) => [...r, { id: Store.uid("as"), area: "New area", asIs: "", toBe: "" }]);
  const patch = (id, c) => setRows((r) => r.map((x) => (x.id === id ? { ...x, ...c } : x)));
  const rm = (id) => setRows((r) => r.filter((x) => x.id !== id));
  const full = mode === "full";

  return (
    <div className="asis">
      <div className={"asis-head" + (full ? " full" : "")}>
        <div className="asis-h">Area</div>
        <div className="asis-h">As-is <span className="asis-h-sub">today</span></div>
        {full && <div className="asis-h tobe">To-be <span className="asis-h-sub">target</span></div>}
        <div />
      </div>
      {rows.length === 0 && <div className="asis-empty">No assessment areas yet. Add the dimensions you want to compare current vs. target state.</div>}
      {rows.map((row) => (
        <div className={"asis-row" + (full ? " full" : "")} key={row.id}>
          <div className="asis-area">
            <span className="asis-area-bar" />
            <UI.Editable className="asis-area-text" tag="div" multiline value={row.area} onChange={(v) => patch(row.id, { area: v || "Area" })} placeholder="Area" />
          </div>
          <UI.Editable className="asis-cell asis-cell-now" tag="div" multiline value={row.asIs} onChange={(v) => patch(row.id, { asIs: v })} placeholder="How is it today?" />
          {full && (
            <div className="asis-cell-wrap">
              <span className="asis-arrow no-print"><Icon name="arrowR" size={14} /></span>
              <UI.Editable className="asis-cell asis-cell-tobe" tag="div" multiline value={row.toBe} onChange={(v) => patch(row.id, { toBe: v })} placeholder="What should it become?" />
            </div>
          )}
          <button className="chip-x asis-del no-print" onClick={() => rm(row.id)}><Icon name="trash" size={13} /></button>
        </div>
      ))}
      <button className="btn btn-sm btn-ghost no-print" style={{ marginTop: 10 }} onClick={add}><Icon name="plus" size={13} /> Add area</button>
    </div>
  );
}

/* ---------- risks embedded read-only (for business case) ---------- */
function RisksEmbed({ go }) {
  const { risks, tasks } = Store.useStore();
  const sorted = [...risks].sort((a, b) => LVL[b.likelihood] * LVL[b.impact] - LVL[a.likelihood] * LVL[a.impact]);
  if (!risks.length) return <p className="bc-body muted">No risks captured yet. Add them on the Risks & mitigation page and they'll appear here.</p>;
  return (
    <div className="bc-risks">
      {sorted.map((r) => {
        const rem = remediation(r, tasks);
        return (
          <div key={r.id} className="bc-risk">
            <span className="risk-score sm" style={{ background: scoreColor(r.likelihood, r.impact) }}>{LVL[r.likelihood] * LVL[r.impact]}</span>
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="bc-risk-title">{r.title}</div>
              <div className="bc-risk-mit">{r.mitigation || "No mitigation recorded."}</div>
            </div>
            <div className="bc-risk-meta">
              <span className="chip" style={{ "--chip-c": RISK_STATUS[r.status]?.c }}><span className="chip-dot" />{RISK_STATUS[r.status]?.label}</span>
              {rem.state !== "none" && <span className="mono" style={{ fontSize: 10.5, color: REMED[rem.state].c }}>{REMED[rem.state].label}</span>}
            </div>
          </div>
        );
      })}
      {go && <button className="btn btn-sm no-print" style={{ marginTop: 12 }} onClick={() => go("risks")}><Icon name="shield" size={14} /> Manage risks</button>}
    </div>
  );
}

/* ---------- Scope page ---------- */
function ScopePage({ go }) {
  return (
    <div className="view-scroll">
      <div className="view-pad view-wide">
        <p className="muted" style={{ margin: "0 0 22px", maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
          Define the boundary of the work, then map where things are today (<b>as-is</b>) against where they need to be (<b>to-be</b>). This drives the business case and keeps the team aligned on what's in and out.
        </p>

        <section className="scope-section">
          <div className="scope-section-hd">
            <h2 className="scope-h serif">Boundaries</h2>
            <span className="muted" style={{ fontSize: 13 }}>What's inside the project, and what's explicitly not.</span>
          </div>
          <ScopeBoundaries />
        </section>

        <section className="scope-section">
          <div className="scope-section-hd">
            <h2 className="scope-h serif">As-is / To-be assessment</h2>
            <span className="muted" style={{ fontSize: 13 }}>Shared with Pre-analysis (as-is) and the Business case.</span>
          </div>
          <AssessmentTable mode="full" />
        </section>
      </div>
    </div>
  );
}

Object.assign(window, { ScopePage, ScopeBoundaries, AssessmentTable, RisksEmbed });
