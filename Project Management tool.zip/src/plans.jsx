/* ============================================================
   PLANS — Communication plan + Change management plan
   Exposes window.CommPlan, window.ChangePlan
   ============================================================ */
const { useState: usePl } = React;

/* shared: editable bulleted cell (array of strings) */
function BulletCell({ items, onChange, placeholder = "Add…", accent }) {
  const list = items || [];
  const set = (i, v) => onChange(list.map((x, idx) => (idx === i ? v : x)));
  const add = () => onChange([...list, ""]);
  const rm = (i) => onChange(list.filter((_, idx) => idx !== i));
  return (
    <div className="bullets">
      {list.map((it, i) => (
        <div className="bullet-row" key={i}>
          <span className="bullet-dot" style={accent ? { background: accent } : null} />
          <UI.Editable className="bullet-text" tag="div" multiline value={it} onChange={(v) => set(i, v)} placeholder={placeholder} />
          <button className="chip-x no-print" onClick={() => rm(i)}><Icon name="x" size={11} /></button>
        </div>
      ))}
      <button className="bullet-add no-print" onClick={add}><Icon name="plus" size={12} /> Add</button>
    </div>
  );
}

/* ============================================================
   COMMUNICATION PLAN
   ============================================================ */
const COMM_COLS = [
  { key: "audience", label: "Audience", w: "120px", kind: "text" },
  { key: "purpose", label: "Purpose of communication", w: "1.3fr", kind: "text" },
  { key: "messages", label: "Key messages", w: "2fr", kind: "bullets" },
  { key: "channels", label: "Channel(s)", w: "120px", kind: "bullets" },
  { key: "timing", label: "Timing", w: "190px", kind: "text" },
  { key: "owner", label: "Owner", w: "100px", kind: "text" },
  { key: "deliverables", label: "Deliverables", w: "1.5fr", kind: "bullets" },
];

function CommPlan() {
  const { commPlan, tasks } = Store.useStore();
  const [del, setDel] = usePl(null);
  const rows = commPlan || [];
  const cols = COMM_COLS.map((c) => c.w).join(" ") + " 78px";

  const addRow = () => Store.setState((st) => ({ ...st, commPlan: [...(st.commPlan || []), { id: Store.uid("cm"), audience: "New audience", purpose: "", messages: [], channels: [], timing: "", owner: "", deliverables: [] }] }));
  const patch = (id, c) => Store.setState((st) => ({ ...st, commPlan: st.commPlan.map((r) => (r.id === id ? { ...r, ...c } : r)) }));
  const remove = (id) => Store.setState((st) => ({ ...st, commPlan: st.commPlan.filter((r) => r.id !== id) }));
  const linkedTask = (rid) => (tasks || []).find((t) => t.sourceId === rid && t.origin === "comms");
  const toAction = (r) => {
    if (linkedTask(r.id)) return;
    Store.add("tasks", { id: Store.uid("t"), title: "Comms: " + (r.audience || "audience"), status: "backlog", tags: [], priority: "med", assignees: r.owner ? [r.owner] : [], desc: r.purpose || "", phase: null, category: null, origin: "comms", sourceId: r.id, start: r.date || "", end: r.date || "", deps: [] });
  };

  return (
    <div className="view-scroll">
      <div className="view-pad">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
            Who needs to hear what, through which channel and when — and who owns each message. One row per audience.
          </p>
          <button className="btn btn-primary no-print" onClick={addRow}><Icon name="plus" size={15} /> Add audience</button>
        </div>

        <div className="plan-table">
          <div className="plan-head" style={{ gridTemplateColumns: cols }}>
            {COMM_COLS.map((c) => <div key={c.key}>{c.label}</div>)}
            <div />
          </div>
          {rows.length === 0 && <div className="plan-empty">No audiences yet. Add the first one to start the plan.</div>}
          {rows.map((r) => (
            <div className="plan-row" style={{ gridTemplateColumns: cols }} key={r.id}>
              {COMM_COLS.map((c) => (
                <div className={"plan-cell" + (c.key === "audience" ? " plan-cell-key" : "")} key={c.key}>
                  {c.kind === "bullets"
                    ? <BulletCell items={r[c.key]} onChange={(v) => patch(r.id, { [c.key]: v })} />
                    : c.key === "timing"
                      ? (<div className="comm-timing">
                          <UI.Editable className="plan-text" tag="div" multiline value={r.timing} onChange={(v) => patch(r.id, { timing: v })} placeholder="e.g. 2 weeks before go-live" />
                          <label className="comm-date no-print">
                            <Icon name="calendar" size={12} />
                            <input type="date" value={r.date || ""} onChange={(e) => patch(r.id, { date: e.target.value })} />
                          </label>
                          {r.date && <div className="comm-date-badge print-only">📅 {r.date}</div>}
                        </div>)
                      : <UI.Editable className="plan-text" tag="div" multiline value={r[c.key]} onChange={(v) => patch(r.id, { [c.key]: v })} placeholder="…" />}
                </div>
              ))}
              <div className="plan-row-actions no-print">
                {linkedTask(r.id)
                  ? <span className="plan-linked" title="Already in the action list"><Icon name="check" size={12} /> In actions</span>
                  : <button className="plan-toaction" title="Add this communication to the action list" onClick={() => toAction(r)}><Icon name="plus" size={12} /> Action</button>}
                <button className="chip-x plan-del" onClick={() => setDel(r.id)}><Icon name="trash" size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {del && <UI.Confirm title="Remove audience row?" body="This deletes the communication-plan row." onConfirm={() => remove(del)} onClose={() => setDel(null)} />}
    </div>
  );
}

/* ============================================================
   CHANGE MANAGEMENT PLAN — grouped tables
   ============================================================ */
const CHG_COLS = "150px 1.6fr 1.5fr 110px 78px";
const CHG_ACCENTS = ["indigo", "teal", "purple", "amber", "green", "blue", "pink", "red"];

function ChangePlan() {
  const { changePlan, tasks } = Store.useStore();
  const groups = (changePlan && changePlan.groups) || [];
  const [del, setDel] = usePl(null);
  const linkedTask = (rid) => (tasks || []).find((t) => t.sourceId === rid && t.origin === "change");
  const toAction = (r, groupLabel) => {
    if (linkedTask(r.id)) return;
    Store.add("tasks", { id: Store.uid("t"), title: r.component || "Change activity", status: "backlog", tags: [], priority: "med", assignees: r.owner ? [r.owner] : [], desc: r.description || "", phase: null, category: null, origin: "change", sourceId: r.id, start: "", end: "", deps: [] });
  };

  const setGroups = (fn) => Store.setState((st) => ({ ...st, changePlan: { ...(st.changePlan || {}), groups: fn((st.changePlan && st.changePlan.groups) || []) } }));
  const addGroup = () => setGroups((g) => [...g, { id: Store.uid("cg"), label: "New group", accent: CHG_ACCENTS[g.length % CHG_ACCENTS.length], rows: [{ id: Store.uid("cr"), component: "New component", description: "", deliverables: [], owner: "" }] }]);
  const patchGroup = (gid, c) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, ...c } : x)));
  const rmGroup = (gid) => setGroups((g) => g.filter((x) => x.id !== gid));
  const addRow = (gid) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, rows: [...x.rows, { id: Store.uid("cr"), component: "New component", description: "", deliverables: [], owner: "" }] } : x)));
  const patchRow = (gid, rid, c) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, rows: x.rows.map((r) => (r.id === rid ? { ...r, ...c } : r)) } : x)));
  const rmRow = (gid, rid) => setGroups((g) => g.map((x) => (x.id === gid ? { ...x, rows: x.rows.filter((r) => r.id !== rid) } : x)));

  return (
    <div className="view-scroll">
      <div className="view-pad">
        <div className="between" style={{ marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
          <p className="muted" style={{ margin: 0, maxWidth: 620, fontSize: 14, lineHeight: 1.55 }}>
            The activities that move people to the new way of working — grouped by audience. Each component has a description, deliverables and an owner.
          </p>
          <button className="btn btn-primary no-print" onClick={addGroup}><Icon name="plus" size={15} /> Add group</button>
        </div>

        {groups.length === 0 && <div className="empty"><div className="serif">No change groups yet</div>Add a group (e.g. a team or audience) to start the plan.</div>}

        {groups.map((g) => (
          <div className="chg-group" key={g.id} style={{ "--chg-c": "var(--t-" + (g.accent || "indigo") + ")" }}>
            <div className="chg-rail">
              <UI.Editable className="chg-rail-label" tag="div" multiline value={g.label} onChange={(v) => patchGroup(g.id, { label: v || "Group" })} placeholder="Group" />
              <div className="chg-rail-actions no-print">
                <button className="chg-rail-btn" title="Change colour" onClick={() => patchGroup(g.id, { accent: CHG_ACCENTS[(CHG_ACCENTS.indexOf(g.accent) + 1) % CHG_ACCENTS.length] })}><Icon name="tag" size={13} /></button>
                <button className="chg-rail-btn" title="Remove group" onClick={() => setDel({ type: "group", gid: g.id })}><Icon name="trash" size={13} /></button>
              </div>
            </div>
            <div className="chg-table">
              <div className="chg-head" style={{ gridTemplateColumns: CHG_COLS }}>
                <div>Component</div><div>Description</div><div>Deliverables</div><div>Owner</div><div />
              </div>
              {g.rows.map((r) => (
                <div className="chg-row" style={{ gridTemplateColumns: CHG_COLS }} key={r.id}>
                  <div className="plan-cell plan-cell-key"><UI.Editable className="plan-text" tag="div" multiline value={r.component} onChange={(v) => patchRow(g.id, r.id, { component: v })} placeholder="Component" /></div>
                  <div className="plan-cell"><UI.Editable className="plan-text" tag="div" multiline value={r.description} onChange={(v) => patchRow(g.id, r.id, { description: v })} placeholder="What is it?" /></div>
                  <div className="plan-cell"><BulletCell items={r.deliverables} onChange={(v) => patchRow(g.id, r.id, { deliverables: v })} accent={"var(--chg-c)"} /></div>
                  <div className="plan-cell"><UI.Editable className="plan-text" tag="div" multiline value={r.owner} onChange={(v) => patchRow(g.id, r.id, { owner: v })} placeholder="—" /></div>
                  <div className="plan-row-actions no-print">
                    {linkedTask(r.id)
                      ? <span className="plan-linked" title="Already in the action list"><Icon name="check" size={12} /> In actions</span>
                      : <button className="plan-toaction" title="Add this change activity to the action list" onClick={() => toAction(r, g.label)}><Icon name="plus" size={12} /> Action</button>}
                    <button className="chip-x plan-del" onClick={() => setDel({ type: "row", gid: g.id, rid: r.id })}><Icon name="trash" size={13} /></button>
                  </div>
                </div>
              ))}
              <button className="chg-addrow no-print" onClick={() => addRow(g.id)}><Icon name="plus" size={13} /> Add component</button>
            </div>
          </div>
        ))}
      </div>
      {del && <UI.Confirm title={del.type === "group" ? "Remove group?" : "Remove component?"} body={del.type === "group" ? "This deletes the group and all its components." : "This deletes the component row."} onConfirm={() => del.type === "group" ? rmGroup(del.gid) : rmRow(del.gid, del.rid)} onClose={() => setDel(null)} />}
    </div>
  );
}

Object.assign(window, { CommPlan, ChangePlan });
