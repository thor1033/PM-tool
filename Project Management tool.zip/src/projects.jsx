/* ============================================================
   PROJECTS LANDING — programs, subprojects, create, sync
   Exposes window.ProjectsHome
   ============================================================ */
const { useState: usePj, useRef: usePjR, useEffect: usePjE } = React;

const PRJ_COLORS = ["purple", "indigo", "blue", "teal", "green", "amber", "pink", "red"];

function projStats(p) {
  const tasks = p.tasks || [];
  const done = tasks.filter((t) => t.status === "done").length;
  const active = tasks.filter((t) => t.status === "inprogress").length;
  const openRisks = (p.risks || []).filter((r) => r.status !== "closed").length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  return { total: tasks.length, done, active, openRisks, pct };
}
function relTime(ts) {
  if (!ts) return "—";
  const d = Math.floor((Date.now() - ts) / 86400000);
  if (d <= 0) return "today";
  if (d === 1) return "yesterday";
  if (d < 30) return d + " days ago";
  return Math.floor(d / 30) + " mo ago";
}

function ProjectCard({ p, projects, onOpen, onDelete, sub }) {
  const s = projStats(p);
  const [menu, setMenu] = usePj(false);
  const ref = usePjR(null);
  usePjE(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setMenu(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  // candidate parents: any top-level project that isn't this one and isn't this one's child
  const childIds = new Set(projects.filter((x) => x.parentId === p.id).map((x) => x.id));
  const parents = projects.filter((x) => x.id !== p.id && !childIds.has(x.id) && !x.parentId);

  return (
    <article className={"pj-card" + (sub ? " sub" : "")} onClick={() => onOpen(p.id)}>
      <div className="pj-card-bar" style={{ background: "var(--t-" + (p.color || "indigo") + ")" }} />
      <div className="pj-card-top">
        <span className="pj-code mono">{relTime(p.createdAt) === "today" ? "New" : ""}</span>
        <div className="pj-card-actions no-print" ref={ref}>
          <button className="pj-menu-btn" title="Group / move" onClick={(e) => { e.stopPropagation(); setMenu((m) => !m); }}><Icon name="layers" size={14} /></button>
          <button className="pj-del" title="Delete project" onClick={(e) => { e.stopPropagation(); onDelete(p); }}><Icon name="trash" size={14} /></button>
          {menu && (
            <div className="tagpicker-menu panel" style={{ right: 0, left: "auto", minWidth: 210 }} onClick={(e) => e.stopPropagation()}>
              <div className="dep-menu-label">Group under a major project</div>
              {p.parentId && <button className="tagpicker-opt" onClick={() => { Store.projects.setParent(p.id, null); setMenu(false); }}><Icon name="x" size={13} /><span className="grow">Make top-level</span></button>}
              {parents.length === 0 && !p.parentId && <div className="dep-menu-empty">No other top-level projects to nest under yet.</div>}
              {parents.map((par) => (
                <button key={par.id} className={"tagpicker-opt" + (p.parentId === par.id ? " on" : "")} onClick={() => { Store.projects.setParent(p.id, par.id); setMenu(false); }}>
                  <span className="chip-dot" style={{ background: "var(--t-" + (par.color || "indigo") + ")" }} />
                  <span className="grow">{par.meta?.project}</span>
                  {p.parentId === par.id && <Icon name="check" size={14} />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      <h2 className="pj-name serif">{p.meta?.project}</h2>
      <div className="pj-progress">
        <div className="pj-progress-track"><div className="pj-progress-fill" style={{ width: s.pct + "%", background: "var(--t-" + (p.color || "indigo") + ")" }} /></div>
        <span className="pj-progress-pct mono">{s.pct}%</span>
      </div>
      <div className="pj-statline">
        <span><b>{s.active}</b> active</span><span className="pj-dot-sep" />
        <span><b>{s.total}</b> tasks</span><span className="pj-dot-sep" />
        <span className={s.openRisks ? "pj-risk" : ""}><b>{s.openRisks}</b> risks</span>
      </div>
      <div className="pj-card-foot">
        <div className="pj-faces">
          {[...new Set((p.tasks || []).filter((t) => t.status === "inprogress").flatMap((t) => assigneesOf(t)))].slice(0, 4).map((n, i) => (
            <span key={i} className="avatar pj-face" style={{ background: "var(--t-" + PRJ_COLORS[i % PRJ_COLORS.length] + ")" }} title={n}>{initials(n)}</span>
          ))}
          {s.active === 0 && <span className="muted" style={{ fontSize: 12 }}>No one assigned yet</span>}
        </div>
        <span className="pj-updated muted">Updated {relTime(p.updatedAt)}</span>
      </div>
      <span className="pj-open">Open <Icon name="arrowR" size={14} /></span>
    </article>
  );
}

function ProjectsHome() {
  const root = Store.useRoot();
  const [create, setCreate] = usePj(false);
  const [intake, setIntake] = usePj(false);
  const [del, setDel] = usePj(null);
  const [sync, setSync] = usePj(false);
  const [importing, setImporting] = usePj(false);
  const [importNote, setImportNote] = usePj(null);
  const importInputRef = usePjR(null);

  const handleImport = async (file) => {
    if (!file) return;
    setImporting(true);
    setImportNote(null);
    try {
      const txt = await file.text();
      const pkg = JSON.parse(txt);
      await window.restoreWorkspace(pkg);
      setImportNote({ ok: true, msg: `Imported — ${pkg.root?.projects?.length || "?"} project(s) restored.` });
    } catch (e) {
      setImportNote({ ok: false, msg: "Import failed: " + (e.message || "unreadable file") });
    }
    setImporting(false);
  };
  const projects = root.projects;

  const open = (id) => { Store.projects.open(id); location.hash = "home"; };
  const byId = Object.fromEntries(projects.map((p) => [p.id, p]));
  const childrenOf = (id) => projects.filter((p) => p.parentId === id);
  // top-level = no parent, OR parent missing
  const tops = projects.filter((p) => !p.parentId || !byId[p.parentId]);
  const programs = tops.filter((p) => childrenOf(p.id).length > 0);
  const standalone = tops.filter((p) => childrenOf(p.id).length === 0);

  const allTasks = projects.flatMap((p) => p.tasks || []);
  const totalActive = allTasks.filter((t) => t.status === "inprogress").length;
  const totalRisks = projects.flatMap((p) => p.risks || []).filter((r) => r.status !== "closed").length;

  const cardProps = { projects, onOpen: open, onDelete: setDel };

  return (
    <div className="pj-root">
      <div className="pj-wrap">
        <header className="pj-head">
          <div className="between" style={{ marginBottom: 28 }}>
            <div className="brand" style={{ padding: 0 }}>
              <div className="brand-mark" style={{ width: 40, height: 40 }}><Icon name="layers" size={22} /></div>
              <div>
                <div className="brand-name" style={{ fontSize: 24 }}>Atlas</div>
                <div className="brand-sub">Project portfolio</div>
              </div>
            </div>
            <button className="btn no-print" onClick={() => setSync(true)}><Icon name="reset" size={15} /> Backup & sync</button>
          </div>
          <div className="pj-hero">
            <div>
              <h1 className="pj-title serif">Your projects</h1>
              <p className="pj-lead">Every initiative in one place — group related work under a major project, then open any one to manage its board, plan, people, risks and deliverables.</p>
            </div>
            <div className="pj-rollup">
              <div className="pj-roll"><span className="pj-roll-n serif">{projects.length}</span><span className="pj-roll-l">projects</span></div>
              <div className="pj-roll"><span className="pj-roll-n serif">{totalActive}</span><span className="pj-roll-l">active tasks</span></div>
              <div className="pj-roll"><span className="pj-roll-n serif" style={{ color: totalRisks ? "var(--t-red)" : "inherit" }}>{totalRisks}</span><span className="pj-roll-l">open risks</span></div>
            </div>
          </div>
        </header>

        {programs.map((prog) => {
          const kids = childrenOf(prog.id);
          const rolled = [prog, ...kids];
          const tot = rolled.reduce((a, p) => a + (p.tasks || []).length, 0);
          const dn = rolled.reduce((a, p) => a + (p.tasks || []).filter((t) => t.status === "done").length, 0);
          return (
            <section key={prog.id} className="pj-program" style={{ "--prog-c": "var(--t-" + (prog.color || "indigo") + ")" }}>
              <div className="pj-program-hd">
                <span className="pj-program-mark"><Icon name="layers" size={15} /></span>
                <div>
                  <div className="pj-program-name serif">{prog.meta?.project}</div>
                  <div className="pj-program-sub">Program · {kids.length} subproject{kids.length === 1 ? "" : "s"} · {tot ? Math.round(dn / tot * 100) : 0}% complete overall</div>
                </div>
              </div>
              <div className="pj-grid">
                <ProjectCard p={prog} {...cardProps} />
                {kids.map((k) => <ProjectCard key={k.id} p={k} {...cardProps} sub />)}
              </div>
            </section>
          );
        })}

        {standalone.length > 0 && (
          <section className="pj-program plain">
            {programs.length > 0 && <div className="pj-section-label eyebrow">Other projects</div>}
            <div className="pj-grid">
              {standalone.map((p) => <ProjectCard key={p.id} p={p} {...cardProps} />)}
            </div>
          </section>
        )}

        <div className="pj-grid" style={{ marginTop: standalone.length > 0 || programs.length > 0 ? 0 : 20 }}>
          <button className="pj-new" onClick={() => setCreate(true)}>
            <span className="pj-new-icon"><Icon name="plus" size={26} /></span>
            <span className="pj-new-label serif">New project</span>
            <span className="pj-new-sub">Blank, guided setup, or AI</span>
          </button>
          <button className="pj-new pj-import" onClick={() => importInputRef.current.click()} disabled={importing}>
            <span className="pj-new-icon">{importing ? <Icon name="reset" size={26} className="spin" /> : <Icon name="upload" size={26} />}</span>
            <span className="pj-new-label serif">{importing ? "Importing…" : "Import workspace"}</span>
            <span className="pj-new-sub">Load a previously exported file</span>
          </button>
          <input ref={importInputRef} type="file" accept="application/json,.json" hidden onChange={(e) => { if (e.target.files[0]) handleImport(e.target.files[0]); e.target.value = ""; }} />
        </div>
        {importNote && (
          <div className={"sync-note " + (importNote.ok ? "ok" : "bad")} style={{ marginTop: 14, maxWidth: 600 }}>
            <Icon name={importNote.ok ? "check" : "warn"} size={14} /> {importNote.msg}
          </div>
        )}

        {projects.length === 0 && (
          <div className="empty" style={{ marginTop: 20 }}>
            <div className="serif">No projects yet</div>
            Create your first project to get started.
          </div>
        )}
      </div>

      {create && <CreateProject projects={projects} onClose={() => setCreate(false)} onGuided={() => { setCreate(false); setIntake(true); }} />}
      {intake && <IntakeWizard onClose={() => { setIntake(false); location.hash = "home"; }} onDone={() => { setIntake(false); location.hash = "home"; }} />}
      {sync && <SyncPanel onClose={() => setSync(false)} />}
      {del && <UI.Confirm title="Delete project?" body={childrenOf(del.id).length ? `"${del.meta?.project}" will be deleted. Its ${childrenOf(del.id).length} subproject(s) become top-level projects.` : `"${del.meta?.project}" and all its tasks, risks and deliverables will be permanently removed.`} confirmLabel="Delete project" onConfirm={() => Store.projects.remove(del.id)} onClose={() => setDel(null)} />}
    </div>
  );
}

function CreateProject({ onClose, onGuided, projects }) {
  const [name, setName] = usePj("");
  const [color, setColor] = usePj("indigo");
  const [parent, setParent] = usePj("");
  const [method, setMethod] = usePj("guided");
  const tops = (projects || []).filter((p) => !p.parentId);
  const create = () => Store.projects.create(name.trim() || "Untitled project", "", color, parent || null);
  const go = () => {
    create();
    if (method === "guided") onGuided();
    else { location.hash = "home"; onClose(); }
  };
  const METHODS = [
    { id: "guided", icon: "scope", label: "Guided setup", sub: "Answer a few questions — we fill the sections", tag: "Recommended" },
    { id: "blank", icon: "plus", label: "Blank project", sub: "Start from an empty board" },
  ];
  return (
    <UI.Modal narrow onClose={onClose}>
      <div className="modal-hd">
        <div className="grow">
          <div className="cm-title" style={{ fontSize: 21 }}>New project</div>
          <div className="muted" style={{ fontSize: 13 }}>Name it, then choose how to set it up.</div>
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}><Icon name="x" /></button>
      </div>
      <div className="modal-bd">
        <div className="field-label">Project name</div>
        <input className="input" autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Data Warehouse Consolidation"
          onKeyDown={(e) => e.key === "Enter" && go()} style={{ marginBottom: 16 }} />
        <div className="row" style={{ gap: 12, marginBottom: 16, alignItems: "flex-start" }}>
          <div className="grow">
            <div className="field-label">Part of <span className="ai-opt">optional</span></div>
            <select className="select" value={parent} onChange={(e) => setParent(e.target.value)}>
              <option value="">— Top-level project —</option>
              {tops.map((p) => <option key={p.id} value={p.id}>{p.meta?.project}</option>)}
            </select>
          </div>
          <div>
            <div className="field-label">Colour</div>
            <div className="wrap" style={{ maxWidth: 150 }}>
              {PRJ_COLORS.map((c) => (
                <button key={c} className={"pj-swatch sm" + (color === c ? " on" : "")} style={{ background: "var(--t-" + c + ")" }} onClick={() => setColor(c)}>
                  {color === c && <Icon name="check" size={12} />}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="field-label">How do you want to set it up?</div>
        <div className="method-list">
          {METHODS.map((m) => (
            <button key={m.id} className={"method-card" + (method === m.id ? " on" : "")} onClick={() => setMethod(m.id)}>
              <span className="method-ico"><Icon name={m.icon} size={17} /></span>
              <span className="method-text">
                <span className="method-label">{m.label}{m.tag && <span className="method-tag">{m.tag}</span>}</span>
                <span className="method-sub">{m.sub}</span>
              </span>
              <span className={"method-radio" + (method === m.id ? " on" : "")}>{method === m.id && <Icon name="check" size={12} />}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="modal-ft">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <div className="grow" />
        <button className="btn btn-primary" onClick={go}>{method === "blank" ? "Create project" : "Continue"} <Icon name="chevR" size={14} /></button>
      </div>
    </UI.Modal>
  );
}

Object.assign(window, { ProjectsHome });
